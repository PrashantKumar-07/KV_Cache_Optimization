# TieredKV experiment log

**Preregistered early final-shared-root placement (3 October):** `results/hardware/early_shared_cpu_phase_v1/plan.json`. Allocate the final visible/hot shared buffer while placing each layer, then fill cold tails at unchanged global batched handoff. Full current-layer attention still receives original full KV. Targets measured649/1982 prefill+10.838% versus faithful Snap. Previous hot-only layerwise guard failure remains stopped. Require exact model/state/native payload/call replay, >=10% lower prefill versus frozenCPU point, strict GPUdecode/reserved<=2% worse, complete scoped512MiB and faithful prefill<=10%worse. Failed guard stops expansion; no holdout tuning.

**Preregistered prompt-boundary comparison pilot (3 October):** `results/hardware/prompt_boundary_comparison_v1/plan.json` was written before driver creation and GPU launch. Capacities come from row-byte algebra, not task scores: hot649/cold1982/exposed32 and faithful Snap prompt682 give341MiB initial KV backing in each arm. Native cold slots2046 fit the256MiB rounded pinned block. First require ordinary/candidate4K12 preservation; then measure fresh16K50 actual roots, GPU/pinned/CPU envelope, effective head/width geometry and cleanup. Width ratio limit1.075; each scoped active envelope<=512MiB. Failed pilot stops timing/quality expansion. Initial match is explicitly separate from unequal growing decode allocations and does not complete the full joint gate. No holdout tuning or baseline change.

**CPU phase boundary and score-fallback checkpoint (3 October):** **498 tests pass**. Two reproduced regressions exposed a shared batched-score crash on multi-token attention. A single-query shape guard restores the ordinary scorer fallback. Real GPU appends of2/32 tokens preserve exact logits, KV data, metadata and slot order across7 boundaries, then return to native single-token phases. Transformers-owned lazy capture hooks are initialized before ownership checks; both failed harness attempts are preserved. [Fallback proof](results/hardware/cpu_phase_append_fallback_v1/verified_fallback.json).

Three full-model4K/50 checks preserve all predictions/state/counters/native KV: exclusive promotion24832 rows, floor-above-capacity protection, and50 write-aware fallback steps. Native cold reclaim executes1152 times. [Boundary proof](results/hardware/cpu_phase_boundaries_v1/verified_boundaries.json). Fresh current-source4K/12 parity also passes; current-source16K/50 resource and geometry proofs pass, scoped memory433.33 MiB. Fresh current-source3ABBA speed passes: **58.76 to54.12 ms median,7.89% gain/4.64 ms saved**, p95 improves8.87%, TTFT+1.37%. All300 measured predictions/arm, state/counters/native KV and25 quiet observations match. All owned jobs are terminal. The multi-query guard preserves existing ordinary scoring fallback; it does not redesign multi-query attention accumulation. [Current proof](results/hardware/cpu_phase_score_guard_v1/verified_status.json), [figures](results/hardware/cpu_phase_score_guard_v1/figures/manifest.json). Historical speed evidence below remains tied to its archived source.

The ownership audit confirms resident KV roots272.25 MiB constant across51 candidate boundaries versus faithful SnapKV487–512 MiB, growing0.5 MiB/step. Attention width1024 differs on49/50 steps. No fixed SnapKV prompt capacity can equal that constant allocation vector throughout decode. This is an unresolved comparison-design requirement, not permission to claim equality or pad allocations. [Geometry proof](results/hardware/cpu_phase_geometry_v1/verified_geometry.json). Full P0/P1/P2 remains open; no new day estimate.

**CPU phase controller integration (3 October):** **496 tests pass**, including seven integration checks. Native canonical CPU promotion, append and demotion are integrated with pooled GPU metadata and native KV transfers. Recorded 4K/12 matches all predictions, 13 state/visibility snapshots, counters and native KV traffic. All 384 layer transitions use the new CPU phases, with zero fallback. [Correctness proof](results/hardware/cpu_phase_controller_v1/verified_correctness.json).

Fresh 16K/50 matches frozen output/state/counters/native KV and passes scoped memory: **433.33 MiB including owned pinned and CPU array roots**, versus ordinary541.08 MiB. Prefill peak is unchanged. Quiet preregistered3ABBA speed gate **passes: 58.93 to54.09 ms median (8.22%,4.84 ms saved)**, p95 improves8.76%, TTFT+1.40%. All300 measured predictions/arm and frozen state/counters/native KV match;25 GPU quiet observations pass. Longer-context8K/31.5K teacher parity and forced cold256-row slot-recycling parity pass, each50 steps with native CPU phases and no fallback. Free-generation parity passes on all12 reused development documents across six tasks: exact tokens, scores, state, trajectory, counters and native KV. **597 native CPU phase steps/19104 layer transitions** execute with no fallback;174 additional native cold reclaims occur. All owned jobs are terminal. Joint faithful-baseline/quality gates remain open. Candidate remains research-only. Production defaults are unchanged. Full P0/P1/P2 remains incomplete; the unsupported day estimate is withdrawn. This checkpoint supersedes earlier statements that controller integration is unimplemented.

Append-only summary; raw JSON remains authoritative. Earlier entries recorded
only the calendar date; their exact times are unknown and are not invented.
New entries use a completion timestamp in IST.

| Date/time (IST) | ID | Isolated hypothesis | Result | Decision/evidence |
|---|---|---|---|---|
| 2026-09-29 23:02 | CPU-COLD-PROBE (preregistered) | Keeping cold K/V in CPU DRAM, with unchanged token selection and fixed decode inputs, lowers actual GPU-resident KV bytes; copying only exposed/promoted rows back may have a measurable full-loop cost. Experimental subclass only; default path and STT bandwidth assumptions unchanged. | Pending: first 4K/5-step correctness pilot, then 16K/10-step paired ABBA if parity passes. Primary: exact policy counter/output parity and actual final GPU allocation; guards: no silent residency mismatch, report all measured latency/p95 and explicit H2D/D2H payload, do not claim a win unless quality and end-to-end costs pass the protocol. | Pending: `results/hardware/cpu_cold_probe_20260929.json` |
| 2026-09-29 23:05 | CPU-COLD-PROBE (outcome) | CPU-backed K/V preserves the fixed-stream policy/output while reducing GPU allocation. | 4K/5-step pilot passed parity. At 16K/10 steps, all four ABBA arms matched predicted tokens, promoted/demoted/paid/saved writes; final GPU allocation 14.628 vs 14.847 GB (−0.219 GB), decode peak 14.909 vs 15.136 GB, prefill peak equal at 18.594 GB. CPU ITL 122.19/99.59 vs GPU 79.35/78.33 ms; CPU p95 221.52/122.58 vs GPU 85.78/85.93 ms. Explicit payload per CPU arm: 66.58 MB H2D, 206.64 MB D2H including prompt placement. | **Trade-off, not promoted:** correctness/capacity check passes; latency gate fails. Pageable synchronous CPU DRAM is a surrogate, not STT-RAM; use grouped/overlapped transfers and a bounded prefill only after a measured architectural screen. Raw: `results/hardware/cpu_cold_pilot_4k_20260929.json` and `results/hardware/cpu_cold_probe_20260929.json`; the executed driver snapshot is preserved beside them. |
| 2026-09-29 23:10 | CPU-GATHER (preregistered) | CPU list-indexed cold K/V gathers dominate the physical-tier probe's extra policy time; `torch.index_select` can preserve rows while reducing host gather overhead. | Descriptive 16K/10-step cProfile shows 2,048 cold-gather calls taking 0.983 s on CPU versus 0.072 s on GPU, and CPU append/cat also costs 0.844 s; rankings are profiling-perturbed. Isolated 32-row random CPU gather: 0.0891 vs 0.00722 ms/call. Test only an opt-in subclass on the same 16K/10-step fixed stream, CPU/fast/fast/CPU, one warm-up per arm. | Advance only if predicted tokens, policy/write counters, cold bytes, transfer bytes and memory match; median full-loop ITL improves ≥5% in both pairs and p95 does not worsen >2%. Otherwise reject this local change; no default policy change. |
| 2026-09-29 23:24 | CPU-GATHER (10-step outcome) | Native CPU index-select improves the opt-in physical-tier probe. | 4K/5-step parity passed. At 16K/10 steps, CPU/fast/fast/CPU ITL was 104.516/94.143/94.987/104.286 ms: paired improvements 9.93% and 8.92%; p95 improved in both pairs. Predicted tokens, cache/write counters, 206.64 MB cold payload, 66.58 MB H2D, 206.64 MB D2H, prefill/decode peaks and final GPU allocation matched. | Passes the preregistered small gate but remains opt-in pending longer-decode/edge-case stress; does not close the gap to GPU-resident TieredKV or faithful SnapKV. Raw: `results/hardware/cpu_gather_pilot_4k_20260929.json`, `cpu_gather_abba_16k_20260929.json`. |
| 2026-09-29 23:26 | CPU-GATHER (50-step stress) | Faster host gather remains correct and helpful after longer decode. | On a fixed 16K/50-step teacher stream, three paired CPU/fast blocks improved median ITL 101.745→94.864, 100.892→92.152, and 101.160→92.896 ms (6.8%, 8.7%, 8.2%); p95 improved in all three. All six arms matched predicted tokens, demotion/promotion/write counters, 315.62 MB H2D payload, 212.34 MB D2H payload, prefill/decode peaks and final GPU allocation. | Retain the native gather **only in the opt-in CPU-DRAM probe**. It passes the local speed/parity stress but remains slower than GPU-resident TieredKV and SnapKV, has no physical STT device or multi-request quality result, and does not solve prefill peak. Raw: `results/hardware/cpu_gather_stress_16k_50_20260929.json`. |
| 2026-09-29 23:29 | CPU-RESERVE-SCREEN | Preallocating host K/V slots avoids append `torch.cat` without worsening the dominant gather. | Isolated H=8, N=1536, D=128 bf16 append: `cat` 0.080 ms versus reserved `copy_` 0.007 ms. But the active `[H,N,D]` view into a 2,081-row reserved buffer is noncontiguous; a 32-row `index_select` rose from 0.003 to 0.086 ms (28×) in the same process. The frequent read path would pay more than the append saves. | Reject this buffer layout at the cheap screen; no live code edit. A future design needs contiguous active rows or token/page-major storage that keeps the read path fast. These microbenchmarks are diagnostic, not end-to-end timing. |
| 2026-09-29 23:31 | CPU-RESERVE-RECHECK (supersedes prior screen decision) | The first single-run append timing understated real host `cat` cost; compare both gains and losses across alternating blocks before rejecting. | Five blocks at identical H=8,N=1536,D=128 bf16: median append `cat` 0.629 ms versus reserved `copy_` 0.0079 ms, while 32-row gather is 0.0033 ms contiguous versus 0.0868 ms reserved view. With ~32 appends and ~102 gathers per 16K decode step in the profiled workload, this gives a rough net *positive* screen, but operation counts/costs overlap and this is not an end-to-end prediction. Raw: `results/hardware/cpu_reserved_layout_screen_20260929.json`. | Reopen as an opt-in candidate, not a default change. Test exact fixed-stream parity, explicit transfer bytes, CPU reserved capacity, GPU allocation, median/p95 full-loop ITL. Require ≥5% paired median gain and p95 no worse than +2%; reject if layout causes correctness or memory blowup. |
| 2026-09-29 23:33 | CPU-RESERVE-ABBA (outcome) | Preallocated `[H,capacity,D]` host buffer pays for noncontiguous cold-row reads. | 4K/5-step parity passed but single-run ITL regressed 109.32→113.95 ms. At 16K/10 steps, CPU-fast/reserved/reserved/fast ITL was 91.767/99.162/99.394/91.618 ms: reserved was ~8% slower in both pairs, and one p95 pair worsened >2%. Predicted tokens, policy/write counters, transfer payload and GPU allocation matched. Reserved host K/V capacity was 272.76 MB versus 206.64 MB actual cold payload. Raw: `results/hardware/cpu_reserved_pilot_4k_20260929.json`, `cpu_reserved_abba_16k_20260929.json`. | **Reject**; remove the failed candidate from the active probe and preserve its exact executed source in `results/hardware/probe_cpu_cold_reserved_executed_20260929.py`. No default policy or STT bandwidth change. This is direct evidence that append-only microbenchmarks cannot justify the layout. |
| 2026-09-29 23:36 | SDPA-SCORE (preregistered) | Decode's eager attention may be avoidable if a small separate computation reconstructs the exact attention probabilities needed by the policy from the current query and visible keys. | First compare hook-captured rotary query plus returned KV against eager attention weights at 1K/one token, including per-layer maximum absolute error and policy-relevant head-mean score difference. If parity fails, stop. If it passes, benchmark an opt-in SDPA-plus-recomputed-scores path against eager on one fixed 16K/50-token stream, with identical generated predictions/cache decisions as the correctness gate; require ≥5% whole-loop median gain and p95 no worse than +2%. | Pending. Keep the default and source-matched baselines unchanged. A same-source performance win would still require task quality and second-model checks before promotion. |
| 2026-09-29 23:39 | SDPA-SCORE (outcome) | Exact score reconstruction alone is insufficient if switching the model's attention kernel changes downstream cache decisions. | On the same 1K/one-token eager forward, captured-query/returned-key softmax reproduced every layer's eager attention weights exactly (max absolute error 0). But an opt-in 4K/five-step SDPA-plus-recomputed-score pilot had the same five predicted token IDs yet a different final cache-state digest and 1,213 versus 1,211 paid writes (saved writes 1,955 versus 1,957). Single-run ITL was 87.842 versus 84.531 ms/token, a descriptive regression. | **Reject before 16K scale-up:** exact placement parity gate failed and no speed signal appeared. Restore the benchmark's normal eager path and remove the failed candidate from active experiments. Raw: `results/decode_overhead/sdpa_score_parity_1k_20260929.json`, `sdpa_scores_pilot_4k_20260929.json`; exact executed driver/profile snapshots preserved beside them. |
| 2026-09-24 | CTRL-V3 | Correct positions/accounting/visibility/provenance yield a trustworthy control | Corrected six-task control and full-loop benchmark | Frozen: `results/remediation_v3/` |
| 2026-09-25 | SHADOW-FULL | Inclusive backups reduce paid writes without material quality loss | 88.1% normalized write reduction; quality -0.20, CI [-0.47,+0.07] | Retain; hardware claim unverified: `results/shadow_ablation_full/report.json` |
| 2026-09-26 | QUERY-FULL | Current-query selection beats access-time selection | +4.35, CI [+2.12,+6.61], but latency and writes regress | Trade-off: `results/query_selection_full/report.json` |
| 2026-09-26 | QUERY-UPSTREAM | Query selector beats closer upstream SnapKV selector | -0.34, CI [-2.13,+1.56]; not byte matched | Inconclusive: `results/snapkv_adapter_full/comparison.json` |
| 2026-09-26 | PAGE-PROBE | Compact page bounds screen cold keys sufficiently | k8 recall 21.6%; k32 recall 59.9% while selecting 33.0% | Reject current settings as deployable: `results/page_recall/report.json` |
| 2026-09-27 | FP8-COLD | FP8 improves memory/latency/quality frontier | Cold bytes halve; prefill peak unchanged; quality/latency gain unproven | Pause: `results/fp8_cold_pilot/` |
| 2026-09-27 | PREFILL-BUG | Initial chunked prefill preserves all retained context | Only exposed cold rows carried between chunks | Reject/fixed with `resident_tuple()`: `pilot.json`, `pilot_v2.json` |
| 2026-09-27 | PREFILL-2048 | 2,048 chunks cut peak ≥10% with TTFT <10% worse | Peak -13.3%; TTFT +7.9%; 15-example quality +0.18, CI [-3.58,+4.82] | Inconclusive quality; keep opt-in: `results/bounded_prefill/quality_2048_report.json` |
| 2026-09-27 | POLICY-IDX | Carry exposed slow indices and batch singleton hysteresis without changing decisions | Corrected three-block ABBA: 16K median 106.17 vs 120.48 ms (-11.9%), p95 129.53 vs 180.36; 8K median 106.41 vs 120.50 ms (-11.7%), p95 142.60 vs 180.04; 15/15 matched predictions against exact control | Retain; one-model/prompt limit: `results/decode_overhead/fastpath_abba_{8k,16k}_v3.json` |
| 2026-09-27 | ADMIT-4 | Cap residency promotion at 4 while keeping 32 slow rows visible to attention | 16K screen: 1,934 vs 15,904 promotions, 1,316 vs 2,391 paid writes; 15-example quality -0.31, CI [-1.56,+0.94], GovReport -0.92 | Reject as new default; keep opt-in diagnostic: `results/promotion_budget/report4_15.json` |
| 2026-09-27 | STT-COMPACT | Select survivors before appending slow-tier victims, avoiding one full temporary copy | Three-block 16K ABBA: median ITL 107.24 vs 106.89 ms control; p95 145.46 vs 135.38 ms; decode peak 7.45 MB lower | Reject and remove experimental path: `results/decode_overhead/deferred_stt_abba_16k.json` |
| 2026-09-27 | SLOT-PROBE | Recycling freed slow-tier physical slots avoids repeated full K/V copies | Exact final K/V parity; 32-layer isolated ABBA update+32-row read median 0.937 vs 2.037 ms (-54.0%); peak allocation 0.587 vs 0.600 GB | Full-capacity case is outside the 16-step control workload; no end-to-end benefit established: `results/decode_overhead/slot_storage_probe.json` |
| 2026-09-27 | SLOT-REALITY | Guarded slot recycling improves current 8K/16K real-policy decode | The path never activated: prefill filled 1,536 of 2,048 rows and only 16 decode steps ran. 8K and 16K ABBA timings fluctuated without a valid treatment contrast | Reject rollout and remove candidate; raw invalid-for-effect timings retained: `results/decode_overhead/slot_recycling_abba_{8k,16k}.json` |
| 2026-09-27 | RESERVE-APPEND | Preallocate all 2,048 slow rows to speed the common 1,536→1,552 append regime | Exact final K/V; isolated 32-layer ABBA median 1.424 vs 1.191 ms/step (+19.5%); peak 0.472 vs 0.413 GB (+58.7 MB) | Reject; no production change: `results/decode_overhead/reserved_append_probe.json` |
| 2026-09-27 | POLICY-PROFILE | Find active decode costs before another optimization | One 8K/16-token cProfile: 512 `evict_and_demote` calls total 0.751 s cumulative CPU, visible assembly 0.249 s, score update 0.153 s; PyTorch trace shows many kernel launches/transfers | Prioritize demotion decision/synchronization; descriptive profile, not a speed claim: `results/decode_overhead/policy_cprofile_8k_summary.json` |
| 2026-09-27 23:49 | FINITE-COUNT | Count eligible demotion victims from the host mask instead of synchronizing a GPU finite-score reduction | 8K three-block screen favored shortcut but p95 worsened; 16K pooled median regressed and paired blocks disagreed | Reject and remove experimental branch; historical raw timing: `results/decode_overhead/finite_victims_abba_{8k,16k}.json` |
| 2026-09-28 00:03 | BACKUP-BATCH | Batch updates when shadow backups are reactivated during demotion | Final-source ABBA: 8K median 109.22→98.13 ms/token (−10.2%), p95 174.44→152.04; 16K median 108.30→97.80 (−9.7%), p95 152.40→126.80; 2/3 paired blocks favor batch at each length; 15/15 real-prompt capped generations and write counters match | Retain as default; one-model/prompt timing limit: `results/decode_overhead/batch_backup_abba_{8k,16k}_final.json`, `batch_backup_parity_15_final.json` |
| 2026-09-28 00:12 | HOST-XFER | Capacity-matched physical-tier feasibility depends on transfer granularity and PCIe link | Pinned local-NUMA CPU-DRAM↔L40S Gen4×16: 4 MiB H2D in 1,024×4 KiB copies 9.38 ms, 32×128 KiB copies 0.299 ms, one copy 0.171 ms; 256 MiB copy 10.02 ms (26.8 GB/s). Two 1Gb STT chips have only 5.4 GB/s ideal aggregate read/write by vendor spec | CPU/PCIe surrogate only; no physical STT latency/energy claim: `results/hardware/host_transfer_gpu0_v3.json`, `host_transfer_report.json` |
| 2026-09-28 00:16 | DROP-CHARGE | Discarding a cold row requires no victim-payload read in the modeled policy | Removed phantom `drop_cost` read. Corrected equal-VRAM control had zero drops, so its old modeled totals are unchanged; equal-total GovReport had 25,920 dropped layer-rows, giving exact old-report corrections of −2.123 ms and −0.001699 J in modeled totals | Fix retained; old raw files preserved with arithmetic correction: `results/hardware/drop_cost_correction.json` |
| 2026-09-28 18:54 | ENDURANCE-SPEC | Logical saved write bytes predict candidate-device lifetime | Vendor datasheet defines a cycle as an access to one 1,024-bit (x8) or 2,048-bit (x16) page, with 10^10 cycles per page; current simulator lacks physical page-address/read traces | Hypothesis unsupported; require physical per-page access trace before lifetime claim: [EMD4E001GAS2 datasheet](https://www.everspin.com/sites/default/files/EMD4E001GAS2_1.3_10102022.pdf) |
| 2026-09-28 18:58 | SNAP-BYTES | Equal token budgets approximate equal KV payload bytes against expanded-head SnapKV | SnapKV 524,288 bytes/row vs TieredKV 131,072; 134/135 SnapKV final payloads exceed TieredKV's configured 384 MiB steady resident ceiling | Reject equal-byte interpretation; require matched measured bytes and attended width: `results/baseline_fidelity/snapkv_byte_comparison.json` |
| 2026-09-28 18:59 | BMatch-PILOT (preregistered) | At 512 MiB prompt KV payload and 1,024 attended rows, query-aware TieredKV may match the upstream-selector SnapKV adapter's quality | Same current Mistral/runtime/GPU0, first 2 Qasper and 2 GovReport examples, greedy decoding; TieredKV bf16 fast=992/cold=3104/expose=32; SnapKV bf16 expanded heads/capacity=1024/window=32. Both nominal prompt KV ceilings=512 MiB; decode bytes differ as SnapKV grows. Primary pilot: paired task-balanced score; guards: prediction IDs, actual final bytes, time, no OOM. No statistical advancement from 4 examples | Run both arms, record source/dataset hashes; reject any equal-byte superiority claim from pilot alone |
| 2026-09-28 19:09 | BMatch-PILOT (outcome) | Configured prompt-byte ceiling and attention-width match might reveal a favorable query-aware TieredKV quality signal | Eager/eager same-runtime paired 2 Qasper + 2 GovReport: Qasper 13.12 vs 30.62 SnapKV; GovReport 37.31 vs 32.08; task-balanced paired difference −6.13. TieredKV measured final resident KV bytes were only 68.5–83.1% of SnapKV final payload. All four TieredKV predictions reproduced exactly after byte instrumentation | No-go for this configuration as a quality win; unequal measured bytes and 4 examples prevent an equal-byte claim: `results/baseline_fidelity/matched_pilot_report.json` |
| 2026-09-28 19:10 | EXPOSE-128 (preregistered) | Reallocating 96 fast attended rows to current-query-selected cold rows may repair the Qasper deficit at fixed 4,096 resident-row and 1,024 attended-row ceilings | Same current Mistral/GPU0/eager/query selector, first 2 Qasper examples; compare 896 fast+3200 cold+128 exposed to 992+3104+32. Primary pilot target: at least +5 Qasper score points; guards: same sample IDs, measured final KV bytes no higher than 512 MiB, no OOM; compare elapsed descriptively because output lengths vary. No statistical claim from 2 examples | Run candidate; do not promote without broader paired quality and latency gates |
| 2026-09-28 19:12 | EXPOSE-128 (outcome) | Reallocating attention width to 128 cold rows improves Qasper | Mean exposure rose from 32 to 128 with zero starvation, but the paired two-example Qasper score fell 13.12→10.82 (differences −4.62, 0); measured final resident KV bytes stayed under 512 MiB | Reject this allocation as a quality improvement; focus on prompt selection instead of widening exposure: `results/baseline_fidelity/expose128_report.json` |
| 2026-09-28 19:13 | REAL-Q-PREFILL (preregistered) | Actual rotary prompt queries with a causal observation mask improve initial TieredKV placement over its K-as-Q proxy | Opt-in Q capture for only the last 128 prompt positions, same 992 fast/3104 cold/32 exposed Mistral eager GPU0, first 2 Qasper examples and same sample IDs. Primary screen: +5 task points versus 13.12; guards: no cache invariant failure, final resident KV ≤512 MiB, full-prompt logits unchanged, measured peak/TTFT recorded before any promotion. Failing screen is rejected; 2 examples cannot establish quality generality | Implement tiny-model/parity check, run pilot, preserve old default |
| 2026-09-28 19:28 | REAL-Q-PREFILL (stress screen) | Actual-query placement quality gain survives other tasks and boundaries | 27 paired examples across six tasks: task-balanced +4.45, conditional 95% CI [+0.81,+8.86]; Qasper +19.65, GovReport −1.72; 4/27 examples regress. Logical paid demotion writes fell 109,660→60,643 (−44.7%). Single-run median prefill time rose 5.5–11.4% and peak allocation rose 54–506 MB by task before GQA optimization. Tiny-model tests cover causal future masking, one token, at/over capacity, full logits, K/V/position integrity | Keep opt-in trade-off; do not promote until full quality, prefill overhead, decode latency, and held-out stress gates pass: `results/baseline_fidelity/real_q_prefill_six_task_report.json` |
| 2026-09-28 19:29 | REAL-Q-CHUNK (preregistered) | Avoiding repeated GQA key storage and scoring prompt queries in 16-row chunks reduces actual-query prefill peak without changing selected KV | Same 27-example actual-query arm is the semantic control; first test CPU score equality and 2 Qasper predictions/write counters, then paired peak/TTFT. Target exact prediction/position/counter parity, ≥100 MB lower prefill peak on Qasper, and no >10% TTFT regression against proxy. If parity fails, reject optimization | Implement only in opt-in actual-query score path; preserve default |
| 2026-09-28 19:37 | REAL-Q-GQA (outcome) | GQA broadcast with one observation-query pass reduces duplicate-key overhead without changing quality | All 27 predictions, scores, final resident bytes and cache counters exactly matched expanded-head actual-query scoring. Separate-process descriptive median prefill peaks fell 57–473 MB and prefill times fell 0.3–3.7% by task; against K-as-Q prefill times still rose 4–7%. Six-task paired prefill benchmark is still needed for a timing claim | Retain optimized opt-in path; no default promotion or latency claim: `results/baseline_fidelity/real_q_broadcast_{short5,gov2}.json` |
| 2026-09-28 19:40 | REAL-Q-PREFILL-ABBA | The optimized actual-query selector fits the ≤10% prefill-time guard on fixed prompts | Same-process three-block ABBA on Qasper 4,895-token and NarrativeQA 31,500-token first prompts: prefill+placement +7.53% and +5.07% versus K-as-Q; peak allocated +16 MiB and +32 MiB, respectively; all blocks agree on timing direction | Guard passes on two prompts, but it is still a measured latency/peak regression and decode latency remains unmeasured: `results/baseline_fidelity/real_q_prefill_abba_report.json` |
| 2026-09-28 19:43 | REAL-Q-FULL (preregistered) | The optimized actual-query placement gain and write reduction survive the frozen 135-example six-task sample | Same Mistral bf16/GPU0/current source/seed0, Qasper/MultiFieldQA/NarrativeQA/HotpotQA/TriviaQA 25 each and GovReport 10, 992 fast+3104 cold+32 exposed, eager decode/SDPA prefill, query selector fixed. Arms differ only in real-query prefill. Primary: paired task-balanced score, bootstrap lower bound >0; guards: per-task regressions reported, paid writes, prefill time/peak, source/dataset/sample identity. This is existing selected evaluation data, not held-out. No promotion without full-loop latency and stress gates | Run control and candidate sequentially, preserve raw checkpoints |
| 2026-09-28 19:46 | NOVELTY-AUDIT | Tiering or redundant-write avoidance alone can support a new systems claim | DirectKV (OSDI 2026), KVDrive (2026 preprint), TensorRT-LLM host offloading, and a 2026 Harvard KV flash write-budget seminar cover overlapping mechanisms. They do not validate this prototype's physical STT claims | Reject generic tiering/write-saving novelty; require a distinct measured joint quality/latency/write-budget policy and faithful comparisons: `RESEARCH_ROADMAP.md` |
| 2026-09-28 20:21 | REAL-Q-FULL (outcome) | Actual-query prompt placement improves the frozen 135-example six-task quality score | Paired task-balanced +2.34, conditional 95% CI [+0.30,+4.42]; Qasper +5.45, NarrativeQA +2.02, MultiFieldQA −2.22, HotpotQA +4.09, TriviaQA +2.40, GovReport +2.29. 19/135 examples regress. Logical paid demotion writes 581,067→298,543 (−48.6%). Source/dataset/IDs/scores/bytes independently verified. An unrelated Ollama job overlapped candidate Qasper/NarrativeQA; full-run timing/peak comparisons are invalid | Quality and logical-write gates pass on selected samples; keep opt-in until held-out, adversarial, full-loop latency, baseline fidelity, and physical-tier gates: `results/baseline_fidelity/real_q_prefill_full_report.json` |
| 2026-09-28 | REAL-Q-LOOP (outcome) | Actual-query placement may improve complete-loop decode enough to offset scoring overhead | Three same-process ABBA blocks, 16K real-text prompt and 50 fixed decode tokens, 992 fast/3104 cold: median ITL −1.23%, p95 ITL −1.21%; median TTFT +6.22%; prefill peak +0.199 GB (+1.07%). All three blocks agree. GPU0 process check showed only the benchmark; GPU1 had another job. One prompt/model and no throughput measurement | Keep as opt-in quality/prefill trade-off. Decode change is small and does not close the larger SnapKV latency gap: `results/baseline_fidelity/real_q_full_loop_abba_report.json` |
| 2026-09-28 | REAL-Q-LRU-PILOT (preregistered) | Actual-query prompt placement retains a quality gain with cheap access-time decode, avoiding the full cold-key query scan | Same current Mistral bf16/GPU0/eager and 992 fast/3104 cold/32 exposed, first five examples each of Qasper, NarrativeQA, and GovReport; arms differ only in actual-query versus K-proxy prefill. Primary: paired task-balanced score. Guards: sample IDs, measured resident KV bytes, full-loop latency separately, and individual regressions. Advance only if gain is positive without severe task regression; five examples per task are a screen, not a publishable estimate | Run both arms; keep query-aware full-scan results distinct |
| 2026-09-28 21:46 | REAL-Q-LRU-PILOT (outcome) | Actual-query placement helps even with access-time decode | Five examples each: Qasper 4.20→15.65 (+11.46 unrounded), NarrativeQA 18.53→20.03 (+1.50), GovReport 27.96→28.17 (+0.21); task-balanced +4.39. Four of 15 examples regress, none in Qasper. Source/config/sample IDs matched except the prefill flag | Advance to frozen 135-example screen; no significance/generalization claim from 15 examples: `results/baseline_fidelity/real_q_lru_{control,candidate}_15.json` |
| 2026-09-28 21:46 | REAL-Q-LRU-FULL (preregistered) | Actual-query placement improves quality and logical paid writes under cheaper access-time decode across the frozen six-task sample | Same source/model/GPU0/seed0/data, 992 fast+3104 cold+32 exposed, first 25 Qasper/MultiFieldQA/NarrativeQA/HotpotQA/TriviaQA and first 10 GovReport. Primary task-balanced paired score and conditional bootstrap interval; guards: per-task regressions, sample IDs, actual resident bytes, paid writes. Compare full-loop latency separately with paired ABBA; selected sample is not held-out | Run both arms; reject deployment/publication claim if task losses or latency violate gates |
| 2026-09-28 | REAL-Q-LRU-FULL (outcome) | Actual-query placement improves selected-sample quality with access-time decode | Verified 135 examples: task-balanced +5.20, conditional paired 95% CI [+2.84,+7.69]. Qasper +8.97, NarrativeQA +4.29, MultiFieldQA +6.34, HotpotQA +10.98, TriviaQA +1.98; GovReport −1.35. 22/135 examples regress. Logical paid demotion writes 359,473→292,996 (−18.49%). Measured resident bytes stayed ≤512 MiB; all IDs, dataset hashes, scores and runtime/source configuration checked | Significant selected-sample gain triggers stress audit; keep opt-in due GovReport and individual failures: `results/baseline_fidelity/real_q_lru_full_report.json` |
| 2026-09-28 | REAL-Q-LRU-LOOP (outcome) | Access-time decode can retain the placement gain without a large full-loop decode penalty | Same-process 16K/50-token three-block ABBA: median block ITL −0.50%, p95 −0.13%; one block median +0.21%, so decode is effectively neutral. Median TTFT +6.89%; prefill peak +0.199 GB (+1.07%); decode peak approximately unchanged. One prompt/model, no serving throughput | Continue as quality/write trade-off, not all-metric dominance: `results/baseline_fidelity/real_q_lru_full_loop_abba_report.json` |
| 2026-09-28 | REAL-Q-LRU-STRESS (triggered audit) | The significant aggregate gain is stable across prompt/generation boundaries and has no severe failures | Descriptive bins: prompt ≤4K +5.23 (8/39 regress), 4K–16K +6.16 (11/81), >16K +6.50 (3/15); short outputs ≤32 +5.94 (11/101), 33–128 +8.91 (5/24), >128 −1.35 (6/10, all GovReport). Six examples drop >10 points; two previously positive scores become zero. Worst TriviaQA −60 (100→40) stems from an added incorrect answer qualifier. Cache/prefill boundary tests 40/40 pass. OOD, adversarial, temporal, concurrency, physical-tier and multi-model stress were not run | Do not advance to default or tune hyperparameters; prioritize robust long-generation retrieval and severe-regression protection, then rerun paired quality/latency: `results/baseline_fidelity/real_q_lru_stress_report.json` |
| 2026-09-28 | LATE-QUERY-32 (preregistered) | Switching from access-time cold exposure to current-query exposure after 32 generated tokens repairs long-output GovReport loss | Same actual-query prompt placement and 992/3104/32 cache; first 10 GovReport examples. Compare to fixed access-time candidate. Primary: paired GovReport score improves by ≥1.35 points (recovers control), with no new severe >10-point losses. Guards: sample IDs, resident bytes ≤512 MiB, paid writes and elapsed only descriptive; if promising, require full 135-example and paired timing before adoption. No claim from one task | Add opt-in decode-step gate and run candidate |
| 2026-09-28 | LATE-QUERY-32 (outcome) | Query selection after 32 steps repairs long-output quality without defeating other goals | GovReport 27.00→30.98 (+3.98), one of ten regressions, no new >10-point drop; paid demotion writes 96,890→107,317 (+10.8%). Aggregate wall time/generated token 94.05→136.54 ms (+45.2%); outputs differ in length, and runs were sequential rather than ABBA, so this is a descriptive but large latency warning. Median prefill peak unchanged | Reject as practical fix and remove hook; seek bounded retrieval that avoids full cold-key scans: `results/baseline_fidelity/late_query32_gov10.json` |
| 2026-09-28 | PAGE-L2-BOUND (preregistered) | A per-head page mean plus maximum L2 residual yields better current-query top-32 retrieval than axis-aligned min/max at lower metadata bytes | Same frozen Mistral 16K prompt/20 decode steps, 16-row pages, 8 and 32 page budgets, access-time trajectory. Primary top-32 recall and oracle attention-mass fraction; guards: mathematical upper-bound check, identical trajectory/IDs and candidate row fraction, fp32 summary bytes. Candidate summaries rebuilt from full keys in this offline diagnostic, so even a gain cannot support latency/deployability | Run paired bound probes; reject if no material recall or mass gain at equal candidate rows |
| 2026-09-28 22:30 | PAGE-L2-BOUND (outcome) | L2 summaries improve page ranking | Eight pages: top-32 recall 21.56% box vs 20.07% L2; oracle mass 40.73% vs 33.09%. Thirty-two pages: recall 59.92% vs 54.81%, mass 80.37% vs 72.00%. L2 summary bytes across 32 layers 12.23 MiB vs box 24.27 MiB, candidate fraction ~equal. Both satisfy upper-bound unit checks | Reject as retrieval-quality fix; archive diagnostic: `results/page_recall/p16_k{8,32}_{box_recheck,l2}.json` |
| 2026-09-28 | PAGE-CENTROID (preregistered) | Query-dot-page-centroid ranking improves top-32 retrieval with fewer summary bytes than box/L2 bounds | Same prompt/trajectory and 16-row pages, 8 and 32 page budgets. Primary oracle top-32 recall and attention-mass fraction at equal candidate rows; summary fp32 center bytes. This is a heuristic, not an upper bound; if it loses to box at both budgets, reject. No latency or serving claim from offline rebuilt summaries | Run paired probe and verify trajectory equality |
| 2026-09-28 22:32 | PAGE-CENTROID (outcome) | Centroid ranking improves offline candidate retrieval | All 640 layer-step trajectory records match the box control. Eight pages: top-32 recall 21.56%→41.41%, oracle mass 40.73%→55.09%; 32 pages: 59.92%→72.35%, mass 80.37%→82.54%. Candidate row fraction ~8.24%/33.03%; fp32 summary bytes across 32 layers 24.27→12.14 MiB | Advance to candidate-only reranking diagnostic; no deployable quality/latency claim because summaries rebuilt from full keys and reranking used oracle denominators: `results/page_recall/p16_k{8,32}_{box_recheck,centroid}.json` |
| 2026-09-28 | PAGE-CENTROID-LOCAL (preregistered) | Centroid candidate gains survive reranking using only fast and selected candidate K, without full slow-key softmax denominators | Same 16K/20-step trajectory and 8/32-page budgets. Compare local reranker top-32 recall/mass against optimistic global-denominator reranker, keeping selected pages fixed. A drop >5 points in oracle mass or recall blocks the next implementation step | Add local rerank to diagnostic; still no persistent summaries or serving quality |
| 2026-09-28 22:34 | PAGE-CENTROID-LOCAL (outcome) | Candidate-only reranking preserves centroid candidate coverage | Eight pages: optimistic/local top-32 recall both 41.41%, oracle mass 55.09%/55.08%. Thirty-two pages: recall 72.35%/72.33%, mass 82.54%/82.53%. All 640 trajectory and page candidate records reproduced exactly | Advance to small end-to-end quality screen, not latency/physical-tier claim: `results/page_recall/centroid_report.json` |
| 2026-09-28 | PAGE-CENTROID-QUALITY (preregistered) | Selecting query-ranked cold rows from 32 centroid-ranked 16-row pages retains most full-query quality on first two Qasper and GovReport requests | Actual-query prompt placement fixed, 992/3104/32 cache, same model/GPU0/data. Compare first-two scores, sample IDs, writes and resident bytes with archived LRU and full-query arms. Screen target: improve task-balanced quality over LRU, with no >10-point regression; two examples/task are not generalizable. Rebuilt centroids read the full cold pool; no latency claim | Run opt-in centroid selector; reject or broaden based on score and invariants |
| 2026-09-28 22:39 | PAGE-CENTROID-QUALITY (outcome) | Centroid page selection improves the tiny task-balanced score over LRU without severe individual drops | First two Qasper scores LRU 28.03, centroid 53.97, full query 53.97; first two GovReport LRU 29.51, centroid 27.09, full query 35.59. No >10-point centroid-vs-LRU drop; measured resident KV 420–465 MiB under 512 MiB. Qasper mean matches full-query but only one of two predictions is exact | Advance only GovReport to ten-example stress; no latency/deployability claim: `results/page_recall/centroid_quality_2x2.json` |
| 2026-09-28 | PAGE-CENTROID-GOV10 (preregistered) | The centroid candidate avoids the long-output degradation seen in the 2-example screen | Same first 10 GovReport examples and actual-query prefill, compare against archived LRU and full-query runs. Primary paired score versus LRU; gate ≥0 improvement and no new >10-point drops. Guards: sample IDs, resident bytes, logical paid writes; elapsed is descriptive because output lengths differ and runs are sequential. Reject broader run if it fails | Run ten-example GovReport stress |
| 2026-09-28 22:52 | PAGE-CENTROID-GOV10 (outcome) | Centroid candidate repairs long-output quality | GovReport LRU 27.00, centroid 29.33 (+2.33), full query 32.97; four of ten centroid-vs-LRU regressions, none >10 points. Paid writes 96,890→104,832 (+8.2%, below full query 121,762). Resident KV ≤469.5 MiB. Descriptive wall time/output token 94.05→251.01 ms, worse even than full query 142.68; sequential runs and output lengths differ, but Python page-loop cost is severe | Quality gate passes; current implementation is rejected for latency. Test vectorized centroid summary for exact candidate parity and paired speed before broader quality: `results/page_recall/centroid_quality_gov10.json` |
| 2026-09-28 | PAGE-CENTROID-VECTOR (preregistered) | Vectorized 16-row page sums remove per-page Python/kernel-launch overhead without changing selected candidates | Same float32 centroid ranking, including partial final page. First require exact candidate row parity on random and recorded 16K trajectory; then measure same-source 16K/50-step full-loop latency, comparing vectorized centroid against current loop and full query. Latency target <143 ms/token; no quality claim without matching predictions. This still reads all cold K to build summaries | Implement only centroid diagnostic path; keep default unaffected |
| 2026-09-28 22:56 | PAGE-CENTROID-VECTOR (outcome) | Vectorization makes centroid selection faster than full-query selection | Candidate rows match loop in 70 random cases and all 640 frozen layer-step records. One same-process ABBA pilot: median full-loop ITL query 142.95 vs vector centroid 150.80 ms/token (+5.49%); TTFT 2168.57 vs 2210.84 ms (+1.95%); prefill/decode peaks effectively equal. Earlier loop GovReport 251.01 ms/output token was descriptive on a different workload, so no paired loop-vs-vector speed ratio is claimed. The <143 ms target fails | Reject vectorized full-key rebuild as a latency solution; retain opt-in research diagnostic only. Persistent page summaries with stable IDs would require a separate architecture and proof: `results/page_recall/centroid_latency_abba_pilot.json` |
| 2026-09-28 23:00 | POSITION-PAGE (preregistered) | Stable absolute-position 16-token page IDs retain centroid retrieval quality despite slow-row compaction | Same frozen 16K prompt/20 decode steps/32 layers and 8/32-page budgets. Compare with row-page centroid on exactly the same access-time trajectory; primary top-32 recall, oracle mass, candidate-row fraction, page count and metadata bytes. Gate: within 5 percentage points recall and mass at a comparable candidate fraction, with no fewer than 32 candidates where at least 32 live rows exist. This is offline grouping, not incremental maintenance or serving quality | Run position-group probe; stop before index integration if grouping itself fails |
| 2026-09-28 23:02 | POSITION-PAGE (outcome) | Absolute-position page IDs preserve retrieval density | Eight pages averaged 22.7 candidate rows (85.9% of layer-steps underfilled) vs row pages 127.4; recall 27.53% vs 41.41%, mass 39.66% vs 55.08%. Thirty-two pages averaged 122.3 vs 510.5 rows, recall 53.22% vs 72.33%, mass 66.80% vs 82.53%; metadata 37.77 vs 12.14 MiB. Retained KV is sparse in absolute prompt positions | Reject fixed absolute-position buckets; test stable IDs assigned to initially dense resident-row groups instead: `results/page_recall/p16_k{8,32}_position_centroid.json` |
| 2026-09-28 23:02 | STABLE-DENSE-PAGE (preregistered) | Stable page IDs assigned in blocks of 16 at first cold placement preserve row-centroid retrieval over compaction | Same frozen trajectory. Assign each initially resident slow token a page ID by initial row order; new demotions append to new 16-slot pages, prior tokens retain IDs. Recompute centroids offline each step; primary candidate rows, top-32 recall/mass, underfill, number of pages and summary bytes at 8/32 budgets. Gate: within 5 percentage points of row-centroid recall/mass at comparable candidate fraction, no underfilled 32-row exposure. No incremental-maintenance or latency claim | Probe grouping before implementation |
| 2026-09-28 23:07 | STABLE-DENSE-PAGE (outcome) | Stable IDs preserve dense centroid retrieval while rows compact | Verified identical 640 layer-step baseline trajectories. Eight pages: stable 126.4 candidate rows, 41.87% top-32 recall, 55.82% oracle mass vs row pages 127.4/41.41%/55.08%; 32 pages: 507.9/73.17%/82.52% vs 510.5/72.33%/82.53%. No underfill; ~98.46 active pages per layer; estimated fp32 centers/counts plus 4-byte page ID per retained row 12.51 MiB across layers vs 12.14 MiB row-centroid. Fixed absolute-position pages failed badly | Grouping gate passes; next prove incremental updates through promote/demote/shadow/reclaim before any speed claim: `results/page_recall/stable_page_report.json` |

| 2026-09-28 23:08 | INCREMENTAL-PAGE (preregistered) | Maintaining stable page sums/counts from only live-status deltas avoids full cold-key scans while preserving centroids through every cache transition | Experimental cache subclass and selector only; default unchanged. First prove exact counts and ≤1e-4 relative fp32 sum parity with full rebuild after initial placement, inclusive promotions, backup restoration, paid demotion, shadow reclaim and live eviction; verify candidate rows/IDs against offline stable grouping on a frozen 16K/20-step trajectory. Then run a tiny paired quality screen and same-process latency. Advance only if no stale index, no underfill, no significant quality regression, and full-loop latency below the 142.95 ms full-query control; account for index metadata and changed-key reads. No physical STT claim | Implement and validate transition parity before timing |
| 2026-09-28 23:26 | INCREMENTAL-PAGE (outcome) | A Python/PyTorch delta index delivers fast, correct centroid routing | Three synthetic 100-step transition tests passed full-rebuild sum/count parity after each step, including inclusive backup reuse, shadow reclaim, paid demotion, and live eviction. Final real-request parity also passed. Tiny quality screen: Qasper indexed 53.97 vs rebuilt 53.97; GovReport indexed 33.46 vs rebuilt 27.09, with different stable grouping and 2 examples/task only. Logical index size up to 22.41 MiB plus uncounted Python dict overhead; changed-key reads totaled 170.42 MiB Qasper and 1052.60 MiB GovReport (2 requests each). One same-process 16K/50-token ABBA: indexed 533.47 vs full-query 146.72 ms/token (+263.6%); prefill/decode peak each ~0.018 GB higher. The latency gate fails decisively | Reject this runtime implementation; preserve opt-in code/results for reproducibility, no broader quality run. Next require batched/native metadata updates or a page layout that avoids per-token Python scans and launch overhead before reconsidering: `results/page_recall/indexed_report.json` |
| 2026-09-28 23:28 | INDEX-PROFILE (preregistered) | Python position scans and per-page GPU updates dominate the indexed selector's latency | On one fixed 8K prompt and five decode tokens, profile the actual indexed model+policy loop after model load, attributing CPU cumulative time to selector, page reconciliation, page ranking, PyTorch kernels/synchronization and model forward. No speed claim from a single cProfile trace; use it only to choose or reject the next architecture | Capture and inspect focused profile before further index optimization |
| 2026-09-28 | INDEX-PROFILE (outcome) | Full position dictionaries dominate the failed index | One 8K/5-token trace: `reconcile` 320 calls, 1.826 s cumulative; its two full position→row dictionary comprehensions 0.853+0.831 s self-time. `_decode_step` 2.228 s cumulative, `candidate_rows` 0.249 s, selector hook 0.467 s, model forward 1.239 s. cProfile includes CUDA waits; descriptive attribution, not a throughput result | Target change detection only, then paired timing: `results/page_recall/indexed_cprofile_8k.txt` |
| 2026-09-28 | INDEX-SET-DELTA (preregistered) | Replacing full position→row dictionary rebuilds with live-position set differences and changed-row mapping reduces indexed latency without changing page state | Same opt-in index, 100-step synthetic inclusive/non-inclusive transition parity, exact final real predictions on first two Qasper/GovReport requests, and same-process 16K/50-token ABBA against prechange source if feasible. Gate: material ≥20% indexed latency reduction while still below no quality regression; reject if correctness fails or still uncompetitive with full-query | Patch `reconcile` narrowly and test |
| 2026-09-29 00:10 | INDEX-SET-DELTA (outcome) | Set differences materially reduce indexed full-loop latency | Three 100-step transition tests retained full-rebuild parity. Same-process one-block 16K/50-token ABBA: archived dictionary index median 525.15 vs set-delta 522.46 ms/token (−0.51%), same 15.256 GB decode peak; nowhere near the ≥20% gate or 146.72 ms full-query control. The candidate was reverted, temporary duplicate source removed, and raw timing preserved | Reject local Python-set optimization; profile confirms need to eliminate repeated full-row metadata scans and many small updates architecturally: `results/page_recall/index_set_delta_abba.json` |

| 2026-09-29 00:12 | OBS-32 (preregistered) | Scoring only the final 32 real prompt queries, while retaining the 128-token protected window and identical 992/3104/32 budgets, cuts TTFT without losing the 128-query quality benefit | Same Mistral/GPU0/source/seed/data; access-time decode fixed. First 5 Qasper, NarrativeQA and GovReport examples versus archived actual-query-128 arm; primary task-balanced paired score, gate no task loss >1 point and no example loss >10. Same-process three-block ABBA prefill+placement on fixed Qasper and NarrativeQA prompts; target ≥3% TTFT reduction and no peak increase. If screen passes, expand to frozen 135 examples; otherwise reject. This is selection-window tuning, not protected-window change | Implement opt-in capture width and validate causal/logit parity |
| 2026-09-29 | OBS-32 (outcome) | Fewer observation queries preserve quality and reduce prefill cost | Source-matched 15-example screen: Qasper −0.06, NarrativeQA −2.73 (one example >10-point drop), GovReport +1.94 versus 128 queries. NarrativeQA violates the preregistered −1 task guard; separate-run median prefill was not consistently faster (NarrativeQA 4.726→4.819 s). Paid writes fell modestly on all three tasks. Tiny-model causal/logit/recent-window test passed, but quality gate fails, so paired TTFT and full 135-run were skipped | Reject 32-query variant and remove option; retain 128-query candidate. Raw `results/baseline_fidelity/obs{128,32}_lru_15.json` records exact executed source hashes |
| 2026-09-29 00:20 | SNAP-768-PILOT (preregistered) | Actual-query TieredKV's quality gain survives a closer physical-KV-footprint comparison with upstream SnapKV prompt selector | Same Mistral/GPU0/eager/data/seed, first five Qasper, NarrativeQA, GovReport examples. Tiered arm is archived actual-query-128 access-time 992 fast/3104 cold/32 exposed; SnapKV adapter uses fixed capacity 768 query-head-expanded bf16 rows, window32, giving 384 MiB prompt KV cap plus uncapped decode growth. Primary paired task-balanced quality; explicitly report per-request final KV bytes and attended rows, not claim exact equality. If SnapKV wins or bytes differ materially, do not scale or claim resource-matched superiority. Source/dataset/sample IDs, model and byte formula checked | Run fixed 768-capacity upstream adapter and verify resource deltas |
| 2026-09-29 | SNAP-768-EAGER-OOM (execution incident) | Eager attention can execute the same 31.5K prompt as the SDPA prefill control | Qasper completed, but NarrativeQA prefill requested an additional 59.14 GiB attention matrix and OOMed on L40S. No NarrativeQA/GovReport score was produced. Retry the identical capacity/sample selection with adapter SDPA, which retains the same upstream prompt selector; label execution mode and avoid latency/peak comparisons to eager as equal-mode | Preserve partial eager file and error log; SDPA retry required |
| 2026-09-29 | SNAP-768-PILOT (outcome) | Fixed 768 expanded-head rows provide a close physical KV comparison | Verified first five each: Qasper Tiered actual-query LRU 15.65 vs upstream SnapKV 14.89, NarrativeQA 20.03 vs 14.23, GovReport 28.17 vs 29.96. Mean final Snap/Tiered KV payload ratios 0.940, 0.933, 1.378 respectively; SnapKV growing decode cache makes GovReport materially larger. Its 768-row prompt cache also attends fewer rows than Tiered's 992+32. No latency/throughput or SOTA claim | Do not scale or call equal-byte; test task-level resource-matched prompt capacities as a diagnostic: `results/baseline_fidelity/snap768_sdpa_pilot15_report.json` |
| 2026-09-29 | SNAP-TASK-BYTES (preregistered) | Task-level prompt capacities 832 (Qasper/NarrativeQA) and 500 (GovReport) bring upstream SnapKV mean final KV payload near Tiered's archived 422/420/384 MiB means | Same first five examples/model/GPU0/SDPA/upstream selector/window32. Capacity chosen from row-byte formula and observed output-length regime before this run; cannot establish ex-ante fairness or control attention width. Primary report per-request measured bytes, score, output lengths; target mean payload ratio within ±10% on all three tasks. Reject any superiority claim if quality or bytes are not comparable; no throughput claim | Run two fixed-capacity adapter groups, then paired verification |
| 2026-09-29 | SNAP-TASK-BYTES (outcome) | Near-matched task-mean final payload shows a TieredKV quality lead | Mean Snap/Tiered final KV byte ratios 1.020 Qasper, 1.011 NarrativeQA, 1.014 GovReport; but GovReport per-request ratios range 0.806–1.840. Paired five-example scores Tiered vs Snap: Qasper 15.65 vs 20.30 (−4.64), NarrativeQA 20.03 vs 16.45 (+3.58), GovReport 28.17 vs 29.13 (−0.96); task-balanced −0.68, conditional 95% CI [−4.93,+3.36]. Snap attends fewer rows than Tiered's 1,024-row ceiling, and capacities were chosen using prior observed length regime. Mixed SDPA/eager Tiered vs SDPA Snap also prevents latency comparison | Reject superiority and scaling claim; publishable comparison still requires ex-ante per-request resource controls, matched attended width, more samples/models and full-request metrics: `results/baseline_fidelity/snap_task_bytes_report.json` |

| 2026-09-29 00:28 | SNAP-EXANTE-512 (preregistered) | At the same ex-ante 512 MiB maximum final resident KV payload, actual-query TieredKV with access-time decode may outperform upstream SnapKV | Mistral/GPU0/same first five Qasper, NarrativeQA, GovReport; Tiered cap 4096 compact GQA rows=512 MiB and attended width ≤1024. Snap expanded rows=0.5 MiB; set prompt capacity `1024 - task_max_gen + 1`: 897 for Qasper/NarrativeQA (128 max generation), 513 for GovReport (512), so the uncapped decode cache remains ≤1024 rows=512 MiB by construction. SDPA adapter prefill; Tiered SDPA prefill/eager decode. Primary task-balanced paired score, per-task losses and actual bytes; guard exact sample IDs/source hashes and no OOM. This matches configured final KV ceilings, not exact actual bytes, attended width, prefill peak, transfer policy, or runtime. Pilot only; no SOTA claim from 15 examples | Run both fixed-capacity Snap groups, verify formula and report limits |
| 2026-09-29 | SNAP-EXANTE-512 (pilot outcome) | Ex-ante equal 512 MiB final KV ceilings reveal a TieredKV quality lead | First five Qasper/NarrativeQA/GovReport: Tiered−Snap paired −4.24/+3.01/+0.16 points; task-balanced −0.36, conditional interval [−4.47,+3.46]. Snap actual mean final bytes are 9.7%, 8.6%, 3.8% higher respectively; Gov per-request ratios 0.784–1.904. Every Snap final payload ≤512 MiB. Sample IDs, scores and byte formula verified. No superior policy established from pilot | Freeze the formula and expand to selected 135 examples; still not equal actual bytes/width or SOTA: `results/baseline_fidelity/snap_exante_512_report.json` |
| 2026-09-29 | SNAP-EXANTE-512-FULL (preregistered) | A 135-example six-task comparison resolves the ex-ante ceiling pilot's wide quality interval | Fixed first 25 Qasper/NarrativeQA/MultiFieldQA/HotpotQA/TriviaQA, first 10 GovReport. Snap capacity per task =1025−LongBench max generation: 897/897/961/993/993/513, window32, bf16 expanded heads, SDPA; Tiered archived actual-query prefill/access-time decode 992+3104 compact rows, exposed32, same seed/model/data. Primary task-balanced paired score and conditional 95% interval; report task losses, individual regressions, actual final byte ratios and attended-width mismatch. Guard source/runtime/data/sample identity and every payload ≤512 MiB; no latency/energy/SOTA claim | Run fixed groups, verify independently, update go/no-go |
| 2026-09-29 | SNAP-EXANTE-SOURCE (audit finding) | Archived TieredKV full arm is source-identical to the new SnapKV run | Runtime source hashes differ (`f81473a5…` vs `58a54787…`) because intervening source edits added an opt-in cache-class hook. Package versions/Git revision match, but strict source identity fails. No 135-example cross-arm claim until TieredKV is rerun under current source and reproduces old predictions/scores/bytes/counters | Rerun current-source TieredKV 125+10 and verify exact archive parity |
| 2026-09-29 | SNAP-EXANTE-SOURCE (outcome) | Current-source TieredKV run reproduces archive and matches Snap runtime | All 135 sample IDs, predictions, scores, final resident bytes and task cache counters reproduced exactly. Tiered and Snap runs now share aggregate source hash `58a54787…`, package versions and Git revision. Adapter tiny-model SDPA/eager integration gates pass full-prefill logits, reference-selected cache, expanded-head decode and cleanup | Use current-source raw files in 135-example report: `results/baseline_fidelity/real_q_lru_rescore_{125,gov10}.json` |
| 2026-09-29 | SNAP-EXANTE-512-FULL (outcome) | TieredKV beats upstream-selector SnapKV under equal configured final KV ceilings | Verified 135 selected examples: task-balanced Tiered−Snap **−0.05**, conditional paired 95% CI **[−1.36,+1.36]**. Per-task deltas Qasper −3.46, NarrativeQA −0.21, MultiFieldQA +1.14, HotpotQA +2.67, TriviaQA −0.91, GovReport +0.50. Both per-request final KV payloads ≤512 MiB, but Snap/Tiered *mean actual* byte ratios are 1.121/1.085/1.296/1.234/1.268/0.944. Attended rows, prefill peak, precision layout, and physical tier differ. SDPA Snap vs Tiered SDPA prefill/eager decode prevents latency claim | Reject superiority/SOTA conclusion; next design must beat this faithful selector under ex-ante budget and full-request metrics, with held-out model/task validation: `results/baseline_fidelity/snap_exante_full_report.json` |

| 2026-09-29 00:52 | SNAP-TIER-LOOP (preregistered) | Under the same configured 512 MiB final-KV ceiling, actual-query TieredKV with cheap access-time decode has competitive complete-request latency against upstream-selector SnapKV | Same Mistral/GPU0/real 16K prompt, fixed 50 model decode forwards, bf16, same source/runtime/seed; Tiered 992+3104 compact rows, 32 cold exposed, SDPA prefill/eager decode with required attention weights; Snap capacity 974 expanded rows so 974+50=1024 max, window32, SDPA prefill/eager decode without unused attention weights. Same-process ABBA 3 blocks, each arm 1 warmup+2 measured trials. Primary median ITL and TTFT; guards p95, PyTorch prefill/decode peak, final actual KV bytes, no other GPU0 process. Do not claim same actual bytes, attention width, output tokens, serving throughput or physical STT performance | Implement matched-loop pilot, then run full blocks if valid |
| 2026-09-29 00:58 | SNAP-TIER-LOOP (outcome) | The actual-query TieredKV policy is competitive with faithful SnapKV on complete decode time | Three-block same-process ABBA, 12 measured trials/arm, 600 timed tokens/arm: median Tiered/Snap ITL 95.08/25.74 ms (3.69x); p95 100.56/25.96 ms; median TTFT 2217.22/2097.99 ms. Tiered's own median model-forward time was 25.15 ms/token, leaving roughly 70 ms/token outside forward. Tiered/Snap maximum prefill peak 18.796/17.958 GB, decode peak 15.234/16.522 GB, actual final KV payload 425/512 MiB despite equal configured 512 MiB ceiling. GPU0 had only the benchmark process during a spot check. This is one prompt, fixed 50 forwards, different generated tokens, and different attention-weight requirements; it is not a serving throughput or physical STT comparison | **Fail latency gate.** Do not claim competitive speed or all-metric/SOTA superiority. Profile the current 16K policy loop, then test only a parity-preserving structural fix. Raw and verified summary: `results/baseline_fidelity/snap_tier_loop_abba.json`, `results/baseline_fidelity/snap_tier_loop_abba_report.json` |
| 2026-09-29 00:58 | POLICY-OVERHEAD-16K (preregistered) | Repeated per-layer victim selection, backup maintenance, and visible-tuple reconstruction explain most of the ~70 ms/token non-forward time | Profile a representative current-source 16K prompt with fixed decode; attribute cumulative CPU time to `_decode_step`, `evict_and_demote`, `_visible_tuple`, `update_scores`, and their hottest lines. The prior 8K profile is only a hypothesis generator because it used an older source. No optimization or speed claim from a single profile | Run one focused diagnostic and choose one narrow experiment only if the dominant operation is clear |
| 2026-09-29 01:01 | POLICY-OVERHEAD-16K (outcome) | Victim maintenance and visible tuple construction account for much of the non-forward gap | One current-source 16K/10-token actual-query cProfile: observed 97.89 ms/token full loop, 25.38 ms/token model forward. `_decode_step` 0.637 s cumulative (10 calls), including 320 `evict_and_demote` calls at 0.334 s and 11 `_visible_tuple` calls at 0.201 s; `update_scores` 0.076 s. Cumulative times overlap and cProfile perturbs timings. This confirms a Python/per-layer policy bottleneck, not an attention-kernel bottleneck | A parity-preserving structural change to victim maintenance/visible selection is the next candidate. Keep the existing implementation as quality control until exact predictions and paired latency pass: `results/baseline_fidelity/tier_policy_16k_10.prof`, `.txt` |
| 2026-09-29 01:03 | VISIBLE-STABLE-TOPK (screen) | Unique-key top-k could replace full stable sort for 32 visible rows | On 32 synthetic GPU layers, each with 3,104 rows and tied recencies, `topk(recency*(N+1)-index,32)` exactly matched the stable-sort selected sets. But a 100-iteration synchronized microbenchmark took 1.377 versus 1.065 ms per 32 layers (+29%) before any extra gather/sort. This does not test full-loop latency or quality | Reject; no runtime source change. Sorting the visible rows is not a promising stand-alone fix |
| 2026-09-29 01:06 | HOT-DEFER-APPEND (preregistered) | Deferring hot-tier K/V append until after victim selection avoids one full K/V copy per layer per decode while preserving order and decisions | Add an opt-in path only. First require exact cache K/V, positions, scores, shadows, counters and model-generated tokens over synthetic overflow/backup transitions and representative real prompts. Then measure same-process 16K/50-token ABBA against unchanged control with matched source, prompt and configuration; primary full-loop median/p95 ITL, guards TTFT, prefill/decode peak and final bytes. Advance only if parity and consistent ≥5% decode improvement without material memory or prefill regression. Keep control default until gates pass | Implement narrowly; test transitions before GPU latency |
| 2026-09-29 18:33 | HOT-DEFER-APPEND (outcome) | Removing the first hot K/V copy improves complete decode latency | Synthetic inclusive/non-inclusive 20-step transition parity passed; generated text, all 32 per-layer cache tensors/metadata, and counters matched exactly on 4K, 8K, and 16K real prompts. But three-block 16K/50-token ABBA gave control/deferred median ITL 92.43/96.19 ms (+4.1% slower), p95 100.07/103.87 ms; every paired block favored control. TTFT 2205.64/2209.67 ms, same 425 MiB final KV, prefill peak equal at 18.793 GB, decode peak +0.002 GB. The indexed gather plus final concatenation outweighed avoiding the initial append copy | Reject and remove opt-in runtime branch/tests/scripts; preserve raw timing and parity artifacts `results/baseline_fidelity/hot_defer_{abba,parity}.json`. Next architectural candidate must avoid a full visible-cache rebuild or per-layer policy work, not merely reorder the same copies |
| 2026-09-29 18:36 | POLICY-LINE-16K (preregistered) | A few per-layer Python lines or host/device synchronizations dominate the current ~70 ms/token policy overhead | On current source, trace only `evict_and_demote` and `_visible_tuple` across a real 16K prompt and 8 fixed decode forwards. Report cumulative host wall time by line and call count; use trace solely for localization because tracing perturbs latency and includes nested calls/GPU waits. No speed claim or source change from this diagnostic | Choose next structural candidate from measured hotspots, avoiding repeated speculative micro-optimizations |
| 2026-09-29 18:37 | POLICY-LINE-16K (outcome) | The hot lines isolate one avoidable host-index gather | Current-source 16K/8-token trace: 256 `evict_and_demote` calls, 9 `_visible_tuple` calls; observed traced ITL 116.22 vs model forward 25.51 ms/token. Largest individual line was `la=cache.stt_last_access[live]` at 76.22 ms total; next were hard-mask construction 43.47, LRU sort+host list 36.21, hot K/V gathers 35.67/33.18 ms. Line totals include nested GPU waits and trace overhead, so not additive proof | Screen a boolean-mask gather that preserves live-row order; require exact policy and model parity before ABBA: `results/baseline_fidelity/policy_line_16k_8.json` |
| 2026-09-29 18:39 | BOOL-LIVE-GATHER (preregistered) | Replacing `stt_last_access[live_python_list]` with boolean-mask gather avoids constructing/transferring a long index tensor per layer while preserving order | Synthetic 32-layer/N=2328/10%-shadow screen: exact gathered values; 7.138→0.974 ms/32 layers in a synchronized 100-iteration microbenchmark. Add opt-in one-line runtime path; test CPU and real 4K/8K/16K prompt exact selections, predictions, per-layer state/counters. Then same-process 16K/50-token three-block ABBA. Advance if ≥5% median ITL gain consistent across blocks, no p95/memory regression; otherwise remove candidate | Implement and test opt-in path |
| 2026-09-29 18:44 | BOOL-LIVE-GATHER (outcome) | Ordered boolean indexing improves the complete policy loop with exact behavior | Real Mistral 4K/8K/16K, 12-token comparisons matched every selected cold-row index at every step, all per-layer final cache state/counters and generated text. Three-block 16K/50-token ABBA: control/candidate pooled median ITL 93.88/86.34 ms (−8.0%), p95 100.26/93.08 ms (−7.2%); block medians 93.88→86.37, 92.66→85.48, 92.33→85.08. Median TTFT 2216.02→2199.95 ms; prefill/decode peak both equal at 18.793/15.233 GB; final KV 425 MiB both. GPU0 had only benchmark process at spot check. This is one prompt, not throughput or cross-hardware proof | **Keep as default** (control switch retained for reproduction). Exact parity and every latency block pass the preset gate. Remaining ~86 ms/token is still far above faithful SnapKV; rerun matched-source Snap comparison. Raw: `results/baseline_fidelity/bool_live_gather_{parity,abba}.json` |
| 2026-09-29 18:52 | BATCH-VISIBLE-SYNC (preregistered) | Deferring `.tolist()` for visible cold-row selection indices until all layers sort can remove 32 per-layer synchronization points without changing chosen rows | Preserve each layer's current `argsort` input and operation exactly; stack equal-sized relative-index results and transfer once. Compare every selected absolute index, cache state and output on real 4K/8K/16K prompts, then 16K/50-token three-block ABBA against the accepted boolean-gather path. Gate ≥5% median ITL reduction across all three blocks, no p95, TTFT or memory regression. Keep opt-in until gates pass | Test exact trajectory parity, then measure full loop |
| 2026-09-29 19:00 | BATCH-VISIBLE-SYNC (initial outcome) | Batch transfer of all layer indices reduces full-loop latency while retaining exact outputs | Real 4K/8K/16K comparisons preserved every selected row, final state/counters and output. Three-block ABBA per-block current/batched medians: 89.79/84.18, 86.41/83.80, 88.02/85.34 ms/token; all three favor batching. Pooled median 89.79/85.34 (−4.96%), p95 93.52/91.51; TTFT 2219.10/2214.71 ms; prefill peak equal 18.793 GB, decode peak 15.233/15.234 GB, final KV both 425 MiB. Exact pre-registered 5% speed gate narrowly misses. This is a one-prompt experiment and not a broad performance claim | Do not accept or remove yet; register three additional ABBA blocks under the unchanged ≥5% overall gate to resolve boundary noise. Retain as opt-in during follow-up |
| 2026-09-29 19:00 | BATCH-VISIBLE-SYNC-REPLICATION (preregistered) | Additional paired blocks distinguish a real ≥5% gain from noise near the initial cutoff | Run three more ABBA blocks on the same fixed prompt, model, source logic, and 50-token protocol. Primary is combined six-block pooled median ITL using all 12 measured runs/arm; original ≥5% reduction gate remains unchanged. Guards: exact parity, no worse pooled p95 or peak allocation, equal final bytes; no changing the prompt/config or excluding trials | If combined reduction reaches ≥5% and guards hold, promote; otherwise remove the candidate |
| 2026-09-29 19:06 | BATCH-VISIBLE-SYNC-REPLICATION (outcome) | Six blocks show no ≥5% benefit from batched index transfer | Combined 12 measured trials/arm: median current/candidate ITL 89.61/88.49 ms (−1.26%), p95 92.80/91.40 ms; TTFT 2210.07/2206.79 ms. Per-block medians current→candidate: 89.79→84.18, 86.41→83.80, 88.02→85.34, 85.86→88.66, 88.19→83.44, 87.54→83.52 ms; one full block regressed. Peaks and 425 MiB final bytes were effectively equal. Per-step exact parity passed at 4K/8K/16K, but original ≥5% gate failed decisively on replication | Reject and remove code path; retain raw runs `batched_visible_{abba,followup}.json`, parity `batched_visible_parity.json`. Favor structural work over batching this sync |
| 2026-09-29 18:48 | SNAP-TIER-LOOP-BOOL (outcome) | The accepted gather optimization closes the faithful SnapKV decode gap | New-source same-process three-block ABBA with the same configured maximum 512 MiB final KV: Tiered/Snap median complete-loop ITL 86.73/25.76 ms (3.37x slower), p95 93.01/26.11 ms, median TTFT 2221.27/2102.00 ms. Tiered/Snap prefill peak 18.796/17.958 GB, decode peak 15.234/16.522 GB, actual final KV 425/512 MiB. Tiered median model forward 25.12 ms/token. This improves Tiered's own loop but remains a large policy cost and no joint Pareto/SOTA win. One fixed prompt, 50 forwards, different generated outputs/attention-weight requirements; no throughput claim | Retain gather speedup, continue structural policy/visible-cache work and faithful quality/serving validation. Raw and verified: `results/baseline_fidelity/snap_tier_loop_bool_default.json`, `_report.json` |
| 2026-09-29 19:27 | SNAP-EXANTE-CURRENTBOOL (outcome) | The accepted bool-gather source preserves the complete 135-example quality result under a source-matched SnapKV comparison | Re-ran TieredKV on the frozen 125+10 samples and the upstream-selector SnapKV adapter under identical source fingerprint `a93b716ddb51…`, package versions, model, data hashes, task IDs, ex-ante 512 MiB ceilings, bf16, SDPA prefill, and configured capacities. All 135 Tiered predictions, per-example scores, final resident bytes, and cache counters exactly match the archived Tiered control. Current paired quality is −0.0457 task-balanced points (Tiered−Snap), conditional bootstrap 95% interval [−1.3573,+1.3621]; task deltas: Qasper −3.46, NarrativeQA −0.21, MultiFieldQA +1.14, HotpotQA +2.67, TriviaQA −0.91, GovReport +0.50. This is no demonstrated quality superiority and not an equivalence result; actual bytes/attended width still differ. Full current-source raw runs `currentbool_{tier125,tiergov10,snap_qn25,snap_multi25,snap_ht25,snap_gov10}.json`; verified report `snap_exante_full_currentbool_report.json` | Quality provenance gap closed. Keep claims bounded; complete held-out/generalization and equal-actual-resource tests remain open |
| 2026-09-29 19:29 | BOOL-HOT-COMPACTION (preregistered) | Boolean-mask selection of surviving hot K/V rows avoids converting each Python keep-list to a GPU index during compaction | Synthetic L40S microbenchmark with 32 layers, H=8, S=993, D=128, bf16, eight victims: exact row parity; 3.86→0.90 ms per 32-layer K/V gather batch in 100 iterations. Add opt-in mask path, require exact full cache and generated-text parity for inclusive/non-inclusive transitions and real 4K/8K/16K prompts, then same-source 16K/50-token three-block ABBA. Gate ≥5% median ITL gain in all/overall paired result, no p95/TTFT/peak regression; otherwise remove | Profile highlighted K/V gathers; implement as an experimental flag only |
| 2026-09-29 19:35 | BOOL-HOT-COMPACTION (outcome) | Boolean keep-mask indexing improves hot-cache compaction with exact behavior | Exact per-layer selected cold rows, generated output, all tracked cache tensors/counters match on real 4K/8K/16K prompts. Three-block 16K/50-token ABBA: control/candidate pooled median ITL 90.27/84.22 ms (−6.70%), p95 92.73/86.46 ms (−6.76%); block medians 86.83→84.14, 90.60→84.31, 85.37→83.35 (all favor mask). TTFT 2183.93→2199.63 ms (+0.72%; differences by block −0.6, +15.7, +1.0 ms); this code path is only reached after prefill/TTFT. Prefill peak, decode peak, and final 425 MiB KV are unchanged. No causal prefill work differs | **Keep as default.** Re-run same-source 135-example quality and faithful SnapKV report now that the implementation fingerprint changed. Raw: `results/baseline_fidelity/bool_hot_compaction_parity.json`, `hot_compaction_abba.json` |
| 2026-09-29 19:52 | HOT-COMPACTION-SNAP-EXANTE (outcome) | Final hot-compaction source preserves quality against source-matched faithful SnapKV | Re-ran all 135 Tiered and SnapKV requests under source fingerprint `eea0cf48baa0…`. The Tiered predictions, scores, final bytes, and counters all exactly match the prior controls. Paired Tiered−Snap quality is again −0.0457 task-balanced points, conditional bootstrap 95% interval [−1.3573,+1.3621]; task deltas Qasper −3.46, NarrativeQA −0.21, MultiFieldQA +1.14, HotpotQA +2.67, TriviaQA −0.91, GovReport +0.50. Ex-ante max final payload 512 MiB; actual bytes and attended widths remain unequal. This does not establish superiority or equivalence. Raw `currenthot_*` files and verifier output `snap_exante_full_currenthot_report.json` | Accept behavior-preserving optimization; rerun current-source complete-loop SnapKV latency and retain quality claims as near-tie only |
| 2026-09-29 19:57 | HOT-COMPACTION-SNAP-LOOP (outcome) | Boolean hot-row compaction improves the current-source full-loop latency without changing the quality result | Same-source 16K/50-forward three-block ABBA: Tiered/Snap median ITL 82.76/25.77 ms (3.21×), p95 86.34/26.03 ms, TTFT 2194.82/2086.69 ms. Tiered/Snap maximum prefill peak 18.796/17.958 GB and decode peak 15.234/16.522 GB; final payload 425/512 MiB. This is 4.0% lower Tiered median ITL than its prior gather-only source result (86.73 ms), with exact quality/cache parity verified separately on all 135 examples. Still one prompt, different outputs/attention-weight requirements, and no serving-throughput or physical slow-memory claim. | Keep the parity-proven compaction default; continue investigating the remaining policy/attention overhead. Raw and summary: `results/baseline_fidelity/snap_tier_loop_currenthot.json`, `_report.json` |
| 2026-09-29 20:09 | FUSED-HOT-APPEND (exploratory screen) | Avoiding the append-then-compact hot K/V copy lowers decode latency | The candidate deferred hot K/V append, selected identical victims, then joined surviving rows and the new token in one output allocation. Exact selected rows, generated text, cache state, counters, and metrics matched at 4K/8K/16K. On 16K/50 forwards, three-block ABBA pooled median ITL was 78.51 ms control vs 79.66 ms candidate (+1.46% slower); pooled p95 82.31 vs 84.07 ms. TTFT was 2216.99 vs 2211.88 ms, decode peak 15.233 vs 15.235 GB, prefill peak 18.793 GB for both, and final payload 425 MiB for both. This candidate was implemented before its numeric threshold was logged, so treat this as exploratory evidence, not a protocol-compliant progression result. Its latency and p95 regressions still reject it; candidate code was removed. | Reject. Keep ordinary append plus boolean compaction. Next candidate must be preregistered before implementation. Raw parity and ABBA: `results/baseline_fidelity/fused_hot_append_parity.json`, `fused_hot_append_abba.json` |
| 2026-09-29 20:16 | STABLE-TOPK (preregistered) | GPU top-k can replace full stable sorts when its selected indices exactly match the stable-sort prefix, falling back on ties | Frozen current control: source `eea0cf48baa0…`, L40S GPU0, Mistral-7B, real prompt SHA `18695714f26e…`, seed 0, bf16, 992+3104 rows, 32 exposed cold rows, 16K/50 decode forwards. Profile target is the stable `argsort` calls in per-layer eviction/reclaim; preserve sort order and tie semantics exactly. First capture actual score vectors and compare candidate prefixes; then implement guarded top-k only if exactness and microbenchmark justify it. Validate predictions/cache/counters at 4K/8K/16K. Latency gate: three-block same-process ABBA, ≥5% pooled median ITL reduction, p95 ≤2% worse, no peak-memory or TTFT regression. | Run capture and tie-frequency/speed screen; reject before full ABBA if little exact eligible work or no speed headroom |
| 2026-09-29 20:19 | STABLE-TOPK (screen outcome) | Guarded top-k can reduce the hot eviction selection cost while preserving stable tie order | Captured 320 real 16K hot-eviction selections over 10 decode steps. Every one had a boundary tie; none of the top-k prefixes matched the stable-sort prefix. The exact guarded implementation therefore fell back on all calls and took 34.76 ms over the captured set versus 8.33 ms for stable sort. No cache implementation was changed and no full ABBA was warranted. The source, cache behavior, and current quality evidence remain unchanged. | Reject. Stable tie density makes this optimization unpromising for the measured workload; target per-layer policy structure or launch count instead. Probe and raw summary: `experiments/probe_stable_topk.py`, `results/baseline_fidelity/stable_topk_probe.json` |
| 2026-09-29 20:23 | BATCH-STABLE-EVICTION (preregistered) | A batched stable sort across cache layers can reduce repeated sort launches and host synchronization without changing victim/order semantics | Frozen source `eea0cf48baa0…`, Mistral-7B, L40S GPU0, 16K prompt SHA `18695714f26e…`, seed 0, bf16, 992+3104 rows, exposure 32. First capture real per-layer hot-eviction and visible cold-recency vectors for 10 decode steps; pad only with ordering-neutral infinities and compare every selected index to the independent stable-sort prefix. Do not edit cache behavior unless exact parity holds and the capture-level batched sort plus one grouped index transfer saves ≥4 ms per decode step (enough to plausibly meet the full-loop 5% gate). If advanced, require 4K/8K/16K generated-text/cache/counter parity, then three-block 16K/50-step ABBA; progression gate ≥5% pooled median ITL reduction, p95 ≤2% worse, with no TTFT or peak-memory regression. | Run capture and CPU/GPU grouped-sort microbenchmark; reject if selected indices differ or time headroom is inadequate |
| 2026-09-29 20:26 | BATCH-STABLE-EVICTION (screen outcome) | Batched stable sort across layers cuts sort/sync overhead enough to justify an implementation | Captured 320 hot-eviction and 352 cold-recency sorts over 10 real 16K decode steps. Padded batched stable argsort matched every requested prefix exactly across 21 complete 32-layer groups. Capture-level timing was 47.15 ms individual versus 10.15 ms batched over all 10 steps, a 3.70 ms/step projected saving, below the preregistered 4.00 ms/step screen and the 5% full-loop gate. Cache code was not changed and no ABBA was run. | Reject this batching candidate at the screen; do not promote based on parity alone. Raw summary and probe: `experiments/probe_batched_stable_sort.py`, `results/baseline_fidelity/batched_stable_sort_probe.json` |

| 2026-09-29 20:34 | POLICY-PROFILE-CURRENT (diagnostic) | Reconfirm which current-source operations dominate before selecting another policy optimization | Reran `experiments/profile_tier_policy.py` on Mistral-7B, L40S GPU0, fixed 16K prompt, 10 decode steps, source SHA `eea0cf48baa0…`. cProfile observed 320 `evict_and_demote()` calls at 0.269 s cumulative, `update_scores()` at 0.076 s/10 calls, `_visible_tuple()` at 0.120 s/11 calls, and 704 `argsort` calls at 0.067 s. These totals include instrumentation/GPU waits and overlap; they are localization evidence, not additive latency estimates. | Keep the control. Explore a broader cross-layer decision/update design only if capture-level evidence shows ≥4 ms/step headroom beyond sort-only batching; exact victim order/state and a full-loop ≥5% ABBA remain mandatory: `results/baseline_fidelity/tier_policy_16k_10.txt`, `.prof` |
| 2026-09-29 20:41 | REAL-Q-LRU-HOLDOUT (preregistered) | The actual-query prompt placement quality gain survives fresh examples from the same six LongBench tasks | Current runtime/source `be7e700d…` / `eea0cf48…`; Mistral-7B-Instruct checkpoint hashes in `model_sha256.txt`; L40S GPU0; bf16; seed 0; 992 fast + 3104 cold rows; 32 cold exposed; max context 31,500. Compare K-as-Q LRU control against actual rotary-query prefill with the same LRU decode policy. Five examples per task (30 paired total) were selected uniformly without replacement from rows after the previously evaluated prefix using seed 20260929; exact row indices and IDs are frozen in `real_query_holdout_20260929/manifest.json` (SHA256 `af1a8f7c…`). Primary: task-balanced paired quality, conditional bootstrap 95% lower bound >0 to support holdout replication. Report all task/sample regressions and paid-write counts. Prefill time/peak are descriptive only; no latency/default/SOTA claim from this quality holdout. | Run both arms sequentially on GPU0 from this frozen manifest and verify runtime/sample/source hashes before interpretation |
| 2026-09-29 20:51 | REAL-Q-LRU-HOLDOUT (outcome) | Actual-query placement quality gain generalizes to the fresh disjoint sample | All 30 sample IDs, source dataset slices, scores, config and runtime matched/verified. Task-balanced candidate−control was +5.17, but paired conditional 95% bootstrap interval was [−1.60,+12.95], so the preregistered lower-bound gate failed. Task deltas: Qasper +3.48, NarrativeQA −1.07, MultiFieldQA +26.69, HotpotQA +2.19, TriviaQA 0, GovReport −0.26. Seven of 30 regressed; two fell by >10 points. Error audit: the large Qasper loss omitted precision/recall details; the HotpotQA prediction retained the correct answer “Barnoldswick” but repeated it with a parenthetical, which the token-F1 metric penalized. Candidate median prefill time and peak allocation were higher in all six tasks; paid writes/decode-step increased in five of six. | No-go for a replicated quality claim; leave actual-query placement opt-in. Preserve the Qasper content-loss case; treat the HotpotQA score as a likely metric-format penalty, not confirmed retrieval failure. Do not tune on these holdout rows: `real_query_holdout_20260929/report.json`, raw arm JSON and manifest |
| 2026-09-29 20:55 | REAL-Q-LRU-HOLDOUT-2 (preregistered) | The unchanged actual-query/LRU policy reproduces its quality direction on a second independent fresh tranche | Same Mistral checkpoint, source/runtime `eea0cf48…`, L40S GPU0, bf16, seed 0, 992+3104 rows, expose 32, max context 31,500; only actual-query prefill differs. New five-per-task sample selected uniformly from rows after the prior evaluated prefix and excluding tranche 1 (selection seed 20260930); exact indices, source/slice hashes and sample IDs are frozen in `real_query_holdout_20260929/batch2/manifest.json` (SHA256 `907f0c67…`). Run control then candidate sequentially. Primary is task-balanced paired quality; to account for the two predeclared fresh tranches, replication requires a 97.5% conditional bootstrap lower bound >0. Report all individual/task losses, measured prefill/peak and normalized logical writes; no timing superiority claim. | Run both frozen arms with identical config; do not change selector or tune on either tranche |
| 2026-09-29 21:06 | REAL-Q-LRU-HOLDOUT-2 (outcome/stress) | Actual-query placement independently replicates positive task-balanced quality on tranche 2 | All 30 sample IDs/sources/config/runtime verified. Candidate−control was +7.30, paired 97.5% bootstrap interval [+1.54,+15.12], passing the preregistered replication threshold. Task deltas: Qasper +6.77, NarrativeQA +2.36, MultiFieldQA +8.34, HotpotQA +25.83, TriviaQA 0, GovReport +0.48; 3/30 regressed and one lost >10. Manual audit found that large MultiFieldQA loss changed “The normalized least mean square (NLMS) algorithm” to “The NLMS algorithm,” likely a surface-form/ROUGE penalty rather than a wrong core answer. Stress over both tranches: >16K prompts were flat/slightly negative (−0.15 task-balanced across 15 examples); control generations >128 tokens were +0.11 over 10 examples with 6/10 regressions. | Confirm quality direction only for this second tranche; stress gate blocks broad advancement. Candidate prefill median time and peak memory rose in all six tasks. Across both tranches, descriptive pooled gain is +6.24 [95% interval +1.48,+11.48], while paid writes/decode-step fell only 47.80→47.28 (−1.1%), below the 20% write gate. Keep opt-in; long-context/long-output retrieval, second-model robustness and a Pareto systems gain remain open: batch2 `report.json`, root `combined_descriptive.json` |

## Rejected/paused approaches

- Direct real-model peek injection: shared mask length caused cross-layer coupling and quality/promotion collapse. Revisit with per-layer sparse attention.
- Full live-key scan: costly and no faithful/equal-resource superiority. Replace with compact retrieval.
- Larger slow capacity alone: clean sweep was flat because exposure was limiting.
- More quantization: FP8 did not reduce prefill peak or prove speed/quality. Resume only with packed kernels and a preregistered Pareto target.
- Four-row residency admission: reduced migration but failed the quality non-inferiority gate and weakened the relative write-saving effect. Move the data more efficiently instead of suppressing useful moves.
- Deferred slow-tier append/compaction: saved one intermediate allocation but did not improve median decode latency and worsened p95 in a three-block ABBA check. The experiment also exposed an FP8 simulator sketch bug, which was fixed separately.
- Full-capacity slot recycling: potentially useful for generations exceeding the ~512-row prefill headroom, but the current 16-step benchmark cannot exercise it. Do not infer any effect from that benchmark; run a sufficiently long, instrumented workload only if that regime matters.
- Full-capacity reserved append: in the actual short-decode fill regime it was slower and used more GPU memory than packed append. Do not roll it out from the earlier full-capacity replacement result.
- Fused hot append/compaction: exact parity passed, but 16K ABBA median ITL regressed 1.46% and p95 worsened; candidate code removed. Keep raw result only at `results/baseline_fidelity/fused_hot_append_abba.json`.
- Host-mask finite count: removes a reduction only under a finite-score assumption and gave inconsistent latency across 8K/16K; branch removed.
- Stable top-k for hot eviction: all 320 real selections had boundary ties; exact guarded top-k fell back every time and was 4.2× slower in the captured microbenchmark. No cache code added (`results/baseline_fidelity/stable_topk_probe.json`).
- Batched stable sorting: prefixes matched exactly, but capture-level savings were 3.70 ms/decode step, below its preregistered 4.00 ms screen and the 5% full-loop gate; no cache code added (`results/baseline_fidelity/batched_stable_sort_probe.json`).

### HOLDOUT-DOCUMENT-AUDIT (2026-09-29; exact completion time not recorded)

Post-evaluation provenance audit found 12/60 distinct-row evaluation records
reuse development contexts: NarrativeQA 9/10 and MultiFieldQA 3/10.
NarrativeQA has eight unique evaluation contexts for ten rows. The numerical
quality estimates are unchanged; earlier independent-replication wording is
withdrawn because row-bootstrap intervals omit document dependence. No cache
behavior changed. Next validation must split and resample by document groups,
with near-duplicate checks. Artifact: `real_query_holdout_20260929/context_overlap_audit.json`.

### REAL-Q-LRU-DOCUMENT-HOLDOUT (preregistered 2026-09-29 21:14 IST)

Hypothesis: unchanged actual rotary-query prompt placement plus LRU decode
improves task-balanced quality over K-as-Q prompt placement plus LRU decode on
contexts absent from the earlier development prefix and both prior holdouts.
Freeze: `results/baseline_fidelity/real_query_document_holdout_20260929/manifest.json`
(SHA256 `37dbe68b0e7121502dc64aa13abd4eee36bd1f2209b7989a5c5988cfe3cae01e`).
Python Random seed 20261001 selected four distinct normalized document groups
per task and one row per group, 24 paired rows total; source/row/context hashes
are recorded in the manifest. The four remaining NarrativeQA groups set the
sample size. Run sequential control/candidate with unchanged Mistral checkpoint,
source, seed 0, bf16, 992 fast + 3104 cold rows, 32 cold exposed and 31,500
max context. Primary: equal-weight mean of six within-task paired quality deltas;
support for a positive conditional effect requires a 95% document-group
bootstrap lower bound >0. Report every regression, task delta, prefill cost,
peak memory and paid writes per decode step. The sample is small and reused
for this one test only; no default, SOTA or independent-task claim. Any
substantial gain triggers long-context/long-output stress analysis before
advancement. No STT-RAM bandwidth parameter change.

### REAL-Q-LRU-DOCUMENT-HOLDOUT (outcome 2026-09-29)

All 24 paired rows, six frozen source slices, runtime/config identity,
scores, source/slice hashes, and distinct normalized context groups were
verified by `experiments/report_real_query_document_holdout.py`. Candidate
minus control task-balanced quality was +4.14 points, with a 95% paired
document-group bootstrap interval of [−0.84,+9.01]; the preregistered lower
bound gate failed. Per-task deltas: Qasper +12.44, NarrativeQA −6.25,
MultiFieldQA +9.59, HotpotQA +5.56, TriviaQA 0, GovReport +3.50.
Three of 24 rows regressed, including −19.88 Qasper and −25.00 NarrativeQA.
Candidate median prefill time and peak allocation rose in all six tasks.
Generation lengths changed between arms, so per-decode-step paid-write ratios
are descriptive and cannot establish a matched-output write improvement.
Decision: no-go for a document-level quality replication or default-policy
claim; leave actual-query placement opt-in. Only four documents per task and
one model are represented; semantic near duplicates and training contamination
remain unchecked. Artifacts: `real_query_document_holdout_20260929/manifest.json`,
`control.json`, `candidate.json`, and `report.json`. This one holdout must not
be reused for candidate selection.

Manual loss triage: the −19.88 Qasper case changed the cited MRPC/QQP F1
improvements from +0.58/+0.73 to +0.73/+0.71; the −25 NarrativeQA case
answered “Clarence's trailer” where the reference was “a Detroit theater”
and the control answered “in front of the movie theater.” These are substantive
answer errors, not merely formatting penalties. The small GovReport loss
changed summary content and is less straightforward to classify.

Follow-up placement diagnosis (`experiments/diagnose_prompt_placement.py`):
the Qasper answer span occupies 18 prompt tokens. Under K-proxy placement,
mean hot retention across 32 layers was 13.69/18 and mean permanent drop was
0.03/18; under actual-query placement these were 9.00/18 and 3.00/18.
Neither arm exposed any of the span from the cold tier at the initial step.
Layer 0 changed from 18 hot to 0 hot, 9 cold-hidden and 9 dropped. This is a
credible mechanism for that case's incorrect values, though it does not
isolate causal influence of individual layers. The NarrativeQA meeting scene
is at original token positions 20,410–20,417 of a 77,403-token prompt and is
absent after the shared 31,500-token middle truncation (first/last 15,750).
Its wrong answer cannot be attributed to cache placement from this evidence;
neither arm could access the exact scene. Do not tune a replacement policy on
these held-out questions. Artifact: `real_query_document_holdout_20260929/placement_diagnosis.json`.

### PROMPT-SCORE-MIX-DEV (preregistered 2026-09-29 22:35 IST)

Mechanism hypothesis: a fixed 50/50 mix of normalized actual-query and
K-proxy prompt importance can retain useful spans that actual-query-only
selection discards, without changing the 992 fast + 3104 cold budgets or the
32-row LRU exposure limit. This is an engineering ablation, **not** a novelty
claim: importance/diversity mixing and fine-grained retrieval already exist
in recent prior work. Implement only as an opt-in experimental setting;
default remains unchanged. Screen on the first three development rows each
of Qasper and MultiFieldQA, Mistral-7B-Instruct, bf16, seed 0, L40S GPU0,
max context 31,500; never use document-holdout rows for candidate tuning.
Run actual-query/LRU control and 50/50 candidate with identical source and
settings. Advance to a broader development test only if task-balanced quality
improves by at least +2 points on this cheap pilot **and** median prefill
time rises <5% relative to actual-query-only in both tasks, with no >10-point
new individual loss. Log prefill peak, paid writes, and any source/runtime
changes. The pilot is directional, not inferential; do not claim a default,
Pareto result, or publication value from it. No STT-RAM bandwidth change.

### PROMPT-SCORE-MIX-DEV (outcome 2026-09-29)

The six paired development rows were verified by source dataset hashes,
sample IDs, recomputed scores, and identical runtime/config except the fixed
mix weight. Candidate−actual-query control was **−1.56 task-balanced points**:
Qasper −3.12, MultiFieldQA 0. One Qasper answer lost 9.36 points.
Single-run median prefill increased 1.48% and 0.87% respectively, with
negligible but positive allocator-peak changes. Paid demotion writes rose
5,057→9,293 and 3,424→4,956; generation lengths differed in Qasper, so
these are descriptive totals, not matched-output traffic. The +2 quality
pilot gate failed. **Reject** the fixed 50/50 score mix; do not tune weights
using held-out cases or advance to a larger run. The experimental code was
removed from the live evaluator/policy after a passing 86-test suite; its
exact source files are archived with raw arms and verifier at
`results/baseline_fidelity/prompt_score_mix_dev_20260929/`. The live source
fingerprint returned to `eea0cf48baa0…`; STT-RAM bandwidth is unchanged.

### SHADOW-FIXED-STREAM (preregistered 2026-09-29 22:44 IST)

Hypothesis: inclusive shadowing's large logical demotion-write reduction
persists when both policies consume exactly the same generated token IDs,
removing output-length and token-content confounding from the prior 135-row
comparison. Freeze one 16K real-text prompt and generate a 51-token teacher
stream using the uncompressed Mistral-7B-Instruct model, seed 0, bf16, L40S
GPU0. Replay that stream into matched inclusive and no-shadow policies with
the same 1024 fast + 2048 cold rows, .75 initial cold fill, no STT bandwidth
change, 50 decode forwards. Use ABBA arm order with one warmup and two
measured repetitions per arm; report per-trial paid writes, writes saved,
prompt/decode peaks, TTFT, p50/p95 ITL, and runtime/source hashes. Primary
write gate: at least 20% fewer paid layer-token demotion writes under the
matched stream in every ABBA pair. Timing is descriptive unless at least
three independent measured ABBA blocks are run; this GPU-resident cold tier
cannot support physical STT/endurance claims.

### SHADOW-FIXED-STREAM (outcome 2026-09-29)

The 51-token full-cache teacher stream was replayed identically into both
arms. Every measured 50-step run recorded **2,690** paid inclusive versus
**26,432** paid no-shadow layer-token writes, an **89.82% reduction** in each
of four preregistered ABBA trial pairs; the ≥20% write gate passed. Inclusive
`writes_saved` was 23,742 per run, exactly the paid-write difference.
Prototype median ITL was 82.58 versus 100.99 ms and p95 92.73 versus
125.47 ms; these two ABBA blocks are descriptive and do not establish a
general latency advantage. Median TTFT was 1,997.24 versus 1,996.71 ms,
prefill peak was 18.594 GB for both, and decode peak was 15.118 versus
15.114 GB. Output length/content confounding is removed for this trace;
attention and promotion decisions still differ by policy, as intended.
The cold tier still lives on GPU, so no physical STT-RAM write, energy,
endurance or serving-throughput claim follows. Live cache policy code was
unchanged; the fixed-stream option only extended the measurement harness.
Full suite: 85 passed. Raw and verifier:
`results/shadow_ablation_full/fixed_stream_20260929.json`,
`fixed_stream_report_20260929.json`,
`experiments/compare_shadow_fixed_stream.py`, and
`experiments/report_shadow_fixed_stream.py`.

### DECODE-STRUCTURE-SCREEN (diagnostic 2026-09-29)

The current-source 16K/10-step cProfile localizes roughly 26.9 ms/step
cumulative to `evict_and_demote`, 10.9 ms/step to visible-set construction,
and 7.6 ms/step to `update_scores`; these values overlap and include GPU
waits. Two cheap isolated screens did not show enough headroom for a live
edit. For a 1,024-position CPU protection mask, a NumPy construction took
33.2 µs/call versus 113.2 µs/call with the current PyTorch construction,
projecting only 2.6 ms/step across 32 layers, below the 4 ms screen.
For 32 layers of 8×1,024×128 bf16 hot plus 8×32×128 cold rows,
`torch.cat(..., out=...)` took 0.276 ms/32 layers versus 0.236 ms with
fresh allocation in a ten-block isolated GPU benchmark. Neither change was
applied. The ≥3× gap to faithful SnapKV needs a broader attention/policy
execution redesign, not another one-line allocator or mask tweak.

### ICECACHE-INPUT-FIDELITY (diagnostic 2026-09-29 23:49 IST)

Question: can the released IceCache LongBench data and prompts be used for a
fair direct comparison without silently changing the test? A pinned shallow
checkout of the [official IceCache repository](https://github.com/yuzhenmao/IceCache)
at `6a7ecfd9c710c1b3170b2f5931d048fad0f04b22` was compared with our
local six-task **standard LongBench** files by `experiments/check_icecache_inputs.py`.
All **1,150 standard rows** matched as complete dictionaries in the same
order. This first audit did **not** compare the files selected by the corrected
TieredKV control: its loader prefers the `_e` LongBench-E variant when that
file exists. The first report is superseded for actual-control fidelity by
`icecache_input_audit_v2_20260930.json`, below. Maximum generation lengths
matched on all six tasks. Prompt templates differed on NarrativeQA and
Qasper; the other four matched.
IceCache's released runner also defaults to fp16, whereas the corrected
TieredKV Mistral control uses bf16. Its pinned Python/CUDA stack and external
M-DCI/CUDA dependencies are not installed in the live TieredKV environment.
The runner's `--help` executed, but **no IceCache inference or speed result
has been produced**. This is an input-alignment result, not baseline parity.
For a direct run, use the same model checkpoint and selected requests, align
the two templates and KV dtype, and report actual GPU/CPU bytes and attention
work. Raw checks, hashes and runtime:
`results/baseline_fidelity/icecache_input_audit_20260929.json`.

### ICECACHE-INPUT-FIDELITY correction (2026-09-30)

The v2 audit traced `task_data_path()` rather than assuming the un-suffixed
local JSONL file. The corrected control uses standard NarrativeQA (200 rows),
but `_e` files for Qasper (224 rows), MultiFieldQA (150), HotpotQA (300),
GovReport (300) and TriviaQA (300). Although IceCache's bundled standard
files match our standard files exactly, they do **not** match those five
selected `_e` files; even MultiFieldQA has 150 rows in both variants but
different examples. Its released `parse_args()` forcibly sets `args.e=False`,
so invoking its normal benchmark script with `--e` does not repair this.
A fair direct pilot must supply the exact local `_e` records to IceCache's
model path with our task prompts and the same selected request indices.
The v2 audit uses `read_jsonl()` so Unicode line-separator characters inside
strings are kept as data. Raw corrected report:
`results/baseline_fidelity/icecache_input_audit_v2_20260930.json`.

### ICECACHE-SOURCE-MATCHED-SMOKE (preregistered 2026-09-30 00:15 IST)

Goal: prove that the released IceCache model adapter can process one of the
*actual selected* corrected-control requests, using exactly the control's
prompt and token IDs, before attempting a wider baseline. Freeze the
`multifieldqa_en_e.jsonl` request at zero-based index 9 (1,440 fast-tokenizer
prompt tokens, selected for low setup cost), Mistral-7B-Instruct-v0.2 local
checkpoint, prompt template from `experiments/longbench_metrics.py`, and
greedy generation up to the task's full 64-token limit. Use IceCache release
commit `6a7ecfd9…`, fp16 as in its released runner, page size 16, page budget
16, two unlimited layers, two sink pages, two window pages, 1 GiB allocated
GPU KV pool and 4 GiB allocated pinned CPU KV pool. Seed 0, L40S GPU0.
Run a separate fast-tokenizer pass in the TieredKV environment and require
the exact prompt-ID hash to match; the released IceCache runner uses the slow
tokenizer and its default `[INST]` spacing differs. Record source/environment
hashes, output, score, whole-request latency and GPU peak. Success gate:
model inference finishes, input hash matches, and output/score are
reproducible. These non-resource-matched settings are a **feasibility pilot**;
no superiority or paper-quality claim follows, regardless of score.

### ICECACHE-SOURCE-MATCHED-SMOKE (outcome 2026-09-30)

The pinned IceCache Mistral adapter and its native CUDA/M-DCI extensions built
in an isolated Python environment on the L40S. We ran the registered
MultiFieldQA LongBench-E index 9 twice with the corrected-control prompt
template and the **same 1,440 input token IDs** (SHA-256
`54e41e6b9f3ef83377ff4985916145521fc1eb1ebe33a985cb503d275c10a890`).
Both fresh-process runs generated the same 64-token prediction and the same
single-request F1 score, **10.0/100**. Whole-request wall time was 4.678
and 4.681 seconds; GPU peak allocated was 15.789 GB in both. The success
gate (completion, input identity, reproducible output/score) passed. This is
only a feasibility result. The released IceCache path uses fp16 K/V, stores
CPU K/V as float32, allocates a 1 GiB GPU KV pool and a 4 GiB pinned CPU
pool, and uses a 16-page budget for 30 layers; the TieredKV corrected
control uses bf16 and different budgets/attention width. CPU pool capacity
is **allocated capacity**, not measured live KV residency. The 10.0 score
must not be compared with a TieredKV sample score as a policy effect.

Source, environment, prompt/data/model hashes and both raw runs:
`results/baseline_fidelity/icecache_matched_input_pilot_20260930.json` and
`icecache_matched_input_pilot_repeat_20260930.json`. No TieredKV default or
STT-RAM bandwidth parameter changed.

Follow-up feasibility check: the official IceCache `bf16` branch exists at
`f2afaffcd0959444b778daccbb327fead89e24ca`, but it changes indexing/
CUDA code as well as dtype and hardcodes CUDA architecture 90. The available
L40S reports architecture 8.9. It was **not** compiled or evaluated here;
precision matching remains open.

### ICECACHE-BF16-L40S (preregistered 2026-09-30 00:45 IST)

Question: can the official IceCache `bf16` branch run on the L40S with the
same Mistral prompt IDs as our corrected control? Pin official branch commit
`f2afaffcd0959444b778daccbb327fead89e24ca` in a separate external
checkout. Change only its CMake CUDA target from 90 to 89, matching the
machine's measured compute capability 8.9; record the diff and binary
source hash. Use a separate Python environment with the same pinned
dependencies as the successful fp16 setup. Run the corrected-control
MultiFieldQA-E request index 9 with prompt-ID hash
`54e41e6b9f3ef83377ff4985916145521fc1eb1ebe33a985cb503d275c10a890`,
seed 0, full 64-token greedy limit, and the prior IceCache page and pool
settings; repeat in two fresh processes. Primary gate: build/import succeed,
both runs complete with identical prediction and score, and model/KV are
actually bf16. Record latency and allocation descriptively only. This tests
precision/build feasibility, **not** matched residency, throughput, or
quality superiority. If a runtime/kernel failure occurs, do not patch
IceCache's algorithm during this screen; log and move on.

**Setup correction before model run:** The bf16 IceCache README requires
the *bf16 branch of M-DCI*, not the main M-DCI library used by the fp16
pilot. The CUDA extension compiled, but import with main M-DCI failed at
`ModuleNotFoundError: dci`. Install and pin the official bf16 M-DCI branch
in this isolated environment before interpreting any model result. This is
a dependency mismatch, not an IceCache inference failure. The CPU reports
`avx512_bf16` support.

### ICECACHE-BF16-L40S (outcome 2026-09-30)

**Feasibility gate passed.** The official IceCache bf16 branch
`f2afaffcd0959444b778daccbb327fead89e24ca` compiled with only its
CUDA architecture target changed from 90 to 89; the one-line patch is
archived at `results/baseline_fidelity/icecache_bf16_l40s_arch.patch`.
It used the matching official bf16 M-DCI branch at
`2141a1c842e3420b69843d0c1cd76ccc6ac72dfc`. The latter required a
local GCC 12 C++ toolchain because the machine's default GCC 11 lacks the
released bf16 conversion intrinsic; all build tools remained under
`/data/nishant/tieredkv_external/`. No IceCache retrieval/policy source or
TieredKV source was changed for this test.

Two independent model processes processed the same selected
MultiFieldQA-E index-9 sample and the same 1,440 prompt token IDs as the
corrected control. Both generated exactly the same 64-token prediction,
score **10.0/100**, and 15.788 GB peak GPU allocation. Whole-request time
was 4.686 and 4.569 seconds; these two timings are descriptive. Runtime
introspection verified `torch.bfloat16` for model weights, GPU K/V pool, and
CPU K/V pool. The prior fp16 main-branch pilot happened to produce the same
answer, but the bf16 branch also changes indexing/CUDA code, so this is not
an isolated precision ablation.

Raw results: `results/baseline_fidelity/icecache_bf16_matched_input_pilot_20260930.json`
and `icecache_bf16_matched_input_pilot_repeat_20260930.json`. The executed
runner is archived as `run_icecache_pilot_bf16_executed_20260930.py`
(SHA-256 `383c8c76d4c7a3c3c1ba36158ec376e9b090dba64e0c6ddaaa5198fd2c804c46`).
The native IceCache and bf16 M-DCI extension SHA-256 values are respectively
`0cac8693ca3299e76212fc13ccd37c8ae2f85a6d9b5046c9c741a8e7d3666888`
and `18889752197673b9ca6e567c197a9cc1523988d9fc0b308956bfee504ea3be95`.
Precision is now aligned with TieredKV, but page budget, actual live GPU/CPU
K/V bytes, attention width, software stack, and sample count are not. No
quality, latency, memory, energy or SOTA superiority claim follows.

### CPU-SHADOW-COPY (preregistered 2026-09-29 23:52 IST)

Hypothesis: on the existing opt-in CPU-DRAM cold tier, inclusive backups
reduce explicit GPU-to-CPU K/V payload copies on a fixed decode stream,
relative to the same policy without backups. Use the unchanged Mistral-7B
model, bf16, one fixed 16K prompt and the existing 51-token teacher stream;
50 decode steps on GPU0. Compare `cpu_fast` and `cpu_fast_no_shadow` in ABBA
order, with one warmup and one measured repetition per arm. Both arms use
the same CPU native `index_select` gather and 1024/2048 token budgets.
Record initial prompt CPU writes, total GPU-to-CPU payload bytes, host-to-GPU
payload bytes, logical paid writes, prefill/decode peaks, p50/p95 latency,
predicted IDs, source hash, prompt/stream hashes and runtime. Gate for the
mechanism: ≥20% lower *decode-only* explicit GPU-to-CPU payload bytes in
every paired block; use two ABBA blocks, so latency remains descriptive.
Do not infer STT-RAM page wear or device energy from CPU copies. No STT-RAM
bandwidth parameter changes.

### CPU-SHADOW-COPY (outcome 2026-09-29 23:58 IST)

The exact 16,384-token, 50-step test completed two ABBA blocks (four
inclusive and four no-shadow measured arms). Every arm began with the same
201.327 MB of prompt K/V copied into ordinary CPU memory and read the same
315.621 MB of selected K/V payload back to GPU. Inclusive arms each copied
**11.018 MB** of decode-demotion K/V to CPU versus **108.265 MB** without
shadows: **89.82% fewer explicit decode GPU-to-CPU payload bytes**, passing
the ≥20% gate in every pair. This agrees exactly with 2,690 versus 26,432
paid layer-token writes (4,096 bytes each) on this stream. It measures bytes
passed to explicit PyTorch host-copy operations, **not** PCIe transaction
bytes, CPU internal compaction traffic, STT-RAM page traffic, energy or
endurance. The normal GPU-resident policy is unchanged.

Descriptive median full-loop decode time across the four arms was 93.69
versus 164.82 ms/token; both arms had identical 18.594 GB prefill and
14.910 GB decode allocation peaks. The teacher-forced inputs were identical,
but the two policies disagreed on one of 50 predicted next-token IDs (step
26, one-based); this test does not establish equal answer quality. Only one
prompt/model/GPU and two ABBA blocks were used. A prior smoke/pilot at
16,000 rather than 16,384 prompt tokens is preserved separately and does
not count toward the registered gate. Raw artifacts:
`results/hardware/cpu_shadow_copy_16384_50_20260929.json` and
`cpu_shadow_copy_16000_50_pilot_20260929.json`; the raw configuration records
driver/profile, prompt, stream and runtime hashes.

### ICECACHE-LIVE-RESIDENCY (preregistered 2026-09-30 IST)

Question: for the already matched MultiFieldQA-E index-9 pilot, how many
IceCache K/V pages are occupied after generation, compared with its declared
GPU and pinned-CPU pool capacities? Run the released bf16 branch twice in
fresh processes, unchanged request/prompt/precision/page policy. Record both
pool capacities and occupied page IDs, per-layer GPU and CPU cache page counts,
and CPU index point counts. Require identical input-token hash, prediction,
score and occupied-page counts across the two runs. These are end-of-request
snapshots, not peaks or a matched-resource performance comparison. Native
index metadata and temporary buffers are outside K/V page counts; do not
infer total live memory or physical STT-RAM traffic from them. No STT-RAM
bandwidth parameter changes.

### ICECACHE-LIVE-RESIDENCY (outcome 2026-09-30 IST)

Two fresh bf16 runs of the same 1,440-token prompt and 64-token output agreed
on the token-ID hash, prediction, score (10/100), and every page-accounting
field. IceCache's declared/preallocated GPU K/V pool is 16,384 pages = 1 GiB;
2,888 page IDs = 189.27 MB remained occupied at the final snapshot. Only
668 pages = 43.78 MB belonged to the active per-layer GPU attention caches.
The other **2,220 pages** were prefill-evicted pages retained in the pool's
deferred-free list; `alloc_page()` frees these lazily when the pool runs out.
Their physical allocation is already included in the 1 GiB preallocated
pool. Thus neither 189.27 MB nor 43.78 MB alone is the process's GPU peak.

The pinned CPU K/V pool is preallocated to 65,536 pages = 4 GiB. At the
snapshot, 3,581 page IDs = 234.68 MB were occupied: 3,551 main CPU cache
pages plus 30 offload-window pages. Temporary and neighbour caches were
empty. The DCI index reported 345,600 head-specific points and 26,825
head-specific leaves across 30 indexed layers. Its pointers address CPU
pool pages, so its entries must **not** be added as duplicate K/V payload;
its separate native metadata allocation is not measured by these page counts.
The per-layer vectors and source hashes are in
`results/baseline_fidelity/icecache_bf16_live_residency_detail_20260930.json`
and `_repeat_20260930.json`. Earlier two preliminary snapshots without
deferred-page breakdown are retained under `icecache_bf16_live_residency_*`.
This one short request does not match TieredKV's resource budget or establish
relative quality/latency. The timing window ends before the new end-state
introspection, but these unpaired timings are not used as a speed comparison.

### ICECACHE-LONG-PAGE-STRESS (preregistered 2026-09-30 IST)

Extend the page-accounting check to corrected-source MultiFieldQA-E row 138,
a 15,789-token Mistral prompt (token-ID SHA-256
`66f1b85caf8d6caef6ceff6cc224d1002cfb9c5cd3d24da2cf9af9ed7dc3545b`).
This row was **not** in the corrected 25-row control sample, so this is a
resource stress pilot, not a paired quality comparison. Use the same released
bf16 IceCache branch and page policy; retain the task's 64-token generation
limit. Record end-of-request active/deferred GPU pages, CPU pages and GPU peak
allocation. Gate: generation completes, all page IDs are within pool capacity,
and occupied counts equal the sum of named cache/deferred categories. If
long-prompt behavior disagrees with the short pilot, investigate before
claiming a general memory model. No STT-RAM bandwidth change.

### ICECACHE-LONG-PAGE-STRESS (first attempt and controlled amendment, 2026-09-30 IST)

The released 1 GiB GPU pool failed during prefill with `RuntimeError: Not
enough contiguous free pages in pool` at `KvCache._prefill_alloc_n_pages`.
This is expected to be capacity pressure because a 15,789-token prompt needs
roughly 987 full pages per layer before offload, exceeding 16,384 pool pages
over 32 layers. It is an observed failure of this released configuration, not
proof of algorithmic inferiority. Amend the feasibility test to permit a
4 GiB preallocated GPU pool while keeping the model, row, page budgets,
precision and retrieval policy unchanged. Report the larger pool prominently;
do not compare its peak memory as though it had the 1 GiB setting.

### ICECACHE-LONG-PAGE-STRESS (outcome 2026-09-30 IST)

With the **4 GiB GPU pool**, the same 15,789-token prompt completed; it
generated 47 tokens before end-of-sequence (the task limit was 64) and scored
100/100 on this single row. Peak PyTorch GPU allocation was 20.839 GB and
whole-request time 13.17 s in one descriptive run. At the end, 31,590 GPU
page IDs were occupied: 2,460 active attention-cache pages (161.22 MB) plus
29,130 prefill-evicted pages (1,909.06 MB) still pending lazy release. The
pinned CPU pool had 33,420 occupied pages (2,190.21 MB): 33,390 main cache
and 30 window pages. Both category sums equal their pool occupancy, passing
the registered page-conservation gate. Page capacity bounds also passed.
The GPU and CPU pools themselves were preallocated at 4 GiB each, so the
occupied-page payload figures must not be described as process allocations.

This shows the released 1 GiB pool setting cannot run this long prompt, while
a larger pool can. It also shows why active attention pages, deferred pages,
reserved pools, and whole-process peak must remain distinct in any fair
memory table. This row was outside the frozen 25-row corrected-control
sample; its 100/100 score is **not** a paired TieredKV comparison. Raw
artifact: `results/baseline_fidelity/icecache_bf16_long_page_stress_4g_20260930.json`.

### ICECACHE-TIERED-SAME-ROW (preregistered 2026-09-30 IST)

Run the corrected TieredKV Mistral harness on the **same** MultiFieldQA-E
row 138 as the long IceCache feasibility pilot. Create a one-row copy of the
source JSONL with its source-file hash and row index recorded; use corrected
1024 fast/2048 slow token budgets, bf16, 0.75 initial slow fill, 31,500
maximum prompt tokens, seed 0, and the task's 64-token output limit. Require
the row/sample identity and prompt-token length to match IceCache; compare
prediction, score and generated length descriptively. This is not a fair
quality, latency or memory winner because IceCache has two unlimited layers,
different attended width, a 4 GiB preallocated GPU pool, and a separate
software stack. No claim advances from one row; use it to verify that a later
multi-row paired protocol is executable. No STT-RAM bandwidth change.

### ICECACHE-TIERED-SAME-ROW (outcome 2026-09-30 IST)

The one-row TieredKV harness completed at corrected 1024/2048 logical
fast/slow token budgets. Both runs used the same original row/sample SHA
`0854a09432eba6428764f7a9287eee5dc92450ccb3e61b6504b8831ccb56285d`
and independently verified the same **15,789 prompt token IDs** (SHA-256
`66f1b85caf8d6caef6ceff6cc224d1002cfb9c5cd3d24da2cf9af9ed7dc3545b`).
TieredKV generated 46 tokens and scored **50/100**; IceCache generated 47
and scored **100/100**. The question asks for five Khilafat orders. TieredKV
named Qadiri, Chishti and Naqshbandi but omitted Suharwardi and Madaari;
IceCache named all five. All five names appear in the original context near
character offsets 2,210–2,287 (Qaderi also occurs elsewhere). We have **not
yet traced** which of these token positions TieredKV retained or exposed at
decode, so the precise cause of its omission remains unknown.

The TieredKV sample timing was 6.17 s and IceCache's prior whole request was
13.17 s, but these different stacks and cache/attention budgets make a speed
ranking invalid. IceCache's two unlimited GPU layers plus ~2.19 GB occupied
CPU K/V payload greatly exceed TieredKV's 1024+2048 logical slots in
retained-context capacity. This result is a useful concrete quality failure
case, **not** evidence of comparative SOTA ranking. TieredKV raw result and
the one-row source manifest are in
`results/baseline_fidelity/icecache_tiered_row138/`; the IceCache raw result
is `results/baseline_fidelity/icecache_bf16_long_page_stress_4g_20260930.json`.

### FIVE-ORDER-SPAN-TRACE (preregistered 2026-09-30 IST)

For the same row-138 TieredKV failure, rerun only the corrected prefill path
and inspect each layer's fast positions, slow positions and initially visible
slow positions. Locate the five-order evidence span in exact tokenizer
offsets. Report, per layer, whether every evidence token is fast, retained
slow, exposed slow, or dropped. This can test the cache-placement hypothesis,
but it cannot prove why the model generated a particular answer without
causal intervention. Keep configuration and model unchanged; do not alter
the default policy or infer physical STT-RAM behavior.

### FIVE-ORDER-SPAN-TRACE (outcome 2026-09-30 IST)

The frozen prompt-token SHA matched the paired runs. Tokenizer offsets map
the source sentence from Qaderi through Madaari to **35 prompt token
positions**. After the corrected TieredKV prefill and its 1024-fast/1536-
initial-slow placement, **all 35 positions were dropped in all 32 layers**:
zero fast, zero retained slow, zero visible slow. This proves the specific
evidence span could not be read from TieredKV's cache during decode or later
promoted. It does not prove that losing the span is the only cause of the
answer difference, because information can also persist in hidden states or
other retained tokens. It does identify prompt placement/retention as a
plausible target for a controlled fix. A proposed method must select useful
evidence without knowing the reference answer; an answer-span oracle is only
an upper bound, not deployable. Raw per-layer evidence and exact runner hash:
`results/baseline_fidelity/icecache_tiered_row138/five_order_span_trace.json`.

### FIVE-ORDER-ORACLE-UPPER-BOUND (preregistered 2026-09-30 IST)

On the same row 138, test whether retaining the already identified 35-token
source sentence is sufficient to repair the missing two names. In an
isolated diagnostic script only, compute the unchanged K-proxy prefill
importance and elevate those 35 token positions above the current maximum
before the ordinary fixed-capacity bifurcation. Keep 1024 fast/2048 slow
budgets, model, prompt, output limit and decode policy unchanged. Verify the
same prompt hash, all 35 positions fast in all layers, and record the answer,
score and displaced-content implications. This is a *reference-informed
oracle* and must never be called a deployable selector or paper result. If
the answer does not improve, losing the span was not sufficient to explain
the failure. No STT-RAM bandwidth change.

### FIVE-ORDER-ORACLE-UPPER-BOUND (outcome 2026-09-30 IST)

The no-boost wrapper reproduced the frozen TieredKV answer byte-for-byte:
three names, 46 generated tokens, **50/100**. Boosting only the known
35-token source sentence within the same 1024-fast/2048-slow limits put all
35 positions in the fast tier in all 32 layers. It generated 47 tokens,
named all five orders, and scored **100/100**. Both arms used identical
15,789 prompt token IDs and the same diagnostic runner source hash. This
shows that preserving the source passage is **sufficient in this one
controlled intervention** to repair the observed answer. The intervention
also displaces 35 other fast-tier positions under the fixed budget; it does
not isolate which individual token or layer matters.

This is an answer-informed oracle upper bound, **not** a deployable or
generalized quality result. A useful algorithm must identify relevant
content from the question/prompt alone and avoid the Qasper factual losses
already seen with actual-query placement. Raw paired artifacts:
`results/baseline_fidelity/icecache_tiered_row138/five_order_no_boost_control.json`
and `five_order_oracle.json`; executed source:
`experiments/probe_five_order_oracle.py`.

### QUESTION-LEXICAL-SCREEN (preregistered 2026-09-30 IST)

Test a deployable, answer-free prompt-passage signal before any model edit.
For the row-138 MultiFieldQA question, tokenize the **question only** into
lowercase word terms, remove a fixed small stopword list, and rank 128-token
prompt windows by overlap with those terms weighted by inverse document
frequency across prompt windows. Choose the top one window without using
reference answers or the known source sentence. Only after ranking, measure
how many of the 35 known evidence tokens that window covers. Cheap screen
gate: at least 30/35 evidence tokens covered with only 128 reserved slots.
If it fails, reject this simple lexical signal before a GPU/model run.
Passing only supports a full same-budget model pilot; it is not a quality
result or proof of novelty. The existing real-query and fixed-score-mix
failures require broader regression checks before any default change.

### QUESTION-LEXICAL-SCREEN (outcome 2026-09-30 IST)

The answer-free selector ranked 245 context-only windows using six normalized
question terms and chose token positions **654–781**. The known evidence
sentence spans tokens **770–804**, so the selected 128-token window covered
only **12/35** evidence tokens. It contained every query term but cut the
answer-bearing sentence at the window boundary. The preregistered ≥30/35
coverage gate failed; reject this fixed-window lexical selector before GPU
evaluation. Widening or shifting this one selected window after inspecting
the answer would overfit this diagnosed case. A future sentence-aware method
must be specified before a new, disjoint development/holdout evaluation.
Raw report and exact selector hash:
`results/baseline_fidelity/icecache_tiered_row138/question_lexical_screen.json`;
source: `experiments/screen_question_lexical.py`. No default code changed.

### QUESTION-PASSAGE-SCREEN (preregistered 2026-09-30 IST)

Pivot from the rejected fixed-window selector to a boundary-aware, answer-
free screen. Freeze 12 previously unused **documents** each from
MultiFieldQA-E and Qasper-E, excluding the first 25 development rows, both
prior holdout manifests, the document holdout, and row 138; select by a
fixed random seed without looking at questions or answers. Rank sentence-
bounded context passages by the same six-word-style normalized question
overlap/IDF rule, reserve at most 128 token positions around the top-ranked
sentence, and compare with the prior best 128-token sliding-window rule.
Evaluate only rows where an answer string occurs verbatim in the context;
report how many rows are ineligible. Primary cheap gate: passage method must
cover the answer substring on more evaluable rows than the fixed-window
method with the same 128-token budget, with no drop in coverage on any
evaluable Qasper row. This is a retrieval screen, not a model-quality or
novelty claim; if it fails, reject before GPU use. No default policy or
STT-RAM parameter changes.

### QUESTION-PASSAGE-SCREEN (measurement definition before scoring)

The frozen manifest is
`results/baseline_fidelity/question_passage_holdout_20260930/manifest.json`
(12 unique previously unused contexts per task). For the exact-substring
proxy, ignore reference strings shorter than eight characters and the
literal labels yes/no/unanswerable, since those can match unrelated text.
Count a row as evaluable only when at least one remaining answer appears
case-insensitively in the untruncated context and fits within 128 model
tokens. A selected passage counts as covering evidence only if its entire
answer occurrence is inside the selected 128-token range. If too few rows
are evaluable, report that limitation; do not infer model quality.

### QUESTION-PASSAGE-SCREEN (outcome 2026-09-30 IST)

All 24 frozen rows were processed. Only 1/12 MultiFieldQA and 8/12 Qasper
rows had an evaluable exact answer substring under the preregistered proxy.
At the same 128-token window limit, fixed windows covered 1/1 and 2/8;
sentence-centered passage windows covered 1/1 and 3/8, with no new Qasper
coverage loss. The narrow +1 Qasper gain passes the stated cheap retrieval
gate, but 15/24 rows are unlabeled by this proxy and 5/8 evaluable Qasper
answers remain missed. This justifies a *model-quality pilot*, not a quality
claim or default change. Frozen manifest, answer-free selection-only ranges,
and labeled report are under
`results/baseline_fidelity/question_passage_holdout_20260930/`.

### QUESTION-PASSAGE-MODEL-PILOT (preregistered 2026-09-30 IST)

Run **all 24 frozen questions**, not only the nine exact-substring rows,
through current Mistral/TieredKV twice: unchanged K-proxy placement versus
the selected 128-token answer-free passage boosted above K-proxy scores at
prefill. Both have 1024 fast/2048 slow slots, bf16, 0.75 slow initial fill,
same greedy decode and 31,500 max prompt tokens. Precomputed passage ranges
come from `selections.json`, which contains no answers. Primary pilot gate:
task-balanced score improves by at least +2 points **and** no individual
question loses more than 10 points. Report each task and every regression,
input IDs, selected ranges, generation lengths, and final resident counts.
Timing excludes passage-selection preprocessing and thus cannot establish a
latency gain. A passing 24-row pilot still requires disjoint validation,
end-to-end timing, resident-byte and write checks before promotion. Do not
alter the default policy or STT-RAM bandwidth.

### QUESTION-PASSAGE-MODEL-PILOT (outcome 2026-09-30 IST)

The exact 24 frozen rows completed. Independent score recomputation,
sample/data/selection hashes, identical paired prompt-token hashes, and
128 selected fast positions in all 32 layers passed the verifier. The
candidate beat unchanged placement by **+10.95 MultiFieldQA** and
**+6.72 Qasper** task points, or **+8.84 task-balanced**. A paired,
within-task bootstrap interval conditional on these two fixed tasks and
24 documents is **[+2.25,+16.86]**. There were 9 wins, 4 losses and 11
unchanged rows; no loss exceeded 10 points. The predeclared quality-pilot
gate passed. Gains were concentrated in a few rows, including a substantive
Qasper answer correction; several other changes reflected answer wording.

This is **not yet a default, SOTA, or Pareto result**. The model-loop timing
excluded CPU passage selection; generation lengths differed, and arm order
was fixed. Final fast cache slots matched at 32×1024, but final slow rows,
peak allocation, write traffic and real physical-tier cost have not been
resource-matched. The selector was devised after the diagnosed row-138
failure, though the 24 frozen documents are distinct from prior development
and holdout documents. A second disjoint validation and stress set is needed
before a general quality claim. Raw arm records and verified report:
`results/baseline_fidelity/question_passage_holdout_20260930/`.

### QUESTION-PASSAGE-SELECTION-COST (preregistered 2026-09-30 IST)

On the same 24 frozen prompts, time the exact answer-free selection pipeline
once per prompt after one warmup: fast tokenizer with offsets, sentence
splitting, IDF scoring and 128-token range choice. Check each chosen range
against frozen `selections.json`; record p50/p95 CPU wall time and per-task
breakdown. Feasibility gate: combined median selection time <5% and p95
<10% of the corresponding control model-loop times. Those ratios are only
a screen because model-loop timing excludes loading and may vary with output
length; later end-to-end paired TTFT/prefill/throughput checks remain
necessary. No policy or STT-RAM parameter change.

### QUESTION-PASSAGE-SELECTION-COST (outcome 2026-09-30 IST)

The timed selector reproduced all 24 frozen token ranges exactly. Its
median CPU wall time was 23.67 ms on MultiFieldQA and 12.84 ms on Qasper;
the corresponding nearest-rank p95 values were 77.66 and 19.79 ms.
Across 24 per-row ratios to the control model loop, median was **0.52%**
and p95 **1.38%**, passing the <5%/<10% feasibility screen. This includes
fast-tokenizer offset mapping, sentence splitting, IDF ranking and selection;
one warmup preceded measurement. It was measured once per prompt, outside
the model run and without an ABBA timing design. Do not claim an end-to-end
latency improvement, p95 serving guarantee or overlap from this screen.
Raw report: `results/baseline_fidelity/question_passage_holdout_20260930/selection_cost_report.json`.

### QUESTION-PASSAGE-REPLICATION (preregistered 2026-09-30 IST)

Freeze another 12 MultiFieldQA-E and 12 Qasper-E questions from documents
not used in the original development prefix, prior real-query holdouts,
first passage pilot, or diagnosed row 138. Seed 20261003; select documents
before reading answers. Reuse the **unchanged** sentence/IDF selector and
128-token fast-cache boost, 1024 fast/2048 slow slots, bf16, 0.75 slow fill,
Mistral, greedy decoding and per-task output limits. Include all 24 rows
regardless of exact answer-substring eligibility. Primary replication gate:
task-balanced paired score bootstrap lower 95% bound >0 and no individual
loss >10 points. Check source/data/sample/selection hashes and all paired
prompt token IDs. If the gate fails, do not promote the candidate even if
the original pilot passed. This quality test does not establish latency,
energy, write or SOTA superiority. No default or bandwidth change.

### QUESTION-PASSAGE-REPLICATION (outcome 2026-09-30 IST)

All 24 newly frozen, document-disjoint questions completed. The verifier
checked the manifest, source slices, selected token ranges, sample IDs,
identical paired prompt-token hashes, score recomputation, and all 128
boosted prompt tokens in every layer. Candidate−control was **+2.35** on
MultiFieldQA and **+0.08** on Qasper, or **+1.22 task-balanced**. The paired
within-task 95% bootstrap interval was **[−0.43,+3.27]**. No individual
loss exceeded 10 points, but the required lower bound >0 failed. In the
independent exact-answer retrieval proxy, sentence passages gave no advantage
over fixed windows: 2/3 versus 2/3 MultiFieldQA hits and 0/5 versus 0/5
Qasper hits among evaluable rows. Thus the large first-pilot gain did **not**
replicate on new documents. **No-go for default promotion or a generalized
quality claim.** Do not tune the selector on this replication set; preserve
it as a rejected approach and pivot to a different mechanism. Raw manifest,
selection-only ranges, paired outputs and verified report:
`results/baseline_fidelity/question_passage_replication_20260930/`.

### FLEXICACHE-RESOURCE-PREFLIGHT (preregistered 2026-09-30 IST)

Audit the released FlexiCache source before attempting to compare write or
quality numbers. Freeze its Git commit, official Mistral script settings,
head-profile key/count, host-pool configuration, and local machine
capabilities. Compute *analytical KV payload only* for the same 15,789-token
Mistral prompt and the standard 16-token page/64-page top-K/64-unstable-head
configuration; separate stable-head host copies, unstable-head GPU full
context, and stable-head GPU top-K pages. Compare these with TieredKV's
1024-fast/2048-slow **logical** capacity, but do not call them measured
process allocations or equal-quality budgets. Verify from released code
whether full pages are copied to host once and whether the default host pool
is preallocated. Use the result to decide whether a faithful L40S pilot is
feasible, and state what source/environment adaptation it would require.
No STT-RAM bandwidth change or headline superiority claim.

### FLEXICACHE-TRANSFER-FEASIBILITY (preregistered 2026-10-01 IST)

Complete the pending resource preflight against the pinned FlexiCache checkout
at `ab0f495b10fc6509c1637af35779b29121fb7d3f`. Preserve the original report;
record the local GPU, host memory, CUDA toolchain, pool-allocation source and
offload-kernel hashes in a new report. Then compile the released D2H mapping,
D2H transfer and H2D transfer kernels unchanged for L40S compute capability
8.9, using the existing TieredKV environment in an isolated extension directory.
Use small pinned buffers only. Test fp16 and bf16 K/V, two requests/layers,
nonzero layer offsets, unstable-head exclusion, consecutive completed-page
ranges, empty ranges, chunked transfers and background-stream completion.
Gate: exact source/destination pairs and byte-identical K/V, including untouched
rows. Record build failure rather than patching upstream algorithms. This
checks transfer-kernel feasibility only, not full vLLM compatibility, the
180 GiB pinned pool, model quality, latency, throughput or physical STT-RAM.

### FLEXICACHE-RESOURCE-PREFLIGHT (outcome 2026-10-01 IST)

The original payload arithmetic and all original input hashes reproduce
unchanged against released commit `ab0f495b10fc6509c1637af35779b29121fb7d3f`.
For the 15,789-token prompt, the 64 unstable heads require 517,373,952
analytical GPU K/V bytes; 192 stable heads' 64 selected 16-token pages
require 100,663,296 GPU bytes and their 15,776 completed prompt tokens
require 1,550,843,904 host bytes. Total is 2,168,881,152 bytes, versus
TieredKV's 402,653,184-byte logical ceiling. This excludes partial pages,
generated tokens, metadata, reserved pools and prefill/temporary buffers;
it is not measured allocation or an equal-resource quality comparison.

The source allocates a 180 GiB pinned CPU pool with `torch.zeros`, independent
of occupied KV. Available local host RAM exceeds this configured capacity,
but allocating/pinning the full pool was not tested. L40S is compute
capability 8.9 with local CUDA 12.4; the published setup uses H100 and the
modified vLLM requires torch 2.6.0. The live TieredKV environment uses
torch 2.5.1+cu124 and was not changed. A full engine build therefore belongs
in an isolated environment. GPU1 remains occupied by an unrelated job.
The new report records source hashes, hardware snapshots, memory limits and
toolchain rather than treating the 180 GiB pool as useful live payload:
`results/baseline_fidelity/flexicache_resource_preflight_v2_20261001.json`.
Original September evidence remains intact.

### FLEXICACHE-TRANSFER-FEASIBILITY (outcome 2026-10-01 IST)

The released D2H mapping/copy and H2D copy kernels compile unchanged for
`sm_89` and pass exact fp16/bf16 checks on GPU0. Two requests and two layers
exercise nonzero physical-page offsets and skip unstable heads. Consecutive
completed-page intervals emit exactly 8, 6 and 0 pairs, without recopying
prior pages. Chunk size 2 and background-stream event handoff preserve K/V
and every untouched page in both directions. Each test uses only a 256 KiB
pinned buffer. Source and binary hashes are recorded. This passes the
registered **kernel-only** gate; full modified-vLLM integration, the large
pinned pool, Mistral quality, resource fairness and serving metrics remain open.

The first attempt failed before compilation because `ninja` was absent from
PATH; its failure JSON is preserved. Reusing the existing isolated IceCache
environment's ninja binary fixed setup without changing packages or upstream
source. Reproduce from `kv_cache/`:

```bash
PATH=/data/nishant/tieredkv_external/icecache_bf16_venv/bin:$PATH \
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES=0 \
../venv_kvcache/bin/python experiments/check_flexicache_transfers.py \
  --output /tmp/flexicache_transfer_check.json \
  --build-dir /data/nishant/tieredkv_external/flexicache_transfer_build_20261001
```

Use a new output path; both checks now refuse to overwrite existing evidence.
Raw results: `flexicache_transfer_check_20261001.json` (setup failure),
`flexicache_transfer_check_v2_20261001.json` (passed) under
`results/baseline_fidelity/`. No default cache policy, STT bandwidth,
or archived model result changed. Next: isolated modified-vLLM build and
one identical-token Mistral request before broader baseline evaluation.

Fresh-process repeat `flexicache_transfer_check_repeat_20261001.json` is
identical to the passed report, including checks and binary hashes. The
executed runner hash and both binary hashes verify against disk. Full local
suite: **87 passed** (one existing dependency deprecation warning); compilation
checks pass. Two regression tests verify that preflight/transfer commands
refuse existing output paths without modifying their contents.

### FLEXICACHE-ENGINE-L40S (preregistered 2026-10-01 IST)

Build the released modified vLLM at `ab0f495b10fc6509c1637af35779b29121fb7d3f`
in a detached external worktree and a new Python environment. Keep torch
2.6.0+cu124 and transformers 4.50.0; target CUDA architecture 8.9 on GPU0.
Do not change TieredKV packages or the upstream attention/selection policy.
First gate: native build/import succeeds and reports the released source.
Then use exactly the 1,440 prompt token IDs of the earlier MultiFieldQA-E
index-9 pilot, bf16, seed 0 and the full 64-token output limit. Retain the
released 64 unstable heads, 64-page selection and 16-step rerank frequency.
Record any explicit pool/serving configuration adaptation and actual allocated
GPU/host resources. Require completion and identical input-token hash in two
fresh processes; report output reproducibility, source/runtime and resource
limits. This is feasibility only, not an equal-resource quality or performance
claim. Preserve failed builds/runs. No STT-RAM bandwidth change.

### FLEXICACHE-ENGINE-L40S (setup checks, 2026-10-01 IST)

The isolated torch 2.6.0+cu124 runtime passes a bf16 tensor check on
GPU0, the L40S with capability 8.9. `sha256sum -c
results/baseline_fidelity/model_sha256.txt` passes for all three Mistral
weight shards, model config and tokenizer. The unchanged source build
remains queued behind dependency installation; no serving-engine import
or model result has passed yet. Package index resolution lacked released
xgrammar 0.1.16, so the installer builds its exact upstream tag commit
`989222175c2a30fb7987d8bcce35bec1bf6817f2` rather than changing the version.
Resumable setup state is recorded in
`results/baseline_fidelity/flexicache_engine_setup_20261001.json`.

### FLEXICACHE-ENGINE-L40S (build failure and environment retry)

Dependencies installed successfully. The first native build failed before
compilation: setup selected CUDA 12.4 via torch, but CMake selected
`/usr/bin/nvcc` 11.5 and omitted the requested FA3 target. Preserve the full
log `flexicache_engine_build_20261001.log` in the external build directory.
Retry with CUDA_HOME and CUDACXX pointing explicitly to `/usr/local/cuda`
12.4, and its bin directory preceding `/usr/bin` on PATH. No upstream
source or cache policy modification; use a separate v2 build log.

The CUDA 12.4 environment retry reached native CUDA compilation (the
initial FA3-target failure is resolved). The upstream worktree is still
clean. Full build/import and paired model feasibility remain pending.
The isolated dependency freeze is saved as
`/data/nishant/tieredkv_external/flexicache_environment_20261001.txt`.

Two fresh-process feasibility runs are queued after the active native
build. A strict import/source/version check must pass first; any error
stops the launcher. Both runs use the preregistered exact 1,440-token
request and unchanged released pool configuration. All logs and outputs
have separate paths; import and pilot outcomes remain unproven. The
launcher path and live session are stored in the resumable setup report.

### FLEXICACHE-PILOT-RESOURCE-OBSERVATION (preregistered 2026-10-01 IST)

Before the queued feasibility runs begin, add observation-only hooks to
the pilot runner. Count submitted paired K/V page copies and payload bytes
at the unchanged native D2H/H2D entrypoints; these exclude bus/controller
amplification and energy. Sample GPU/CPU/minmax allocated block counts
after each scheduler allocation, including pending prompt-release pages.
Keep reserved tensor pools separate from these scheduling snapshots; do
not label snapshots as continuous peak memory or useful token occupancy.
No additional GPU synchronization, attention or selection change. Require
a small passthrough/counting regression check and the same two-process
feasibility gates. Whole-request time includes observation overhead and
is not a baseline speed claim.

The observation regression passes: native call arguments and return
objects are preserved, empty mappings add zero payload, three paired
bf16 16x128 K/V pages count as 24,576 bytes, and scheduler snapshots
separate pending-release GPU pages. Four focused FlexiCache tests pass
(one existing dependency warning); runner compilation and diff checks
pass. The native build and queued two-process pilots remain live.

The full local suite now passes **89 tests** (one existing dependency
warning). The isolated transformers 4.50.0 tokenizer independently
produces exactly 1,440 IDs with SHA256
`54e41e6b9f3ef83377ff4985916145521fc1eb1ebe33a985cb503d275c10a890`.
Native serving-engine and paired pilot gates remain pending.

The queued runner now also pins CUDA_HOME/CUDACXX to CUDA 12.4,
TORCH_CUDA_ARCH_LIST to 8.9 and MAX_JOBS to 8 before importing vLLM,
so its JIT transfer kernels use the same intended toolchain. It records
the hashes of the four loaded transfer/mapping extensions. Final checks
after this change: **89 passed**, runner compilation and diff checks pass.

### HOST-HOT-SCORE-SCREEN (preregistered 2026-10-01 IST)

Hypothesis: host-resident hot cumulative scores/ages, fed by one batched
attention-frame transfer, can remove enough per-layer GPU bookkeeping
to justify a real-cache prototype. Keep cold LRU on GPU: the harness
uses unstable sorting there, so moving it would change tie selections.
First perform a synthetic arithmetic screen only: seed 0, 32 layers,
1,025 rows (992 hot slots plus 33 overflow), float32 scores/ages and
tie-heavy inputs, 33 victims, hard/grace masks. Require exact score and
stable-victim parity CPU versus GPU; reject at any mismatch. Time both
paths with one bulk D2H attention copy charged to the host arm; require
at least 4 ms/step headroom before implementing a real-cache prototype.
Synthetic timing is not full-loop speed evidence. If the screen passes,
require real-model placement/tensor/counter/output parity at 4K/8K/16K,
then the standard three-block ABBA 5% median / 2% p95 gate. No default
policy or bandwidth change from this screen. GPU0 only, project torch
2.5.1 environment; no overlap with the queued model pilots.

### HOST-HOT-SCORE-SCREEN (outcome 2026-10-01 IST)

Synthetic scores, ages and stable victim lists match exactly between
CPU and GPU. Device bookkeeping took 6.009 ms versus 3.277 ms for host
bookkeeping including the batched 131,200-byte attention copy: **2.732 ms
headroom**, below the preregistered 4 ms gate. Reject this isolated
mechanism; no real-cache implementation, ABBA or default change. This
screen does not establish real-model policy parity or complete decode
latency. Artifact: `results/baseline_fidelity/host_hot_score_screen_20261001.json`;
executed source: `experiments/probe_host_hot_scores.py`. GPU0 returned
to its prior 16 MiB footprint before any queued model pilot started.

Screen runner hash verifies against disk. Full suite after adding its
frozen-output guard: **90 passed** (one existing dependency warning);
compilation and diff checks pass. The FlexiCache worktree remains clean,
and its native build and queued pilot launcher remain live.

### FLEXICACHE-ENGINE-L40S (interrupted build recovery, 2026-10-01 IST)

Subsequent process and session checks confirmed both the build and queued
launcher were gone. Native `import vllm` failed: installation had not
completed. The v2 log contains no terminal failure, so the termination
cause is unknown. Retained Ninja evidence contains 223 completed entries;
preserve the original logs and reuse that build directory instead of
recompiling completed work. A detached recovery runner resumes the same
targets with four jobs, runs the release's CMake component installs,
generates unchanged-source package metadata and adds an editable source
path in the isolated environment. It then invokes the existing strict
native import and two-process pilot gates. No algorithm/source change or
precompiled external wheel. Recovery log and live phase state:
`/data/nishant/tieredkv_external/flexicache_engine_resume_20261001.log` and
`flexicache_resume_status_20261001.json`. Native import and model outcomes
remain pending; the broad baseline milestone remains unchecked.

### CPU-SLOT-TRANSFER-SCREEN (preregistered 2026-10-01 IST)

Screen one storage mechanism before editing the real cache: pinned physical
host slots, recycled by logical mapping, read/written by the already verified
unchanged FlexiCache CUDA transfer kernels with one-token pages. Compare
against the current CPU-fast packed append/index_select/to-CUDA operations.
Seed 0, bf16, 32 layers, 8 KV heads, dimension 128, 1,536 initial rows,
2,081 reserved slots, 16 append-one/read-32 steps, three ABBA blocks.
Charge mapping uploads, paired GPU packing, native launches and completion
synchronization. Keep the same per-layer dispatch ordering in both arms;
no cross-layer batching assumption. Require exact every-step reads and final
K/V including a separate full-capacity recycle/empty-read correctness check.
For implementation consideration require at least 5% median gain with p95
no worse than +2%, and report reserved versus occupied host bytes. Reject
on mismatch or a failed speed gate. This is a storage-only CPU-DRAM screen,
not model/policy parity, physical STT traffic, energy or whole-loop latency.
No cache/default edits; use GPU0 only while native compilation is CPU-only.

### CPU-SLOT-TRANSFER-SCREEN (initial evidence and corrected screen)

Every-step reads and final K/V passed exact parity, including full-capacity
recycling and empty reads. Initial storage medians were packed 14.325 ms
versus slots 5.468 ms, but these are not an admissible speed-gate result:
the first packed arm was abnormally slow (120.07 ms median versus
12.65–18.61 ms later), and paired GPU input was supplied prepacked to the
candidate. Preserve raw JSON and executed initial source. Before any model
implementation, correct the control to separate K/V copies and charge
candidate `torch.stack` packing; add four excluded warmup steps to each
arm, then measure the same 16 steps over three ABBA blocks. Retain all
warmup timings separately. Same 5% median / 2% p95 and exact-parity gates;
initial run does not justify promotion.

### CPU-SLOT-TRANSFER-SCREEN (corrected outcome 2026-10-01 IST)

The corrected screen passes every-step and final exact K/V parity, including
full-capacity recycling and empty reads. Each measured arm excludes four
warmup steps and includes 16 steps, with separate K/V copies in the packed
control and charged GPU packing in the slot arm. Three ABBA block packed /
slot medians: 20.254/6.767, 13.803/6.737, 13.803/6.772 ms. Pooled median
13.891/6.759 ms (51.34% lower); p95 27.166/6.841 ms. The packed path still
has allocation variability; even later-block medians favor the candidate.
Reserved slot host capacity is 272,760,832 bytes versus 203,948,032 bytes
occupied after 20 steps; packed reserved equals occupied. No default/cache
implementation change. The storage screen permits a real-cache trial,
which still requires exact placement/counter/model output parity and
whole-loop latency/memory gates. Source hash matches disk. Raw corrected
artifact: `results/hardware/cpu_slot_transfer_screen_v2_20261001.json`.
The initial unqualified timing and source snapshot remain preserved.

Full-suite verification initially exposed an existing stochastic test
assumption: the random tiny model can emit tokenizer EOS on prefill,
leaving the position test with no decode observations. Its isolated rerun
passed, consistent with the RNG/order-dependent failure. Fix only that
position test by disabling its stub EOS and requiring exact decode positions
120,121,122,123; production EOS handling is unchanged. Final full suite:
**91 passed**, one existing dependency warning. Frozen-output guard includes
the new storage screen; compilation and diff checks pass. The detached
unchanged-source native build remains live and has completed 10 of its
63 remaining Ninja steps at the latest process check.

### CPU-SLOT-REAL-CACHE (preregistered 2026-10-01 IST)

Advance the corrected storage screen through the responsible storage seams:
paired cold select/append/compaction hooks in the cache and real-model
visibility, with existing tensor operations as their default implementations.
The opt-in native pinned-slot cache owns logical-to-physical mapping,
registers the correct per-layer host pool before reads (native module has a
single cached pointer), and keeps pinned pools alive through recorded CUDA
completion events. Logical row counts come from positions, never reserved
capacity. Explicit canonical K/V inspection and simulator sketches must
also return the right logical rows. Reserve cold capacity plus hot capacity
plus one transient row, report this capacity separately, fail rather than
silently expanding it, and support the tested bf16/fp16 storage formats only.
No selection, score, dtype, bandwidth or default-policy change.

Before model timing, require synthetic full-cache parity against CPU-fast
for inclusive and exclusive modes, growth/saturation, promotion/peek,
compaction, alternating pools and close/reset ownership. Then require
same-model 4K/8K/16K fixed-input parity of selected/retained positions,
K/V, score/age/shadow metadata, policy/write counters and predicted tokens.
A 4K/five-step pilot may detect failures early; only after parity passes
run 16K/50-step CPU-fast/slots/slots/fast ABBA in three blocks. Gates:
>=5% median ITL gain, p95 <=2% worse, identical whole-loop policy/output
and transfer payload. Record prefill/decode/final GPU allocation, occupied
and reserved host bytes, explicit transfers and reset completion. No
baseline-quality or STT controller/energy claim from this CPU-DRAM trial.
Preserve failure evidence; do not promote a failed candidate.

### CPU-SLOT-REAL-CACHE (parity milestones 2026-10-01 IST)

The opt-in backend implements the paired seams and canonical CPU inspection;
GPU policy metadata and selection remain unchanged. Four synthetic cases
(two layers each, 24 steps, inclusive/exclusive, 75%/full initial fill)
passed exact every-step K/V/position/score/age/shadow/counter and payload
checks, including alternating host pools, reversed/repeated/empty reads,
promotion/peek, growth/compaction, capacity failure and idempotent close.
A corrected reset check explicitly starts with a nonempty asynchronous host
write and a recorded completion event, then verifies pool release on reset.
The earlier synthetic artifact is preserved; it had tested reset with an
empty cold tier and did not prove that completion case.

Real Mistral fixed-stream 4K, 8K and 16K five-step parity pairs passed:
full final tensor/metadata/metric digests, every visibility frame's retained
and selected positions/shadows, predicted tokens, policy/write counters and
explicit H2D/D2H payload are identical. Pilot timing is descriptive, not
acceptance evidence. At 4K both arms hold 206,286,848 cold bytes; the native
pool reserves 402,784,256 bytes for transient append headroom. Final GPU
allocation differs by only 63,488 bytes. This is ordinary pinned CPU DRAM,
not a physical STT device. No default change. The three-block 16K/50-step
ABBA latency gate is now running with one full excluded warmup per arm.
GPU0 model jobs use a shared advisory lock, including the queued FlexiCache
pair, to avoid overlapping memory use.

Raw: `results/hardware/cpu_slots_synthetic_parity_v2_20261001.json`,
`cpu_slots_model_pilot_4k_20261001.json`,
`cpu_slots_model_parity_8k_16k_20261001.json`.
Full local suite after adding frozen-output guards: **93 passed**, one
existing dependency warning; compilation and diff checks pass.

### CPU-SLOT-REAL-CACHE (full-loop outcome: rejected, 2026-10-01 IST)

All twelve 16K/50-step arms passed exact final K/V/metadata/metric state,
visibility history, predicted tokens, write/promotion counters and transfer
payload parity after one excluded full warmup per arm. Block fast/slot
medians: 88.622/88.918, 90.604/88.600, 89.899/88.756 ms/token.
Pooled median 89.228/88.918 ms (only 0.35% lower), below the unchanged
5% gate; p95 110.828/101.850 ms. Each arm paid 2,690 logical writes.
Slots reserve 402,784,256 host bytes for 212,344,832 occupied bytes after
50 steps, versus packed reserved equal to occupied. **Reject** rollout:
storage-only savings did not carry through the whole loop.

Preserve exact executed sources and source hashes in
`results/hardware/cpu_slots_rejected_source_20261001/`, plus a complete
source bundle `cpu_slots_executed_source_20261001.tar.gz`. Restore the two
active cache/harness files byte-for-byte to their pre-trial snapshots and
remove the rejected adapter/drivers from active experiments. The standalone
storage screen remains runnable and its history remains valid; it does not
prove speed improvement. No default policy, selector, dtype or bandwidth
change. Post-restoration full suite: **91 passed**, one existing warning.
Raw: `results/hardware/cpu_slots_abba_16k_50_20261001.json`.

### FLEXICACHE-ENGINE-L40S (native import passed; runtime resolver failure)

The retained-object recovery completed all native build/install targets.
The frozen worktree remains clean. Strict import passes against the exact
worktree, torch 2.6.0+cu124 and transformers 4.50.0; native _C SHA256 is
`d2a3942212099f65406a2f9abda59cf6e517489472b2b8bccc8a460b385fb4cf`.
Evidence: `results/baseline_fidelity/flexicache_engine_import_20261001.json`.
The first exact-token model pilot failed before model load in stream-priority
initialization; preserve its failure JSON/log. No second pilot ran.

Diagnosis: upstream `ctypes.util.find_library('cudart')` resolves
`libcudart.so.13` from the host's loader cache. Its query returns CUDA error
35 (driver insufficient for runtime), but upstream ignores that return code
and reports zero priorities, tripping its assertion. Explicit CUDA 12.4 and
the isolated torch runtime both return success with priorities (0,-5).
No missing L40S stream-priority support. Retry as a recorded environment
compatibility adapter: explicit --cudart-library points to the isolated
CUDA 12 runtime, validate its version/query return codes and restrict the
worker's runtime library resolver to that path for cudart only. No upstream
source, cache/head selection, attention or pool change. Use distinct v2
pilot/repeat outputs, same frozen request/settings and GPU0 lock. Full-model
and pair reproducibility gates remain unproven.

The resolver adapter's regression checks verify forwarding of unrelated
library lookups and rejection of CUDA 13, query error 35 and an invalid
priority range before changing the resolver. **95 local tests pass**
(one existing dependency warning), compilation and diff checks pass.
The explicit-runtime pilot has passed stream initialization and reached
unchanged-source JIT transfer compilation in the isolated torch 2.6
context; the specific pilot PID is live. GPU0 model use is serialized.
No model/pool/quality result is yet available.

### FLEXICACHE-ENGINE-L40S (pool allocation passed; prefill launch failed)

The CUDA-runtime adapter passed and the engine initialized in 500.616 s.
The released bf16 pools allocated successfully: GPU K/V 24,713,478,144
bytes; pinned CPU K/V 193,273,528,320 bytes (180 GiB); GPU minmax
5,354,029,056 bytes. Initialization peak PyTorch GPU allocation was
44,600,786,944 bytes. The first scheduler snapshot allocated 24,064 GPU,
18,048 CPU and 256 minmax pages for the exact 1,440-token prompt.
These are reserved pools/allocation snapshots, not useful occupancy or
matched budgets. No transfer was submitted before the failure.

Generation failed at the released FlexiCache prefill Triton kernel:
num_stages=3 with unchanged 128x128 tiles needs 163,840 shared bytes,
above L40S's 101,376-byte limit. Preserve v2 failure JSON/log; the repeat
was not launched. The failed process's main thread exited while its CUDA
cleanup thread remained live; host pinned-memory release is progressing,
so wait for that owned process/launcher to finish before another GPU job.
No source/cache/head selection modification or model output has passed.

Next preregistered portability screen: keep the same prefill kernel source,
128x128 tiles, eight warps, dtypes, masks and reduction sizes; change only
launch pipeline stages from three to one through an explicit wrapper.
Require L40S compilation/launch, finite outputs and bf16 attention agreement
against a float32 PyTorch causal/GQA reference on random seed 0 inputs
(no-prefix lengths 512/1440, plus 64-token cached-prefix + 512 new tokens).
Tolerance: max absolute error <=0.03125 and mean <=0.001. Record kernel
source hash, stage change, shared-memory usage and errors. No speed/quality
claim; only after this passes consider another same-input model pair, with
its launch adapter recorded separately from untouched-release results.

### FLEXICACHE-L40S-PREFILL-STAGE-SCREEN (passed; model retry queued)

The launch-only stage-one screen passes all three cases. Compiled shared
memory is 65,536 bytes with the same 128x128 tiles/eight warps. Max/mean
absolute bf16 errors against float32 causal GQA attention were
0.009217/0.000210 (512 no prefix), 0.007797/0.000134 (1440 no prefix),
and 0.003852/0.000165 (64 prefix plus 512 new). These are within the
preregistered 0.03125/0.001 tolerances. No original stage-three execution
is possible on this L40S; this is portability/reference agreement, not
bitwise parity with that unsupported launch or model-quality proof.
Raw: `results/baseline_fidelity/flexicache_l40s_prefill_screen_20261001.json`.

The failed v2 process completed resource cleanup and launcher exited 1;
GPU0 returned to 16 MiB before the screen. A detached v3 launcher now
runs two fresh processes with explicit --cudart-library and
--l40s-prefill-stage-one, otherwise the same frozen request, seed,
bf16 format, head profile, pools and sampling. Both adapters and actual
launch/shared-memory evidence are recorded in pilot outputs; upstream
source remains clean. First v3 process is live and initializing the
released pools; inference/reproducibility remains unproven. Launcher:
`/data/nishant/tieredkv_external/run_flexicache_pair_v3_20261001.sh`.
Full local suite: **97 passed**, one existing warning; compile/diff checks
pass. Tests cover stage-only passthrough and reject unexpected tile/warp
settings, alongside resolver scope/invalid-runtime and frozen-output guards.

### FLEXICACHE-L40S-MATCHED-INPUT (first adapted run passed, repeat pending)

The first v3 process completed the frozen 1,440-token request with unchanged
upstream source and explicit runtime/prefill-launch adapters. It generated
64 tokens and scored 10/100; this is a single-request feasibility result,
not a matched-resource quality/performance comparison. Initialization took
273.873 s, request time 11.205 s including observer overhead and compilation;
no latency claim follows. Peak PyTorch GPU allocation during generation was
44,770,327,552 bytes; process peak RSS 279,718,195,200 bytes.

Submitted paired K/V: D2H 4 calls / 17,856 pages / 146,276,352 bytes;
H2D 3 calls / 5,242 pages / 42,942,464 bytes. There were 67 allocation
snapshots. First: 24,064 GPU, 18,048 CPU, 256 minmax pages. Last:
18,304 GPU, 18,048 CPU, 256 minmax pages, zero pending GPU-release pages.
These are scheduler allocation counts, distinct from reserved pools,
useful filled token occupancy, continuous peak memory and controller traffic.
The main thread completed but CUDA cleanup is still releasing the large
pinned pool; the detached launcher waits for full process exit before its
fresh-process repeat. Preserve the successful first artifact:
`results/baseline_fidelity/flexicache_matched_input_pilot_v3_20261001.json`.
Repeat/reproducibility and resource-matched gates remain unverified.

### FLEXICACHE-L40S-MATCHED-INPUT (pair validated, 2026-10-01 IST)

Both fresh v3 processes pass: exact frozen input, generated token IDs/text,
score (10/100), source/package/adapter identities, transfer extension hashes,
reserved pools and submitted transfer calls/pages/payload match. GPU peak
allocation also matches. No upstream source diff. A read-only pair reporter
validates these identities, bf16 pool geometry, byte/page arithmetic and
allocation bounds before emitting the immutable report.

The full scheduler observation trace does NOT match: 67 versus 71 frames,
with three versus seven idle polls. Removing only zero-scheduled-token frames
reveals identical allocation traces; both scheduled 1,503 tokens, with the
same first/last/max page counts. Initial reporter rejection and source are
preserved separately. The report states full-trace inequality explicitly;
idle-poll cadence was not an experimental acceptance condition, and no
transfer/output/allocation-for-work mismatch is hidden.

Request times 11.205 versus 1.968 seconds differ because compilation/runtime
warmth differs; these are feasibility timings, not a speed comparison.
Generation peak GPU allocation is 44,770,327,552 bytes in both; peak RSS
279,718,195,200 versus 279,672,360,960 bytes. The detached launcher and
both pilot processes are now gone; GPU0 returned to 16 MiB. Both raw outputs,
failed original/v2 attempts and explicit portability adapters remain intact.
Pair report: `results/baseline_fidelity/flexicache_matched_input_pair_report_20261001.json`.
Source/runtime/input/output feasibility passes, but actual occupied/reserved
resources and attention work are unequal to TieredKV. Do not call this a
resource-matched baseline or a quality/performance win.

Final local suite after the pair reporter's frozen-output guard:
**98 passed**, one existing dependency warning; compilation/diff checks pass.

### CPU-CROSS-LAYER-TRANSFER-SCREEN (preregistered, 2026-10-01 IST)

One mechanism: replace 32 per-layer native mapped D2H/H2D dispatch pairs
with one cross-layer pair using the same pinned slot layout and unchanged
verified kernels. Seed 0, bf16, L40S GPU0, 32 layers, eight KV heads,
128 head dimension, 1,536 initial rows, 2,081 capacity, one appended row
and 32 selected rows per layer per step. Charge packing, GPU index creation,
allocation, transfers and final synchronization in both arms. Per-layer
selections differ deterministically. No selection/policy/model changes.
Three ABBA blocks, 20 steps per arm, first four excluded as warmup.
Require every read and final occupied K/V exact, every block faster,
median saving at least 4 ms and p95 no more than 2% worse to advance.
An empty-read/two-layer case validates zero-width transfers separately.
This is an optimistic storage screen: batching requires all layer data and
selection indices available together; it proves neither a schedulable model
integration nor whole-loop acceleration, overlap, quality or STT traffic.
If the screen fails, reject this mechanism without adding model hooks.

### CPU-CROSS-LAYER-TRANSFER-SCREEN (passed storage gate, 2026-10-01 IST)

Immutable raw evidence:
`results/hardware/cpu_cross_layer_transfer_screen_20261001.json`.
Executed source preserved as
`results/hardware/probe_batched_cpu_transfers_executed_20261001.py`;
runner SHA matches raw evidence. Native binary hashes match the verified
Torch 2.5 transfer preflight. Empty reads, every selected K/V and final
occupied K/V pass exact checks against a direct logical-history reference.

Per-layer median/p95: 6.706638 / 6.833749 ms.
Batched median/p95: 2.322573 / 2.359765 ms.
Median saving 4.384065 ms clears the 4 ms screen. Paired block medians
(per-layer/batched): 6.729587/2.328247, 6.710668/2.324515,
6.681396/2.318809 ms. Pool reservation is equal: 272,760,832 bytes.
Both submit identical useful payload (32 layers × eight heads × 128 ×
two K/V × two bf16 bytes): 131,072 D2H and 4,194,304 H2D bytes per
measured step. Dispatches change from 32 per direction to one per direction.
Untimed reference checks happen after synchronization in both arms.
No claim of model throughput follows from this optimistic screen.

Source inspection finds a possible scheduling seam: `_visible_tuple`
already receives all layer caches after `_decode_step`, and selects each
layer's live cold rows independently before constructing visible tensors.
Planning those selections first could batch visibility H2D without changing
row identities. Promotion is a distinct dependency: `promote()` reads cold
rows before that layer's eviction, which may compact/reindex the cold tier.
Therefore blindly batching all transfers at the visibility boundary changes
semantics. A model candidate must preserve promotion-before-eviction,
slot ownership, pending D2H completion, cache precision, row-index lifetime
and independent layer choices; charge packing and any residual promotion
transfers. The frozen archived slot-cache trial supplies reference behavior,
but its rejected default hooks remain removed. No production edits yet.

Full local suite: **99 passed**, one existing dependency warning. Added the
new runner to the frozen-output guard. GPU job exited normally; source
compilation passed. Next gate is an opt-in, schedulable batch architecture
with synthetic lifecycle and 4K/8K/16K model parity before a 16K/50-step
three-block ABBA whole-loop test. Broad P0 requirements stay unchecked.

### CPU-BATCHED-MODEL (preregistered, 2026-10-01 IST)

Advance the passed cross-layer storage screen to one opt-in physical CPU
backend. Reuse the archived, exact-tested slot backend and paired storage
hooks; defaults retain their tensor operations. One shared pinned pool,
per-layer logical slot ownership, batched promotion reads before per-layer
mutations, deferred paid writes flushed before reads, and batched visibility
reads after all layer mutations. Selection/score/tie/hysteresis/floor rules,
inclusive shadow policy, budgets and bf16 cache precision stay identical.
Handle released-and-reused slots without racing queued writes. Explicit
inspection/reset must synchronize outstanding host writes.

Gates: first full tests and synthetic two-layer 24-step inclusive/exclusive
75%/full-fill parity, empty/reversed/repeated reads, overflow and reset.
Then fixed existing prompt/teacher stream, seed 0, Mistral bf16 eager, GPU0,
4K/8K/16K five-step parity against existing packed CPU-fast path: all cache
fields, every visible selection, output IDs, counters, occupied payload and
useful transfer bytes exact. Only passed parity advances to 16K/50-step,
three ABBA blocks, one full warmup per arm. Require at least 5% pooled
median gain, every block faster, p95 at most 2% worse; report occupied and
reserved host/GPU allocations, initialization, prefill and full loop.
No GPU-tier, physical STT-RAM or competing-baseline superiority follows.
If whole-loop gate fails, preserve executed sources/results and remove
candidate/default hooks again. Freeze each executed stage; no raw overwrite.

### CPU-BATCHED-MODEL (synthetic gate passed, 2026-10-01 IST)

Implemented opt-in `cpu_batched_cache.py`, reusing the archived slot backend.
Promotion planning resolves hysteresis exactly once; a pure row planner
shares the existing inclusive floor logic with promotion. Default hooks
retain ordinary tensor operations. Cross-layer selections retain each layer's
independent ranking and row order. Shared reads flush deferred writes first;
reusing an already-pending destination forces an ordered flush to prevent
parallel writes racing. Canonical inspection and reset synchronize ownership.
Native binaries remain unchanged and hash checked.

Four two-layer regimes pass 24 synthetic steps each: inclusive/exclusive,
75%/100% initial cold fill, exact full state and read/write payload,
empty/reversed/repeated reads, ragged promotion counts, inclusive floor,
compaction, repeated-slot write ordering, overflow and queued-write reset.
`results/hardware/cpu_batched_synthetic_v2_20261001.json`.
The initial synthetic run failed only in its final CPU-vs-CUDA equality
assertion; failed output and initial checker source are preserved. The
corrected assertion transfers the expected diagnostic to CPU. Backend
unchanged between these runs. Existing full suite before new guards:
99 passed, one existing warning. Current exact source stage frozen in
`results/hardware/cpu_batched_parity_source_20261001.tar.gz`.
4K/8K/16K five-step model parity is running before any latency gate.

### CPU-BATCHED-MODEL (real-model parity passed, 2026-10-01 IST)

`results/hardware/cpu_batched_model_parity_20261001.json` passes all three
4K/8K/16K five-step pairs. Six exact state hashes per arm cover prefill
visibility plus every decode visibility boundary. Position/shadow/selection
history, final full cache/metric digest, predicted token IDs, promotions,
demotions, paid/shadow-saved writes and useful H2D/D2H payload match.
The current packed reference also matches frozen pre-hook 4K and 8K/16K
CPU-slot trial references for final state/history hashes and all three
transfer payload fields. Thus shared refactoring is checked against prior
source behavior rather than only comparing two newly changed implementations.
Parity instrumentation hashes complete CPU/GPU state inside each visibility
call, so its ~370 ms/token timings must NOT be used as performance evidence.
Each candidate five-step run uses nine shared H2D dispatches and three
shared decode D2H dispatches, plus per-layer initial pool writes.
Candidate/reference retain bf16 KV precision, FP32 policy arithmetic.
The prerecorded runner disables per-visibility full-state hashing for
latency, retaining the same position/shadow history observer in both arms.
16K/50-step three-block ABBA, one full warmup per arm, is now running.

### CPU-BATCHED-MODEL (full-loop CPU control gate passed, 2026-10-01 IST)

Twelve 16K/50-step arms, three ABBA blocks, one full warmup per arm:
packed CPU median/p95 90.685314 / 109.218091 ms; batched CPU
80.017340 / 89.241264 ms. Median improvement **11.7637%**.
Block medians (packed/batched): 88.162955/80.017340,
89.261146/79.952761, 91.542319/79.821643 ms; all blocks improve.
All arms preserve complete final cache/metrics and visibility history
hashes, all 50 predicted IDs, promotions, demotions, paid writes (2,690),
shadow savings and useful transfer payload. Full-state checks at every
visibility boundary were separately proven by the 4K/8K/16K parity gate;
full-state hashing was disabled for both latency arms. No quality metric
from freely generated answers was measured in this fixed-stream experiment.

Useful payload per arm: H2D 315,621,376 B; total D2H 212,344,832 B,
including initial 201,326,592 B and decode 11,018,240 B. Batched engine
submits 76 shared H2D and 25 shared decode D2H dispatches; initial writes
still use 32 per-layer D2H dispatches. Payload is unchanged; dispatch
batching, not omitted copies or changed cache precision, drives the result.

Packed/batched median TTFT: 2,062.9505 / 2,145.035 ms (+3.98%).
Prefill GPU allocation peak identical: 18,594,276,864 B.
Maximum decode GPU allocation: 14,910,151,168 / 14,913,245,696 B
(+3,094,528 B). Final occupied host K/V identical: 212,344,832 B.
Final live host tensor reservation: 212,344,832 / 402,784,256 B.
These are tensor reservations, not process/allocator peaks. Initial shared
pool consolidation owns old per-layer pools plus the new pool, up to
805,568,512 B of host tensors; the pinned allocator may retain freed blocks.
No CPU-memory-peak saving is claimed. Homogeneous layers and single-token
decode are the exercised scope. Ownership is synchronized on inspection,
slot reuse and reset; native kernels and STT bandwidth parameters unchanged.

Evidence: `results/hardware/cpu_batched_abba_16k_50_20261001.json`,
`results/hardware/cpu_batched_gate_report_20261001.json`, frozen exact
source `results/hardware/cpu_batched_parity_source_20261001.tar.gz`.
The gate report verifies all executed source hashes, identities, all arms
and resource fields. Retain the candidate as opt-in; GPU-resident defaults
retain their ordinary operations. This is a same-policy CPU-control win,
not GPU-tier/SnapKV superiority, a resource-matched quality result or
physical STT/controller/energy evidence. Next: fresh GPU control and
independent workload/concurrency validation before broader adoption.

Final full GPU-visible local suite: **101 passed**, one existing warning;
CPU-only run: 100 passed / one GPU-specific skip. Source compilation and
whitespace checks pass. Timed GPU job exited normally; GPU0 is free.

### CPU-BATCHED-GPU-CONTROL (preregistered, 2026-10-01 IST)

Fresh same-source GPU-resident TieredKV versus retained batched CPU backend.
Same existing prompt/teacher stream, Mistral bf16 eager, seed 0, budgets
1024/2048, 75% initial cold fill, unchanged selection/cost assumptions.
First 4K/8K/16K five-step exact parity: all visibility-boundary full state,
selection/shadow histories, final state/metrics, predicted IDs and logical
write/promotion counters. Physical host payload differs by design: GPU
control has zero host transfers; do not require or imply equal transfers.
Check candidate payload against the prior CPU-control evidence instead.
Only parity advances to 16K/50-step three-block ABBA, one warmup per arm.
Speed gate: at least 5% pooled median gain, every block faster and p95 no
more than 2% worse. Report GPU prefill/decode/final allocations, occupied
and reserved host tensors, TTFT and real submitted transfer payload. GPU
memory reduction under 10% of total allocation is not a memory-gate pass.
Single-workload validation only; no QA quality/SnapKV/STT device claim.
A failure against GPU does not erase the passed CPU-control gate, but must
prevent claiming the physical CPU variant outperforms the GPU prototype.

### CPU-BATCHED-GPU-CONTROL (parity passed, 2026-10-01 IST)

Extended the existing benchmark with `--control gpu` (default remains the
packed CPU control), reusing measurement, ownership, warmup and observers.
State/selection/prediction/logical counter equality is mandatory for both
control choices. Physical transfer equality is mandatory only for two CPU
arms; GPU control explicitly records zero host payload and no host allocation.
A regression test proves that this scope switch still rejects changed state
or predictions. GPU parity passes 4K/8K/16K at five steps; all six state
hashes per arm agree with the prior frozen CPU parity request. Candidate
transfer/reservation fields also match earlier CPU-control evidence exactly.
Parity timings include full-state hashing and are not speed evidence.

Raw: `results/hardware/cpu_batched_gpu_parity_20261001.json`.
Frozen new runner/backends/core/tests:
`results/hardware/cpu_batched_gpu_control_source_20261001.tar.gz`.
Previous CPU-control source archive remains unchanged. Focused CPU-only
regressions: 37 passed / one GPU-specific skip, one existing warning.
Fresh GPU/CPU three-block ABBA latency control is running on GPU0.

### BATCHED-POLICY-PROFILE (diagnostic preregistration, 2026-10-01 IST)

After the GPU-control speed gate fails, collect stdlib cProfile evidence
only around the retained batched policy's decode and score-update methods.
Existing model/prompt/stream, seed 0, bf16 eager, 16K, 20 forced steps,
no warmup or cross-arm speed comparison. Exclude model load, prefill and
final-state inspection from profiling. Profiled wall times include implicit
GPU waits/launch ownership effects; call times overlap and are not additive
causal savings. Preserve .prof, text and JSON/source identities. Use call
counts and dominant stacks to rank the next mechanism, not to promote code
or claim a latency win. No policy/backend/default edits in this diagnostic.

### CPU-BATCHED-GPU-CONTROL (speed/memory gates failed, 2026-10-01 IST)

All twelve arms complete normally and preserve full final state, every
visible position/shadow selection, predictions and logical counters. The
five-step boundary hashes already proved intermediate tensor parity.
Candidate payload/reservation fields also match frozen CPU-control evidence.
GPU median/p95 81.515472 / 88.319847 ms; CPU 79.940541 / 88.894754 ms.
Pooled median improvement **1.9321%**, below 5%; p95 +0.65% passes its
2% guard. Block GPU/CPU medians: 79.597211/79.940541,
79.844136/80.030379, 81.515472/79.879907 ms. First two favor GPU.
The speed gate fails; do not describe the CPU backend as outperforming GPU.

Median final GPU allocation 14,856,895,488 versus 14,626,980,864 B:
229,914,624 B saved (**1.5475%**), below the total-memory 10% gate.
Decode allocation peaks 15,137,135,104 versus 14,913,245,696 B.
Prefill peaks remain identical at 18,594,276,864 B.
Median TTFT 2,059.419 versus 2,123.3575 ms (+3.10%).
GPU control has zero host payload/reservation; CPU retains 212,344,832 B
occupied and 402,784,256 B reserved host tensors. Initial/transient pool
and allocator retention limitations are unchanged. Different host resources
are explicit, so this is not a matched-total-resources comparison.

Raw: `results/hardware/cpu_batched_gpu_abba_16k_50_20261001.json`;
validated arithmetic/identity/decision report:
`results/hardware/cpu_batched_gpu_gate_report_20261001.json`.
Decision: retain opt-in for the passed packed-CPU-control result; no GPU
speed or total-memory promotion, no stronger quality/SnapKV/STT claim.

### BATCHED-POLICY-PROFILE (diagnostic completed, 2026-10-01 IST)

`results/hardware/cpu_batched_policy_profile_20261001.json`, `.prof`,
`.prof.txt`; exact profiler and source bundle preserved. Twenty decode
policy calls and 640 per-layer eviction calls observed. Policy-only profile
records 1.198 s total: decode 1.042 s cumulative, eviction/demotion 0.565 s,
visibility 0.205 s, score update 0.155 s, shared reads 0.091 s and shared
flushes 0.006 s. These overlap; do not sum or claim causal speed savings.
There are 1,970 explicit tensor constructions (0.186 s cumulative), 7,366
concatenations and 5,120 `.tolist()` calls. The transfer-only bottleneck has
been reduced; eviction/metadata dispatch remains a stronger candidate than
more changes to grouped native copies. Source inspection places repeated
CPU position construction in `_hard_protected_mask`, candidate indices in
hysteresis resolution and GPU keep-index construction in `update_scores`.
The exact contribution of each construction and its GPU waiting remains
unproven. Use a frozen charged screen to isolate any proposed mechanism.
No policy/backend/default change made from this diagnostic alone.

Source compile/whitespace checks pass. CPU-only full suite before the
profiler guard: 101 passed / one GPU-specific skip; final GPU-visible full
suite including GPU-scope regression and profiler frozen-output guard:
**103 passed**, one existing warning. Both GPU jobs exited normally.

### CROSS-LAYER-SCORE-SCREEN (preregistered, 2026-10-01 IST)

One mechanism: batch measured attention-score bookkeeping across homogeneous
layers, retaining exact per-layer head means, hot cumulative additions and
cold position/index/LRU metadata. Baseline is the actual current
`TieredKVPolicy.update_scores`; candidate packs FP32 head attention, folds
heads in one batch, uses native foreach hot additions and one cold-score
host read. Charge validation, packing, casts, addition, host copy and all
metadata updates. Existing GPU storage/promotion/selection/default unchanged.
Seed 0, L40S GPU0, 32 layers × 32 attention heads, 1024 hot / 32 visible
cold rows, 1057 total attended rows, FP32 cumulative scores and bf16 weights.
Three ABBA blocks, 20 repeated score updates per arm, first four warmup.
Require bitwise hot scores, both attention dictionaries and last-access
metadata exact after every update, all blocks faster, saving >=4 ms pooled
median and p95 <=2% worse. Separately check fp32 weights, zero cold quota,
changed cold-position mapping and heterogeneous-width fallback against the
actual baseline. No model integration unless screen passes. Timings are a
synthetic bookkeeping screen, not whole-loop/quality evidence.

### CROSS-LAYER-SCORE-SCREEN (passed, 2026-10-01 IST)

Actual-policy baseline median/p95 6.386052 / 6.469658 ms;
batched 1.595556 / 1.615459 ms, saving 4.790496 ms. All three ABBA
blocks improve and clear the preregistered headroom screen. Every repeated
update has bitwise FP32 hot scores, attention dictionaries and last-access
metadata equality. bf16/fp32 weights, zero cold quota, changed position/index
mapping and heterogeneous-width fallback pass. Raw immutable evidence:
`results/baseline_fidelity/batched_score_screen_20261001.json`.
Freeze executed runner, then extract the identical helper into an opt-in
policy module. Default score update remains unchanged. Advance to 4K/8K/16K
five-step full boundary-state parity against the retained batched CPU
backend without score batching; only passing parity advances to three
16K/50-step ABBA blocks, one full warmup per arm, >=5% median gain, every
block faster and p95 <=2% worse. Same precision/input/selection/byte counts
and exact output/state/metadata guard. Report TTFT and all GPU/host resources.
No broader QA, GPU-control or SnapKV claim from this isolated gate.

### CROSS-LAYER-SCORE-MODEL (parity passed, 2026-10-01 IST)

Extracted the exact screened helper into `batched_score_policy.py`;
textual function identity verified against the frozen executed screen source.
The benchmark adds an explicit candidate choice; defaults remain unchanged.
Opt-in score policy extends the retained shared CPU backend. Guard fallback
uses the original method for incomplete/unordered/heterogeneous visibility.
Five CPU regression cases verify complete, zero-cold, remapped, unordered
and heterogeneous updates, plus a frozen-output guard for the screen.
Focused CPU-only tests: 44 passed / one GPU-specific skip, existing warning.

4K/8K/16K five-step pairs pass every boundary-state hash, final complete
state, selection/shadow history, output ID, logical counter and actual
host payload/reservation check. All match the earlier frozen shared-CPU
parity results, guarding against a changed reference. Raw:
`results/hardware/batched_scores_model_parity_20261001.json`.
Frozen executed core/backends/runner/tests:
`results/hardware/batched_scores_model_source_20261001.tar.gz`.
Three-block 16K/50-step ABBA with one full warmup per arm is running;
score screen/parity timings are not whole-loop performance evidence.

### CROSS-LAYER-SCORE-MODEL (full-loop CPU gate passed, 2026-10-01 IST)

Twelve 16K/50-step arms, three ABBA blocks, one full warmup per arm:
shared CPU median/p95 80.955981 / 89.494202 ms;
score-batched CPU 75.560466 / 84.855675 ms. Median improvement **6.6648%**,
passing the 5% gate and p95 guard. Block control/candidate medians:
81.138029/75.177403, 80.522039/75.662118, 80.398018/76.011882 ms.
All three blocks improve. All arms preserve final full state/metric hashes,
visibility/shadow histories, all 50 predicted IDs, promotions, demotions,
paid/shadow-saved writes, actual host bytes and native dispatch counts.
All also match frozen pre-score shared-CPU evidence, so the control change
is not hidden. Separate 4K/8K/16K parity proves intermediate tensor states.

GPU prefill and decode allocation peaks are identical between arms:
18,594,276,864 B and 14,913,245,696 B. Final GPU allocation also identical:
14,626,980,864 B. Host occupied/reserved unchanged: 212,344,832 /
402,784,256 B; transient/allocator limitations unchanged. Median TTFT
2,126.1125 / 2,144.161 ms (+0.85%). Source helper bitwise identity and
all executed runner/backend hashes verified against frozen source bundle.

Raw: `results/hardware/batched_scores_abba_16k_50_20261001.json`;
verified report: `results/hardware/batched_scores_gate_report_20261001.json`.
Decision: retain opt-in after CPU-control gate; do not promote defaults
without independent stress results. This result is not against GPU-resident
TieredKV or faithful SnapKV, nor freely generated QA or physical STT-RAM.
The earlier GPU-control failure belongs to transfer-only batching. A fresh
GPU control must separately test the new score-batched variant before any
GPU superiority claim. Same frozen prompt/stream/model/budgets, 16K/50,
three ABBA blocks with full warmups and >=5% median / every-block / p95
<=2% guards apply to that next control. Logical-state/prediction equality
and unequal physical host payloads must remain explicit.

Final GPU-visible suite: **109 passed**, one existing warning. CPU-only:
108 passed / one GPU-specific skip. Source compilation/diff checks pass;
timed job exited normally and GPU0 is free. Extracted screen runner now
records its separate helper hash for future probes; original inline screen
source/result remain immutable. No change to production score method,
selection rules, bf16 cache/FP32 scores, native transfer kernels or agreed
STT bandwidth assumptions.

### SCORE-BATCHED-GENERATION-STRESS (preregistered, 2026-10-01 IST)

After the score-batched GPU latency gate passes, test systems-only
non-inferiority under free greedy generation/EOS, not forced teacher tokens.
Freeze the first four distinct-document rows from each existing verified
real_query_holdout_20260929 slice: multifieldqa_en, qasper, gov_report.
These data were used by earlier selection experiments; they are not a new
unseen corpus. They are independent of this score/transfer optimization's
synthetic and fixed-stream development data. Twelve documents × seeds 0/1
× GPU/score-batched CPU arms = 24 pairs / 48 generations. Alternate arm
order by document and seed. Use unchanged task prompt/chat formatting,
native task generation limits (QA 64/128 as configured, summaries 512),
max_ctx31500, same model/budgets/bf16 KV/FP32 scores, GPU0 advisory lock.

Require every generated token ID/text, task score, final full state/metrics
and every visibility-boundary position/selection/shadow trajectory exact
within each pair. Systems-only quality guard: task-balanced paired 95%
bootstrap lower bound > -0.5; exact identical scores imply [0,0]. A mismatch
fails the pilot, preserve it and diagnose; do not tune samples or drop it.
Record real token lengths, EOS/cap termination, GPU peak/final allocations,
host useful bytes/reservations and identities. Trajectory observer is
identical in both arms; request times are diagnostic, not paired ABBA speed
evidence. This pilot covers QA/summarization, natural stopping, second seed,
longer decode and possible saturation. It does not establish second model,
concurrency, full boundary/needle suite or physical STT/controller evidence.

### SCORE-BATCHED-GPU-CONTROL (latency gate passed, 2026-10-01 IST)

Fresh twelve-arm 16K/50-step ABBA control, one full warmup per arm:
GPU median/p95 80.474698 / 88.882655 ms; score-batched CPU
75.646408 / 84.981969 ms. **5.9998%** pooled improvement; all three
blocks favor CPU (GPU/CPU: 80.474698/75.646408,
80.176017/75.689282, 80.442130/75.777370 ms). Speed gate passes.
Every final state/metric hash, visibility history, predicted ID and logical
counter matches prior frozen CPU evidence; candidate host bytes/dispatches
also match. GPU host payload is zero by design. Executed source identities
verified against the unchanged score-model archive.

Final GPU allocation: 14,856,895,488 versus 14,626,980,864 B,
229,914,624 B saved (1.5475%), below the 10% total-memory gate. Decode
GPU peaks: 15,137,135,104 versus 14,913,245,696 B. Prefill peaks both
18,594,276,864 B. Median TTFT 2,053.676 versus 2,140.4935 ms (+4.23%).
Host tensor reservation/occupancy/transient limits unchanged. No matched
combined-resource comparison or faithful SnapKV claim.
Raw `results/hardware/batched_scores_gpu_abba_16k_50_20261001.json`;
verified report `results/hardware/batched_scores_gpu_gate_report_20261001.json`.
Retain opt-in until remaining stress gates pass; GPU default unchanged.

### SCORE-BATCHED-GENERATION-STRESS (pilot passed, 2026-10-01 IST)

All 24 free greedy generation pairs / 48 arms pass: 12 distinct frozen
reused documents, multifieldqa_en/qasper/gov_report, seeds 0/1, native task
generation limits and alternating order. Source/manifest/data identities
verify; every generated ID/text, task score, final cache/metric digest and
visibility position/selection/shadow trajectory matches exactly. New tokenizer
wrapper captures the existing final decode call without modifying model or
production generation code. Identical trajectory observer encodes length-
prefixed int64 positions/indices and raw shadow bytes; encoding recorded.

Actual prompt lengths 3,467–21,202 tokens; generation 11–449 tokens.
QA exercises cap/EOS stops; all summaries stop naturally at EOS after
327/341/430/449 tokens. Paired task-balanced delta 0, interval [0,0],
passes systems-only non-inferiority -0.5. Every paired score difference is
exactly zero; any paired task/document bootstrap has [0,0], so Monte Carlo
resampling adds no information. This is preserved quality on these reused
cases, not quality improvement, unseen-corpus evidence or a headline.
Largest final host occupancy 267,444,224 B (near the 268,435,456 B logical
cold ceiling), final reservation 402,784,256 B. Not a process/allocator
peak or proof that every layer reached capacity. Request timings include
observers and have no paired ABBA speed interpretation.

Raw/source/manifest in
`results/hardware/batched_scores_generation_stress_20261001/`;
`verified_report.json` independently rechecks all 24 pairs, EOS/cap counts,
lengths, source/data identities and quality/resource arithmetic. Both runs
exited normally. Remaining mandatory cases include empty/one/capacity/max
contexts, explicit saturation/migration bursts, needles/repeated distractors/
similar keys/rare-answer/dropped-content requests, another model and
concurrency when supported, allocator/process peaks and independent headline
rerun. Keep broader robustness and P0 gates open; do not promote defaults.

Final local GPU-visible suite: **110 passed**, one existing dependency
warning; CPU-only 109 passed / one GPU-specific skip. Frozen-output guard
covers the new stress runner. Compilation/diff checks pass; GPU0 returned
to 16 MiB, and no experiment process remains active.

### SCORE-BATCHED-BOUNDARY-RETRIEVAL (preregistered, 2026-10-01 IST)

Freeze exact tokenizer IDs before running. Application no-op: empty IDs,
zero generation. Real-model contexts: one BOS token, 1023/1024/1025 hot
boundary, 3071/3072/3073 total-budget boundary, 16384 and 31500 tokens.
Use native budgets 1024/2048; total-budget cases set initial cold fraction
1.0 in both arms to reach true cold capacity. Eight decode tokens for hot
boundaries, 64 for total/long cases. Same greedy/EOS semantics, seed 0.
Record per-layer maximum logical cold count and largest promotion/paid-write
increments to prove which saturation/burst conditions were actually reached.

Retrieval: 16K and max31500, needle depths .1/.5/.9, exact rare code
ZXQ-7391-TERRA, repeated similar-key decoys TARGET-70/ZQX-7391-TERRA versus
unique TARGET-07. Freeze answer-token positions; inspect initial retained
answer spans per layer to identify requests for actually dropped content.
GPU/score-batched CPU outputs/state/trajectory/counters must match exactly.
Also run unchanged FullCache oracle on retrieval cases to distinguish a
sparse-policy loss from a prompt the model cannot answer. Oracle outcomes
are descriptive, not a resource-matched baseline or an accuracy headline.
Never discard/tune a failing retrieval case. Shared failures constrain the
policy claim; a CPU/GPU divergence fails integrity and requires diagnosis.

No timing gate: synchronized request times include identical observers.
Record GPU allocations, explicit host payload/reservations and cleanup.
Freeze all IDs/source; outputs immutable, incremental checkpoints allowed.
This closes only exercised integrity boundaries; another model/concurrency,
process peaks, independent timing rerun, faithful matched baselines and
physical STT/controller evidence remain separate requirements.

### SCORE-BATCHED-BOUNDARY-RETRIEVAL (integrity passed, retrieval failed,
2026-10-01 IST)

All 16 GPU/CPU pairs match exact generated IDs/text, full final cache/metrics,
visibility trajectories, counters, answer-retention metadata and cold/burst
observations. Exact tokenizer IDs/source/manifest hashes verified. Contexts:
empty zero-generation no-op (no model forward or pool allocation), one BOS,
1023/1024/1025, 3071/3072/3073, 16384 and maximum 31500. Decoder generation
retains original EOS behavior. Total-budget cases use initial fraction1.0
in both arms; 3072/3073 reach all 32 layers at 2048 cold rows, largest-step
promotions1024 and paid writes1056. No candidate divergence or overflow.

Six synthetic similar-key/repeated-decoy retrieval cases, 16K/max context,
10%/50%/90% depth: GPU and CPU BOTH wrong in 6/6; unchanged FullCache
oracle correct in 6/6. Sparse outputs report decoy ZQX-7391-TERRA instead
of true ZXQ-7391-TERRA. No layer retains the full 12-token answer span.
Fully dropped-layer counts: 32,29,29 at 16K; 32,31,30 at max context.
At 10% depth, every answer token is dropped in every layer in both contexts.
Other layers retain at most4/11 tokens at 16K and5 at max context.
This implicates the shared prompt compression/retention path, not a change
introduced by CPU transfer or batched scoring. Full-cache success rules out
a universally unanswerable prompt, but is not a matched-resource comparison
or an isolated intervention proving which retained subset would suffice.
No failing case discarded, no hyperparameter tuning, no selector fix made
from these six handcrafted development probes alone.

Raw/source/frozen exact IDs in
`results/hardware/batched_scores_boundary_retrieval_20261001/`.
Independent `verified_report.json` verifies all16 pairs, token/source hashes,
actual saturation/bursts and all six oracle outcomes. It separates
integrity_passed=true from retrieval_quality_passed=false. Oracle is only
a descriptive quality reference: peak captures live generation, but its
post-return final allocation has no retained KV owner and cannot be used
for steady-memory comparison against owned tiered caches.

Decision: preserve speed-qualified backend opt-in and record the shared
retrieval limitation; do not claim robustness, quality superiority or promote
new defaults. Remaining work includes defensible matched-resource faithful
baselines, a deployment-available retention mechanism validated on independent
quality data, process/allocator peaks, another model/concurrency when
supported, independent headline rerun and physical STT/controller evidence.

Local full suite **111 passed**, one existing dependency warning. CPU-only
110 passed / one GPU-specific skip. Frozen-output guard covers this runner.
Compilation/whitespace checks pass. The boundary/retrieval GPU process
completed normally; GPU0 returned to16 MiB. No owned experiment remains live.

### SNAPKV-NEEDLE-DIAGNOSTIC (preregistered, 2026-10-01 IST)

Reuse all six frozen 16K/31500 needle IDs, answer spans, max64 generation
and EOS semantics; Mistral bf16, seed0, GPU0. Run the existing faithful
upstream-selector SnapKV adapter with capacity1024/window32/kernel5/avgpool,
SDPA full prefill and eager decode. Observe the actual selected indices by
inserting a read-only callback into the loaded selector's AST immediately
after index expansion; verify removing that callback gives the identical
original AST. No upstream file change, tensor mutation, new rank rule or
independent top-k recomputation. Record head-specific answer retention,
predictions and actual owned KV bytes before closing the cache. Callback
synchronization makes timings/memory peaks diagnostic, not a speed gate.

Primary question is whether stronger actual-query/head-specific prompt
selection preserves/retrieves the rare code the common-position K-as-Q
Tiered selector drops. Do not claim resource matching: expanded SnapKV
stores32 query heads versus8 KV heads in Tiered, and decode grows its cache.
Preserve all cases, including failures; oracle and Tiered raw outcomes remain
immutable references. A positive synthetic result does not authorize a
selector change without independent document quality/prefill gates.


### SNAPKV-NEEDLE-DIAGNOSTIC (outcome, 2026-10-01 IST)

All six frozen cases recover the exact rare code with faithful upstream
SnapKV prompt selection; GPU/CPU Tiered miss all six and full-cache answers
all six. Actual expanded-head selected indices preserve the complete12-token
span in495/551/582 layer-head pairs at16K and429/528/594 at31500 (depth.1/.5/.9),
out of1024 possible pairs per request. Each SnapKV final owned KV payload is
549453824bytes (524 MiB). Head-specific storage, attended width and growing
cache are unequal to Tiered, so this is a retention diagnostic only, not a
resource-matched accuracy/speed/memory win or independent quality evidence.
No selector/default is changed. Further placement work needs deployment-time
information, controlled resources and independent document/prefill gates.

Initial runner failed before inference because the AST-strip verifier visited
`body` but missed `orelse`. Its raw error and executed source are immutable:
`snapkv_needles_20261001.json`, `check_snapkv_needles_executed_initial_20261001.py`.
Corrected only observer verification and cleanup, then used a new v2 output.
CPU regression proves identical upstream K/V outputs and observed gather
indices for compressed and short-prompt paths; stripping the callback yields
identical upstream AST. Adapter cleanup now includes failed verification.
Full local suite113passed; CPU-only112passed/oneGPUskip; one existing dependency
warning. Model run completed normally; no owned diagnostic remains running.

Frozen raw, verified identity/retention report, executed source and source
bundle: `results/baseline_fidelity/snapkv_needles{_v2,_verified_v2,_source_v2}_20261001.*`.
The verified report checks input/source hashes, all32layer×32head retention
counts, final payload equation, answer outcomes and prior Tiered/oracle cases.

### SNAP-TIER-RESOURCE-TRAJECTORY (preregistered, 2026-10-01 IST)

Measure actual cache ownership at prefill and all50 fixed-teacher decode
boundaries on frozen16K latency prompt, seed0, Mistral bf16/L40S. Three arms:
faithful expanded-head SnapKV capacity974/window32/kernel5 (512 MiB after50
forwards), default GPU Tiered1024hot/2048cold/quota32/fill.75, and identical
opt-in batched CPU+score Tiered. No ranking or baseline changes. Record per
layer logical resident hot/cold/shadow rows, visible rows/heads, useful versus
reserved cold bytes, distinct underlying KV storage allocations on each
device (deduplicate aliases), actual PyTorch process allocations, and shared
CPU pool reservation. Charge visible DynamicCache storage too; separate
metadata from KV and GPU allocation from process RSS. Fixed stream IDs and
all source hashes must be frozen. Each arm consumes identical teacher IDs;
GPU/CPU Tiered must preserve predictions and row trajectories. SnapKV
predictions may differ. This observational run is not a speed or quality gate.
Reject any equality label contradicted by actual boundary bytes/widths.


### SNAP-TIER-RESOURCE-TRAJECTORY (outcome, 2026-10-01 IST)

All three arms completed the same16K prompt and50 teacher-forced inputs.
At each of51 boundaries, all32layers record cache rows, shadow rows, visible
geometry and actual owned KV storage. Alias-aware whole-storage accounting
counts shared pinned capacity once and includes the distinct attention cache
copy. Independent verifier checks source/input hashes, geometry-derived
payload equations, pool reservation, and GPU/CPU prediction/geometry equality.

SnapKV GPU KV grows510656512→536870912bytes (487→512 MiB); GPU Tiered
473956352→484974592bytes (452→462.5 MiB); CPU+score Tiered stays272629760GPU
and402784256CPUbytes (260+384.125 MiB). Final useful cold payload212344832bytes
(202.508 MiB), with unused host reservation counted. Tiered logical hot+cold
alone omits the visible copy and is not total owned KV storage. Actual decode
attended widths are975–1024 SnapKV versus1057 Tiered, even with fixed teacher
inputs. Thus no arm pair is resource-matched; current gains remain conditional
backend evidence. Full process RSS/pinned allocator high water and independent
matched-resource quality/latency gates remain open. Do not equate reserved
host pool with all pinned allocator/process memory or call CPU DRAM STT-RAM.

Raw/source/verified artifacts:
`results/baseline_fidelity/snap_tier_resource_trajectory{,_source,_verified}_20261001.*`.
Executed runner is preserved separately. CPU-only114pass/oneGPUskip; full
suite115pass; one existing warning. The CUDA process completed normally.

### TIERED-REALQ-NEEDLE-ISOLATION (preregistered, 2026-10-01 IST)

Reuse all six frozen16K/31500 needle token sequences, seed0, Mistral bf16,
max64 greedy/EOS generation. Paired GPU Tiered control versus existing
`PromptQueryCapture` with chunked causal GQA importance/chunk128. Fixed
1024hot/2048cold/quota32/.75fill, sink4/recent128, common positions and
unchanged decode scoring/promotion/visibility. No new rank rule or oracle
selection. Alternate arm order by case. Require fresh control predictions,
state and trajectory to reproduce frozen boundary controls; verify all32
captured rotary-query layers were available and consumed by placement.
Record initial resident row/byte counts, actual answer retention and output;
retain every case and failure. Compare initial storage to separate ranking
from added capacity; free-generation final counts may differ. Existing
actual-query option previously failed broader factual/prefill gates: six
reused development probes cannot override that decision or promote defaults.
Instrumented times/peaks remain diagnostic, not quality/latency acceptance.


### TIERED-REALQ-NEEDLE-ISOLATION (outcome, 2026-10-01 IST)

All12 arms completed: existing actual-query placement recovers6/6 versus
K-as-Q0/6. Full12-token spans remain in24/27/29 layers at16K and22/24/28 at31500
(depth.1/.5/.9), versus0complete layers for control. All32rotary-query capture
shapes[32,128,128] were recorded before placement and consumed. Initial
1024hot/1536cold rows,1056visible rows and320 MiB hot+cold KV payload are equal;
common8KV-head positions and original decode policy are unchanged. Every
fresh control reproduces frozen generated IDs/text, full state, trajectory,
retention and counters. This separates query-based placement from increased
initial KV capacity on these six probes; extra prefill query/scoring memory
and free-generation final states are not resource-matched.

Keep actual-query placement opt-in. These reused development cases cannot
replace independent quality evidence or jointly gated prefill/decode/baseline
results. Historical qualification: initial preregistration/runner phrasing
about failed factual/prefill gates was too broad. The two-prompt prefill
ABBA guard passed; the24-document quality bootstrap interval[−.84,+9.01]
crossed zero with severe regressions. The precise no-go is replicated
quality/default promotion, not a claim that every prefill guard failed.
Future runner wording is corrected after preserving the executed source;
the immutable v2 raw record and verified report include the qualification.

Initial runner stopped on a verifier-only integer/string JSON layer-key
mismatch after its first control. Preserve initialraw/executedsource. Corrected
comparison normalizes JSON types and reruns to a newv2file. A tiny CPU Mistral
integration test now proves query capture/consumption, fixed initial KV
geometry, and hook cleanup; frozen-output guard includes the new runner.
CPU-only116pass/oneGPUskip; fullsuite117pass; one existing dependency warning.
Source/runtime/input/control identities and retention/payload equations are
verified, with exact source bundle and initial failure preserved:
`results/baseline_fidelity/tiered_query_needles{_v2,_verified_v2,_source_v2}_20261001.*`.

### CPU-REALQ-NEEDLE-INTEGRATION (preregistered, 2026-10-01 IST)

Run batched CPU+score Tiered with existing actual-query prefill on all six
frozen needle inputs, same seed/model/bf16/budgets/generation semantics.
Compare every output token, final complete cache/metrics digest, selection
trajectory, retention, initial row/payload geometry, counters and consumed
query shapes against the frozen GPU actual-query run. GPU control was
independently repeated with exact frozen proxy controls in that run. CPU
physical reservation/transfers differ and are reported; no new independent
quality or speed claim from same synthetic probes. Fail on any mismatch;
keep defaults unchanged and preserve immutable source/raw evidence.

### REALQ-CPU-FRESH-DOCUMENTS (preregistered, 2026-10-01 IST)

The conservative inventory excludes sample IDs in all recorded result JSON,
all existing manifest selections/development prefixes, and matching normalized
contexts across standard/LongBench-E variants. Eligible distinct documents:
Qasper85, MultiFieldQA57, HotpotQA261, TriviaQA261, GovReport276; NarrativeQA0.
Freeze20 documents/task (100 total), one random question/document, selection
seed20261003, sorted group IDs before sampling and global cross-task uniqueness.
NarrativeQA is excluded before generation because its current corpus is
exhausted; broader NarrativeQA generalization remains open and requires
additional unseen source documents, not reuse under an independence label.
Semantic near duplicates and training overlap remain unverified.

On frozen source slices, seed0/Mistral bf16/L40S0/maxctx31500, evaluate three
arms per document: default GPU proxy placement, existing actual-query GPU,
and actual-query batched CPU+score. All use1024hot/2048cold/quota32/.75fill,
sink4/recent128, original task chat/EOS/max64/128/512 generation semantics.
Actual-query is unchanged chunked causal GQA/chunk128. Alternate three-arm
order by request index. CPU/GPU actual-query must exactly match generated IDs,
scores, final complete state, counters and selection trajectory. Candidate
quality is CPU actual-query minus GPU proxy, evaluated by task-balanced paired
bootstrap over20 document groups/task,10000draws/seed20261003. Primary quality
non-inferiority lower95%bound>−.5; superiority only iflower>0. Report every
regression, >10-point loss, per-task differences and generation lengths.
Do not tune on this tranche after inspection or silently drop failures.
Instrumented elapsed/peak/transfer/resource figures are descriptive; separate
paired whole-loop and matched-baseline gates still required. One model/seed
and five tasks cannot close full generality, NarrativeQA, physical STT or SOTA.


### CPU-REALQ-NEEDLE-INTEGRATION (outcome, 2026-10-01 IST)

All6 CPU+score actual-query arms exactly reproduce frozen GPU actual-query
IDs/text/quality, full final cache+metrics, trajectories, retention, initial
geometry, consumed queries, counters and occupancy/burst extrema. Each
returns25tokens and the correct code; full-span retention24/27/29layers16K
and22/24/28layers31500. Submitted H2D153747456bytes and D2H208404480bytes
(including initialization) per request; final host occupied208404480bytes,
reserved402784256bytes. GPU/CPU physical resources differ. No new independent
quality, joint latency or baseline claim. Frozen raw/verified/source evidence:
`results/baseline_fidelity/cpu_query_needles{,_verified,_source}_20261001.*`.

### REALQ-CPU-FRESH-DOCUMENTS (selection outcome, 2026-10-01 IST)

Conservative source inventory and deterministic sample freezing pass independent
verification. Exclude IDs recorded in result JSON, all earlier manifest
selections/prefixes and normalized contexts across standard/E variants.
NarrativeQA current200rows contain20 normalized documents, all used; no new
independent NarrativeQA sample exists in this source. Qasper85/MultiFieldQA57/
HotpotQA261/TriviaQA261/GovReport276 groups remain eligible. Freeze20each of
these five tasks,100distinct normalized documents globally, one row per group.
Source/slice/context/sample-ID hashes, disjointness and seeded sampling are
independently verified. **No new quality evaluation has run yet.** Broader
NarrativeQA/generalization requires additional data; unrecorded manual cases,
semantic near duplicates and training overlap remain unverified. Frozen
manifest/slices and verifier:
`results/baseline_fidelity/realq_cpu_fresh_documents_20261001/`;
immutable inventory `unused_document_inventory_20261001.json`.

Latest full suite120passed; one existing dependency warning. Earlier CPU-only
116pass/oneGPUskip and new output guards pass. Both GPU diagnostic and corpus
inventory processes are terminal; GPU0 idle. Next run is the preregistered
three-arm100-document quality/integration evaluation, then paired systems
and faithful matched-resource baselines. No broad P0/P1/P2 gate is closed.


### REALQ-CPU-FRESH-DOCUMENTS (execution started, 2026-10-01 IST)

GPU0 model process PID3966311/toolsession31054 is confirmed live. It runs
all300 arms in rotating three-arm order, with per-arm atomic checkpoints,
exact GPU/CPU actual-query comparisons and official first-line TriviaQA
scoring. The original generation helper now accepts an opt-in query capture;
query-shape/consumption observation lives with the shared trajectory observer.
No default model/policy/scorer change. Exact executed source bundle and hashes
were frozen before execution in the study folder. Do not edit its dependencies
while the process is live or restart from a timeout.

Latest observed checkpoint59/300; outcomes are incomplete and no
primary aggregate/interval is interpreted. Source/slice/metric/termination/
query/state/trajectory checks and the preregistered10000-draw document bootstrap
are implemented in `experiments/report_fresh_documents.py`; run only after
terminal completion. Source/code guards pass: full suite121 before launch;
after reporter addition CPU-only121pass/oneGPUskip. One existing warning.
Timing/peak figures are diagnostic and no broad research gate is closed.


### NARRATIVEQA-OFFICIAL-STORY-INVENTORY (2026-10-01 IST)

To address the exhausted20-document LongBench subset, frozen official source
metadata from https://github.com/google-deepmind/narrativeqa at commit
904246f6d1fe99a99a08a03501fe3e619af2cee5. CSVs/README/license/download script
are immutable with URLs/bytecounts/SHA256 at
`/data/nishant/tieredkv_external/narrativeqa_metadata_20261001/manifest.json`.
All200 LongBench questions/answers match official QA metadata; each of20
normalized contexts identifies exactlyone official story, all from the
validation split. Exclude those story IDs and normalized Wikipedia titles.
All355 official test stories remain distinct by those identities; metadata
length range5K–25Kwords covers37movie scripts/23books. No raw story download,
cleaning, token-length validation, evaluation selection or quality claim yet.
Current availability/semantic duplicates/training overlap remain unverified.
Independent verifier checks every old question/answer against its mapped
story, all source hashes, exclusions, official split and candidate inventory.
Artifacts: `narrativeqa_official_story_inventory{,_verified}_20261001.json`;
executed audit and verifier scripts preserved. Primary source README confirms
metadata links to full stories and QA pairs; summaries are a separate task,
so they must not replace full stories in long-context validation.

The existing100-document GPU process remains confirmed live at PID3966311 /
session31054; latest inspected checkpoint170/300. Do not restart.
Latest full suite121passed before launch; additional CPU-only reporter/audit
checks122passed/oneGPUskip, one existing warning. No primary aggregate quality
decision is interpreted before all documents and independent verification.

### NARRATIVEQA-TEST-STORY-PREFLIGHT (preregistered, 2026-10-01 IST)

From verified official commit904246f6… and unused test-story inventory,
freeze10 Gutenberg books+10 movie scripts whose metadata word count is5K–25K,
sampling sorted story IDs with Python Random seed20261004. Freeze one official
question/two answers per selected story using the same RNG and sorted QA rows.
Exclude old20 validation-story IDs and normalized titles. Selection happens
before any story download or model inference; do not replace failed stories.

Fetch official story URL with timeout20s/bodylimit5 MiB, gzip decompression
when appropriate. If original HTTP URL fails, record its error then try the
same host/path/query over HTTPS (transport-only adapter). No mirror/content
substitution. Respect upstream Gutenberg two-second inter-request interval.
Preserve raw bytes, final redirected URL/headers/charset and SHA256. Plaintext
is decoded using declared charset or UTF8 then CP1252; HTML visible text is
extracted with stdlib HTMLParser, omitting script/style and preserving block
separators. Record normalized text/hash/token length and original-size drift.
Require both official normalized start/end token markers to occur in order,
minimum5K normalized words, and no size limit/truncated response before a
story is marked usable. Marker failure or changed source is evidence, never
silently repaired through summaries or new sampling. Original size drift is
reported; current downloads are adapted data, not unchanged2017 bytes.

This is availability/content feasibility only. Story IDs/splits/QA provenance
and hashes must be verified before a separate frozen three-arm NarrativeQA
quality run. Semantic duplicates and model-training overlap remain unverified;
any missing/invalid story remains explicit. Five-task GPU study stays untouched.


### NARRATIVEQA-TEST-STORY-PREFLIGHT (outcome, 2026-10-01 IST)

Independent verification confirms seeded selection/story/QA exclusion,
original URLs, raw/text SHA256, byte limits, decoding, ordered whole-token
markers and explicit coverage for all20fixed selections. Current-source
preflight passes14/20 (10books+4movies); six preserved failures:3declaredUTF8
headers conflict with legacy bytes (HTML body declaresISO8859),1URL unavailable,
2missing official start markers despite long scripts. No replacement or model
quality evaluation. All20selected IDs/QA/raw attempts retained. Story text
contexts13,961–52,234tokens; future evaluation must record standard31500
middle truncation. Size drift against2017metadata is reported, not concealed;
marker/word feasibility alone does not prove annotation/semantic integrity.

Frozen selection, executed sampler/downloader, per-source raw/text files,
preflight and independent selection/content reports:
`results/baseline_fidelity/narrativeqa_test_stories_20261001/`.
Next diagnose charset contradictions offline from retained bytes before any
separate adapter; preserve strict-original failure report. Never substitute
Wikipedia summaries for full stories or silently redraw failed IDs.
CPU-only125pass/oneGPUskip; subsequent focused whole-token marker/parser+
frozen-output checks26pass. One existing dependency warning.

The100-document GPU job remains live PID3966311/toolsession31054, latest
checkpoint266/300. Narrative download process77102 is terminal,
independent preflight verified. GPU source dependencies remain frozen and
unchanged. No primary aggregate/CI is interpreted while quality run is active.

The independent preflight verifier initially compared CRLF-preserving decoded
text through `Path.read_text`, which normalizes line endings. Its initial
source is preserved; the comparison now decodes stored UTF8 bytes directly.
All original byte/text hashes and coverage checks pass; downloaded evidence
and selection were unchanged.

Protocol clarification before final quality analysis: the fresh-document
preregistration listed64/128/512 generation limits as shorthand but explicitly
anchors generation to the original per-task semantics. Unchanged source
`DATASET_TO_MAXGEN` gives TriviaQA32, MultiFieldQA64, HotpotQA32, Qasper128,
GovReport512. All three arms used those native caps; no cap was overridden,
adapted after observing scores, or silently doubled. The independent report
verifies every record against the frozen native task limits.

### NARRATIVEQA-CHARSET-ADAPTER (preregistered, 2026-10-01 IST)

Strict preflight preserved3UnicodeDecodeError cases. Their HTTP headers claim
UTF8 but original HTML meta tags explicitly declareISO8859-1. Frozen official
WHATWG encoding labels map that HTML label toWindows1252 (primary source:
https://encoding.spec.whatwg.org/; encodings.json URL/SHA256 recorded alongside
Narrative metadata). Offline adapter may re-decode only these3preserved raw
bodies, without new network requests, source/story replacement or changed
marker/word gates. Require the in-body Latin1 label, failed declared UTF8,
strictCP1252 decoding and exact byte round-trip before HTML extraction.
Write newtext_v2/encoding_preflight_v2 evidence, preserving original errors,
source bytes and all20selected stories. Re-run the same ordered whole-token
markers/5Kword minimum; failed markers remain failed. No model inference or
quality selection occurs in this phase. This is documented encoding repair,
not unchanged-source or browser HTTP-priority behavior.


### NARRATIVEQA-CHARSET-ADAPTER (outcome, 2026-10-01 IST)

Offline decode succeeds for all3preserved raw bodies with conflictingUTF8
headers and explicitISO8859-1HTML meta labels. StrictWindows1252 round-trip
preserves raw bytes; WHATWG labels/sourceSHA verified. Same ordered whole-token
markers/5Kword gate admits2more stories; thirdstillmissing original startmarker.
Readiness16/20 (10books+6scripts). No new requests, replacement, changed
selection or model evaluation. Alloriginalerrors retained in immutable v1.
Independent verifier confirms unchanged17other rows, source/selection/raw/text
hashes, encoding evidence, byte roundtrip and unchanged content gates.

Remaining4failures:1URL unavailable,3start markers absent. Inspection shows
all3start markers are `if ( window`, original websiteJavaScript boilerplate,
not narrative prose. It is excluded by visibleHTML extraction and may have
changed at source. Do not silently weaken predicates or include site code to
manufacture fidelity; full-content/source review is still needed before any
exception. Token/truncation/annotation/semantic/training qualifications remain.
Artifacts: `narrativeqa_test_stories_20261001/encoding_preflight_v2.json`,
`verified_encoding_v2.json`, exactexecutedadapter and original evidence.

CPU-only126pass/oneGPUskip; oneexisting warning. Original main100-document
model job remains live PID3966311/session31054, latest293/300records.
Report only after all300 records and terminal status are verified. Do not
restart on an observation timeout. No aggregate quality decision made yet.

### REALQ-CPU-SYSTEMS-GATE (preregistered, 2026-10-01 IST)

The independently verified100-document/five-task study passes paired quality
NI and superiority versus GPU proxy: +5.8658points,95%CI[3.1641,8.8280], but
17regressions/5losses>10 remain. GPU/CPU actual-query exact state/output holds
on all100documents. Next compare GPU actual-query control versus CPU+batchscore
actual-query at unchanged1024/2048/.75/quota32/bf16. Reuse existing fixed16K
prompt/50teacher inputs; add only opt-in query capture to existing comparator.
Before speed trial, require complete boundary-state/prediction/visibility/
counter parity at4K/8K/16K,5decode steps,warmup0. Then3ABBA blocks at16K50,
warmup1/repeat1 perarm, eagerdecode+SDPAprefill, capture cost charged to TTFT.
Acceptance: candidate medianITL≥5%faster, p95≤2%worse, everypaired blockfaster;
reportTTFT≤10%guard, prefill/decode peaks and host occupied/reserved/submitted
bytes. No actual-resource equality/SnapKV speed/physicalSTT claim. Preserve
raw/source for every result; no source tuning based on this fixed-trial outcome.


### REALQ-CPU-FRESH-DOCUMENTS (verified outcome, 2026-10-01 IST)

All300 arms completed normally; tool31054 terminalexit0, PID3966311 gone,
GPU0 idle before subsequent jobs. Independent reporter verifies all100source/
slice/context/sample identities, archive/runtime/source hashes, official task
scores/first-line trimming, EOS/caps, query capture/consumption and exact GPU/
CPU actual-query generated IDs, metrics, final state and trajectories.
Primary task-balanced CPU actual-query−GPU proxy **+5.8657516**, preregistered
10000-draw paired document bootstrap seed20261003 CI95**[3.1641294,8.8279760]**.
NI lower>−.5 and aggregate superiority lower>0 bothpass. Per-task deltas:
Qasper+12.15397, MultiFieldQA+8.27167, HotpotQA+5.92658, TriviaQA+2.5,
GovReport+.47653. **17/100regress,5losses>10** (Qasper1,HotpotQA2,GovReport2).

Supports conditional placement quality at equal configured Tiered budgets,
not uniform per-document quality, matched physical resources, speed, faithful
SnapKV superiority, NarrativeQA or SOTA. One model/seed/fivefixedtasks; semantic/
training overlap unverified. Do not tune on these now-inspected documents.
Raw/source/manifest and immutable independent report:
`realq_cpu_fresh_documents_20261001/verified_report.json`.

Combined actual-query GPU/CPU fixed-stream4K/8K/16Kfive-step fullboundary
parity now also passed (`realq_cpu_systems_20261001/parity.json`). Added only
opt-in existing query capture to the comparator; source frozen before GPU job.
Full suite127pass, one existing dependency warning. Three-block16K50ABBA
currently running on GPU0/tool58353 under shared lock; no results inferred yet.


### REALQ-CPU-SYSTEMS-GATE (verified outcome, 2026-10-01 IST)

Actual-query GPU/CPU full4K/8K/16Kfive-step parity passes. The unchanged-source
three-block16K50ABBA completes12arms (eachwarmup1/repeat1). All final full
states, visibility/positions/shadows, predictions and logical counters agree.
Independent source/parity/state/timing/resource verifier passes.
GPU/CPU medianITL81.32949/75.27026ms, **7.45023%faster**, p9589.45051/84.69808ms;
everypaired block faster. Latency≥5%/p95≤2%/everyblock guards pass. TTFT
2179.571/2254.9935ms (+3.46043%) passes10% guard. Prefill peak18.69657/18.62783 GB,
decode peak15.13634/14.91325 GB, final GPU allocation14.85016/14.62698 GB
(~223.18 MB lower; far below10% model-wide memory guard). Hostoccupied211812352B,
reserved402784256B; submittedH2D315621376B/D2H211812352B including initialization.
Physicalhostresources unequal; no SnapKV throughput/STT/endurance claim.

Artifacts: `results/hardware/realq_cpu_systems_20261001/` includes immutable
parity,12armABBA, executed source bundle/hash manifest and independent
`verified_gate_report.json`. Tool92593/parity and58353/ABBA terminalexit0;
GPU0 returned16 MiB. Full local suite127pass (before parity/ABBA), oneexisting
warning; no dependency edits during activeGPU jobs. DefaultGPU/proxy retained.

Combined evidence now supports opt-in actual-query placement quality on
100previously unused normalized documents/fivetasks plus an exact same-placement
physicalCPU batching latency gain on one controlled stream. Keep17quality
regressions/5large losses visible. NarrativeQA16/20data preflight, another
model, process/allocator peaks, concurrency/saturation generality, independent
headline rerun, faithful resource-matched baselines and physicalSTT/controller
verification remain open. Do not mark broad research/paper goals complete.


### REALQ-CPU-CLI (integration plan, 2026-10-01 IST)

Expose the already verified physical CPU/score batching path through the
query-selection experiment runner with an explicit LRU-only opt-in flag.
Preserve GPU defaults and source before edits. Record occupied/reserved host
bytes and submitted transfers without materializing canonical CPU snapshots;
release pools after task statistics are captured, including evaluation errors.
Acceptance: CLI rejects unsupported strategy combinations before loading model,
existing suite passes, and one GPU-backed matched-input CLI smoke reproduces
GPU actual-query IDs/quality/logical counters. This integration is not another
quality or performance study; no new headline claim or defaults promotion.


### REALQ-CPU-CLI (integration outcome, 2026-10-01 IST)

Added LRU-only `--cpu-batched-scores` to existing query-selection runner.
MeasuredCpuPolicy uses existing timing wrapper and unchanged ScoreBatchPolicy
through cooperative inheritance. Unsupported query/centroid CPU combinations
fail before model loading; default GPU backend retained. CPU reporting avoids
canonical cold tensor copies, records occupied/reserved bytes and submitted
H2D/D2H, and resets task pools after capturing statistics, including evaluation
exceptions. Both GPU0 CLI processes exit0 under shared model lock.
One reused Qasper sample: equal prediction/score/prompt2329/generated63/logical
counters/317329408B logical payload. CPU hot134217728B, occupied183111680B,
reserved402784256B, H2D390332416B/D2H183111680B inclinitialization.
All127 tests pass; unsupported strategy CLI exit2 as expected; diffcheck clean.
Preregistration limitation: normal runner exports token counts/text but not IDs;
planned CLI ID equality could not be asserted. Earlier dedicated GPU/CPU
full-state checks establish IDs, but are not this smoke. No quality/speed
claim from this reused one-input integration. Frozen before/executed sources,
raw outputs and independent verifier/report in
`results/hardware/realq_cpu_cli_20261001/`.

Next broad work: NarrativeQA conditional source coverage, process/pinned
allocator peaks, concurrency, fair faithful-baseline comparisons and actual
STT/controller evidence. Full research/paper goal stays active; estimate remains
10–20 working days, contingent on hardware access and research gate outcomes.


### NARRATIVEQA-CONDITIONAL-QUALITY (preregistered, 2026-10-01 IST)

Evaluate all16 usable stories from the frozen20 official test-story selection,
no replacement or source/marker relaxation:10books/6movies,4source failures
retained in denominator/manifest. Original metadata QA/answers and current
verified adapted full story text; native NarrativeQA prompt, F1,maxgen128,
EOS,seed0,Mistral7B,31500standard middle truncation. Record original prompt
tokens, retained tokens and exact truncated input-ID hash. All three arms
GPU proxy/GPU actual-query/CPU actual-query use1024hot/2048cold/.75fill,
bf16,sink4/recent128/quota32; actual query chunk128. Rotate armorder bystory.
Require CPU/GPU actual-query exactIDs/scores/fullstate/trajectory/counters.
Primary quality delta CPUactualquery−GPUproxy over16 feasible stories; paired
10000draw story bootstrap seed20261005,95%CI; NI lower>−.5,superioritylower>0.
Kinds10/6 reported descriptively; report every regression/loss>10. Availability
conditional adapted NarrativeQA, not published LongBench sample set or all20
intent-to-evaluate quality (four outcomes missing), not population/latency
claim. Source bytes/selection fixed beforemodel. No tune on this new holdout.


NARRATIVEQA-CONDITIONAL-QUALITY launch: frozenmanifestSHA
752ae3b68d6c912180f1139df0d9f1505c54151cc2e039bc126e1841a924c47c,
sourcebundleSHAe67ef166cacad1205bc235eec29198295f2e074be9f081e574997b919ac4b685.
GPU0 owned process under advisorylock/tool91534;48plannedarms. Independent
reporter prepared while job runs; no inference dependency edits. Partial
checkpoint is not a verified complete outcome.


### NARRATIVEQA-CONDITIONAL-QUALITY (verified outcome, 2026-10-01 IST)

All48arms complete normally; ownedPID3995768 gone,tool91534 terminalexit0,
GPU0returned16 MiB. Independentreporter/tool29687 terminalexit0 verifies source
bundle/runtime/hash, all frozen selectedQA/answers/raw/text, exact truncated
inputIDhash/prompt/counts, nativeF1/EOS/cap, rotationorder, all16CPU/GPU
actual-query IDs/quality/fullstate/trajectory/counters. Originalprompt14066–52345
tokens;6of16standardmiddletruncatedto31500.

Mean CPUactualquery−GPUproxy **+0.3648905**,proxy/candidate21.71897/22.08386,
10000draw storybootstrap seed20261005 CI95**[−7.7963173,+9.0604204]**.
**NI−.5 andsuperiority gates bothfail; inconclusive**, not proven harmful
aggregate and not proven noninferior. **6/16regress,4losses>10**. Descriptive
books10delta+4.81653/scripts6delta−7.05450; no subgroup population claim.
Four sourcefailedoriginalselections remain missing/no replacement, so outcome
conditional16/20currentadapted officialteststories, not LongBenchpublished
slice/intention-to-evaluate20quality. No tuning on this now-inspected holdout.
Severe losses include one untruncatedbook16.67points and three scripts15.38/
31.75/15points; standardtruncation is not a demonstrated sole cause.

Outcome supports exact physicalCPUplacementimplementation; positivefive-task
quality does not establish uniform NarrativeQAquality. Keep path opt-in, broad
quality/stress requirement open. No speed/resources/Snap/physicalSTT claim.
Artifacts `results/baseline_fidelity/narrativeqa_conditional_quality_20261001/`:
frozenmanifest/sourcebundle,raw48arms,prepared/executedreporter and immutable
`verified_report.json`. Next: fair actualresource/processallocator measurement
and supportedmultirequest integrity; diagnose quality only on development or
preregistered causal probes rather than tuning this holdout.


### CPU-MULTIPOOL-STREAM-INTEGRITY (preregistered, 2026-10-01 IST)

Native H2D caches a host pointer but captures it by value at each CUDA launch;
backend registers each request pool immediately before dispatch. Check2/4
independent request pools×2layers on single/alternating2CUDAstreams,32rounds,
request/layer/round tagged bf16 payloads. Queue writes/repeatedslot overlap,
ragged/reverse/repeated/emptyreads without per-read CPU synchronization; verify
all delayed read values exactly after dispatches. Reset one pool with queued
writes while other requests retain ownership, recreate distinct tagged pool,
require no contamination and final idempotent cleanup. Freeze source/binaries
and retain failed evidence. Serialized Python host dispatch only: this is
storage integrity, not threaded register/launch safety, model concurrency,
throughput/saturation or physicalSTT. No backend edits unless failure has a
credible identified cause. Acceptance all scheduled values exact/noCUDAerrors
and poolreset/isolation.


CPU-MULTIPOOL-STREAM-INTEGRITY passes768 delayed exactK/V observations across
2/4requestpools×2layers×1/2CUDAstreams×32rounds.48overlapflushguards and4
queuedwrite reset/recreation/idempotentcleanup scenarios pass. GPU0tool84685
terminalexit0, native/backend sources unchanged. Frozenrunner/backend/raw/
verifiedsummary `results/hardware/cpu_multi_pool_20261001/`. Source inspection:
nativecachedhostpointer is captured byvalueperlaunch, so laterregistration
does not change alreadyqueuedCUDAkernels; Pythonregister/launch calls still
not atomicacrossthreads. No threaded/model-serving/saturation/throughput claim.

### CPU-INTERLEAVED-MODEL-INTEGRITY (preregistered, 2026-10-01 IST)

Three fixedrealtext requests:A4K12decode,B8K24decode,Cdistinct4K12decode,
Mistral7B/seed0/bf16/default1024/2048/.75budgets,actual-querychunk128. Compare
isolated GPU andisolatedCPU controls withinterleavedCPU requests;A/B live
together, retire/resetA after12steps thenprefillC whileBcontinues. Serialize
model hostforwards ondefaultstream, explicitabsolutepositions, fixedlength
greedydecodeignoresEOS. Requireeveryboundaryfullstate/history/finalcounters/
predictedIDs identical perrequest acrossschedules; cleanuponepool cannot
changeothers. Querycaptureattachedonlyduringeachrespectiveprefill. No speed/
freeEOSquality/threadedbatch/streamoverlapheadlineclaim. Freezehash/source
beforeGPU execution, preservefailures; backendunchanged unless evidence.


### CPU request isolation outcomes (verified, 2026-10-01 IST)

Cold storage768delayedK/Vchecks pass2/4requestpools×2layers×1/2CUDAstreams,
48overlapflushes and4queuedwritereset/recreation/idempotentcleanupcases.
Model-levelthreefixedlength greedy requestsA4K12/B8K24/Cdistinct4K12decode
allmatchacrossisolatedGPU/isolatedCPU/interleavedCPU:generatedIDs,51full
cacheboundaryhashesperschedule,finalfullstate/history/logicalcounters. A/B
liveconcurrentlyinPython;retire/resetA at12thenprefillC whileBcontinues.
CPU transfer/backendunchanged. Interleavedmodel executionserialized ondefault
stream;complete-stateobservers synchronizeso not asynchronousserving. No
threadedregister/launchatomicity, batchedmodelthroughput, saturation, allocator
peaks, EOSfreegenerationquality or physicalSTT claim.

Artifacts `results/hardware/cpu_multi_pool_20261001/` and
`results/hardware/cpu_interleaved_model_20261001/` contain frozenexecuted
runners/backends/raw andindependenthash/count/equality summaries. Tools84685
and30715 terminalexit0;GPU0returned16 MiB,otherGPUuntouched. Pythoncompile/
diffcheckpass;lastfullsuite127pass remainsapplicable becauseproduction/core/
backend unchanged;newresearchharnessescheckedbyactualGPUexecution.
Do not closebroadconcurrency/physicalresourcescheckbox: storageintegrity and
serializedmodelrequestisolation proven, throughput/generality stillpending.
Next concreteevidence: freshprocessRSS/VmHWM/GPUreserved/pinnedallocator
accounting and actual-resource faithfulbaseline comparisons.


### REALQ-FRESH-PROCESS-MEMORY (preregistered, 2026-10-01 IST)

RunonefreshPythonprocessperarm GPUactualquery/CPUbatchedscoresactualquery,
16Krealprompt/50fixedteacherdecode, existingchunk128/bf16/default1024/2048
/.75sink4/recent128/quota32. OnearmperprocesssharedGPU0lock. Record/prove
sameinputs,generatedIDs/finalfullcachehash/logicalcounters. GPUallocation/
reservedpeaks sinceaftermodelload; process/procVmRSS/VmHWM/RssAnon/RssFile/
VmLck plus20mssamplingduringmodelprefill/decode. VmHWM includesimport/model
load, not phase-resettable; RSS samplinglowerbound not exacthighwater.
Trace onlyexplicit torch.empty(pin_memory=True) requestedrootstorages via
weakref finalizers; peakownedrequestedbytes includes perlayer→sharedpool
consolidation overlap. This is not allocatorphysicalreservedpeak. Local
Torch2.5exposes nohoststats but internal_host_emptyCache ispresent:after
GPUcompletion/policyreset/releasingtensors/gc, observebefore/afterhostcache
flush andGPUcacheflush. RSSdifferences descriptive, notexactpinnedbytes.
Requirezeroownedpinnedrootsaftercleanup, unchangedGPU/CPUIDs/state/counters.
Memory10%modelwidepeakgate reportedonlyifqualityNIeligible; unequalhost
resources andfailedNarrativeQANIremain, nopromotion/fairbaselineclaim.
Freeze sourcebeforeinference, preservefailures.


### REALQ-FRESH-PROCESS-MEMORY (verified outcome, 2026-10-01 IST)

GPU/CPU tools65865/74991 terminalexit0, distinctfreshprocesses, identical16K
inputs/50teachers/predictedIDs/finalfullstate/logicalcounters. Samefrozen
source; no backend/corechange. Independentverifierchecks52boundaries/arm,
GPUreserved≥allocated/peaks, RSS≤lifetimeHWM, explicitpinnedownershipevent
accounting and cleanup. Native transfer binariesremain sameverifiedbuild.

GPUpeakallocation18696433664/18627830784B =**.3669303%lower**, not10%gate;
peakGPUreservation20600324096B both. Finalgenerationallocation14993305088/
14768592384B (lastout/logits/attentions still live; do not conflateolder
posthelperreturnfinalallocation scope). RSSsampledpeaks1574887424/2674638848B
(lowerbounds20mssampler). LifetimeVmHWM15195963392/15191769088B dominated
by import/model-loadhistory; not phase-resettable.

CPUroottrace33allocations:32perlayerpools+oneconsolidatedsharedpool,
requestedownedpeak805568512B/final402784256B/occupied211812352B. Weakref
root ownershipzeroafterGPUcompletion/reset/gc, no rootleak. CPUprocessRSS
afterreset2680774656B, afterinternalhostcacheflush1604935680B (drop1075838976B).
GPUcontrolRSSdrop2097152B. InstalledTorch2.5CachingHostAllocator.h:131 uses
PowerOf2Ceil(size); explicittraceinfers32×16 MiB+512 MiB=**1GiB** capacity at
consolidation, consistentwithmeasuredRSSdrop. Thisis source/traceinference,
notdirectphysicalallocatorreservedmetric; nopublichostallocatorstats here.
CUDApinnedallocations notshowninVmLck (0), so do not useVmLck asinventory.
GPUemptycache afterwardreducesreservation14.50810 GB both; modelstillowned.

Evidence `results/hardware/fresh_process_memory_20261001/`: frozenexecuted
runner/backend, rawfreshprocessoutputs, independentverify_result.py/report,
installedheader snapshots/hashes andallocator_rounding_audit.json. Noquality
promotion (NarrativeQANIunproven), latency/fairSnapbaseline/physicalSTTclaim.
Current CPU path adds materially morehostmemorythanlogicalcoldoccupancy;
future directsharedpoolinitialization mayavoidperlayerpoolconsolidationpeak,
but requires preregisteredfreshprocess/parity/TTFT guards beforeimplementation.
Memory measurement completed narrowly; broadphysicalresources/alllengths/
concurrency/saturation/controllerhardware gates remain open.


### CPU-DIRECT-SHARED-INIT (preregistered, 2026-10-01 IST)

Mechanism:allocateonepinnedsharedroot beforefirstlayerinitialization, bind
eachcacheview to itsregion andwriteinitialselectedKV directly withunchanged
nativeD2H. Flushperlayerduringprefill to avoidholdingallcoldGPUrows. Reuse
unchangedSharedPooldecode/read/eventownership andexactbatchedscoreupdates.
Newexperimentalpolicy/module only; oldCpuBatch/ScoreBatch controls unchanged.
Primaryhostmetric explicitownedrequestedrootpeak≤402784256B (50%lower than
805568512B), trace-roundedcapacity512 MiB ratherthan1GiB, no leakedroots.
Fresh16K50GPU/oldCPU/directCPU parity allIDs/finalfullstate/counters;4K/8K/
16Kboundary parity andnativepoolreset/isolation. PrefillTTFT≤10%regression
vsoldCPUactualquery inthreeABBAblocks,warmup1. Full-loopdecode≥5%gain not
expected frominitialization-onlychange: requiremedian/p95no>2%regression/
allblocksreport, do notclaimnewdecodeimprovement. GPUpeaknot>2%worse.
Noqualityselectionchange; inheritedNarrativeQANIunproven, opt-inonly. Freeze
oldsource/raw(memoryaudit) andcandidatebeforeinference, preservesfailure.


Direct-init full4K/8K/16Kfive-step modelparitypasses, freshmemorycontrol/
candidatebothcomplete:requestedpinnedpeak805568512→402784256B (50%), GPU
peakallocation18627830784B same. BeforeABBA corrected comparator's dispatch
reportingonly:directinitializationalreadyincludedinmanager.d2h_calls, so
per_layer_initial_d2h_calls0instead32toavoiddoublecounting. Originalexecuted
parity/memorysourcebundle preserved; separateabba_source frozenbeforetiming.
No changes to candidate transfer/policy mechanism afterthese results.


Directcandidate stress extension beforeexecution: reuseoriginal768-observation
independentpool/1–2CUDAstream/overlapflush/reset checker with--directonly
changingpool/cacheinitializer. Defaultcheckercontrolretained, oldexecuted
source/raw preserved. Candidate decode/event/routingunchanged; requireall
checksagree. No threadsafety/throughputclaim.


### CPU-DIRECT-SHARED-INIT (verified outcome, 2026-10-01 IST)

New experimental DirectScorePolicy/DirectCpuCache/DirectSharedPool initializes
one shared pinned root before the first layer, then dispatches each layer's
initial selected KV directly into its view. Existing SharedPool read/decode/
event ownership and batched_update reused unchanged; oldbackend/core remain
controls. Source frozen in source.tar.gz; dispatch-count reporting correction
only recorded before separate abba_source.tar.gz.

Full4K/8K/16Kfive-step model cache-boundary/state/IDs/history/payload parity
passes;32syntheticcases (1,31,32,33,95,96,97,256tokens×inclusive/exclusive×
75/100%fill,2layers/12steps) match allK/V/metadata/counters andcleanup. Direct
multiplepool/stream extension passes768delayedK/Vchecks/48overlapflushes/
4queuedwrite reset/recreation cases. No threadedmodel serving proof yet.
Freshprocesscontrol/candidate match IDs/fullstate/counters. Explicit pinned
rootpeak805568512→402784256B **50% lower**, allocations33→1, finalowned
402784256Bsame, roots0afterreset. Trace/header rounding infers1GiB→512 MiB
capacity, not allocator telemetry. Sampled generation RSS2674462720→
2130558976B (~543.9 MB lower), GPUpeak18627830784Bsame.

3ABBAblocks16K50,warmup1/repeat1, twelvearms allfullstate/history/IDs/logical
counters/transferpayload equal. MedianTTFT2237.6935→2285.306ms **+2.12775%**,
within10%guard. Decode median76.02024→75.88255ms **−.18112%**, p95
85.54104→85.62958ms **+.10350%**, bothwithin2%regressionguard, allblocks
reported. No5%newdecodegain claim. Prefillpeak18627831296Bsame, ≤2%guard.
Independent memory/parity/source/timing verifier and multistream verifier pass.

Evidence `results/hardware/direct_shared_init_20261001/` retains frozen old
runner snapshots, two sourcebundles/manifests, rawparity/memory/synthetic/ABBA/
multiplepool results and independent verify_result.py/verified_report.json/
verified_multi_pool.json. Tools5303/parity,6963/controlmemory,60105/candidate
memory,88037/synthetic,71137/ABBA,57576/multipool terminalexit0. GPU0returned
16 MiB; unrelatedGPU1untouched. Fullsuite127pass beforemeasurements; subsequent
comparatorchange dispatch-reportingonly; newharnesses compiled/GPUexecuted.

Decision: opt-in conditionalhostmemory engineering improvement; noquality
placement change, model-wideGPUmemorygate or defaultpromotion. NarrativeQA
NI remains unproven. Normal evaluation CLI integration/direct modelinterleaving
proof stillpending; faithful resource/width-matched baselines, saturation,
secondmodel, actualSTT/controller and independentheadline remain broadopen.


### CPU-DIRECT-INTEGRATION (preregistered, 2026-10-01 IST)

Expose the verified DirectScorePolicy via --cpu-direct-shared in the query
runner; require --cpu-batched-scores/LRU, preserve defaults. Record direct
source identity and existing host/transfer metrics, reuse task cleanup.
CLI smoke: one reused Qasper input, compare oldCPU/directCPU text/token
counts/score/logical counters/payload, no new qualityclaim/tokenIDexport.
Model integrity: existing A4K12/B8K24/Cdistinct4K12 checker adds --direct
only to interleaved CPU arms; isolated GPU/oldCPU controls rerun in same
harness. Requireall51boundaryframes/schedule/IDs/state/counters equal and
reset/reuse isolation. Serialized defaultstream; no serving throughput claim.
Freeze sourcebefore execution. Unsupportedflag combinations fail before
model load; fullsuite + actualGPU runs.


### CPU-DIRECT-INTEGRATION (verified outcome, 2026-10-01 IST)

Added --cpu-direct-shared to query-selection CLI, requiring existing
--cpu-batched-scores/strategyLRU. MeasuredDirectCpuPolicy reuses existing
MeasuredTieredPolicy timing/host payload reporting/taskcleanup around unchanged
DirectScorePolicy. Config records direct backendSHA and flag. Unsupported
missingCPUflag/nonLRU combinations exit2 beforemodel load. Defaults retained.

Rerun modelchecker with --direct only for interleavedarms: isolatedGPU/oldCPU
controls sameharness, A4K12/B8K24/Cdistinct4K12, all51boundaries/schedule plus
generatedIDs/finalfullstate/history/counters match. ResetA/recreateC whileB
continues proves serializedmodelrequest ownership for directinitializer.
NativeEOS CLI oldCPU/directCPU reusedQasper item match prediction/score/token
counts/logicalcounters/logicalhot+coldpayload/hostreservedoccupied/submitted
transferbytes. CLI stilldoesnotexport tokenIDs; dedicated modelchecker does.
No new quality/timing/throughput/threadsafety/physicalSTT headline claim.

Fullsuite127passed (oneexistingdependencywarning), invalidflagproof and
independent sourcebundle/hash/9armmodel/2CLI verifier pass. Tools67765/tests,
55578/interleaving,17339/controlCLI,23089/directCLI terminalexit0;GPU0idle,
otherGPUuntouched. Frozen before/executed sourcebundle plus rawoutputs and
verify_result.py/verified_report.json:
`results/hardware/direct_integration_20261001/`.

Direct initializer now usable and verified through normalexperimentCLI;
its50%host-ownedpeak improvement/TTFT+2.13%guard remain conditional evidence.
Broad resource/quality/stress/physicalSTT/paper requirements stayopen. Next
priority: current decode overhead and faithfulbaseline actualresource/attended
width controls; avoid any defaultpromotion based on these narrow successes.


### DIRECT-DECODE-LOCALIZATION (preregistered, 2026-10-01 IST)

Diagnostic cProfile of currentDirectPolicy withactual-queryprefill,16K
realtext/20fixedteachersteps, default1024/2048/.75bf16seed0. Profileonly
scoreupdate/decodepolicy calls; fullrun/traces are instrumentednotlatency
evidence. Freeze dependencies/sourcebeforeGPUrun; preservebaselineprofile
runner. Rank currenteviction/visibility/score/transfer work, choose a narrow
charged4msfalsification screen if measuredmechanism supportsone. No algorithm
edit/defaultpromotion from profiling itself; overlapping cumulative GPUwaits
not additive savings. Update status after diagnosticconclusion.


DIRECT-DECODE-LOCALIZATION outcome:640evictioncalls/.541s and protectedmask
.098s across20steps; scorebatchupdate.069s, sharedread.092s,flush.006s.
Policy-only total1.089s, includesnestedGPUwaits/observerwork; notadditive
savings or a speed gate. Biggest narrow charged screen: CPUprotectedmask.

### PROTECTED-MASK-NUMPY-SCREEN (preregistered, 2026-10-01 IST)

Replace repeatedtorch.tensor(positionlist)/CPU max/compare/bitwise kernels
with NumPyint64 conversion/max/vectorcomparison andtorch.from_numpy; preserve
nonint64 input fallback to existinghelper. No backend edit yet. Charge32
layers×~1057positions, variable/reversed/irregular realposition geometry,
ABBA3blocks20calls/arm,warmup4, CPUoperations andCUDA boundary synccharged.
Exactboolmask parity onempty/short/capacity/reverse/negative/repeated/int64
edge/allprotected/defaultwindow andfloat/bool fallback. Require≥4msmedian
per32layercall, all3blocksfaster,p95≤2%worse beforemodel candidate; failed
screen retained/rejected. Freeze source/dtype; no precision/selection drift.


### DIRECT-DECODE-LOCALIZATION / PROTECTED-MASK-NUMPY-SCREEN (verified outcome)

Current directactual-query16K20fixedteacher policy profile completesnormally
(tool27539exit0). Frozen sourcehashes/profilerbinary/textchecked.20_decode_step
calls cumulative1019.95ms,640evictions540.64ms,640protectedmasks97.96ms;
visible178.05ms,score68.62ms,sharedread91.81ms,flush6.23ms. These are nested
instrumentedhosttimes withGPUwaits, notadditive causal savings.
Source/prof/text/raw/independent summary:
`results/hardware/direct_decode_profile_20261001/`.

NumPyint64 protectedmask candidate:initialharnessimport failure exitsbefore
measurement (36945exit1), source/error preserved. v2 checkerassumed bool
positions valid, butexistingcontrolrejects bool subtraction; error/source/raw
preserved (92000exit1). v3 correctly requiresmatchingcontrol/candidate input
rejection ratherthandroppingthecase.33validmaskcases+3matchingrejections
pass; then3ABBAblocks×20calls/arm,warmup4,32layerspositions~1057 charged.
Baseline/NumPy medians3.726568/1.348185ms, saving**2.378383ms<4ms**, allblocks
faster/p95better butheadroomgatefails. Independenthash/case/count/ABBA/
statistics verifierpass. **Reject; no cache/helper integration or modeltrial.**
No architecture/backend/core/source tuning based on finaldata; thissynthetic
maskmicrobenchmark is notquality orfullmodel latency evidence.

Evidence `results/hardware/protected_mask_screen_20261001/`:allthreeexecuted
sources, initial_import_failure.json,v2failure/v3raw,verify_result.py and
verified_report.json. Tool31554terminalexit0. GPU0idle/otherGPUuntouched.
Existing cache code unchanged; profile/probeharnessesexecuted, diffcheckpass.
Next meaningful candidate needs larger cross-layer eviction-stage savings,
not another isolatedmask rewrite; preserve stableties/precision/floor/shadow/
positions/paidwrites and require charged4ms screen beforemodel. Broadgoalopen.


### BATCHED-EVICTION-SELECTION-SCREEN (preregistered, 2026-10-01 IST)

Screen fullvictim-selectionstage, not isolatedsort/mask:32layerspost-promotion
/post-appendhot arrays(~1057rows), CPUpositions/grace, GPUF32cum/age.
ReferenceexactproductionselectionAST extracted fromevict_and_demote through
beforebackup lookup (append intentionallyexcluded,bothinputs already appended).
Candidate pack masks/cum/age, GPUdivision/clamp/stableargsort/finitecounts,
bulkreturnsoftvictimIDs; batchhard/gracefallbackonlyremaininglayers. Charge
CPUmaskconstruction,padding,GPUtransfers/arithmetic, finitecounts/hostreturn
andfallback; allcostincluded.32typicalhomogeneous layers/ABBA3blocks20calls
(warmup4), require≥4msmedian saving/allblocksfaster/p95≤2%worse.
Parity edgecases zerooverflow,short/empty,ragged,ties,nonfinite,scarceordinary/
gracefallback/allprotected, F32subnormals. writeawarelambda0 only; no production
cache/policyedit until headroompasses andarchitectureparitypreregistered.
Frozen source/hash/raw everyattempt; no quality/speedclaim fromsynthetic.


BATCHED-EVICTION-SELECTION-SCREEN initialcomplete-stage candidate saves
3.918233ms (baseline10.286845/batched6.368612), below4ms; no advancement.
All declared parityregimes pass, but nonfinitefixturevalues were masked by
sinks, so add unprotectednonfinite cases before claiming broad edgecoverage.

### BATCHED-EVICTION-NUMPY-PREPARATION (preregistered, 2026-10-01 IST)

Distinctcombinedcandidate: samebulkGPUselectionstage pluspreviously exact
NumPypositionmask construction. IsolatedNumPycandidate wasbelowheadroom,
but combining2.38msCPUmaskconstruction savings with3.92msbulkstage savings
has credible≥4ms potential; measurewholecombination, do notadd timings.
SameABBA3blocks20calls/warmup4/32layers, control exactproductionASTunchanged,
allCPUpadding/conversion/transfers/GPUcompute/fallback/hostreturn charged.
Requireall parity/precision/stableties/finitecounts/fallback, ≥4ms/allblocks/
p95≤2% beforemodelarchitecturework. Place nonfinitevaluesoutsideprotected
sinks inedge fixtures; no stagealgorithm tuning/thresholdrelaxation. Preserve
initialsource/raw andcombinedsource/raw. No cache/backendedit yet.


### BATCHED-EVICTION-SELECTION / NUMPY-PREPARATION (verified screen outcome)

Initial fullselectionbatching:productionAST reference10.286845ms vs
6.368612ms, saving3.918233ms<4ms, failsheadroom. Preserve initial
probe_executed.py/result.json. Its nonfinitefixture valueswere sinkmasked,
so do not claimunprotectednonfinitecoverage fromthat initialrun.

Distinctpreregisteredcombinedcandidate fullycharges NumPyint64CPU masks
plus paddedGPUcum/age/division/stableargsort/finitecounts/bulkhostreturn/
conditionalhard/gracefallback. SamebaselineproductionAST. Source/control
conditions/thresholdretained;unprotectednonfinitecases added beforecombined
execution. Combined baseline10.369330/batched2.654512ms; saving**7.714817ms**,
all3blocksfaster,p9510.469845→2.708761ms; **4msheadroomgatepasses**.
Primary32×1057 postpromotion/postappendfixture and6edgegroups (zerooverflow,
raggedties,gracefallback,allprotected,nonfiniteoutside sinks,subnormalF32)
matchallvictimIDs. Conditionalwriteawarelambda0 only.

Independent sourcehash/productionASTidentity/7casegroups/ABBAorder/counts/
stats/gatesverifierpasses. GPUtools32765initial/73180combined terminalexit0,
GPU0idle/otherGPUuntouched. Freezeoriginalcorecontrol andbothscreenrunners/
NumPyhelper/raw/verify_result.py/verified_report.json in
`results/hardware/batched_eviction_selection_20261001/`. Cache/model/core
unchanged. No fullsuite repeat because only syntheticprobe added/changed and
actuallyexecuted; last127pass stillapplies tocore. No model speed/quality/
faithfulbaseline/physicalSTT claim fromscreen.

Next meaningful implementation: opt-in cross-layer coordinator prepares
promotions and projected append/age states, uses bulk victimselection, then
existing physicaldemotion/compaction. Must preserveexact_t/LRU timestamps,
floor/deferredpromotioncounts, stableties/nonfinite behavior, grace/sinks/
recentpositions, shadowrestoration/paidwrites andresets. Preregister and
verifyisolated source-preserving selector extraction beforechangingruntime;
4K/8K/16K/maxcontext/syntheticboundaries/fullstateparity before ABBA≥5%
median/p95≤2%/allblocks/TTFT≤10%guards. Broaddecodegap and quality/resource
researchgoal staysopen.


### BATCHED-EVICTION-COORDINATOR (preregistered, 2026-10-01 IST)

Afterchargedcomplete-selection screen7.71msheadroom, implementopt-in staged
coordinator overDirectScorePolicy. Extract existing hotvictimselector into
virtualhelper withoutalgorithmchange; proveASTinlining restores original
evictbody, runcoretests beforecoordinator. Existingdirect/GPU defaults retained.
Coordinator usesexisting promotionplan/hysteresis/batchedreads once, stages
each promotion withnext_ttimestamp, projects post-append positions/cum/age/
grace, batchesexactGPUF32stablevictimselection+NumPyCPUhardmask, thenexisting
perlayer evict/demote/metadata/compaction/costrecord path consumesprepared
promotion/victims. No duplicateages/promotions/appends/hysteresis. Guard
unsupported lambda/dtype/partialgeometry withoriginalpath beforemutation.
Require timestamps/ages/cum/floor/deferred/grace/shadows/positions/KV alignment/
paidwrites/LRU/transferpayload/wholecachehash parity, projectedposition identity
checked beforeconsumingvictims. Reset clearsallpreparedstate; errorscleanup.
Gates:syntheticboundary/inclusion/fill/multi-token/decode parity,4K/8K/16K/
31500model cacheboundaryexactIDs/counters beforetiming;16K50ABBA3blocks
warmup1,≥5%median,p95≤2%worse,allblocksfaster,TTFT≤10%,GPUpeak≤2%worse.
Preservebefore/executedsource/raw/failures. Qualityselectionunchanged/inherited
NarrativeQANIunproven, opt-inonly; no faithfulSnap/physicalSTT claim.


Selector extraction wholebodyAST inliningproof + full128tests pass.
Firstsynthetic initialsource/raw retained: existingcontrolscoreupdater rejects
three-query attention tensors (tool70938exit1). Correct test to multipleKV
appends plus one last-querysummary, matchingexistingAPI; no claimarbitrary
chunkattention scoring. Twelvecalls append18tokens. Candidatealgorithm/core
unchanged; correctedharness in separate source_v2 bundle.


Modelparity6arms4K/8K/16Kexact; initialmaximum attempt failsbeforeinference
becausefixedprompt30907tokens<31500. Preserveparity.json/error/source_v2
(tool36642exit1); no coordinatoralgorithmchange. Preregister deterministic
maxprompt originaltext+newline+sameoriginaltext, first31500tokens; record
source/textSHA. Comparatoroptional--prompt-file only, defaultsretained;
newsource_v3frozen beforemax-only parity. No qualitycontentselection/tuning.


Cross-layer coordinator parity update (1 October 2026): all 32 synthetic
boundary cases and full model states at 4096/8192/16384 tokens passed.
The initial `parity.json` preserves a failed 31500-token request: the frozen
real-text prompt contained 30907 tokens, so inference did not begin at that
boundary. `max_context_prompt_manifest.json` freezes a deterministic doubling
of the same prompt, without candidate changes; `max_parity.json` passes the
31500-token boundary. Source v2 covers the initial parity trial; source v3
covers the optional prompt-file harness, maximum-context and ABBA trials.
Three ABBA 16K/50-step blocks are now running; no speed claim yet.


Cross-layer eviction coordinator gate (1 October 2026): archived verifier
recomputes exact source hashes, whole-body selector AST preservation,
32 synthetic cases, all four context boundaries, 12 ABBA arms and gates.
Median 74.8154 → 72.5004 ms = 3.0942% gain, below preregistered 5%:
REJECT performance promotion. All three blocks faster; p95 84.4049 →
77.1335 ms, TTFT 2271.9265 → 2271.7845 ms, prefill peak 18.627831296 GB
unchanged. All states/IDs/counters/payloads exact. No normal evaluator flag
added. Further free-generation/interleaved candidate gates are deferred
because this candidate failed the required speed gate. CPU/direct defaults
stay unchanged; prior independent NarrativeQA NI remains unresolved.
Artifact: results/hardware/batched_eviction_coordinator_20261001/verified_report.json.
Next research gate: matched resident resources and attended width against
faithful SnapKV, with joint quality/timing/peak evidence.


Preregister owned-KV envelope audit (2 October 2026): snap974prompt rows;
GPU Tiered991hot/2082cold/32quota; directCPU Tiered991hot/1090cold/32quota.
Include the visible cache copy and whole pinned root. All arms share512 MiB
steady boundary-owned KV ceiling and1024single-token forward row ceiling;
actual bytes/widths need not equal. Configurations derived algebraically, not
from measured quality. Actual-query Tiered placement unchanged. Fixed16K
realprompt/50teacherstream, seed0, 51boundaries/arm. No latency/quality claim.
No tuning these capacities on outputs. Frozen plan/source in
results/baseline_fidelity/snap_tier_owned_envelope_20261002/.

Owned-envelope audit independently verified153boundaries/4800forward-layer widths.
Snap487–512 MiB; GPU446.875–456.875 MiB; directCPU512 MiB (251.75GPU+260.25CPU).
Snap975–1024rows; Tiered1024. Equal ceilings, actual use unequal.
Preregister12sameprocessABBAarms Snap/directCPU withthese unchanged settings,
16K/50teachersteps, seed0,warmup1/repeat1. Shared nestedCUDA-sync wrapper;
SDPA fullprefill/eagerdecode, requiredTieredattentionweights. No diagnostic
snapshots within timing. Repeated IDs/counters/payload/finalgeometry mustmatch
within eacharm. ≥5%median/p95≤2%/allblocks/TTFT≤10% comparedagainstSnap;
recordfailures, no tuning or jointquality/physicalSTT/equalactualuse claim.
Timing plan and executedsource frozen separately in same envelope folder.


Shared owned-KV envelope systems result (2 October 2026): all12ABBAarms
and source/resource/repeatability verified. Snap median25.7417/p9525.9552ms;
directCPU median71.2026/p9578.6061ms, 2.7660×slower. All3blocks slower;
decode/p95 gates fail. TTFT2074.8358→2239.9855ms (+7.9597%) passes10%guard.
Prefill GPU peak16.958269→18.627831 GB; decode15.037793→14.901711 GB:
no10%modelwide memory improvement. These configurations share512 MiB boundary
owned-KV ceiling and1024forward-row ceiling, actualresources/widthdiffer.
CPU991hot/1090cold/32quota differs from prior default1024/2048quality study;
priorquality cannottransfer tothese capacities. No jointquality gate yet.
Artifact: results/baseline_fidelity/snap_tier_owned_envelope_20261002/verified_timing.json.
Refreshunused inventory:65Qasper/37Multi/241Hotpot/241Trivia/256Gov document
groups remain; NarrativeQA standardcorpus exhausted. BroadP0/P1/P2open.


Preregister shared-envelope independent quality (2 October2026): frozen100
new normalized unused documents,20each Qasper/Multi/Hotpot/Trivia/Gov;
selection/bootstrapseed20261005, modelseed0/nativecaps/EOS/31500middletrim.
CPU actual-query991hot/1090cold/32quota/directshared, faithfulSnap upstream
expanded32heads/window32/kernel5 withpromptcapacity1025-nativecap chosen
before outputs. SDPAfullprefill/eagerdecodeboth. Alternatepairedarmorder.
Per-boundary CPUownedroots+hot+visible<=512 MiB/nextforwardrows<=1024;
Snap finalowned<=512 MiB/growingwidth<=1024. QualityNI lower95CI>-.5,
superioritylower>0, task-balanced document bootstrap10000, reportallregressions
andlosses>10. No tuning inspected cohort, noNarrativeQA/generalquality claim.
Frozen source/data/plan: results/baseline_fidelity/snap_tier_envelope_fresh_quality_20261002/.


Allocator boundary clarification (2October2026), capacities unchanged:
shared512 MiB is liveKV tensor-storage, not physicalallocator reservation.
SameinstalledTorch2.5coreheaderSHA34433351...a43c7 usesPowerOf2Ceil(size)
atline131. DirectCPU rootrequest260.25 MiB roundsbythat source to512 MiB;
with251.75MiBGPUKV, inferred763.75 MiB beforecachedblocks/otherallocations.
This is source/geometryinference, not measuredactivehost-reservationtelemetry.
Do not claim equalphysicalmemory. Frozenquality/timing continueunchanged.
Artifact: results/baseline_fidelity/snap_tier_owned_envelope_20261002/allocator_capacity_note.json.


Shared-ceiling independent quality gate (2 October2026) completed:
100new normalized unused documents/five tasks/200arms, all source/data/seed/
exclusion/sampling/prompt/nativecap/EOS/counters/geometry verified. CPUactualquery
991hot/1090cold/32quota/directshared minusfaithfulSnap task-balanced−2.56985,
paired95CI[−5.293844,−0.507108], bootstrap10000/seed20261005. NI−.5 and
superiorityfail; 33regressions/10losses>10. TaskmeansQasper−1.7946/Multi−5.1511/
Hotpot−2.0519/Trivia−5.0/Gov+1.1482. All resource-boundary guards pass for
liveKV tensor-storage; activeallocatorroundingexcluded (inferred763.75 MiB
rootcapacity+GPUKV, not512 MiB physicalparity). ThreeABBA systems comparison
alsofailed speedguards (2.766×slower). No advancement/defaultpromotion or
SOTAclaim. This is a result for these frozen capacities/one model/seed, not
all Tiered configurations. Do not tune inspected100documents. Standard
NarrativeQA exhausted; prior adapted-storyNI and broader P0/P1/P2stillopen.
Fullsuite128passes after optional experimentalmeasurefactory extension;
all ownedmodeljobs terminal, GPU0idle. Artifact:
results/baseline_fidelity/snap_tier_envelope_fresh_quality_20261002/verified_report.json.
Next: allocator-reservation efficiency and structural retention/eviction
costs on development inputs, preserve full-model gates.


Preregister bounded pinned-pool prototype (2October2026). Cold append occurs
before overflow reclamation, but perpolicy promotion_budget bounds hotgrowth.
With steadyhot<=cap and n_new<=declaredmax, demotioncount<=budget+n_new.
Reservecold+promotion_budget+max_decode_append slots, with allboundguards
before mutation; logicalcold/hot/placement/sourceunchanged. For991/1090,
budget32/maxappend32 yields1154slots vs2082; 144.25 MiB request vs260.25 MiB,
source-inferred256 MiB activeblock vs512 MiB (not hosttelemetry). Primary25%
explicitownedhostpeak improvement, exactstate/payload and fullsystemguards.
Need syntheticmultiappend/cold-saturation + unsupportedboundrejection,4K/8K/
16K/31500fullmodelparity, freshprocessmemory and3ABBA16K50 TTFT/p95/prefill
guards; freegeneration/interleaved following gains. Do not tuneheldoutquality
orclaim10%modelpeak/physicalSTT/defaultpromotion. Frozenplan/before-source:
results/hardware/bounded_pinned_pool_20261002/.

Bounded-pool first gates pass:13focusedguards/full141tests,32native2layer
syntheticcases withinclusive/exclusive75/100%fill,multiappends,full75slot
transientpeak, exactstate/payload/counters, rejectionbeforemutation.
All4K/8K/16K/31500 fullmodelboundaryhash/IDs/counters/payloadexact;
31500usesrecordedextendedprompt. No timingclaim fromhashedparityruns.
Model-sourcebundle frozen beforeexecutedparity/freshprocess/timing.
Freshprocess991/1090 controlmemorytrial nowrunning.

Bounded-pool freshprocess primarypasses: oneexplicitpinnedroot each,
272891904→151257088bytes (44.5725%lower), cleanupownedroots0 each.
SampledRSSpeak2127233024→1857204224bytes (lowerbound270028800drop);
GPUpeak18627830784same. 50teacherpredictions/fullcanonicalstate/counters/
occupiedpayload/inputstream exact. This is hostmemory improvement, not
10%model GPU peak saving. Source-inferredactive512→256 MiB, notallocator
telemetry. Now3ABBA16K50 warmup1, p95≤2%/TTFT≤10%/prefillpeak≤2% guards.

Bounded-pool primaryandregressionguards independentlypass:44.5725%owned
pinnedpeak lower,p95−1.1672%,TTFT+.2444%,prefillpeakunchanged. Median−.7032%
not5%speedgain andthirdblockslightlyslower; no decodespeedclaim. Mandatory
stresspreregister:12developmentdocs (first2distinctnormalizedeach6tasks),
seeds0/1greedy/nativecaps/EOS/31500,24CPUdirect/boundedpairs48arms, same
991/1090logicalcapacities, requireIDs/fullstate/trajectory/counters/payload
exact. No newqualitysuperiority/inferencefromseedsgreedydiversity. Then3
interleaved/recycledmodelrequests matchingisolatedGPU/oldCPU atsamecapacities.
Fresh stress-source frozen separately; boundalgorithmSHA unchanged.
Manifestpreparation typo failedbeforedata/sourcewrites/inference; retained
stress_preparation_error.json. No candidatechange or incompleteGPUtrial.

Additionalwideappendboundary preregisterbeforeexecution: extendnativechecker
to36cases including991hot/1090cold/budget32/maxappend32 at4096prompt,
75/100%fillandbothinclusionmodes. Twentyfourcalls append210tokens with
lastquerysummaries only; require all1154physicaltransientslots reached in
onefullfillcase, exactcontrols, reject33-token appendbeforemutation.
Candidatealgorithmunchanged. Original32case source/raw preserved; newwide
sourcebundle frozen separately. Executeafterlivefreegenjobterminal.

Bounded-pool freegen48arms exact6tasks/2seeds; source preserved.
Additionalnativeisolationpreregister:4geometries(2/4pools,1/2streams),2layers,
32rounds, delayedreads/overlapwriteflush/queuedreset+recreation. Bounded
coldpool75slots via64cold+8promotion+3append, pointer/eventstorageisolation.
SerializedPythonhostdispatch; no threads/servingthroughput claim. Source
frozen underisolationbundle beforeexecute. Modelinterleave same991/1090
requestA4K12/B8K24/Cdistinct4K12, recycleA→CwhileBlive; compareall51frames
againstisolatedGPU/oldCPU, EOSignored asprevious fixedlengthisolationstudy.

Boundedpool fullmandatory stresspasses:36nativecases includingmax32append
full1154slottransientpeak;768delayedpool/stream observations with48overlap
flushes/4queuedreset+recreates;3interleaved/recycledmodelrequests exact51
boundaryframes againstGPU/oldCPU at991/1090. Serializedhost/defaultmodel
stream only, no thread/serving claim. BeforeCLIintegration addconstructor
rejection forhotcapacity<protected_sink+recent; this avoidsunsupported
geometry failingafterfirstdecode. Allmeasuredconfigs satisfyguard; AST
removalproof restoresentiretestedmodule, no selection/decoder change.
Newflag--cpu-bounded-pool requiresCPUdirect/shared/score/LRU andhot>=132
forfixedsink4/recent128; reservesbudget32+maxappend32. Defaultsunchanged.
Newintegration-source frozen beforeCLIcontrols; compareone reuseddevelopment
Qasper nativecap outputs/counts/score/payload/counters anddifferentreserved
rootbytes. Invalidflagsmustreject beforedata/model load.

CLIcontrol smoke initiallyusedoutdated../datasets/longbench/data andfailed
config hashingbeforemodelload; terminalerror savedcli_preload_error.json.
CorrecttoverifiedHFcache sourcefolder, candidatealgorithmunchanged. Full
143tests pass includingaddedprotectedwindowguard andwholemoduleASTproof.

Independentstress verifier initiallyusedUnicode-aware splitlines onJSONL
source, splittingvalidUnicode line-separator charactersinsidequotedcontext.
Preservebefore-fix verifier/error; readphysicalLFrecords instead, matching
runnerprovenance reader. No source/data/model/candidate changes or reruns.


Boundedpool milestone verified (2October2026): primary44.57%ownedhostroot
reduction andp95/TTFT/prefillguards pass,36nativecases/full1154slots,24free
generationpairs/6tasks,768delayedstreamobservations/48overlapflushes/4resets,
3interleavedrecycledrequests/51frames, CLIoutput/counts/score/payload/counters
match and3invalidflag combinations rejectbeforeload. Final143tests pass.
Opt-in--cpu-bounded-pool requires--cpu-direct-shared --cpu-batched-scores
--strategy lru, hot>=132; defaultsunchanged. Verified991/1090scope.
Before nextgeneralization no ownedGPUjoblive. Existingquality/speedfailures
remain; no globalpromotion/model GPU peak/physicalSTT/completion claim.
Evidence: results/hardware/bounded_pinned_pool_20261002/verified_stress_report.json.

Preregisterdefaultgeometry boundedpool audit: unchanged1024hot/2048cold,
budget32/maxappend32. Old3073slots402784256bytes vs2112slots276824064bytes
(31.27%lessrequested), but bothrootcapacitiesroundto512 MiB: do notexpect
allocator backingmemorygain. Exact4contexts+freshprocess50teacherstate/IDs/
payload/counters then3ABBAregressionguards/nativefullfill. Noqualitytuning.
Frozenplan/source: results/hardware/bounded_pool_default_geometry_20261002/.

Defaultgeometrymemoryexact:ownedroot402784256→276824064(31.2724%),
sampledRSSpeak2129731584→2128539648(1.19 MB difference), GPUpeakunchanged;
no observedlargeRSSgain/bothrootrounded512 MiB. Exact4contexts/50teacher
state/IDs/counters. ABBA running. Nativefullfillsupplement preregister4cases
1024/2048/32promotion/32append,2layers/24calls/210tokens,75/100%filland
inclusive/exclusive; require2112transientslots reached and33appendreject
beforemutation. Candidate unchanged; nativechecker/source separatelyfrozen.


Defaultgeometry boundedpool result (2October2026) independentlyverified:
1024/2048 unchangedlogicalcapacities, root402784256→276824064bytes (31.27%
requestedreduction), sampledRSS2129731584→2128539648(~1.19 MB difference).
Bothrootactivecapacitiesinfer512 MiB frominstalledallocator; GPUpeakunchanged
18627830784bytes. Exact4K8K16K31500cacheboundarystate+50teacherfreshprocess
outputs/counters/payload;4nativefullfill/inclusioncases reach2112transient
slots and33appendrejectedbeforemutation. ThreeABBA16K50median75.2151→
75.1726ms, p9584.6353→84.1376ms, TTFT2302.8145→2296.769ms, prefillpeak
same18.627831296 GB. Regressionguardspass; no5%speedgain or substantial
RSS/backingallocation gain. Special991/1090memorybenefit notgeneralized.
Defaultgeometry freegeneration/interleaved notyetverified; retainopt-in.
No defaultpromotion/qualitywin/physicalSTT/broadP0/P1/P2completion.
Artifact: results/hardware/bounded_pool_default_geometry_20261002/verified_report.json.
AllownedGPUjobs terminal; fullsuite143passes fromintegration, onlyexperimental
nativechecker optionalgeometryflag addedsince; no modelalgorithmchanges.

Preregisterfull50step CUDA-policy diagnosis 2October2026: existingdirectCPU
1024/2048 actual-query chunk128, fixed16Kprompt/50teacherstreamseed0.
Existing20profile undersamplescoldoverflow. Extenddiagnosticonlyrunner to
50 andoptionalNVTX/cudaProfilerApi collection arounddecode/scores; collect
nsysCUDA/NVTX withoutCPUsampling. Namedcacheevict/select/promote andpolicy
visibility/prepare regions. Keep backendunchanged. Compareoverflowstep
geometry withtrace; rankwaits/kernellaunches/Pythoncritpath. No speedclaim
or addingnestedtimes, requirecharged4ms screen beforeoptimization.
Artifacts: results/hardware/full_decode_trace_20261002/.


50stepNVTX/CUDAtrace (2October2026) disprovescoldoverflowhypothesis: all
32layers end1616/2048coldrows, nosaturation anyboundary. Trace142645kernel
launches,37037cudaMemcpyAsync,25837cudaStreamSynchronize. Innermosthost
range attribution: hotselection17600kernels/36800APIcalls; remainingevict
24768kernels/47040APIcalls; visible8176kernels/19826APIcalls. Evictexcluding
hotselection hostAPI4.447ms/step/devicekernels1.385ms, overlappingdiagnostic
notadditive. CProfile/NVTX/CUPTI perturbations; nofull-loop speedclaim.
Nextcandidate screenhotstatecompaction usingoneGPUintindex reusedacross
KV/cum/age replacingrepeatedCPUbooladvancedindexing. Currentpurebool path
wasalreadybetterthanPythonlist indexing; this isdistinctindex_select stage.
Require entiremask/keepindices/CPUpositionbuild/GPUindexupload/gathers
charged, exactstate,≥4ms saving andp95≤2%; no backendeditbeforepasses.
Evidence: results/hardware/full_decode_trace_20261002/verified_trace_analysis.json.


Sharedhotindex screen outcome2October2026: charged full32layer hotcompaction
control6.52006→candidate4.38838ms, saving2.13168ms<4msminimum. All12edge
checks and primary/ABBApostarmKV/metadata/positions bit-equal, all3blocks
better/p956.75623→4.60991, but REJECT modeladvancement. No backend/core edit.
CandidateisoneGPUintkeepindex reusedbyK/V/cum/age, CPUgrace+position list;
notcurrentCPUlist/booleanvariant. Cannotaddthisisolatedsaving toprior
hotselection savings orcallitfullloop speedgain. ExactarchivedproductionAST
and allrawtimings/hash independentlyverified. Verifier firstfailedabsolute
__file__key vsrelativearchive name; normalizedrepo paths, before/errorretained.
Raw/source unchanged. Diagnosticrunner compiles; no newproductiontestsneeded.
Artifact: results/hardware/shared_hot_index_screen_20261002/verified_report.json.
Nsight50trace falsifiescoldoverflowexplanation, instead manytinyAPIlaunches/
metadata/visibility operations. Profiler times perturb andoverlap. Future
architecturalstage should combine complete update/materialization with
chargedcausalproof; no defaultpromotion or tuningoftestedqualityholdouts.
AllownedGPUjobs terminal; broadP0/P1/P2 stillopen.

Preregisterhead-maxretention developmentpilot2October2026. Existingcausal
actual-queryplacement sumsallqueryheads toglobaltokenranking; faithful
Snapselectsperhead (differentlayout). Hypothesisminorityheadsignal diluted
bygloballycommonsalience. Onlychange: poolreceivedattentionperqueryhead
thenmaxacrossheads, same128window/chunk128/kernel5/1024hot2048cold/.75/LRU.
No perheadcache/headexpansion/budget/window/decode changes. Currentinitial
importancealsosetscum, so do notclaimprefillonlyqualityisolation. Sixreused
rare-answerdevelopmentprobes, require>=4/6answers plusbetterfullspanretention
andinitialgeometryequal; reproduceoldactualquerycontrol. CPUunitexpanded
reference/causality/chunking. Ifpilotfailsreject, no finalholdoutevaluation.
No tuningoftested100documents. Frozenplan/data: results/baseline_fidelity/head_max_retention_dev_20261002/.

Headmaxunit10tests pass (expandedcausalreference, poolingbeforemax,
chunkboundaries, patchrestoreonerror). Beforeexecution preflight verifies
frozenneedlecap64, not32mentionedininitialplantext; use unchangedmanifest
64/EOSstopping forbotharms. Correctplanbeforefreezingexecutedsource; no
probe/model hasrun yet. Existingneedleprior manifestSHA matches.


### 2026-10-02 — Head maximum development pilot and frozen broader screen

Six reused synthetic probes pass exact control replay and independent source/data/output verification. Both sum-head and max-head methods answer 6/6 correctly; complete answer-span retention increases only 154→156 layer/probe pairs. Frozen pilot permits broader development, not quality superiority. Full local suite: 153 passed (one dependency deprecation warning). Frozen broader plan: 12 existing development documents, six tasks, greedy seed0/native caps, same bounded CPU991/1090; exact previous control replay. Three ABBA blocks charge model/query/placement cost at16K and31500. Gate: development CI lower≥−.5 and no loss>10, plus ≤10% prefill regression and no peak increase. Fail either gate: stop this candidate before untouched evaluation. Evidence and preregistration in `results/baseline_fidelity/head_max_broader_dev_20261002/plan.json`.

Broader-screen first control replay stopped at prefill-query-shape comparison: live dict has integer layer keys, saved JSON has string keys. Earlier IDs/state/counters/payload fields matched. Preserve failed report/log/original source. Normalize comparison through JSON serialization only; no model, policy, selection or numeric change. Freeze v2 source and rerun identical preregistered inputs.


### 2026-10-02 — Pooled-head maximum fails broader development gate

Independent verification confirms all 12 previous bounded-CPU control outputs,
IDs, states, trajectories, counters, task-native caps/EOS and transfer payloads.
Source archives, JSON-key comparison repair, dataset/sample/prompt hashes and
recomputed metrics pass. Candidate uses the unchanged global-token GQA layout.
Six-task task-balanced difference: −0.6012 points, paired within-task bootstrap
95% CI [−3.0922,1.8898], 10,000 draws/seed20261006. Two regressions; one loss
over 10 points (NarrativeQA −17.2727). The −.5 noninferiority screen and
individual-loss screen fail. This reused development set is not independent
quality evidence. Different initial importance also changes later cumulative
eviction scores; no pure prompt-retention causal isolation is claimed.

Three ABBA blocks, one warmup per arm, charge complete model SDPA prefill,
rotary-query capture and bounded CPU placement. At16K, median2.25558→2.25637s
(+.0351%); at31.5K, 5.06368→5.06438s (+.0139%). Peaks are identical within
length (18.62783/22.41822 GB), initial geometry and151257088-byte root request
match, and placements repeat within each arm. Prefill guards pass; no decode
or speed superiority claim. Quality failure rejects this frozen candidate
before unused evaluation documents. Defaults stay unchanged. Owned GPU0
process exited; last full suite153passed.

Evidence: `results/baseline_fidelity/head_max_retention_dev_20261002/` and
`results/baseline_fidelity/head_max_broader_dev_20261002/verified_report.json`.
Next: close the explicitly open usual-budget free-generation/interleaved
integrity checks; then screen a complete update/materialization architecture.


### 2026-10-02 — Frozen usual-budget bounded pool final integrity checks

Close explicitly open1024/2048free-generation/interleaved proof. Same12developmentdocs/six tasks/native caps/EOS, onegreedyseed, alternating direct/bounded arms. Require exact predictions/IDs/quality/state/trajectory/counters/transfers; root402784256→276824064bytes. Existing serialized three-request recycling harness: exact51boundaryframes vsisolatedGPU/oldCPU, allroots reset. Source/data/plan frozen before GPU job. Parameterize only existing experimental generation runner manifest budgets/seed count; no policy or default changes. `results/hardware/bounded_pool_default_stress_20261002/plan.json`.


### 2026-10-02 — Usual-budget bounded pool free generation and isolation verified

At1024hot/2048cold, 12 direct-versus-bounded CPU free-generation pairs across
six tasks are exact in predictions, IDs, native caps/EOS, scores, state,
trajectories, counters, query shapes and submitted transfer payloads. Same
reused development documents, one greedy seed; occupied host data match.
Reserved roots differ402784256→276824064bytes as frozen. This establishes
storage preservation rather than independent quality superiority.

Three requests A4K12/B8K24/Cdistinct4K12 match isolated grouped-GPU and
old-CPU controls exactly at all51 complete boundary frames per mode. A is
reset/recycled into C while B remains live; all request roots reset cleanly.
Serialized Python/default model stream and fixed lengths ignore EOS in this
isolation test. No threaded/asynchronous serving, concurrency throughput,
saturation, physical STT or default-budget host-RSS gain is established.

Independent verifier checks executed source archive, dataset/sample/prompt/
input hashes, task metrics, caps/EOS, unchanged policy-class ASTs and all
per-boundary outputs. Generic experimental runner now reads frozen manifest
budgets and seed count. Its historical two-seed limitation string was fixed
for future runs after verification; raw/source are retained and exact
metadata-only text preservation is proved separately. No cache-policy or
default change. GPU0 owned jobs exited; last full suite153passed.

Evidence: `results/hardware/bounded_pool_default_stress_20261002/verified_report.json`
and `metadata_fix_report.json`. These explicitly close usual-budget
free-generation/interleaved integrity gaps, while broad P0/P1/P2 remain open.
Next: charged screen of complete update/materialization, then causal/actual
resource quality and wider systems gates. Estimate remains10–20workingdays,
contingent on hardware access and research outcomes.

Final local suite after manifest parameterization and metadata wording repair:153passed, one dependency deprecation warning. Raw output: `results/hardware/bounded_pool_default_stress_20261002/final_suite.txt`.


### 2026-10-02 — Frozen cross-layer fused hot compaction screen

Test single CUDA gather of allhotBF16KV/F32scores against exactproductionAST, chargecompleteCPUmask/index/descriptor/upload/validation/allocation/gather/grace/position path.32raggedsource layers withsame1024keptwidth. Require4msmedianheadroom/all3ABBAblocks/p95guard/bitwiseedgecaseproof. Ifpasses preregcoordinator+fused experimentalmodelvariant withcoldoverflow/unsupported fallback; no default/qualityclaim. Plan/source frozen in `results/hardware/fused_hot_compaction_screen_20261002/`.

Initial fused-compaction JIT attempt failed before compilation/GPU work because Ninja was absent from PATH. Existing native Ninja binary in external Flex environment is available; reuse executable via PATH only, preserve Torch2.5 Python/ABI. Failed source/result/log retained, environment binary SHA/version recorded before unchanged-source rerun.

Fused-compaction v1 verified:6.5895→6.2232ms, only.3663mssaving; no modelintegration. Diagnostic nativekernelmedian.5232ms, CPUprofile shows656000perindex generatorcalls/20stages plusvalidation/nestedlisttensor construction. Freeze v2 CPUpreparation only: NumPybulkkeep/range/positions/grace/fromnumpy uploads; unchangednativekernel/binary/layout/selection. Same fullstage4ms gate, source/plan_v2 frozen before execution. No qualitytuning.

Vectorized CPUpreparation passes complete stage:6.5361→2.5051ms,4.0310mssaving,all3blocks faster,p95improves,13bitwisecases. BinaryunchangedSHA0bae116c4ef89525e4fe3cced69935409b87631c2627d3536592e911cebfa610. Exactmodel combinedcandidate preregistered, originalevictwholebody changedonlyhotcompaction hook withcoldoverflow/unsupported eagerfallback. Focused ASTtestpasses. Source/plan frozen before synthetic32case and4context/3ABBAmodel jobs. No normalCLI/defaultchange.


### 2026-10-02 — Combined coordinator/fused compaction clears model gate

IndependentwholebodyAST/source/data/binary verification,32syntheticcases(442fused/222eagercompactions),all13boundaryframes at4K8K16K31500 exact.3ABBA16K50teacher/warmup1:median75.4689→66.4404ms,11.9632%faster;p9585.0156→72.1715ms;TTFT2281.77→2292.29ms(+.46%);prefillpeak 18.627831296 GB identical, decodepeak14.91440→14.91133 GB. Allblocksfast/5%speed/regressionguards pass. Bothcoordinator+gather measuredtogether; notkernel-only/Snap/physicalSTT/quality-superiority. Freeze mandatorynativebit/stream-lifetime,12docfreegeneration andthreeinterleavedrequest stress before ordinaryCLI promotion.

Mandatoryfusedstress independentlyverified:15nativebit/streamlifetimecases,12freegenerationpairs/six tasks/nativecaps/EOS,threeinterleaved/recycledrequests51boundaryframespermodes exact. Native/policy mathsource unchangedfrommodelgate. Add ordinary optin`--cpu-fused-compaction`, actualquery+direct/batchedCPU/LRU/hot>=132required; rejectboundedcombinationuntiltested. Verifiedbinarystdlibloader avoidsNinja/recompileinmeasuredABI; gather/compactionAST/shader unchanged. Freeze integration source beforecachedloader/CLI/invalidflag smoke.


### 2026-10-02 — Fused CPU coordinator/compaction integrated after all gates

The new opt-in combines the existing exact cross-layer eviction coordinator
with one CUDA gather of all hot BF16 keys/values and F32 score/age metadata.
CPU positions/grace compact immediately; GPU gathers complete before the
visible cache is materialized. Cold overflow and unsupported geometry use
the original eager compaction. The complete original eviction AST is
preserved outside its compaction hook; token ranking and budgets are unchanged.

The first charged prototype saved only0.3663ms and was rejected. Diagnosis
measured0.5232ms for the kernel and identified per-index Python checks/list
conversion as CPU overhead. Vectorizing CPU preparation, with the shader and
binary unchanged, saved4.0310ms (6.5361→2.5051) in the complete-stage screen;
all3ABBAblocks/p95/13bitwise cases pass. Initial missing-Ninja failure and all
original sources/results/logs are retained.

Independent model verification: all13boundaries at4K8K16K31500 exact,32
synthetic cases with442fused/222eager paths exact. Three ABBA16K50teacher-step
blocks, one whole-request warmup per arm, same CPU backend/query capture/
observer/synchronization: median75.4689→66.4404ms (11.9632% faster), p95
85.0156→72.1715ms; TTFT2281.77→2292.29ms (+.461%); prefillpeak 18.627831296 GB
identical, decodepeak14.91440→14.91133 GB. Both coordinator and compaction are
measured together; do not attribute this whole gain to the kernel alone.

Mandatory native proof includes all65,536BF16bit patterns, F32 signed zero,
subnormal/infinity/quiet+signalingNaN payloads, full/strided/reordered+duplicate
keeps, and12delayed gather/allocator-pressure rounds using one producer/two
consumer streams with explicit event waits. All15checks pass. Twelve reused
free-generation document pairs across six tasks/one greedy seed/native caps
and EOS have identical predictions/IDs/scores/state/trajectory/counters/
transfers. Three serialized interleaved/recycled requests match isolated GPU
and old CPU controls at all51boundaries per mode; roots reset cleanly. These
are integrity/ownership checks, not asynchronous model serving/throughput proof.

Ordinary CLI: add `--cpu-fused-compaction` to
`--strategy lru --real-query-prefill --cpu-batched-scores --cpu-direct-shared`.
Requires hot>=132; combining with bounded pool is explicitly rejected until
verified. Cached loader checks shader/binary hashes and measured Torch2.5.1+
cu124/Python3.10 ABI, then imports the verified binary without Ninja or a
recompile. Gather/compaction AST and shader are unchanged; one Qasper CLI
control/candidate matches predictions, score35.8974, token counts, payloads
and counters, with768fused compactions. Five invalid combinations fail before
model loading. Final full suite154passed (one dependency deprecation warning).

Evidence: `results/hardware/fused_hot_compaction_screen_20261002/`,
`fused_eviction_model_20261002/`, `fused_eviction_stress_20261002/`, and
`fused_cli_integration_20261002/` under `results/hardware/`.

No normal-policy default, STT bandwidth, quality ranking or capacity changes.
This12%improvement is within one CPU surrogate configuration; the earlier
shared-ceiling quality/SnapKV failures remain authoritative and have not been
rerun with this backend. No model-wide memory-gain, physical STT/controller,
energy/endurance, second-model or serving superiority is established. Broad
P0/P1/P2 remain open. Next: verify bounded+fused combination and shared-ceiling
resource/speed accounting, then broader research gates. Remaining estimate
10–20workingdays, conditional on hardware access and research outcomes.


### 2026-10-02 — Frozen bounded/fused composition gates

Reuse both existing cache/policy components through cooperative MRO; no new kernel/selection/math. Fourteen pre-mutation/constructor/factory tests; first positive fixture lacked coordinator prepared fields, corrected fake metadata only. Freeze40native/fullappend cases,4context×2geometry exactmodelparity,3ABBA regression guards andmandatoryfreegeneration/interleaved at1024/2048and991/1090. Rootrequest31.3%/44.6%reduction primary; no inferreddefaultRSS or new5%speedclaim. No ordinaryCLIcombinationuntil gates pass. Plan/source in `results/hardware/fused_bounded_pool_20261002/`.


### 2026-10-02 — Bounded/fused composition verified; SnapKV and transient gates fail

`FusedBoundedCache(BoundedCpuCache,FusedVictimCache)` and cooperative policy
MRO reuse both verified implementations. Constructors, pre-mutation guards,
selection, score math and CUDA shader are unchanged; only the cache factory
composes them. Default policies and modeled STT 50/12.5 GB/s stay unchanged.

Fourteen guard tests and 40 native cases pass, including full 1,154/2,112-slot
saturation and oversized-append rejection before mutation. Both geometries
match fused control at 4K/8K/16K/31.5K and all 13 boundaries. Three 16K/50-step
ABBA blocks per geometry pass median/p95 ≤2%, TTFT ≤10%, prefill peak ≤2%
regression limits. Default median 70.1204→66.1838 ms, p95 73.1649→73.0787;
shared geometry median 63.0216→62.9801, p95 69.4500→68.9279. No new 5% speed
claim for this storage composition. Requested pinned root bytes:
402,784,256→276,824,064 (31.3%) and 272,891,904→151,257,088 (44.6%).
These requests do not measure allocator capacity or RSS. Usual-budget roots
still infer the same 512 MiB host allocator block.

Twelve reused development-document pairs/six tasks/one greedy seed at each
geometry match predictions, native caps/EOS, score, trajectory/state, counters,
occupied bytes and transfer payloads. Three interleaved/recycled requests
match isolated GPU and old-CPU controls at all 51 frames per mode/geometry.
The unchanged prior 15 native bit/stream tests are reused, not counted as
new runs. Initial stress-verifier provenance incorrectly compared the whole
helper to the pre-cached-loader source; preserved v1 and error note, corrected
to verified cached-loader identity plus unchanged gather/compact AST. No raw
result or model source was changed to fix verification.

Ordinary CLI now accepts both `--cpu-fused-compaction --cpu-bounded-pool`
with actual-query/direct/batched/LRU flags and hot≥132/max append32. First
Qasper sample matches fused-alone at both geometries, with 768/800 fused
compactions. Five invalid combinations reject before load, cached binary
loads without Ninja, full suite 168 passed (one dependency warning).

Frozen Snap974-expanded/window32/kernel5 versus CPU991/1090/quota32 rerun:
16K/50 teacher steps, warmup1, three ABBA blocks, unchanged prompt/seed/source.
Snap median/p95 25.8345/26.0068 ms; CPU 60.5628/67.9453 ms (2.3443× slower).
Median/p95/all-block superiority gates fail; TTFT +8.4475% passes. Prefill
peaks 16.9583 versus18.6278 GB; no model-wide memory improvement.
All 51 CPU boundaries own396 MiB and all1,600 layer-forward widths≤1024.
At 50 fused launches, known live KV reaches528.25 MiB: pinned root144.25,
raw visible128, old hot128, queued writes4.125, new fused output123.875 MiB.
This is a lower bound excluding metadata/other temporaries/allocator blocks.
The 512 MiB transient gate fails despite passing boundary ceilings. No actual
equal-resource claim. Prior independent quality failure remains authoritative;
no inspected holdout was retuned or rerun.

Evidence: [combined systems](results/hardware/fused_bounded_pool_20261002/verified_systems.json),
[integrity](results/hardware/fused_bounded_pool_20261002/verified_stress.json),
[CLI](results/hardware/fused_bounded_pool_20261002/cli/verified_report.json),
[SnapKV and storage](results/baseline_fidelity/snap_fused_bounded_envelope_20261002/verified_report.json).
Broad P0/P1/P2 remain open. Next: diagnose whole-decode live storage and visible
materialization before a preregistered candidate; retention/physical tier,
broader models and serving gates remain. Estimate10–20working days conditional
on hardware and research outcomes.


### 2026-10-02 — Whole-decode lifetimes and storage-only native reuse gates

Weak C++ StorageImpl references, alias deduplication and independently recomputed
lifetime intervals show ordinary fused/bounded policy KV reaching 528.26 MiB,
visible assembly 524 MiB and promotion 527.75 MiB. A separate full-forward
SnapKV classifier reaches 520 MiB; classifiers/scopes differ, and neither
boundary snapshot proves transient resource equality. These are known live KV
lower bounds excluding some workspace, metadata and cached allocator blocks.

A checked PyTorch raw-buffer reuse screen was exact but regressed and was
rejected. Native writer v1 also regressed. CPU profiling identified Python
view creation; v2 changes only view construction, not CUDA shader or math.
All BF16 bit patterns, F32 signed-zero/subnormal/Inf/NaN payloads, duplicate/
reversed indices, aliases and untouched tails pass. Charged v2 stage:
shared 4.449→4.188 ms, usual 4.606→4.266 ms; only 0.26–0.34 ms saved, so
4 ms speed gate fails. It advances solely as a storage architecture candidate.

Both 991/1090 and 1024/2048 geometries match at 4K/8K/16K/31.5K and every
13 boundary frames per arm. Fifty-step observed policy KV peak falls
528.2578→406.2539 MiB (23.10%); post-decode boundary is 272.25 MiB. Full
model three-ABBA regression guards pass: median shared 62.0568→62.8854 ms
(+1.34%), usual 67.9880→69.1821 ms (+1.76%); p95/TTFT/prefill within frozen
limits. Whole-request peak stays 18.627831296 GB; decode peak changes only
14.8989→14.7804 and14.9113→14.7899 GB. No model-wide10% memory or new speed
claim. Independent resource and timing verifiers pin source archives/raw
hashes. Full suite182passes. Fifteen NEW native bit/stream lifetime checks
pass, releasing both source and destination owners with delayed two-consumer
execution and producer allocator pressure.

Generation on the same12reused development documents/six tasks/one seed at
both geometries is active. Saturation, interleaved recycling and ordinary CLI
remain mandatory. No new holdout consumed or default changed. Earlier
SnapKV speed/quality failures remain authoritative. Broad P0/P1/P2 open;
estimate10–20workingdays conditional on hardware/research outcomes.
Evidence: `results/hardware/decode_kv_lifetimes_20261002/`,
`snap_decode_kv_lifetimes_20261002/`, `reuse_visible_native_screen_20261002/`,
`reuse_visible_model_20261002/`, `reuse_visible_integrity_20261002/`.


### 2026-10-02 — Native raw-buffer reuse integrity and ordinary CLI complete

Fifteen new native bit/stream checks pass. Same12reused development docs/six
tasks/seed0 at eachgeometry yield24exactfree-generation pairs, including
nativecaps/EOS, score, complete state/trajectory, counters and transfer bytes.
Forty native saturation/boundary cases cover full1154/2112slots, inclusive
on/off, fill.75/1.0, eager full-cold fallback and append33rejection before
mutation. Three interleaved/recycled requests at eachgeometry match isolated
GPU/oldCPU controls atall51frames permode; newreuse dispatch48calls/1536layers
pergeometry. Independent source/raw/binary/pair verifier passes.

Ordinary evaluator now accepts `--cpu-reuse-visible` only with fused/bounded,
direct/batched, actual-query/LRU configuration. Cached loader verifies binary,
CUDA/pybind source and Torch/Python ABI, loading without Ninja. Five new cached
loader tests bringfullsuite to187passes/one existingdependencywarning.
One reusedQasper sample pergeometry matches priorcombinedcontrol, same
roots151257088/276824064bytes, with800/768reuse compactions respectively;
seven invalid combinations rejectbeforemodel load. Independent CLI verifier
pins loader identity and unchanged gather/class AST/shaders. Defaults unchanged.

Primary is23.1%reduction inKNOWNpolicy KV, notactual allocator/process or
model-wide memory; whole-request peak unchanged, median decode+1.34%/+1.76%,
no4ms-stage/new5%speedclaim. Source bundles/raw results immutable. Broad
P0/P1/P2 remainopen; next actual-resource accounting/end-to-endcosts before
retention/widerresearchgates. Remaining estimate10–20workingdays contingent
hardware/researchoutcomes. Evidence:
`results/hardware/reuse_visible_integrity_20261002/verified_report.json`,
`results/hardware/reuse_visible_integrity_20261002/cli/verified_report.json`.


### 2026-10-02 — Direct host allocation capacity closes accounting gap; gates fail

Installed Torch2.5.1 exposes no public host memory statistics. Initially built
read-only private HostBlock probe, validating caching-allocator deleter and
installed header against upstream2.5.1. Six live sizes/aliases/nonpinned
rejection pass; direct block capacities256/512 MiB for144.25/264 MiB requests.
Eight fresh CPU fused/bounded versus reuse processes (two perarm/geometry)
match state, IDs, counters, teacher inputs and GPU peaks; root capacities
confirmed, roots release atreset, pinned cache remains untilhostflush.

Then screened CUDA public allocation-range attributes11/12. They returnthe
same capacities, including33bytes→64bytes. Crosschecked six sizes/aliases
against retained private binary. Active reader replaced with stdlibctypes/
publicdriver API; private C++source removed, old binary/source preservedin
archive. Four newfresh processes match prior8state/IDs/counters/peaks and
runwithoutNinja/hostextension. Whole allocated/reserved GPU peaks remain
18.627830784/20.600324096 GB; fresh decodepeak15.8263/15.8341 GB unchanged.
Final GPU allocated drops129.8/134.1 MB; sampled RSS gains negligible.

Add measured shared root excess 111.75 MiB toSAMEprior406.2539 MiB knownKVtrace:
strongerlowerbound 518.0039 MiB, failing512 MiB evenbeforeGPUworkspaces,
othercachedblocks/OSrounding. Model-wide10%memorygate alsofails. No resource
superiority claim or defaultchange. Initial verifier incorrectly read raw
boundariesattoplevel; preservedv1/errornote, correctedresult.boundaries
andindependently checkedrootatallboundaries/phases. No raw/sourcechanged.

Two weak-storage modelhooks prove1000 MiB[1,16384,32000]BF16prefilllogits stay
live throughfreshdriverfirstdecodeforward, expirebeforesecond. No strong
payload refs or alteredmodelargs; rawstate/IDs/counters/peaks preserved.
Legacytimingprefillfunction releasesout earlier, so peaksnotinterchangeable.
Native last-logit-only option and precise root allocation remain prospective
candidates requiring exactness/regression gates. BroadP0/P1/P2remainopen,
remainingestimate10–20workingdays conditionalhardware/researchoutcomes.
Evidence `results/hardware/actual_reuse_memory_20261002/verified_report.json`,
`public/verified_report.json`, `logits/verified_report.json` beneathit.


### 2026-10-02 — Exact-size pinned roots: host-memory pilot passes; stress active

One mechanism: allocate the unchanged bounded/native-reuse CPU root through
public CUDA cuMemHostAlloc instead of the Torch power-of-two host allocator.
No new dependency or host compiler. Buffer-owner lifetime frees the allocation
after synchronizing its owning CUDA context; this serialized-use ceiling is
explicit. Frozen capacities, actual-query ranking, teacher stream and cache
math are unchanged. Candidate remains research-only, with ordinary defaults
preserved. Plans/source bundles/raw data are archived under
`results/hardware/exact_pinned_pool_20261002/`.

Nineteen real allocation/lifetime checks, 768 multi-pool reads, 40 saturation
cases, four-context parity at both geometries and 198 full-suite tests pass.
Four fresh processes measure root ranges 256→144.25 / 512→264 MiB; sampled
RSS falls 117.17 / 255.49 MB. Single-process RSS is descriptive, without CI.
Whole-request GPU peak stays 18.6278 GB. Three ABBA blocks pass all regression
guards: median decode −1.44% / +0.12%, TTFT +4.59% / +7.77%; no speed claim.

Frozen reused-generation and interleaved/recycling gates are running. A
preregistered whole-decode diagnostic reports Torch allocated and reserved
peaks minus only immutable model storage, plus public host allocation ranges.
Reserved includes retained prefill blocks; missing driver/other host scopes
will remain explicit. No complete-resource or CLI promotion before these
gates. Broad quality/physical-tier/second-model/throughput/paper work remains
open; overall estimate 10–20 working days, conditional on research/hardware.


### 2026-10-02 — Exact-root stress closes; resource gate blocks adoption

Both geometries now pass 12 reused free-generation pairs/six tasks/seed zero
and three interleaved/recycled requests (51 boundary frames per mode).
All 30 candidate roots release. First shared interleaved wrapper produced
correct outputs but failed its observed-launch assertion: it patched the
replacement policy class while the recorded subclass inherited the original
base. Fixed only the wrapper’s interleaved class selection; one focused test
proves hook reachability. Failed raw JSON/log and source remain preserved;
corrected shared and usual runs pass 48 launches/1536 layers each.
Full suite now passes 199 tests, one pre-existing dependency warning.

Independent whole-decode verification reports shared cached/exact active
Torch allocation plus host range 539.02→427.40 MiB; usual 804.36→556.25 MiB.
Only immutable model parameter/buffer storage is subtracted. The legacy caller
releases prefill logits before decode. Reserved scopes retain prefill blocks:
exact 5977.74 / 6097.49 MiB beyond constant model storage plus host range.
Driver/non-Torch and other host allocation/cache scopes remain excluded.
Neither result establishes complete actual-resource equality. Whole-request
GPU peak remains unchanged; no new speed/quality/model-wide memory claim.

Decision: preservation passes; keep the exact-root candidate research-only.
Usual active scope and both reserved scopes fail the 512 MiB target, so no
ordinary CLI flag or default promotion. Next preregister a caller-lifetime/
retained-prefill-allocation screen with the same state and timing guards;
quality, physical tier, wider models/serving and final paper gates stay open.
Evidence: `results/hardware/exact_pinned_pool_20261002/verified_integrity.json`
and `verified_resources.json`. Status, plain guides, roadmap and paper draft
updated. Estimated remaining effort: 10–20 working days, conditional on
hardware access and research outcomes.


### 2026-10-02 — Preregister retained-prefill CUDA allocation reclamation

Frozen exact-root policy in both arms, same 16K prompt/teacher/seed/BF16 and
991/1090 plus 1024/2048 geometries. One caller mechanism: delete unused prefill
output after its compressed cache/token are extracted, then empty unused CUDA
cache inside the charged TTFT function. Native transfer/retention math unchanged.
Primary: ≥10% lower decode GPU reserved peak, with exact state/IDs/history/
counters/transfers, TTFT ≤10% worse and decode median/p95 ≤2% worse. Cheap
five-step pair first; no promotion from pilot. If direction passes, run three
50-step ABBA blocks and mandatory integrity/resource proof. Full model-wide
memory/speed/quality claims remain gated. Plan and frozen sources:
`results/hardware/prefill_reclaim_screen_20261002/plan.json`.


Retained-prefill reclamation screen: both three-ABBA trials pass the ≥10%
decode reserved-memory primary (19.57% / 19.56%) and all regression guards.
Median decode −1.62% / −1.85%; TTFT +1.76% / +0.95%; prefill active peak
18.6278 GB unchanged. Full resource target remains failed/incomplete:
reserved-plus-host envelopes 2133.74 / 2255.49 MiB, active 427.33 / 556.11 MiB.
Advance to frozen generation and recycled-request preservation checks only;
no speed/model-wide memory/quality/physical STT claim or CLI/default change.
Integrity plan: `results/hardware/prefill_reclaim_screen_20261002/integrity_plan.json`.


### 2026-10-02 — Retained-prefill reclamation preservation verified

Frozen exact-root policy/native/source files are byte-identical to the
preregistered control. The timing caller deletes unused prefill output and
clears unused CUDA cache inside charged TTFT; the generation caller performs
the same cleanup before decode. Source AST projection proves no other model/
policy logic changed. Three 16K/50-step ABBA blocks at both geometries meet
the decode-reserved-memory primary: 20.6003→16.5696 / 16.5717 GB,
19.57% / 19.56% lower. Median decode −1.62% / −1.85%, p95 −0.62% / −0.35%,
TTFT +1.76% / +0.95%; all regression guards pass. This is below the 5% speed
threshold and does not reduce whole-request active peak (18.6278 GB).

Both geometries pass 12 reused generation pairs/six tasks/seed zero and
three recycled/interleaved requests with 51 boundary frames per mode.
All 54 exact roots, including generation control arms, release. New generation
control and candidate rows also reproduce the prior frozen exact-root result
across all 16 output/state/trajectory/counter/transfer/capacity fields. Full
suite passes 199 tests, one existing dependency warning. Native/lifetime/
saturation code remains byte-identical to the previously verified sources.

Full resource equality remains failed/incomplete: active-plus-host envelopes
427.33 / 556.11 MiB, reserved-plus-host 2133.74 / 2255.49 MiB; other driver/
host allocations are excluded. No CLI flag/default promotion, physical STT,
model-wide memory, independent quality or serving-throughput claim follows.
Next diagnose allocator fragmentation and preregister a single allocator-layout
screen. Broad P0/P1/P2 remain open; estimate 10–20 working days conditional
on hardware access and research outcomes. All owned GPU0 jobs finished.

Evidence under `results/hardware/prefill_reclaim_screen_20261002/`:
`verified_abba.json`, `verified_integrity.json`, `verified_frozen_replay.json`.
Runnable checks: `verify_pilot.py`, `verify_abba.py`, `verify_integrity.py`
(write-once proof producers); `verify_frozen_replay.py` is read-only and
rechecks archived control equality. Raw/source/failed prior evidence preserved.
Status, plain guides, roadmap, implementation guide and draft updated.


### 2026-10-02 — Preregister public allocator snapshot/layout screen

Freeze exact native-reuse policy plus charged prefill cleanup in all arms.
Diagnose remaining CUDA reservation with public memory_snapshot data. One
candidate sets only child-process PYTORCH_CUDA_ALLOC_CONF to
expandable_segments:True, a documented experimental Torch 2.5.1 allocator
option. Default control explicitly uses expandable_segments:False. Four
fresh 16K/12-step processes, two identical measurements each, at both budget
geometries; state/IDs/history/counters/payload exact. Primary ≥10% lower decode
GPU reserved peak beyond cleanup. Timing guards median/p95 ≤2% worse, TTFT
≤10%, prefill active peak ≤2%; pilot timing is direction-only. Advance to
alternating fresh-process 50-step blocks only if the memory primary passes.
No global environment, dependency, CLI/default or full-resource claim.
Plan/source freeze: `results/hardware/allocator_layout_screen_20261002/plan.json`.
Official pinned source: https://raw.githubusercontent.com/pytorch/pytorch/v2.5.1/docs/source/notes/cuda.rst


Allocator snapshot pilot: four fresh processes pass state/IDs/history/counters/
payload equality with both cleanup rows identical. Public snapshots confirm
requested native/expandable layouts. Shared reserved peak 15.1603→14.8772 GB
(1.87%) fails the ≥10%pilot; stop this arm, with no shared or joint claim.
Usual 16.5717→14.9003 GB (10.09%) narrowly passes; advance this geometry only
to three alternating fresh-process50-step blocks. Trapped inactive bytes in
live segments fall505→139 MiB /503→197 MiB. Active ceilings427/556 MiB are
essentially unchanged; reserved-plus-host remains519.74/661.49 MiB, both
above512. No promotion/full-resource/model-wide active gain follows.
`timing_plan.json` freezes default/expandable/expandable/default process order,
50 measured steps, one warmup, two identical runs per fresh process, and
original timing guards. Per-step full hashes disabled equally for timing;
final state/IDs/counters/payload preserved. Raw/source pilots untouched.


### 2026-10-02 — Allocator layout timing fails; advancement stops

All 16 fresh process pilots/timing jobs pass model/state/ID/history/counter/
payload preservation and requested allocator-layout checks. Public snapshots
confirm free bytes stranded inside live segments. Shared 12-step pilot saves
only 1.87% reservation, below 10%; no larger shared trial is run. Usual geometry
advances on 10.09% pilot, then 12 fresh processes in 3 default/expandable/expandable/
default blocks reproduce10.09% decode reservation gain:16.5717→14.9003 GB.
Measured 600 tokens/layout; both rows use identical charged prefill cleanup and
existing history/synchronization observer, with per-step full hashes disabled
for timings and complete final-state/IDs/counters/payload still exact.

Median 66.7753→68.6290 ms (+2.78%) fails the 2% guard. p95 73.9028→74.4787 ms
(+0.78%), TTFT 2535.120→2577.298 ms (+1.66%) pass. Prefill/model-wide active
peak remains 18.6278 GB. Usual active-plus-host 555.84 MiB and reserved-plus-host
661.49MiB still exceed 512; driver/other host scopes unmeasured. Shared
reserved-plus-host 519.74 MiB also fails. Source/raw evidence immutable.

Decision: shared reject; usual memory/latency trade-off, stop advancement.
No ordinary CLI/default/global environment/dependency change. No expanded
candidate lifetime/free-generation stress is run after a failed timing guard;
prior native/source proofs do not establish this candidate’s serving safety.
Full suite 199 passes, one existing dependency warning. Next profile current
model/policy costs before choosing another implementation; frozen inspected
quality holdouts remain excluded from tuning. Broad P0/P1/P2 remain open.
Estimate 10–20 working days conditional on research/hardware. Status/plain
notes/roadmap/implementation guide/draft updated. Evidence under
`results/hardware/allocator_layout_screen_20261002/`:
`verified_pilot.json`, `verified_timing.json`, `verified_decision.json`.


### 2026-10-02 — Preregister current native-reuse policy profile

Read-only policy cProfile on the ordinary verified CPU actual-query/direct/
batched/fused/bounded/native-reuse path, usual1024/2048geometry,16Kprompt,
10fixed teacher steps/seed0. Use existing ProfileCalls/main harness; select
only native-reuse class. Default host allocator; no experimental exact-root,
caller cleanup or expandable layout. Diagnostic only: overlapping Python
call/GPU-wait times are not speed evidence. Identify dominant responsible
call path before any implementation. Plan/frozen control:
`results/hardware/native_reuse_profile_20261002/plan.json`.


### 2026-10-02 — Preregister standard-Torch projected metadata batching

Current ordinary native-reuse cProfile identifies promotion/projection/victim
preparation as a dominant policy path; no cold overflow. Profiled overlapping
call times are diagnostic only. One mechanism batches equal-length projected
metadata and stacks equal-size metadata/mask lists, preserving identical
Float32 age increment, zero append, ranking/masks/grace and original ragged/
ineligible fallback. No new CUDA kernel/ABI/default or quality-data change.
Primary: ≥4 ms lower median fully charged projection+selection stage, all
three ABBA blocks improve, p95 ≤2% worse. Exact intermediate projected values,
victim indices and no input mutation required; boundaries/ragged/nonfinite/
large ages/new counts checked first. Stop before model integration if stage
threshold fails. Plan/source freeze:
`results/hardware/projection_batch_screen_20261002/plan.json`.


### 2026-10-02 — Current native-reuse profile complete; batching screen stops

Ordinary CPU actual-query/direct/batched/fused/bounded/native-reuse policy,
1024/2048 capacities, 16K development prompt and 10 fixed teacher steps run
on GPU 0 with default host allocator. No exact-root/cleanup/VMM variant.
The frozen profile verifies the actual class, source/binary hashes, ten frames
and no cold overflow. Preparation takes about 199 ms across ten steps, with
about 62 ms in victim selection; nested cumulative times and GPU waits overlap,
so these are diagnostic costs, not additive savings or benchmark claims.
Evidence: `results/hardware/native_reuse_profile_20261002/verified_profile.json`.

Standard-Torch projected-metadata batching passes all 18 exact numerical/input
preservation cases and three ABBA blocks. All projection allocation/packing,
CPU masks, ranking/fallback, return and CUDA synchronization are charged.
Median stage 4.517608 → 3.052513 ms; p95 4.597027 → 3.081749 ms. All blocks
improve, but 1.465095 ms saving fails the preregistered 4 ms primary.
Decision: stop before model/native/generation/recycling/CLI integration. No
new speed/quality/whole-loop memory claim. No ordinary setting/dependency change.

Independent result audit checks all 12 timing rows, sample counts, medians,
p95, per-block decisions, frozen source hashes and unchanged control bytes.
The active stage reference matches the production projection AST. Unused
model-integration prototype removed; all four measured helper ASTs remain
identical to the tested archive. Original candidate/source/raw records remain
untouched. Final cleaned stage module retained alongside the proof.
Evidence: `results/hardware/projection_batch_screen_20261002/verified_stage.json`.
Full suite: 199 pass, one existing dependency warning. Both GPU jobs terminal;
GPU 0 idle, unrelated GPU 1 workload untouched. Seven status/guide documents
updated. Next localize remaining promotion/index/transfer costs before another
charged, preregistered mechanism screen. Full P0/P1/P2 remain open; estimate
10–20 working days conditional on research outcomes and hardware access.


### 2026-10-02 — Preregister actual promotion-planning capture

Current ordinary native-reuse profile places roughly 5 ms/step in promotion
planning and additional time in repeated floor/row checks. Scalar CPU tensor
shadow access is a plausible mechanism; overlapping profiler times remain
diagnostic. Capture CPU metadata/attention inputs and original plans/streaks/
prefetch selections from ten fixed development steps on GPU 0. Observer
timing is invalid. Replay exact semantics before a charged stage candidate;
4 ms primary and existing ABBA/p95 guards remain. No quality holdout tuning.
Plan: `results/hardware/promotion_planning_screen_20261002/capture_plan.json`.


### 2026-10-02 — Preregister bulk CPU promotion metadata stage

All 320 captured layer inputs reproduce original plans, streaks and prefetch
selections under both the original and proposed bulk access helpers. Candidate
uses one CPU NumPy shadow view per original method and Float32 CPU array
hysteresis, preserving sort/floor ASTs and unsupported fallback. No model
prototype or new dependency. Charge ranking, conversion, streak mutation and
both row checks. Primary: at least 4 ms median saving, three ABBA blocks all
improve, p95 within 2%; exact bytes/decisions and boundary cases mandatory.
Failed stage stops model advancement. Candidate frozen before numerical/stage
run: `results/hardware/promotion_planning_screen_20261002/stage_plan.json`.


### 2026-10-02 — Bulk CPU metadata stage passes; freeze model trial

Actual captured inputs: 320 layer cases and 50 synthetic/fallback cases exact.
Three charged ABBA blocks save 6.631489 ms (9.013625 → 2.382136 ms); p95
9.422208 → 2.641051 ms. All blocks improve; stage clears 4 ms primary.
Independent audit recomputes every summary/sample/block decision and checks
frozen source/input hashes plus unchanged original control files. Model
composition preserves original batched victim preparation via verified MRO;
one exact AST call replacement selects bulk planning, cache overrides use
verified eligible NumPy helpers. No default/CLI/dependency change. Freeze
four-context parity then usual-geometry 3 ABBA full-model gates; mandatory
stress/adoption gates remain if timing passes. Plans and proof:
`results/hardware/promotion_planning_screen_20261002/model_plan.json`,
`verified_stage.json`.


### 2026-10-02 — Bulk promotion passes full-loop speed; mandatory integrity starts

Four contexts pass all 13 boundary frames/arm, IDs, history, counters, useful
transfers, root and dispatch counts. One trial per row, as the unchanged
measure harness specifies. Initial audit script assumed a Python-only source
archive also contained native sources; verification corrected via earlier
frozen native proofs and an immutable supplemental native archive. The
original new source archive and raw runs remain untouched. Timing launched
before that audit finished; no speed decision accepted until parity/source
audit passed. Current proof: `verified_model_parity.json`.

Three usual-budget ABBA blocks: median 65.973147 → 62.521754 ms/token,
5.231512% faster, p95 73.082143 → 67.936601 ms; TTFT 2288.884869 →
2285.050014 ms. All blocks improve; model prefill/decode active peaks unchanged
18.627831/14.789913 GB. All state/history/IDs/counters/transfers/root/dispatch
identities pass. Full suite 199 passes, existing dependency warning only.
Proof: `results/hardware/promotion_planning_screen_20261002/verified_model_timing.json`.

Freeze native lifetime, two-geometry boundary/saturation,24 generation pairs
and six serialized interleaved/recycled requests before ordinary CLI adoption.
Reuse existing unchanged drivers and frozen development manifests; wrapper
selects the bulk policy, preserving the original gather-count hook. New
hardware/quality/full-resource/model2/throughput/paper gates remain open.
Plan: `results/hardware/promotion_planning_screen_20261002/integrity_plan.json`.


### 2026-10-02 — Bulk promotion integrity/shared timing pass; ordinary flag added

All 15 native bit/stream checks,40 saturation/boundary cases,24 generation
pairs/six tasks and six serialized recycled/interleaved requests pass at both
geometries. Each mode preserves 51 frames; all 48 generation rows reproduce
the earlier frozen native-reuse results across 16 fields. Shared ABBA median
63.309762 → 59.169153 ms (6.54% improvement); all regression guards pass,
p95 70.167721 → 64.753371 ms, TTFT +0.28%, active GPU peaks unchanged.
Proofs: `verified_integrity.json`, `verified_shared_timing.json`.

Add `--cpu-bulk-promotion` to ordinary evaluator, requiring existing native
reuse chain; defaults unchanged. Candidate source identities recorded in
configuration. No algorithm/native change: only module descriptions updated
for verified opt-in use, with remaining AST byte-identical to measured source.
Seven tests prove composition/default independence and six dependency
rejections before dataset/model I/O; full suite206 passes. Freeze two-geometry
ordinary evaluator parity and invalid cases before marking adoption verified.
Plan: `results/hardware/promotion_planning_screen_20261002/cli/plan.json`.


### 2026-10-02 — Bulk promotion ordinary evaluator adoption verified

Four ordinary CLI runs (two capacities, control/native versus bulk) finish.
Predictions, scores, prompt/generated token counts, logical counters, submitted
transfer bytes, host occupancy/reservation and native reuse/fallback counts
match. Both baseline samples reproduce earlier frozen ordinary-native output.
Flag/backend source identities match the final source archive; descriptions
changed after integrity, but measured helper/class ASTs remain identical.
Eight missing-dependency/hot-budget/strategy cases reject before data/model
I/O. Cached native binaries load without Ninja. Full suite 206 passes; one
existing dependency warning. No ordinary default change.

Proof: `results/hardware/promotion_planning_screen_20261002/cli/verified_report.json`.
Same-CPU speed gains 5.23% usual / 6.54% shared are verified; no faithful
SnapKV, quality, actual-resource, physical-STT or serving superiority follows.
Seven status/guide files and README usage updated. All owned GPU jobs terminal;
unrelated GPU 1 workload untouched. Full P0/P1/P2 remain open. Next audit the
current native/bulk resource envelope before another frozen memory mechanism.
Estimate 10–20 working days conditional on research outcomes/hardware access.


### Current bulk implementation — preregister resource audit v1

Freeze six fresh processes covering both capacities and both ordinary CPU
policies. Reuse unchanged fresh/legacy callers; observe public host ranges,
allocated/reserved GPU scopes,constant model storages,model-associated allocator
segments and weak prefill-logits lifetime. Segment association is diagnostic,
not causal attribution. No experimental allocator/caller/semantic change.
512 MiB target and original scope unchanged; all other host/driver scopes
remain excluded. Plan: `results/hardware/bulk_resource_audit_v1/plan.json`.

## Bulk resource audit v1 — verified result

All six preregistered GPU 0 subprocesses finished with exit 0. The read-only
verifier checks the 190-file frozen source bundle, all raw source hashes,
prior ordinary CLI proof, public allocator snapshot arithmetic, root ranges,
cleanup, state/IDs/counters/payload equality and weak-storage observations.
`results/hardware/bulk_resource_audit_v1/verified_report.json` records hashes;
`verify_results.py` reproduces the audit without model execution.

Fresh control/bulk have exactly equal phase GPU peaks: prefill/whole active
18.627830784 GB, reserved 20.600324096 GB. Decode active plus the observed
host range after subtracting unique constant model storage is 1536.641 MiB
shared / 1800.090 MiB usual. Legacy paired observed active envelopes are
539.016/539.145 MiB shared control/bulk and 804.361/804.252 MiB usual.
Reserved envelopes are 6089.492 / 6345.492 MiB. All exceed 512 MiB; these
observed upper envelopes exclude other host/cache/driver/non-Torch scopes
and cannot establish complete resource equality. Within-caller preservation
is demonstrated; fresh-versus-legacy differences are not causal effects.

Weak storage confirms a 1000 MiB prefill logits tensor remains alive at the
first fresh decode entry and expires before the second. Loaded-model public
snapshots have only 3.491 MiB inactive bytes in model-only segments: reject
weight-only packing as a sufficient explanation/fix for this resource gap.
Observer timings are invalid. No new candidate/default, quality, speed or
physical-STT claim. Previous 206-test suite/source remains unchanged.

Decision: diagnostic complete; broader P0/P1/P2 gates stay open. Next inspect
releasable versus trapped allocator bytes and ordinary generation ownership
before choosing a narrowly scoped mechanism. Estimated remaining research
effort remains 10–20 working days, conditional on hardware and research gates.

## Decode reclaim screen v1 — preregistration

{
  "timestamp": "2026-10-02T20:05:21.480241+00:00",
  "hypothesis": "Expandable-layout shared decode snapshot has100MiB fully inactive reservation. Charged per-token empty_cache may reduce peak reserved memory; boundary reduction alone does not qualify.",
  "control": "Fixed research-only exact-pinned/native policy, charged prefill cleanup, expandable_segments:True in both arms. Neither exact roots nor expandable layout is adopted. Ordinary bulk/native source unchanged.",
  "control_proof_sha256": "6af2c831f29f4f40072a3d29645ade29e2b504b2ebf1200139bd2c3ed9fa7923",
  "latest_resource_proof_sha256": "0489e3f93bb649e0c90547442fadaa3d6630ce368c90edb7e6e10975b0dbd9ac",
  "model": "../models/mistral-7b-instruct",
  "seed": 0,
  "hardware": "GPU0 NVIDIA L40S, advisory model lock",
  "dtype": "BF16 KV/F32 metadata",
  "hot": 991,
  "cold": 1090,
  "context": 16384,
  "decode": 12,
  "primary": "At least10% lower decode GPU reserved PEAK, not final boundary. Report full active/reserved+actual host range against512MiB separately.",
  "guards": {
    "state_ids_history_counters_payload": "exact",
    "median_decode_pct": 2,
    "p95_decode_pct": 2,
    "ttft_pct": 10,
    "prefill_allocated_peak_pct": 2
  },
  "mechanism": "Both caller arms release dead out/tup references at the identical end-of-decode boundary. Candidate alone calls public torch.cuda.empty_cache there, inside charged decode.",
  "progression": "One fresh paired pilot; failed memory primary stops before full timing/generation/integration. Passing pilot requires3ABBA warm50-step timing and mandatory preservation stress before any adoption. No ordinary/default/global env change."
}

## Decode reclaim screen v1 — failed primary, stop

Command: `CUDA_VISIBLE_DEVICES=0 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
flock /data/nishant/tieredkv_external/gpu0_model.lock ../venv_kvcache/bin/python
experiments/screen_decode_reclaim.py --hot 991 --cold 1090 --decode 12 --output
results/hardware/decode_reclaim_screen_v1/pilot.json` (exact argv/environment in `job.json`). One fresh paired pilot
finished exit0. AST restoration proves only charged per-token empty_cache
differs between caller arms; both use identical dead-output reference release
and charged prefill cleanup. Exact pinned policy and expandable layout are
fixed research-only conditions, not newly adopted production changes.

Read-only `verify_results.py` checks archived/current source, both earlier
proof hashes, two12-step trials,13visible frames, IDs/state/history/counters/
transfer equality, actual exact host ranges, public snapshots and206-test
suite. Both151257088-byte roots release; live exact allocations/bytes zero.
Result: decode GPU reserved peak14877196288bytes in BOTH arms, saving0%
against the10% primary. GPU allocated peak14780093440bytes also matches.
Allocated+actual-host envelope427.137 MiB; reserved519.742 MiB still exceeds
512. Final reserved boundary14877196288→14768144384bytes (104 MiB reduction),
fully inactive segments100→0MiB. Boundary saving is not peak saving.

Decision: reject; no full timing, generation, ordinary CLI or default changes.
Observer timings are invalid. Keep raw/source/proof artifacts. Full suite
206pass, one existing warning,8.71seconds. All owned jobs finished. Broader
quality/resource/physical tier/generalization/paper gates stay open. Next
investigate actual live decode payload/temporary demand rather than more
allocator-boundary cleanup; retain inspected quality holdouts unchanged.

## Decode prefix audit v1 — preregistration

{
  "timestamp": "2026-10-02T20:14:25.758642+00:00",
  "scope": "Read-only observer on ordinary BulkPromotionPolicy. Two fresh processes, both capacities,4/8/16/31.5K context,12 teacher steps. No policy mutation/kernel/CLI candidate.",
  "hypothesis": "Incoming model raw KV prefix is bit-identical to cached hot KV before promotion. Its visible tail has capacity for actual promoted rows plus new tokens. Determine whether duplicate old hot storage can be avoided without changing values.",
  "frozen_control_proof_sha256": "f8d03b1eb43f902bffd2eabb01f4d568a9afa69b26995d18218d7967668c2355",
  "prior_trace_proof_sha256": "afd848223cefb31f79f1d644d437a44de2a00cac78df08b147b01423ea811e13",
  "guards": "Within-harness predicted IDs,every visible state,history,counters,transfer payload and root equal. Bitwise prefix equality,distinct storages,capacity and unchanged new-token tail checked every layer. Failed invariant rules out proposed reuse contract; no integration from observer evidence alone.",
  "limits": "Untimed observer sync/copies invalidate timing/memory effects. CPU hashes and weak handles only persist. Other GPU0 users remain untouched. No source/core/default changes; need an isolated prototype+peak/timing/quality/stress gates before any candidate adoption."
}

## Decode prefix audit v1 — necessary reuse conditions verified

Two fresh GPU0 subprocesses under the advisory model lock finished exit0.
Exact argv/environment in `results/hardware/decode_prefix_audit_v1/jobs.json`.
Both use ordinary bulk/native policy, standard host allocator and unchanged
caller. Observer only reads bits, hashes new-token tails and records primitive
weak-owner facts; equality sync/CPU copies invalidate timing/memory effects.
Unrelated GPU0 workloads were left untouched; no timing claim made.

Four contexts4K/8K/16K/31.5K per geometry,12teacher steps,32layers:3072checks.
Every hot prefix matches bitwise, old/current storages are distinct, actual
promotions+new rows fit current raw capacity, and new tails stay unchanged
through ordinary prepared promotion. Old hot owners expire exactly when
promotion occurs; this is C++owner lifetime, not physical stream retirement.
All16rows replay frozen ordinary-native/shared and bulk/usual control records
for state/history/every-visible-frame/IDs/counters/transfer payload/root.
206tests pass in8.90seconds; one existing warning. No production changes.

Read-only verifier also groups allocation birth/expiry intervals at five
historical policy phase peaks and checks sums against frozen lifetime proof.
The maximum includes128MiB incoming raw KV and129.998MiB concatenated3D KV,
plus144.25MiB requested root and smaller staging/casts. Shape/origin labels
are descriptive, not causal attribution; unclassified forward/metadata/
allocator/host-cache/driver scopes remain excluded.

Decision: advance only to an isolated buffer-reuse prototype. Necessary
prefix/capacity conditions pass, but no in-place mutation/overlap-safe
compaction, metadata/position preservation, numerical/lifetime/generation
stress, memory saving or speed has been demonstrated for that proposal.
No new native kernel, ordinary flag or default. Full P0/P1/P2 objective open.
Next preregister one mechanism and peak/timing guards; keep inspected quality
holdouts untouched and full512MiB/resource/hardware target unchanged.

## Raw input reuse screen v1 — preregistration

{
  "timestamp": "2026-10-02T20:24:13.233488+00:00",
  "hypothesis": "Use already-identical incoming hot prefix for promotion/append, then compact one layer through a temporary Torch gather and copy back. This removes simultaneously retained concatenated hot KV without a new CUDA kernel.",
  "control": "Ordinary BulkPromotionPolicy, unchanged CPU host allocator, caller,model,teacher,caps. Candidate only changes hot payload backing/growth/compaction; original metadata and selection math retained through AST hooks.",
  "prefix_proof_sha256": "7dd9b5bca69d7ac3b384f0118becfb5d6150faef8389e3ecc4e67be6e7e36762",
  "control_cli_proof_sha256": "f8d03b1eb43f902bffd2eabb01f4d568a9afa69b26995d18218d7967668c2355",
  "model": "../models/mistral-7b-instruct",
  "seed": 0,
  "precision": "BF16KV/F32meta",
  "hardware": "GPU0 L40S/advisory lock; other workloads untouched",
  "contexts": [
    4096,
    8192,
    16384,
    31500
  ],
  "decode": 12,
  "geometries": {
    "shared": [
      991,
      1090
    ],
    "default": [
      1024,
      2048
    ]
  },
  "primary": "At least10% lower observed whole-decode Torch allocated peak minus constant model storage plus actual host range. Report whole-request/prefill and reserved scopes separately; do not substitute final boundaries for peak.",
  "guards": {
    "state_ids_history_counters_payload": "exact",
    "median_decode_pct": 2,
    "p95_decode_pct": 2,
    "ttft_pct": 10,
    "prefill_allocated_peak_pct": 2
  },
  "progression": "First CPU payload/metadata/fallback fixtures; then paired4context model parity and separate public resource pilot. Failed primary/correctness stops. Passing memory pilot needs3ABBA warm50-step model timing and saturation/native/lifetime/free-generation/recycled-request stress before adoption. No ordinary flags/defaults until all gates pass.",
  "implementation": "StandardTorch functional per-layer scratch gather before writing overlapping prefix; no concurrent in-place scatter or new native kernel. Check all incoming hot prefix bits before binding. Nonmatching/unsupported/short/multiappend or aliasing extension falls back to ordinary path.",
  "limits": "Decode memory target only; prefill full prompt unchanged. Actual host allocator still rounded256/512MiB, so complete512MiB equality may remain failed. No quality/SnapKV/physicalSTT claim or inspected-holdout tuning."
}

## Raw input reuse — post-rejection phase diagnostic

{
  "timestamp": "2026-10-02T20:36:16.191930+00:00",
  "pilot_sha256": "f8459741b67294cee4f8e32522f82ae16af5b30c03a34288d7d3a152abe5f025",
  "scope": "One4K/12-step read-only phase diagnostic after failed memory primary. No usual-budget/timing/generation advancement.",
  "question": "Confirm actual bound/compaction branch counts and identify whether whole-decode peak is already reached in model forward before payload reuse. Standard allocator counters only, no peak resets or GPU payload owners.",
  "control": "Same frozen raw_input_reuse.py and ordinary BulkPolicy; observer subclass/counters only. No algorithm changes.",
  "raw_policy_sha256": "42199dcddc1a1ad154360d9b6a95a7e9d4e696fda89d3b8b918f663d3cee193d",
  "limits": "Timing invalid; one context diagnosis does not prove phase attribution at other lengths. Prior failed primary unchanged; no tuning a passed gate."
}

## Raw input reuse screen v1 — verified failed primary

Exact argv/environment/source hashes are in plan/jobs/source bundles under
`results/hardware/raw_input_reuse_screen_v1/`. TwoGPU0 jobs finished exit0: a
four-context paired shared-budget pilot and a separate4K read-only phase
diagnostic. Source/algorithm remains unchanged between them. No usual-budget
run, full timing, generation/lifetime expansion or ordinary integration after
failed primary. No new CUDA kernel/dependency/global setting/default change.

Eleven focused CPU payload tests pass: original promotion/append metadata,
overlapping/duplicate/empty gathers, invalid-prefix/dtype/short/alias/multiappend
binding and alias-extension fallback. Full suite217pass, one existing warning,
8.99seconds. Four contexts4/8/16/31.5K have exact state/history/visible frames/
IDs/counters/transfers/root, all8rows replay prior frozen records. Observed
whole-decode allocated-minus-constant-model-plus-actual-host envelopes:
539.051→538.801;539.276→539.284;538.887→538.895;539.003→539.011MiB.
Best reduction0.0464%, far below10%; all exceed512MiB. Standard host root
range stays256MiB behind144.25MiBrequest; reserved scopes also fail.

4K phase diagnostic confirms the proposal actually ran:384bindings and
384per-layer compactions. Preparation releases127.81–128MiBlive allocated
GPUmemory, but does not lower peak. Public read-only allocator counters show
the final decode peak first reached during the second model forward, before
that step's preparation; no peak reset or GPU payload owner retained. Both
observer rows preserve pilot outputs/state/counters/transfers. Timing invalid.

Initial verifier assumed the final peak arose on first decode; raw counters
show a0.19MiB increase at second decode. Saved `verifier_v1.py`; corrected
verification checks every forward/preparation/visibility peak consistently
and reports step2. Raw evidence unchanged; no model rerun needed.

Decision: reject. The experiment confirms post-forward hot allocation reuse
is insufficient for the whole-decode target, despite exact payload math and
lower live memory later in the step. Phase attribution is4K-only, not proof
for all lengths. Next diagnose stale hot-buffer ownership during forward;
preregister a new mechanism/guards before editing. Keep217-test prototype
fixtures and frozen rejected sources for reproduction; no ordinary CLI flag.
Broader P0/P1/P2 quality/resource/physical tier/generalization/paper gates stay
open. Estimated remaining effort10–20workingdays, conditional research/hardware.

## Forward owner release v1 — preregistration

{
  "timestamp": "2026-10-02T20:45:58.969758+00:00",
  "hypothesis": "Policy hot views keep old DynamicLayer input storage alive when model update replaces it. Clear only policy KV references before one-token forward and restore exact hot prefixes from the updated same DynamicCache afterward, including exceptions.",
  "control": "Frozen research-only RawInputPolicy standardTorch compaction, default host allocator/caller; candidate adds only validated temporary forward ownership release and consumes restored hot prefix for existing payload reuse.",
  "control_proof_sha256": "144fba29472053295bad1f909ad197a6f22244d68edb4e89bf1e50755a18e52b",
  "raw_policy_sha256": "42199dcddc1a1ad154360d9b6a95a7e9d4e696fda89d3b8b918f663d3cee193d",
  "dynamic_layer_update_sha256": "15d634e7095acc0e2c229a11eb387496e462b8c51dc4e5000cd330c7d4e58c75",
  "model": "../models/mistral-7b-instruct",
  "seed": 0,
  "precision": "BF16KV/F32metadata",
  "hardware": "GPU0L40S/model advisory lock; unrelated workloads untouched",
  "geometries": {
    "shared": [
      991,
      1090
    ],
    "default": [
      1024,
      2048
    ]
  },
  "contexts": [
    4096,
    8192,
    16384,
    31500
  ],
  "decode": 12,
  "primary": ">=10% lower whole-decode Torch allocated peak minus unique constant model storage plus actual owned pinned range. Whole-request/prefill and reserved scopes reported independently.",
  "guards": {
    "state_ids_history_counters_payload": "exact",
    "median_decode_pct": 2,
    "p95_decode_pct": 2,
    "ttft_pct": 10,
    "prefill_allocated_peak_pct": 2
  },
  "progression": "CPU exception/partial-update/fallback/no-owner-retention fixtures first; shared4-context public resource pilot; failed primary/correctness stops. Passing pilot advances usual geometry,3ABBA warm50-step timing and mandatory generation/lifecycle/stream/saturation/recycled-request stress before any ordinary adoption.",
  "mechanism": "Read-only bit-prefix validation before release, same DynamicLayer torch.cat semantics. Save only DynamicCache container+primitive indices/row counts, never old KV tensors. Always-call posthook restores views; restored-prefix prepare bypasses duplicate backing bind and preserves original Bulk planner/metadata.",
  "limits": "Experimental model hooks only scoped to one serial measure; no ordinary flag/default/controller/new kernel. Default host roots still256/512MiB; full512MiB equality may fail. Inspected quality holdouts untouched; no quality/SnapKV/physicalSTT/throughput claim."
}

## Forward owner release — read-only starting-state diagnosis

{
  "timestamp": "2026-10-02T20:54:08.144906+00:00",
  "scope": "One4K/12step read-only owner/forward phase diagnosis after shared4context memory primary failed. No usual/timing/generation advancement.",
  "pilot_sha256": "5264420d8da0237b58b33adfbcfd21c481b46bad7cc23c46044b5ebb853ebf90",
  "owner_helper_sha256": "4a07e33de813d3e25548953301b237cac557704a442b892dab93abe44274075d",
  "question": "Is the post-prefill decode starting allocation already the observed candidate peak before first owner release? Record before/after lease and forward public counters without retaining tensors or resetting peaks.",
  "limits": "One context; timings invalid. No algorithm edits or post-hoc gate change. Preserve raw/failed result."
}

## Forward owner release v1 — verified failed primary and starting-state diagnosis

TwoGPU0 subprocesses under the advisory model lock finished exit0: shared
four-context12step pilot and a4K read-only phase diagnosis. Exact argv/env
and immutable source/proof hashes are in `forward_owner_release_v1/jobs.json`,
plans, archives and `verified_report.json`. The underlying RawInputPolicy is
unchanged between arms and from its prior frozen failed screen. Installed
DynamicLayer.update source hash confirms the measured torch.cat semantics.

10focused CPU fixtures pass: normal and partial-forward exception recovery,
weak owner expiry, unsupported-prefix/dtype/short/multiappend/alias/uninitialized
fallbacks, row-padded cache layouts, original Bulk preparation and lease flag
cleanup. Full suite227pass, one existing warning,8.71seconds.

Four contexts4K/8K/16K/31.5K preserve all per-boundary states/history/IDs/
counters/transfers/root and reproduce8prior frozen rows. All1,536layers are
released/restored over48forwards, no outstanding lease after each call.
Torch allocated peak minus constant model storage plus actual256MiBhost range:
539.059→521.309;539.219→518.391;538.895→519.254;539.011→520.561MiB.
Primary savings3.29/3.86/3.64/3.42%, all below10%; all still exceed512MiB.
Reserved and whole-request/prefill scopes remain separately reported; no
usual-budget, timing, generation/stress or ordinary CLI expansion.

4K read-only public counters: first pre-forward starting allocation is already
near peak; bit-prefix validation raises it by~1MiB before clearing. First
release then reduces live allocation127.8105MiB, while later model forwards
stay below the existing peak. This supports investigating compressed-prefill
ownership before decode begins, rather than more post-boundary release.
Phase attribution is4K-only and counter scopes exclude other host/cache/driver/
non-Torch allocations. Observer timing invalid; unrelated workloads untouched.

Decision: reject. Scoped model hooks and standardTorch payload prototype stay
research-only; no ordinary/default/new kernel/dependency/global setting change.
Current raw/helper sources/tests preserved for reproducibility. Next preregister
end-to-end compressed-prefill ownership before editing; quality/hardware/full
resource/generalization/paper P0/P1/P2 remain open. Estimate10–20workingdays,
conditional on hardware access and research outcomes.

## Prefill owner share v1 — preregistration

{
  "timestamp": "2026-10-02T21:02:56.499230+00:00",
  "hypothesis": "Share initial hot KV with the already-identical visible prefill buffer before decode peak reset. Forward-owner release then avoids retaining old payloads during model append. One changed mechanism: initial payload backing; existing forward leases/RawInputPolicy unchanged in both arms.",
  "control": "Frozen ForwardOwnerPolicy+scoped OwnerRelease in both arms, same standard host allocator/caller/teacher/model/caps. Candidate validates and rebinds hot-prefix views only at decode_step_count0.",
  "control_proof_sha256": "4a80b1ac1d8fd5701db34ac933c463deb821b6c866840fb0d53c7f7253b65f11",
  "owner_helper_sha256": "4a07e33de813d3e25548953301b237cac557704a442b892dab93abe44274075d",
  "raw_policy_sha256": "42199dcddc1a1ad154360d9b6a95a7e9d4e696fda89d3b8b918f663d3cee193d",
  "model": "../models/mistral-7b-instruct",
  "seed": 0,
  "precision": "BF16KV/F32metadata",
  "hardware": "GPU0L40S/model lock; unrelated workloads untouched",
  "contexts": [
    4096,
    8192,
    16384,
    31500
  ],
  "decode": 12,
  "geometries": {
    "shared": [
      991,
      1090
    ],
    "default": [
      1024,
      2048
    ]
  },
  "primary": ">=10% lower whole-decode Torch allocated peak minus constant model storage plus actual owned host range. Report complete512MiB and reserved/whole-request/prefill scopes separately.",
  "guards": {
    "state_ids_history_counters_payload": "exact",
    "median_decode_pct": 2,
    "p95_decode_pct": 2,
    "ttft_pct": 10,
    "prefill_allocated_peak_pct": 2
  },
  "progression": "CPU prefix/weak-owner/fallback fixtures then shared4-context public memory/parity pilot. Failed primary/correctness stops. Passing advances usual geometry,3ABBA warm50step model timing and mandatory saturation/stream/lifetime/generation/recycled-request proof before ordinary adoption.",
  "limits": "Serial research Mistral/DynamicLayer only; default host ranges256/512MiB. Full-resource equality may remain failed. No new native kernel,ordinary flag/default,physicalSTT/SnapKV/quality/throughput claim; inspected holdouts untouched."
}

## Prefill owner share v1 — verified memory pilot

Both owned model jobs and the full suite finished successfully. The persistent
verifier independently checks all eight pairs, 16 frozen replay rows, source
hashes, per-boundary history/state/IDs/transfers, and completed scoped leases.
Shared active envelopes fall 20.7–21.2% to 410.83–411.01 MiB; usual envelopes
fall 14.0–14.1% to 671.67–672.93 MiB. Both memory primaries pass. Shared active
storage fits the observed 512 MiB scope; usual active and both reserved scopes
fail it. Whole-request/prefill peak remains unchanged. Public host ranges are
256/512 MiB; no complete-resource equality or model-wide memory claim.

Nine focused fixtures and the full 236-test suite pass. No ordinary/default
change. Quiet-GPU 3-ABBA timing, saturation/stream/lifetime/generation/recycled
request checks and any CLI adoption remain open. GPU 0 has an unrelated
dystream workload; leave it untouched and run only untimed preservation while
timing is unavailable. Estimate remains 10–20 working days, conditional on
hardware access and research outcomes. Proof: prefill_owner_share_v1/verified_pilot.json.

## Prefill ownership — untimed generation preservation plan

{
  "timestamp": "2026-10-02T21:22:19.172001+00:00",
  "pilot_proof_sha256": "0d06b69d6ff807188a6ee5bb09c23fdb032e54fc33008556b4c85c97eb45f02c",
  "progression": "Both memory primaries passed. While unrelated GPU0 workload prevents clean timing, execute untimed mandatory generation preservation. Timing guard remains pending; any failure stops ordinary adoption.",
  "control": "Ordinary BulkPromotionPolicy without owner hooks",
  "candidate": "Frozen research PrefillSharedPolicy plus one scoped OwnerRelease per serialized generation",
  "generation_manifests": {
    "shared": {
      "path": "results/hardware/fused_bounded_pool_20261002/generation_shared/generation_manifest.json",
      "sha256": "8c2f787fbe70e98356a2d4a77a1a5886d3aac4bede8c37e73f9b680514655db7"
    },
    "default": {
      "path": "results/hardware/fused_bounded_pool_20261002/generation_default/generation_manifest.json",
      "sha256": "b46a64ea3bb14e82dc4f6cf9caa24828279b09c22a5430c874daa80f59caa723"
    }
  },
  "source_bundle_sha256": "cb4aa5d10291dd3260b65a9babcebca2e8a541de4ba174b0b96e3a1f4ff27e43",
  "guards": "24 pairs across two geometries, six tasks,12 reused documents,seed0: exact tokens/score/state/trajectory/IDs/counters/queries/transfers/root; prefill share32, balanced lease restoration and complete model hook cleanup.",
  "limits": "Timing diagnostic only while unrelated workload exists. No holdout tuning, new native-kernel proof, concurrent serving, complete resource equality, physical STT or ordinary adoption."
}

## Prefill ownership — boundary and request preservation plan

{
  "timestamp": "2026-10-02T21:28:36.053048+00:00",
  "pilot_proof_sha256": "0d06b69d6ff807188a6ee5bb09c23fdb032e54fc33008556b4c85c97eb45f02c",
  "scope": "Existing 36shared+4usual multi-token/inclusive/fill/saturation/before-mutation boundaries; existing three serialized interleaved/recycled requests per geometry, with only the active candidate request hooked during each forward.",
  "candidate": "Frozen PrefillSharedPolicy; synthetic multi-token path has no model lease. RecordedSharedPolicy plus scoped OwnerRelease around each active model advance.",
  "control": "Existing synthetic DirectScorePolicy and model GpuPolicy; isolated CPU model controls replaced by ordinary RecordedBulkPolicy.",
  "guards": "Exact boundary state/history/KV/IDs/counters/root,40cases andfullsaturation; six candidate requests/all51frames pergeometry; prefillshare32/balanced48leases/1536layers pergeometry; no inactive request hooks, reset/isolation restored.",
  "source_bundle_sha256": "c6dd44f55d31fd9267380f939e97d8b7ac503e2845cdc8fd6bec8c9bc8a62809",
  "limits": "Untimed serial default-stream preservation while unrelated GPU0 workload persists. No threaded/async serving, physical tier, new native-kernel proof, full resource equality or ordinary adoption."
}

## Prefill ownership — verified generation preservation

Both model runs exit0:24 exact candidate/control pairs, six tasks, both
geometries,12 reused documents/seed0. All48 rows reproduce frozen ordinary-bulk
outputs/state/trajectory/counters/queries/transfers/root. All1,213 candidate
forwards restore38,816 layers; hooks are removed after each request.

The first read-only verifier incorrectly assumed every layer compacts on
every token. One shared GovReport case compacts7,634 layers versus7,808
bindings, exactly matching the frozen control's7,634 compactions. Preserve
verify_generation_v1.py; corrected verifier checks actual frozen compaction
counts. No model/helper/source/data/gate change or model rerun. Independent
proof:prefill_owner_share_v1/verified_generation.json. Boundary and recycled
request jobs continue serially. Timing/stream-lifetime/full-resource/ordinary
adoption and broader P0/P1/P2 gates remain open.

## Prefill ownership — verified finished preservation batch

All six GPU preservation jobs exit0. Independent source/hash verifiers confirm
24generation pairs,48frozen generation rows,40saturation/append cases and six
serialized interleaved/recycled requests. All102boundary frames match and
all18request rows replay frozen controls. The96candidate request forwards
restore3,072layers; only the active request has hooks attached. Source helpers,
ordinary evaluators, defaults, data and frozen gates remain unchanged.

The existing236-test suite and9focused prefill cases passed. All owned model
jobs are terminal. GPU0 still has an unrelated dystream workload (last observed
PID737729,588MiB); do not interpret observer times as clean latency evidence.
Quiet-GPU3ABBA timing, practical ordinary-bulk regression guards, additional
stream/lifetime validation and complete-resource/physical-tier/quality/P0/P1/P2
remain open. No ordinary adoption. Full active/shared and reserved/usual scopes
retain their documented512MiB limits. Estimated remaining10–20workingdays,
conditional on hardware access and research outcomes. Combined proof:
prefill_owner_share_v1/verified_report.json.

## Prefill ownership — GPU lifetime preregistration

{
  "timestamp": "2026-10-02T22:06:49.030963+00:00",
  "prior_batch_sha256": "99f0bda2d13f4be255f802d38908156e4fb9cca205bf951ac759f37989c3ee42",
  "scope": "14 untimed GPU checks:five overlapping/duplicate/empty/full BF16/F32 gathers on two consumers; normal and injected partial DynamicCache forwards on each consumer.",
  "guards": "All65536 BF16 bit patterns, special F32 payloads, untouched buffer tails, old prefill-hot owner expiry, delayed recorded consumer and producer allocation pressure; balanced real Torch always_call hooks, exact restored prefixes, normal/partial old model-owner expiry and hook cleanup.",
  "ownership": "Explicit ready events and caller-managed record_stream on every input. Consumers run serially; no automatic cross-stream/concurrent model support claim.",
  "source_bundle_sha256": "ea9216e3caa67440c7282fa6097c5299029a7e74bd1d8cb1e5e91c2eaf1d0354",
  "source_sha256": {
    "results/hardware/prefill_owner_share_v1/check_lifetime.py": "cc1cdd9f192ca6116977d651deab1199e90b2f1693c21adb59bc2381a1c714f7",
    "experiments/prefill_owner_share.py": "939b0293ebd8bf4d2138e8b4cf8ccad7d4b5f1b0aa0a0331ed0ecb11135b0e50",
    "experiments/forward_owner_release.py": "4a07e33de813d3e25548953301b237cac557704a442b892dab93abe44274075d",
    "experiments/raw_input_reuse.py": "42199dcddc1a1ad154360d9b6a95a7e9d4e696fda89d3b8b918f663d3cee193d",
    "tests/test_forward_owner_release.py": "0c269ca17a2233b033b8d55a501f76e2566d5381595bc08c52ea42cfb67db46e"
  },
  "limits": "Toy two-layer DynamicCache model validates real hook and GPU storage behavior, not full Mistral exception compute. No timing/model-memory/quality/ordinary adoption or physical tier claim; original frozen prototype unchanged."
}

## Prefill ownership — verified GPU lifetime and frozen timing gate

Fourteen untimed GPU checks exit0 and independently verify:10 all-BF16/F32-payload overlapping/duplicate/empty gathers with owner release and producer allocation pressure, plus4 real Torch hook/partial DynamicCache exceptions. Two serial consumers use explicit events and caller record_stream. Frozen model/helper sources unchanged; no automatic stream/concurrent-serving/full-Mistral-exception or ordinary claim. Proof:prefill_owner_share_v1/verified_lifetime.json.

{
  "timestamp": "2026-10-02T22:13:26.276273+00:00",
  "lifetime_proof_sha256": "c6024fadffd2a90929ded423d2c4916112b670fdc4eb1a13a5baf6f370da72b3",
  "pilot_proof_sha256": "0d06b69d6ff807188a6ee5bb09c23fdb032e54fc33008556b4c85c97eb45f02c",
  "control": "Frozen RecordedForwardPolicy with scoped OwnerRelease",
  "candidate": "Frozen RecordedSharedPolicy with the same scoped OwnerRelease; only initial hot backing differs",
  "driver": "experiments/compare_prefill_owner.py",
  "driver_sha256": "46035db789e5dcacb21eeaa8d10b58f95e3063f4e8af0896a328f749de503038",
  "source_plan_sha256": "d9c5d58832ad87916ad80634e00db8c5705513d8eb1c6c4bf36e66af4edf3fd6",
  "prompt_sha256": "44d127150e182f3fe0f83e4e1c005814bc7db9c61a1fd5ed21f4ab6535e816fc",
  "teacher_sha256": "620ac3a383997c9afbc6a3f0b06acec9f261d5a2a5827bf5988e0bb5b69f12a2",
  "model": "../models/mistral-7b-instruct",
  "seed": 0,
  "precision": "BF16KV/F32metadata",
  "context": 16384,
  "decode": 50,
  "warmup": 1,
  "blocks": 3,
  "geometries": {
    "shared": [
      991,
      1090
    ],
    "default": [
      1024,
      2048
    ]
  },
  "guards": {
    "median_decode_max_regression_pct": 2,
    "p95_decode_max_regression_pct": 2,
    "ttft_max_regression_pct": 10,
    "prefill_allocated_peak_max_regression_pct": 2,
    "state_history_ids_counters_payload": "exact"
  },
  "hardware_requirement": "GPU0 L40S under advisory model lock; no other compute process before launch and contention monitoring throughout. Do not start on a brief gap between repeating dystream jobs. Archive/stop contaminated runs; do not infer clean latency.",
  "progression": "After both scoped mechanism timing guards pass, require a separately frozen practical regression comparison to ordinary BulkPromotionPolicy before considering any CLI adoption. Full resource equality remains separately unproven.",
  "commands": {
    "shared": [
      "../venv_kvcache/bin/python",
      "experiments/compare_prefill_owner.py",
      "--contexts",
      "16384",
      "--decode",
      "50",
      "--warmup",
      "1",
      "--blocks",
      "3",
      "--hot",
      "991",
      "--cold",
      "1090",
      "--output",
      "results/hardware/prefill_owner_share_v1/timing_shared.json"
    ],
    "default": [
      "../venv_kvcache/bin/python",
      "experiments/compare_prefill_owner.py",
      "--contexts",
      "16384",
      "--decode",
      "50",
      "--warmup",
      "1",
      "--blocks",
      "3",
      "--hot",
      "1024",
      "--cold",
      "2048",
      "--output",
      "results/hardware/prefill_owner_share_v1/timing_default.json"
    ]
  },
  "limits": "Memory preservation guard only, not a new speed gain or full512MiB/physicalSTT/SnapKV/quality/general-serving claim. Original frozen helper/evaluator/default sources unchanged."
}

## Prefill ownership — timing availability result

Twenty GPU0 process snapshots over38+seconds find no sustained observed quiet interval. Preserve timing_preflight_v1.json; no model timing starts, no unrelated workload touched. Scoped GPU lifetime gate passes14cases; timing and separately frozen ordinary-bulk regression guards remain pending. Full512MiB physical equality, quality/baseline/hardware and wider P0/P1/P2 remain open. Estimate10–20workingdays remains conditional on hardware access and research outcomes.

## Fresh prefill ownership portability — preregistration

{
  "timestamp": "2026-10-02T22:29:29.945050+00:00",
  "hypothesis": "Does the frozen initial-hot/forward ownership prototype keep >=10% lower active decode envelope in the actual fresh teacher-generation caller, which retains prefill logits through the first decode?",
  "control": "Ordinary BulkPromotionPolicy, reset-only primitive recording subclass",
  "candidate": "Frozen PrefillSharedPolicy plus one scoped OwnerRelease; reset-only primitive counts. No caller/allocator/precision/capacity/model/data change.",
  "model": "../models/mistral-7b-instruct",
  "seed": 0,
  "context": 16384,
  "decode": 50,
  "hot": 991,
  "cold": 1090,
  "precision": "BF16KV/F32metadata",
  "primary": ">=10% lower decode Torch allocated peak minus constant model bytes plus actual owned host range; report whole-request/reserved peaks and absolute512MiB separately.",
  "guards": "Exact50 predictions,finalstate/counters/input/teacherIDs/hostoccupancy/root/transfer bytes+calls; candidate prefillshare32,balanced50ownerforwards/1600layers,hookcleanup; allhostroots released.",
  "progression": "Shared geometry first. Failed portability primary stops usual/timing/ordinary expansion for this caller; preserve the earlier isolated legacy result. No ordinary promotion from this audit alone.",
  "hardware": "GPU0L40S under model lock; unrelated workload untouched. Untimed public resource/lifetime proof only.",
  "prior_proof_sha256": "ee9f2f4bd9798465a3db67e51bd0a32e889bfe620b6d400c0613cfba1fa36df5",
  "ordinary_prior_proof_sha256": "0489e3f93bb649e0c90547442fadaa3d6630ce368c90edb7e6e10975b0dbd9ac",
  "source_bundle_sha256": "3a644acad4634abc86df3d24755932054d3dd7c6a81a0c1fda4590db59173dc9",
  "prompt_sha256": "18695714f26e35cb8d2b039ae9efb3b7e64291cbd7bcd91956efc07e16a732cd",
  "teacher_sha256": "620ac3a383997c9afbc6a3f0b06acec9f261d5a2a5827bf5988e0bb5b69f12a2",
  "limits": "Two fresh processes,one model/seed/fixed teacher stream. Public host range and Torch counters exclude other host/cache/driver scopes. No speed,quality-superiority,physicalSTT or complete resource equality claim."
}

## Fresh prefill ownership portability — verified rejection

Both GPU0 processes exit0. The independent verifier checks frozen sources,
primitive allocator snapshots, actual256MiBhost ranges, all50predictions/final
state/counters/inputs/teacher IDs, occupied/reservedhostbytes, transferpayloads
and nativecalls. Both rows replay the earlier frozen ordinary state. Candidate
shares32prefilllayers and restores50forwards/1600layers; hooks remove and all
hostroots release. No ordinary/helper/allocator/caller/data/default change.

Active decoded envelope1536.641 to1410.895MiB gives8.1832%, below10%primary.
Both exceed512MiB. Reserved6089.492MiB and prefill18.627830784GB are unchanged.
Weak handles independently confirm1000MiBprefilllogits persist through first
decode in both arms, expiring before the second. The legacy20.7–21.2% result
is valid only in its separately measured caller. Reject portability expansion:
no usual geometry, model timing or ordinary adoption for this unchanged fresh
caller. Next preregister an isolated early-output-release caller experiment
after checking every use of the output. Unrelated GPU workload untouched;
observer timing invalid. Full P0/P1/P2 remains open, estimate10–20workingdays
conditional on hardware access and research outcomes. Proof:
fresh_prefill_owner_v1/verified_report.json.

### 2026-10-03 — Ordinary caller prefill-output lifetime fix

Preregistered caller-only release before implementation. Archived both original
callers; an AST verifier proves one deletion in each function and no other
AST change. CPU regression reproduced unused prefill-output retention in both
normal and chunked prefill; 243 tests pass after the fix. EOS, one-token and
zero-token behavior also passes. Two fresh GPU ordinary-bulk processes finish
with exact 50 predictions, final state, counters, payload/call counts and frozen
replay; all pinned roots release and diagnostic hooks are removed.

Weak handles prove 1000 MiB prefill-logits storage expires before first decode.
The original phase scope starts at compressed-prefill handoff before release,
so the measured active envelope falls only 1536.6411→1518.2856 MiB (1.1945%):
FAIL the declared 10% primary. Reserved 6089.4917 MiB and whole-request prefill
18.627830784 GB are unchanged. The boundary/reset was not moved. Keep the
lifetime bug fix, stop expansion as a phase-memory optimization, and retain
this negative result. Paired generation replay is running at both geometries.
Proof: results/hardware/prefill_output_release_v1/verified_resources.json.

Caller fix completion: both generation jobs exit 0. All 24 archived/current
ordinary-bulk pairs preserve 16 fields across six tasks and both geometries;
48 rows replay frozen ordinary controls (1237 candidate generated tokens).
All four owned GPU jobs are terminal. Native Mistral forward source explicitly
supports logits_to_keep and slices hidden states before lm_head; no experiment
or implementation of that separate mechanism yet. Combined proof:
results/hardware/prefill_output_release_v1/verified_report.json.

### 2026-10-03 — Native last-prompt-logit resource pilot

Preregistered native logits_to_keep=1 for prefill only, retaining caller release
in both arms. Research AST wrapper proves exactly the intended keyword additions;
ordinary sources/defaults unchanged. Seven real tiny-Mistral branch cases pass,
including bounded chunks/EOS/one-token/zero-token. Two fresh GPU processes at
991/1090 preserve 50 predictions, state, counters, all transfer bytes/calls and
frozen ordinary replay. Native prefill output is [1,1,32000]/64000 bytes instead
of [1,16384,32000]/1000 MiB. Both expire before decode.

Active decode envelope: 1518.2856→541.0771 MiB, 64.3626% (PASS10%). Reserved
6089.4917→5089.4917 MiB; whole-request prefill18.627830784GB unchanged. Shared
active still exceeds512MiB. No speed/quality-superiority/physicalSTT/equal-resource
claim. Run usual resources and 24 generation pairs next; timing guards before
ordinary integration. Proof: prefill_last_logits_v1/verified_resources_shared.json.

Last-logit preservation completion: usual active envelope1781.3130→806.5005MiB
(54.7244%, PASS10%), reserved6345.4917→5345.4917MiB, prefillunchanged. Both
resource pairs preserve all50predictions/state/counters/payload/calls and frozen
replay. All24free-generation pairs/six tasks/both geometries preserve16fields
and replay48frozenordinaryrows/1237candidate tokens. Six untimedjobs exit0.
QuietGPU20sample/40s preflight and per2s monitoring preregistered before3ABBA
TTFT/decode guards; guardfailure stops expansion, no automaticretry. Ordinary
source/defaultsunchanged. Proof: prefill_last_logits_v1/verified_preservation.json.

Last-logit timing: clean20sample/40s preflight and no unrelated compute PID in
both per2s monitors. ThreeABBAblocks eachgeometry preserve model/policy/state/
payloads. Sharedmedian59.8302→60.3569ms (+0.8804%),p9565.2981→64.5668ms;
usual64.9508→64.8886ms,p9569.0411→68.3462ms. TTFT2259.8495→2237.5747ms
shared,2312.5854→2288.4325ms usual; GPUpeaksunchanged. All regression guards
pass; no5%speedclaim. Bothowned timingjobs exit0. verified_timing.json.

Preregistered ordinary opt-in integration after guards pass. FourCLIs/APIflag,
newcheckpointfingerprint, disableddefault and explicitnative-support error.
252tests pass after correcting newprofilerfixture to useTieredcounterstats;
originalFullCache fixed-teacher KeyError preserved as separate followup. All4
helpchecks pass. Two realbulk-evaluator Qasperruns off/on preserve output/score/
transfercounts; two realfreshCLI runs replay prototype50pred/state/transfers.
ActualAPIgeneration24pair replay running at bothgeometries; no final integration
adoption yet. Initial model/experiment sources unchanged by fixture correction;
original and final test archives retained separately. Proofs in
prefill_last_logits_integration_v1; fullP0/P1/P2 remainopen.

Ordinary integration completion: 24actualAPIpairs preserve16fields and replay
48frozenrows. SixintegrationGPUjobs exit0, bringing this mechanism's owned GPU
jobs to14finished including8prototype/resource/timing jobs. ActualresourceCLI
replicates541.0771/806.5005MiBactive and5089.4917/5345.4917MiBreserved scopes;
prefill18.627830784GBunchanged. ActualbulkCLIoff/on Qasper answer/score35.0 and
payload/transfercounts match frozen results. 252tests pass; realevaluatorCLI
checkpoint test with mocked model/task I/O verifies legacy-disabled resume and
enabledmismatch rejection beforetask evaluation. Adopt --prefill-last-logits as
optional nativeAPIoptimization; defaultFalse. Full512MiB, modelpeak, quality
versusSnapKV, physicalSTT and broader P0/P1/P2 remainopen. Next preserved
FullCache fixed-teacher missing-counter issue. Final proof:
prefill_last_logits_integration_v1/verified_final_status.json.

### 2026-10-03 — Fixed-teacher baseline profiler counter repair

Preregistered reporting-only change after observed FullCache KeyError. CPU
regression reproduces8failures/fourbaselinepolicies/twoprefilllogitsettings,
with2Tieredcasespassing before the patch. Emit only policy-exportedSTT deltas;
decode_steps now counts measured model forwards, since baseline stats track
modeled-cost steps that this profiler does not update. Avoid fabricated baseline
STT zero counters. Whole-module AST verifier proves no other behavioral change.

262tests pass. One fullMistral GPUjob verifies5policies/bothlogitsettings/1warmup/
2measuredtrials/4Kcontext/12decode:390forward observations match teacher IDs
and absolutepositions. Eachpolicy's predictions match all/lastlogit paths.
Archived/current ordinarybulk trials replay predictions, canonicalstate/history,
all explicitpayload/callcounts, hostbytes and Tieredcounterdeltas. Jobexit0;
hooks removed. Hook-instrumented times are invalid for speed claims. Unequal
budgets; no matched-resource/quality/physicalSTT claim. FullP0/P1/P2 remainopen.
Next profile query-scoring allocations before resource-matched comparison.
Proof: results/hardware/baseline_profile_counters_v1/verified_report.json.

### 2026-10-03 — Verified whole-prefill allocation attribution

Read-only line trace and independent model child-hook audit replay the frozen
ordinary bulk/last-logit 16K/50-token run at capacities991/1090: all predictions,
canonical policy state, counters, transfers and phase peaks match. Whole-prefill
peak18.627830784GB is first reached at layer31 MLP multiplication, between up
projection return and down projection entry. Full raw BF16 KV retained across
32 layers totals2048MiB; each gate/up/product tensor is448MiB. Query scoring's
observed live maximum17.177814016GB is not the origin of the first global peak.

Four owned GPU jobs terminal: line observer exit0; initial model observers
exit1/exit1 because their strict hook baselines preceded64 lazy native
Transformers output-capture hooks; final observer installs those inactive native
hooks before its baseline, removes all384 diagnostic hooks, and exits0 with
strict child-module baseline equality. Failed raw results/assertions preserved.
Sources, plans, prior results, all accepted/failed evidence and jobs are hashed
in verified_report.json. No ordinary source change;262-test validation remains
current. Synchronization invalidates audit times; Python frame tracing can
extend local lifetimes, so allocation attribution is checked against independent
child hooks and unchanged frozen phase peaks. No optimization or matched
resource/quality/physicalSTT claim. Next preregister exact layerwise placement
with full raw prefill attention and >=10% whole-prefill peak primary.
Proof: results/hardware/prefill_allocation_audit_v1/verified_report.json.

### 2026-10-03 — Exact layerwise prefill placement: primary pass, guard stop

Preregistered before implementation and archived all204 ordinary source files.
Research-local AST helper executes the identical ordinary initial-bifurcation
loop body for each DynamicCache.update with the same captured actual queries.
Future hot KV is stored while original full raw KV is returned to that layer's
prefill attention; no chunking, selection/dtype/kernel/allocator changes.
Scoped weak-policy root hooks inject the cache; partial errors reset state.
Eight tiny real-Mistral pairs across four geometries/two logit settings preserve
all prefill and five-step decode logits/cache/state/counters. Deliberate layer1
exception and out-of-order update cleanup/validation pass.

Fresh GPU control/candidate jobs37126/78445 exit0. Control replays frozen
ordinary50 predictions/state/counters/transfers/phase peaks. Candidate likewise
preserves all predictions/state/counters/payload/call counts and actual pinned
256MiB capacity; all32 full16K raw layer inputs observed. Owned roots release;
scoped root hooks restored. Whole-prefill peak18.627830784→16.709458944GB,
10.2984% lower, PASS10%. But decode GPU-only allocation excluding unchanged
model storage285.0771→291.6514MiB,+2.3061%, FAIL2%. The combined GPU+rounded-host
envelope541.0771→547.6514MiB,+1.2150%, is explicitly reported separately.
The plan did not explicitly exclude the stricter GPU-only scope; do not switch
its denominator to claim a pass. Research tradeoff only: stop second geometry,
generation/timing expansion and ordinary adoption. Ordinary code remains
unchanged and existing262-test validation still applies. Full512MiB, actual
resource matched quality/latency, physicalSTT and fullP0/P1/P2 remainopen.
Proofs: layerwise_prefill_placement_v1/verified_resources_shared.json and
verified_guard_review.json. Next return to matched-resource P0 evidence.

### 2026-10-03 — SnapKV actual envelope preregistration

Read-only fresh faithful SnapKV974/32/5,16K50,seed0,native last-prefill-logit
audit before implementation. Require all50 frozen faithful predictions/cache
widths and strict adapter/root cleanup. Measure CUDA phase allocated/reserved
and unique KV; phase reset matches current ordinary fresh handoff. Compare
actual scopes to frozen ordinary bulk; unequal bytes/widths cannot establish
matched P0. No timing/quality/policy change. Plan and controls frozen in
results/hardware/snap_actual_envelope_v1/plan.json.

### 2026-10-03 — Verified current actual envelope versus faithful SnapKV

Three tiny native-all/last SnapKV pairs preserve predictions/cache/widths;
partial attention failure restores all adapter hooks/groups. Fresh GPU jobs
70166(Snap) and24632(ordinary primitive-width observer) exit0. Both replay all50
frozen predictions; ordinary state/counters/transfers/all phase peaks match its
frozen adopted last-logit run. All owned pinned roots and root hooks release.
Read-only observation changes no ordinary source;262-test validation remains.

Actual active decode scope subtracts identical14,483,464,704B model storage,
then adds owned pinned allocator capacity. Snap528.7412MiB GPU+0host;
ordinary285.0771MiB GPU+256host=541.0771MiB. Both exceed512MiB. Reserved
whole-request envelopes2881.4917/5089.4917MiB; prefill16.958268416/18.627830784GB.
All3200 layer-forward widths observed: Snap975..1024;ordinary1024 always;
49/50 decode steps unequal. No exact byte/width match or matched-P0 completion.
Older independent DirectCPU NI failure is separately labelled; no current
independent quality or latency result inferred. Plans/source archives/raw/jobs/
cleanup hashes verified. Standalone PNG/PDF andCSV diagnostic exports added;
figurev1 preserved after correcting legend overlap in final export. Central
current-state/supervisor paragraphs now supersede stale206/236-test narratives.
Next preregister actual-allocation/attention-geometry comparison before quality/
latency reruns. Proof:snap_actual_envelope_v1/verified_report.json.

### 2026-10-03 — Faithful SnapKV fixed genuine capacity preregistration

Reserve actual1024-row backing while exposing only populated974..1024prefix;
keep upstream selection/expanded heads/full prefill attention. Require all
predictions and populatedKV bits exact, plus overflow/error/cleanup guards.
Research baseline only; no fake allocation, exact TieredKV-use equality,
speed/quality/full512MiB/P0 claim. Plan/control archived before implementation
in results/hardware/snap_reserved_capacity_v1/plan.json.

### 2026-10-03 — Packed real cold capacity preregistration

Configuration-only ordinary bulk research pilot: cold1090->1984 derived from
measured256MiB pinned range/(128KiBslot)-64transient slots. Root requests
144.25->256MiB but physical rounded capacity should remain256MiB. Hot991/quota32
and all code unchanged. First require occupiedcold>=1.5x and total active<=576MiB
shared fixed ceiling; report extraGPU metadata/transfers, do not claim512MiB
or exact measured usage equality. Resource failure stops expansion. Then
12development pairs/nonnegative direction before quality bootstrap/timing
gates; inspected100-document holdout excluded from tuning. Plan/source frozen
in results/hardware/packed_cold_capacity_v1/plan.json.

### 2026-10-03 — Reserved SnapKV fidelity complete; packed cold pilot stopped

Reserved baseline: eight tiny CPU dtype/geometry pairs and two partial-forward
error cases restore roots/hooks/groups. GPU71281 pairs all51prefill/teacher
boundaries: every populatedBF16KV bit, all logits (maxdelta0), and50predictions
match original faithful Snap; overflow rejected before mutation. Fresh50121
charges512MiB actualKV backing at all51 boundaries with unchanged populated
974..1024prefixes. Complete active522.6123MiB exceeds512; retained CUDA reserved
3329.4917MiB vsoriginal2881.4917; prefill16.9857 vs16.9583GB. All64root weak
handles expire; adaptergroups/hooks restored. Research baseline only, original
upstream-growing adapter stays control. No optimization/adoption claim.

Packed cold resource81492: unchanged ordinarybulk code/hot991/quota32, cold1984
from actual256MiB pool capacity minus64transient slots. Rounded host stays256MiB;
requested144.25→256MiB and occupied112.125→196MiB(+74.8049%). Active541.0771→
541.1553MiB; reserved5089.4917/prefill18.627830784GB unchanged;50fixed-teacher
predictions unchanged. More initialD2H bytes charged,117571584→205520896;
H2D payload unchanged315621376. Resource pilot passes declared576MiB cap;
no512MiB/full-use equality claim.

Development20989:24arms/12pairs/six tasks, context-disjoint from100doc final
holdout. All12actualAPIcontrols replay frozen16integrity fields. Task-balanced
candidate-control−0.3291533points, descriptive paireddevelopmentCI
[−1.1244189,+0.4661124],10Kdraws/seed20261003. Negative direction fails pilot;
stop widerquality/timing/adoption. Threepredictionpairs change;3125extra
initialcoldrows are exposed. GovReportmean−1.9749;otherfive taskmeans0. More
physical-retention utilization does not establish quality benefit. Both jobs
exit0 with ownedroot/hook cleanup; ordinary sources unchanged/262tests current.
Proofs:snap_reserved_capacity_v1/verified_report.json,
packed_cold_capacity_v1/verified_resource.json and verified_development.json.
Next inspect existing current-query retrieval quality/cost before another
mechanism; fullP0/P1/P2 remainsopen.

### 2026-10-03 — Native pool current-query selector preregistration

OriginalGPUselector uses canonical cold tensors; CPUCLI correctly restricts
strategyLRU. New research module will reuse nativepairedreads for fullscan
query ranking withoutCPUcanonicalinspection; sameQ/softmax/topk/order and
visiblewidth, consistentselectedpositions/indices. Tiny andGPU4K12 exact
oldGPU/newGPU/newCPU parity first; then16K50 resource<=576MiB,12development
direction and quiet3ABBAregression guards beforeadoption. CPUCLI/defaults
unchanged;full512MiB/physicalSTT/P0 claims stayopen. Control frozen in
results/hardware/pool_query_selector_v1/plan.json beforeimplementation.

### 2026-10-03 — Native pool query correctness and fresh resource gates

Fourtiny CPU pairs/full266tests pass. FirstGPU4K12 job87536 exits1 on missed
CPUshadow-index→CUDA conversion; failedsource/raw/job preserved. One-line
correction plus new rawfilename archived before rerun. GPU24710 exits0:
originalGPU/pairedGPU/nativeCPU match12predictions/13allstatecounterlogitframes/
384visibleKVandchoices; native selector canonicalCPUreads0, H2D1379229696bytes.
Verified_correctness.json links failed/corrected archives and strictchecks.
FreshGPU35999 exits0:16K50,hot991/cold1090/quota32,actualpromptQ,lastlogits.
Combinedactive541.077→544.321MiB passes declared576 ceiling; full512fails.
Roundedhost256MiB/reserved5089.492MiB/prefill18.62783GB unchanged;50teacher
predictions match,1600queryselections/1346400coldrows scanned, H2D315621376→
5825961984bytes,D2H115855360bytes,1701H2D/78D2Hcalls. Roots/hooks release.
No speed/independent-quality/ordinaryCLIadoption/physicalSTT proof. Frozen12
paireddevelopment requests preregistered beforelaunch; nonnegative direction
required before timing/quality expansion. FullP0/P1/P2 remainsopen.

### 2026-10-03 — Native pool query development direction passes

GPU95941 exits0,24arms/12pairs/six tasks. All12currentAPIcontrols exactly
replay16frozen integrity fields; contexts disjoint100documentfinalholdout.
Task-balanced difference+2.1319802points, descriptiveCI[+.1790135,+4.0452644],
10Kdrawsseed20261003. Sixpredictionpairs change,24864querylayerselections,
23702368coldrows scanned. Ownhooks released everyrequest. Nonnegativepilot
passes, independentNI/superiority unproved. Frozen3ABBA16K50warmup1 quietGPU0
latency guard nowrunning; median/p95<=2%worse,TTFT<=10%worse. A failedguard
stops widercandidateexpansion/adoption. OrdinaryCLIs/defaults remainunchanged.

### 2026-10-03 — Native pool query latency guard fails; stop expansion

GPU11587 exits0,all12rows/3ABBA16K50,warmup1,ordinaryBulkLRU/query/query/LRU.
25before/afterGPU0computePID checks quiet; GPU1unrelatedwork untouched.
300measuredforwards/arm replay allfixedteacher predictions; ownhooks release.
Median58.684060→139.831105ms,ratio2.382778; p9564.719989→143.339417ms,
ratio2.214763; both fail<=2%regressionguard. TTFT2229.505998→2211.169701ms,
ratio.991776passes<=10%. Full-scan resource544.321MiBfits576pilot and reused
developmentquality+2.131980points do not override failedlatency guard. Stop
widercandidatequality/timing/adoption; no retryforfavorablemetrics. Full512MiB,
actualfaithful-baselinebyte/widthmatching, independentquality andphysicalSTT
remainopen. Proof verified_timing.json, standalonePNG/PDF/CSVandfiguremanifest.
Next inspect existingcandidate-pruning retrieval code/cost before preregistering
any distinctlowertraffic mechanism. Sixstatusdocs updated;266tests pass.

### 2026-10-03 — Fixed8-page native query recall screen fails

ExistingStablePageIndex constructor/reconcile/candidate-device reads canonical
coldkeys; nativeCpuSlotCache property synchronizes manager and materializesCPU
storage, so unchangedGPUindex cannot be enabled on nativeCPUquery. Historical
indexedGPUcold latency+263.60% remains oldscope, not currentnativeproof.
Newnative_page_recall_v1 preregisters fixed16row stablegroups/8centroidpages,
minquota32, actualnativequery trajectory16K50,hot991/cold1090/quota32. GPU43414
exits0; all50teacherpredictions/finalcache/logicalcounters replay frozenquery
resource run,1600observations,ownhooks/canonicalguard restore. Meancandidate
fraction.13489984, top32overlap.28394531 and bestfull-distribution selectedmass
ceiling.55397531; >=.90recall/>=.95mass screensfail. Zerounderfill/max8pages.
Stop this fixed8pageheuristic's implementation/widerquality/timing. Projected
candidatepairedpayload743956480bytes is notmeasuredsaving; offlinefullkeyaudit
reads5514854400additionalbytes,totalnativeH2D11340816384bytes. Localcandidate
softmax mayretain lessmass; this optimisticdiagnostic is notgenerationquality.
No ordinarychanges;266tests remainverified. PNG/PDF/CSV+immutablehashproofsaved.
Next measure current-queryhook overhead using visible rows before a distinct
lowertrafficindex mechanism. FullP0/P1/P2 remainsopen.

### 2026-10-03 — Visible-only query-hook cost diagnosis

GPU26977 exits0,3ABBA16K50,warmup1. No-op query math repeats existing q_proj/
rotary/headfold/softmax/topk/hostID/visibleconcat but ranks onlyalreadyvisible
32coldrows, preserving originalKVorder and allpolicydecisions. Noextracoldreads.
Everymeasured row exactlyreplays ordinary50teacherpredictions/finalcache/all
logicalcounters/nativeH2D/D2Hbytes; ownhooks release,25before/afterGPU0compute
PIDobservationsquiet. Median58.581346→82.366352ms(+40.6017%),p9564.355195→
87.389711ms(+35.7928%),fail2%screen;TTFT2177.814485→2192.567142ms(+.6774%)
passes10%. Diagnosticincludesconcat/sortingbookkeeping; notformaluniversal
lowerbound oractualretrieval/resource/independentqualityproof. ReducedH2D
alonecannotrescue thisexistingunfusedpattern. Noordinarychanges;266tests remain.
Next inspectprojectionreuse/fusedranking/GPU-generatedreadindices before a
newretrievalmechanism. FullP0/P1/P2 staysopen. Proof query_hook_cost_v1/verified_report.json.

### 2026-10-03 — Native query projection reuse correctness

reused_query_projection_v1 freezesone-expression ASTchange: replace duplicate
module.q_proj(hidden) by actualMistralQprojection output, runselectorfromq_proj
posthook beforeKVupdate. Scopedparentpre/always-callposthooks clearcontext and
constructor/closeerrorcleanup.7CPUtests/273fullpass. GPU32672 exits0: original/
reusednativeCPU full4K12matchpredictions/alllogits/13cachecounterframes/384KV
choiceobservations/H2D1379229696bytes/D2H111562752bytes; frozenoldcontrolreplay,
qprojectioncalls768→384,canonicalCPUreads0,pendingempty/ownhooksremoved.
No ordinarysource/CLI/defaults change, no oldfull-scan widerquality/timing
expansion. Visible-only3ABBA componentcost preregistered5%median improvement,
p95<=2%worse/TTFT<=10%worse; jobrunning. FullP0/P1/P2 remainsopen.

### 2026-10-03 — Native query projection reuse component cost primary fails

GPU22096 exits0,3ABBA16K50/warmup1, duplicated-Qvisible-onlyhook/reusedQ/
reusedQ/duplicatedQ. Bothno-op32visiblecoldrows; exactordinary50predictions/
finalcache/alllogicalcounters/H2D/D2Hbytes perrow.300measuredforwards/arm,
25before/afterGPU0computePIDchecksquiet; ownhooksremoved. Median82.128853→
81.558852ms,saving.570001ms/.6940327%,fails>=5%primary. p9587.893582→
87.350715ms,ratio.9938236; TTFT2192.038626→2194.348509ms,ratio1.0010538;
guards pass. Stop standaloneprojectionreuseexpansion; no full-scan candidate
quality/timingretry/adoption or ordinaryfeature. CorrectnativeQreuse retained
asresearchmodule;273tests andGPUparityproof remain. Next inspect fusedranking
andGPU-generatednativereadindices, notanother duplicateprojection variant.
FullP0/P1/P2 staysopen. Proofs:reused_query_projection_v1/verified_correctness.json
and verified_cost.json. Sixstatusdocs+experimentlog updated.

### 2026-10-03 — BatchedGPU query read indices: correctness/resources pass

gpu_query_read_indices_v1 preregisters existingnativeH2D CUDAblockindices,
validatedbatchedNumPy/GPUsource/live maps refreshedafterordinaryvisibletuple.
SelectorAST changesonlylive lookup/full-livepairedread; Q/rank/math unchanged.
10CPUmaptests/283suite pass. GPU42958 exits0,BF16/FP16/F32 exactread cases,
stale/unconsumedguardbeforedispatch,explicitcallerhandoff/twoserialstreams,
alternatingpoolregisters,zero-row androot/indexcleanup. GPU30311 exits0:
pairednative4K12exact12pred/13logitcachecounterframes/384KVchoices/KVbytes,
frozenoldqueryreplay; candidate metadataH2D19202560bytes/noCPUcanonicalreads.
FreshGPU37219 exits0:16K50querypred/state/counters/nativeKVbytesexact;
active544.321→547.488MiBfits576pilot/full512fails. Host256MiB/reserved5089.492/
prefill18.62783GB unchanged. NativeKVH2D5825961984bytes,D2H115855360bytes;
candidate mapH2D75333120bytes/GPUstorage1477120bytes,51refreshes/1600reads.
Allownroots/hooks/indexrelease. Copiedresourceverifiernextlabel erroneously
alloweddevelopment; originalimmutableproof preserved, correctedv2permits
componentcostonly. Numerics unchanged; oldgenericindexcopiesunmeasured/no
claimtotalH2Dsaving. Component3ABBAoriginalquery/GPUquery preregistered5%median,
p95/TTFTguards. OrdinaryLRU latency guard stillrequiredbeforeanyadoption;
no stoppedoldfullscanqualityretry. FullP0/P1/P2 staysopen.

### 2026-10-03 — GPU query read-index component gains24.61%

GPU76898 exits0,3ABBA16K50/warmup1,originalnativequery vsGPUreadindex query.
Median139.450897→105.133455ms,24.608979%/34.317442ms savings; p95142.704867→
108.065114ms,ratio.757263;TTFT2192.838767→2197.708821ms,ratio1.0022209;
5%primary andguards pass.300measuredforwards/arm,25quietbefore/afterGPU0PID
checks, exactfrozenquerypred/state/logicalcounters/KVbytes andownhooks release.
FullKVH2D5.825961984GB remains; metadata75.33312MBcandidate-onlyknown.
No totalH2D saving or ordinaryLRU/adoption claim. FreshordinaryLRU candidate
3ABBA preregistered2%median/p95 and10%TTFT guards nowrunning; failure stops
standalonefullquery expansion regardlesscomponentgain. FullP0/P1/P2 staysopen.

### 2026-10-03 — GPU query read-index ordinaryLRU guard fails

GPU59757 exits0,fresh3ABBA16K50/warmup1. Eacharm replays itsfrozenstate/
logicalcounters/predictions/nativeKVbytes;300measuredforwards/arm,25quietGPU0
before/afterPIDchecks andownhooksremoved. MedianLRU58.215176→GPUquery
105.361762ms,ratio1.809868; p9564.477327→108.279668ms,ratio1.679345;
bothfail2%guard. TTFT2219.274970→2227.665411ms,ratio1.0037807passes10%.
Stop standalonefullquery GPUindex candidatequality/timing/adoption. Valid
24.61%componentgain vsoriginalquery does notoverride ordinaryLRU guard.
283tests/source/CLIdefaultsunchanged; scientificPNG/PDF/CSV/hashmanifest saved.
Next inspect fusedranking/lowertraffic retrieval withGPU-generatedselectedrow
indices; fixed8pagecentroid andoriginalfullscan candidates remainstopped.
Full512MiB/actualfaithful-baseline matching, independentquality/physicalSTT and
P0/P1/P2 remainopen. Currentstatusdocs/log updated; all5ownedGPUjobs terminal.

### 2026-10-03 — Query phase summary localizes visible composition

Four new CPU parity cases pass and full suite passes287. Profiler annotations
unwrap to exact GPU-index selector AST. First native attempt39233 exits1 before
warmup: concurrent own pytest initialized CUDA; quiet gate rejected it. Both
handles terminal, original log/source retained. Isolated95431 exits1 after all
frozen-query preservation assertions but before saving phase statistics. New
report-retention driver42930 also exits1 at the same name-only count assertion,
but saves all raw observations first:14 rows =8 CPU phases +6 duplicate GPU
annotation spans. All CPU ranges count1600; five quiet observations, fixedquery
prediction/state/counter/KVbyte/call assertions, hook/index cleanup pass.
Initial metadata prose incorrectly said7 duplicate GPU spans; corrected in a
new SHA-linked scope record, with original retained. Installed PyTorch primary
source explains device-type grouping and zero CPU duration on non-CPU events.
New read-only summary verifier filters positive CPU-duration rows; no fifth
model run or favorable-metric retry. Chrome export did not execute and custom
native GPU-kernel attribution is incomplete; no complete trace or speed claim.
Visible composition15.886552ms/decode instrumented CPU range is largest27.71%
of8 phase ranges. Next preregister existing-visible-buffer reuse/cold-row-only
updates with alias/ownership/parity/resource/component/LRU gates. Original
standalone fullscan stop persists1.810×median/1.679×p95; KV5.826GB and separate
candidate index75.33MB unchanged. All owned jobs terminal; full P0/P1/P2 open.
Status docs updated; conditional estimate10–20 working days unchanged.

### 2026-10-03 — Visible cold-suffix reuse verified; LRU guard still fails

Mechanism preregistered: only composition block changes, preserving prepared
hot prefix and writing selected cold rows via index_select out. No ranking/Q/
reader/selection/metadata or ordinary CLI changes.19CPU tests and306suite pass.
GPU93567 exits0:12predictions/13logit-cache-counterframes/384KVchoices exactly
replay GPU-index query;384 candidate destinations keepidentity/offset/stride,
canonical hotKV and prefix unchanged, nativebytes/metadata match, canonicalCPU
reads0 and ownhooks/index cleanup pass. FreshGPU14872 exits0:16K50 frozenpred/
state/counters/nativebytes/calls/indexmetadata replay;1600 suffix updates,
active545.165527MiB vs547.487793MiB, reserved5089.491699MiB/pref18.627830784GB/
roundedhost256MiB unchanged; owned roots/index/hooks release. Complete512fails.
Python-only resource archive omitted3 native sources; initial verifier errored.
Added immutable source supplement matching BOTH measured runtime fingerprints
and frozen reference, preserving originalarchive/verifier; corrected v2 proof
passes without another GPU run. ComponentGPU61187 exits0 quiet3ABBA:median
105.319777→97.051275ms,7.850854%/8.268502ms saved, p95108.207866→99.878384ms,
TTFT2200.487232→2207.972965ms(+0.3402%). Primary5%/4ms andguards pass;300
measuredforwards/arm,25quietchecks, allpred/state/counter/bytes/calls/metadata
replay andownhooks release. FreshordinaryLRU guardGPU75748 exits0:median
57.867588→97.564524ms ratio1.685996, p9564.513261→100.591419ms ratio1.559236;
bothfail2%. TTFT2226.346664→2236.684287ms(+0.4643%) passes10%. Same300
measuredforwards/arm,25quietchecks,frozenarmreplays/nativecalls/hookcleanup.
Stop standalone suffix fullquery expansion/adoption despitecomponentgain.
ScientificPNG/PDF/CSV/manifest saved and visually checked. NativeKVH2D
5.825961984GB plus75.33312MBindex metadata remainunchanged; no totalH2D
saving, independentquality, physicalSTT/full512MiB/adoption claim. Next
preregister keys-only ranking reads and selected-value reads, unchanged Q/rank
math and appropriate parity/resource/cost gates. Full P0/P1/P2 staysopen;
conditional estimate10–20 working days. All4ownGPUjobs terminal; status updated.

| 2026-10-03 11:29 IST | QUERY-CHANNEL-READS-V1 (completed, primary failed) | Exact full cold-key scan plus selected values reduces copied payload without changing ranking. | 328 tests; GPU4K12 exact12pred/13frames/384choices/ownership; fresh16K50 H2D5.826→3.173GB (−45.53%), D2H/indexmetadata unchanged; active545.17MiB >512. Quiet3ABBA97.48→93.02ms (4.57%,4.46ms); p95−4.57%, TTFT+0.05%;300 forwards/arm,25 quiet checks. | >=5% primary fails: stop standalone expansion/adoption before ordinaryLRU/quality. All owned jobs terminal; source/failed-build/scope-correction lineage retained. [Proof](results/hardware/query_channel_reads_v1/verified_cost.json), [figure](results/hardware/query_channel_reads_v1/channel_tradeoff.pdf). |

| 2026-10-03 11:51 IST | COMPLETION-CRITICAL-PATH-V1 | Audit true remaining requirements and localize current ordinary backend cost. | Full512MiB/actualmatching/faithfulspeed/independentquality remain failed or incomplete; physicalSTT external. OrdinaryGPU0 16K50 frozenpred/state/counters/H2D315.62MB/D2H117.57MB/calls76/57 replay;967049 policy calls,1.920s instrumented; eviction/demotion11.48ms/decode, overlapping readprep11.10/visibility9.94, nativegather0.76. Reporting fieldpath failure preserved and diagnostic-only corrected run passes. | Withdraw unsupported repeated10–20day forecast. Prioritize structural ordinary bookkeeping; no claimed speedup. All owned jobs terminal; [audit](results/hardware/completion_critical_path_v1/verified_audit.json). |

| 2026-10-03 12:04 IST | BATCHED-EVICTION-PROJECTION-V1 (screen failed) | Prepare score/age victim projections once across layers, reuse original stable selection/fallback and ordinaryBulk caches. | 19focused/347suite pass;6GPU exact cases (ragged/nonfinite/grace,1/4/32append); charged3ABBA median3.419→2.686ms saves0.733ms<4ms; p953.502→5.831ms (1.665×) failsguard;25quietchecks; all3medians improve. | Stop projection-only candidate before fullmodel/resource/quality expansion. All owned jobs terminal; ordinarysource/CLI/defaults unchanged. [Proof](results/hardware/batched_eviction_projection_v1/verified_stage.json). |

| 2026-10-03 12:16 IST | CPU-LRU-METADATA-V1 (primary failed) | Movecoldtimestamps toCPU; preserveoriginalGPU unstablevisibilityties with oneboundarysnapshot. | 11focused/358suite;GPU4K12 exact12pred/13stateframes/nativeKVtraffic/counters;8GPUtiecases. Fresh16K50 exactfrozenstate/pred/traffic; metadataH2D5.692MB/D2H0.1046MB, CPUtensorpeak229632bytes; active541.19MiB>512. Quiet3ABBA57.85→57.34ms (0.88%,0.51ms) fails5%/4ms; p9564.46→61.51ms/TTFT+0.09% pass;300forwards/arm,25quietchecks. | Stop standaloneexpansion/adoption; all ownedjobs terminal. No widergeneration/quality/favorabletimingretry. [Proof](results/hardware/cpu_lru_metadata_v1/verified_cost.json), [figure](results/hardware/cpu_lru_metadata_v1/timestamp_tradeoff.pdf). |

## 3 October: shared decode ownership resource milestone

**Shared ownership milestone (3 October):** **385 tests pass**, including 11 focused
unified-transition checks. The GPU 4K/12-step pair matches all predictions,
13 cache/visibility-state frames, counters and native KV traffic. Fresh 16K/50
matches the frozen ordinary predictions, final state, counters and transfers.
Unified model append, promotion and immediate compaction share consumed buffers.
Scoped active memory falls **541.08 to 415.16 MiB (23.27%)**, passing both the
512 MiB ceiling and 10% reduction gate. This includes the owned 256 MiB pinned
allocator block; it excludes constant model storage and unowned process memory.
Whole reserved envelope remains 5089.49 MiB; prefill peak remains 18.62783 GB.
[Resource proof](results/hardware/shared_decode_transition_v1/verified_resource.json).

The standalone append reservation was stopped at **531.00 MiB**, below neither
512 MiB nor a 10% reduction. Its failure is preserved separately.
[Standalone stop](results/hardware/reserved_decode_append_v1/verified_resource.json).
Quiet 3ABBA timing is complete: median decode **58.84 to 64.13 ms (8.98%
slower, 5.28 ms added)**; p95 **64.55 to 69.32 ms (7.38% worse)**. TTFT +0.78%
passes. All 300 measured forwards per arm replay predictions, final state,
counters and native KV transfers; 25 quiet GPU0 observations pass. **Stop
unified-transition expansion/adoption:** both speed primaries and the p95 guard
fail. No favorable timing retry or wider quality/baseline run for this failed
candidate. [Timing proof](results/hardware/shared_decode_transition_v1/verified_cost.json),
[measured tradeoff](results/hardware/shared_decode_transition_v1/ownership_tradeoff.pdf).
All owned jobs are terminal; leases, hooks and pinned roots release.

The memory obstacle is resolved only for this experimental design and measured
scope. The joint memory/latency/quality acceptance gate remains open. Next
localize the added cost of consumed-buffer compaction before proposing another
mechanism; do not widen this failed implementation. Independent quality, current
faithful baselines and physical hardware evidence remain open. Full P0/P1/P2
is incomplete; the unsupported 10–20-day forecast remains withdrawn.


## 3 October: paired shared-transition regression localization

**Current regression diagnostic (3 October):** fresh paired GPU0 policy profiles
preserve all 50 predictions, final state, counters and native transfers in each
arm. Shared ownership performs **1600 per-layer in-place gathers**; ordinary
bulk performs **50 batched native gathers**. Instrumented compaction is
6.76 ms/decode versus 3.12 ms for ordinary compaction preparation; ordinary
native gathering adds 0.75 ms in its visibility boundary. Shared reservation
and hot extension also add validation/copy work. These overlapping profile
ranges are localization evidence, not a causal savings estimate or timing gate.

The code trace establishes the ordering constraint: after demotion, cold
reclaim requires compacted hot positions and scores; it does not read compacted
hot KV. A distinct ownership implementation could defer payload gathering with
bounded, alias-safe scratch. However, the ordinary controller still spends
instrumented time in preparation (10.96 ms), eviction (11.75 ms) and visibility
(9.86 ms); these ranges overlap and cannot be added as savings. Nearly one
million calls per 50 steps remain. Removing this regression alone would not
prove the required speed win or close the faithful-baseline gap.
[Verified diagnostic](results/hardware/shared_transition_diagnostic_v1/verified_diagnostic.json).

Next target is broader controller consolidation, with a preregistered complete
mechanism and actual whole-loop/resource/quality gates. Do not repeat the failed
shared implementation or promote a profile as a benchmark. All owned jobs are
terminal; production defaults are unchanged. Full P0/P1/P2 remains incomplete;
the unsupported day estimate remains withdrawn.


## 3 October: bounded deferred ownership tested and stopped

**Bounded deferred ownership checkpoint (3 October):** **401 tests pass**,
including 16 focused checks. A distinct research transition defers compaction
when cold reclamation is unnecessary; overflow preserves immediate compaction.
Two passes of the existing verified native kernel gather to separate scratch
and copy back safely. Groups contain at most eight layers. GPU 4K/12 matches
all 12 predictions, 13 cache/visibility frames, counters and native KV traffic.
There are 384 deferred compactions in 48 groups, no immediate compactions or
append fallbacks, and scratch is bounded at **30.97 MiB**. Fresh 16K/50 exactly replays frozen predictions, final state, counters and
transfers. Scoped active memory is **432.12 MiB**, **20.14% lower** than ordinary
541.08 MiB, passing both the 512 MiB ceiling and 10% reduction gate. Prefill
peak is unchanged. Quiet 3ABBA is complete: median **58.33 to 63.09 ms (8.15% slower)**,
p95 **64.77 to 70.88 ms (9.43% worse)**; TTFT +0.36% passes. All 300 measured
forwards per arm exactly replay predictions, state, counters and native KV
traffic; 25 quiet GPU0 process checks pass. **Stop bounded deferred ownership
expansion/adoption:** speed primaries and p95 fail. No favorable timing retry.
[Timing decision](results/hardware/bounded_deferred_ownership_v1/verified_cost.json).

Reporting correction: the copied timing verifier's zero extra metadata scalar
is false. The native wrapper uploads descriptors: fixed geometry/source derives
**12.864 MB and 1200 upload calls per measured candidate trial**. These are
separate from native KV manager bytes/calls; total extra versus ordinary was
not independently instrumented. Timing and memory charge the descriptor work.
The original artifact remains retained and the failed decision is unchanged.
[Correction](results/hardware/bounded_deferred_ownership_v1/verified_descriptor_reporting_v2.json).
All owned jobs are terminal; hooks, instance methods and pinned roots release. Failed predecessors remain
stopped. [Correctness](results/hardware/bounded_deferred_ownership_v1/verified_correctness.json).
Next target is broader controller consolidation; bounded grouping alone has
failed to deliver a joint win. Do not expand this failed implementation. Production defaults are
unchanged; full P0/P1/P2 remains incomplete and the day estimate is withdrawn.


## 3 October: native controller tested and stopped

**Native controller prototype (3 October):** **437 tests pass**, including
36 focused native core/integration checks. A native CPU module, built with
existing Torch headers and system g++, computes cross-layer promotion plans,
hysteresis/live-floor transitions, backup classification and read addresses.
The research policy also groups timestamp ranking by identical live length,
using the verified fused gather and original unstable CUDA argsort. Grouped
sorting matches separate GPU sorting in 44 fixtures, including ties/nonfinite
values. No process-global patch, retention change or new dependency is used.

The recorded 4K/12-step GPU pair preserves all predictions, 13 cache/visibility
frames, counters and native KV transfers. There are 12 native plans, 384 backup
classifications, 25 address calculations and no planning fallback. Fresh
16K/50 matches all predictions, final state, counters and native KV traffic.
Scoped active memory is **432.12 MiB** versus ordinary 541.08 MiB (20.14% less),
passing the 512 MiB ceiling; with conservative CPU array roots it is432.29 MiB.
Prefill peak is unchanged; C++/Python allocator internals remain unmeasured.
Timestamp rank descriptors upload **5.555 MB** per measured trial; bounded
ownership descriptors derive12.864 MB. These are separate from native KV and
are charged by timing/GPU peaks. Quiet3ABBA is complete: median **57.92 to 62.80 ms (8.43% slower, 4.88 ms
added)**; p95 **64.38 to 66.79 ms (3.74% worse)**. TTFT +0.25% passes. All
300 measured forwards per arm replay frozen predictions, final state, counters
and native KV traffic; all25 quietGPU0 observations pass. **Stop native
controller expansion/adoption:** both speed primaries and p95 fail. No favorable
timing retry or wider quality/baseline expansion for this implementation.
[Timing decision](results/hardware/native_controller_v1/verified_cost.json).
All owned jobs are terminal; hooks, leases, methods and pinned roots release.

The native core proves promotion, backup and address calculations, not the full
controller gate. Promotion/address/ranking are grouped; backup classification
still enters native code once per layer. Complete transition pooling remains
unimplemented. Combining wrappers around the existing layer state has failed
the joint gate; the next mechanism must redesign the complete hot/cold state
layout and account for retention/quality, rather than expand these wrappers. Descriptor uploads and CPU arrays
must be reported separately from native KV transfers. Failed ownership-only
candidates remain stopped; production defaults are unchanged. Full P0/P1/P2
remains incomplete; the unsupported day estimate stays withdrawn.


## 3 October: fixed pooled GPU state primitives verified

**Pooled state primitive checkpoint (3 October):** **450 tests pass**, including
13 focused owner/bounds/alias checks. A distinct GPU transition uses shared
fixed owners for hot cumulative scores/ages and cold timestamps. One GPU prepare
operation increments old/promoted ages and initializes promoted/new metadata.
Compaction gathers KV and F32 metadata to bounded scratch, then scatters safely
into consumed KV and the original metadata owner.

Five GPU fixtures preserve exact BF16 payload and F32 bits, logical views,
owner roots and padding. They include32-layer preparation, eight-layer KV
compaction and a worker stream with explicit source dependency. Two malformed
native descriptor guards pass. The declared32-layer metadata owner is
**417792 bytes (0.398 MiB)**; bounded eight-layer scratch is **32536512 bytes
(31.03 MiB)**. Descriptor uploads are384 bytes for32-layer preparation and
32192 bytes for the measured eight-layer991-row compaction group.
[Primitive proof](results/hardware/pooled_state_transition_v1/verified_stage.json).

**Controller integration remains incomplete.** Primitive sizes are not a
full-model memory peak; no whole-loop speed, quality, faithful-baseline or
physical hardware claim is established. Next integrate the owners and fused
operations while preserving cold reclaim/fallback order, then run recorded
model parity, actual resource and preregistered timing gates. Failed controller
wrappers remain stopped; production defaults are unchanged. All owned jobs
are terminal. Full P0/P1/P2 remains incomplete; day estimate stays withdrawn.


**Pooled controller integration checkpoint (3 October):** **459 tests pass**.
The research controller now uses fixed GPU metadata owners, fused age/tail
preparation and bounded KV/F32 compaction. Recorded 4K/12 preserves all
predictions, 13 visibility/state frames, counters and native KV traffic;
12 pooled preparations and 48 compaction groups execute with no fallback.
Fresh 16K/50 also matches frozen predictions/state/counters/native KV.
Scoped active memory is **432.10 MiB** versus ordinary541.08 MiB (20.14% less);
with conservative CPU array roots it is432.27 MiB, below512 MiB. The417792-byte
GPU arena and descriptor work are charged by GPU peaks. Pooled descriptors
upload6457600 logical bytes per50-step trial, separately from KV traffic and
5555328 timestamp-rank descriptor bytes. Prefill peak is unchanged.

[Correctness proof](results/hardware/pooled_controller_v1/verified_correctness.json),
[resource proof](results/hardware/pooled_controller_v1/verified_resource.json).
Quiet3ABBA is complete: median **58.06 to61.54 ms (6.00% slower,3.48 ms
added)**. Both speed primaries fail; p95 +0.67% and TTFT +0.87% pass. All300
measured forwards per arm replay frozen predictions/state/counters/native KV;
all25 quietGPU0 observations pass. **Stop pooled controller expansion/adoption.**
No favorable timing retry or wider quality/baseline expansion for this candidate.
[Timing decision](results/hardware/pooled_controller_v1/verified_cost.json).
All owned jobs are terminal and hooks/leases/pinned roots release. Production
defaults are unchanged. Full P0/P1/P2 remains incomplete; day estimate is
withdrawn. Primitive proof remains historical component evidence, not full
model proof. Two failed startup attempts are retained, including the corrected
generated-helper name collision; neither measured candidate timing.


**CPU transition diagnostic and corpus (3 October):** Both fresh policy
profiles preserve all50 frozen predictions, final state, counters and native KV.
The0.836-second first extension load is already excluded by benchmark warmup;
it does not reverse the pooled controller's failed speed decision. Native
backup classification costs3.009 inclusive instrumented ms/step across1600
calls. Isolated backup batching is not justified as a4ms whole-loop fix.
Broader CPU state-transition work is the next mechanism, not another wrapper.

A recorded ordinary GPU run freezes **1600 layer transitions**. Independent
CPU/F32/slot replay is exact:2560 paid rows,23872 restored backups and1600
queued compactions. Positions, flags/streaks, metadata bits, logical/free slots
and outcomes match. The native backup classifier matches every record. This
corpus supports CPU-stage validation without repeated model launches per edit.
Cold occupancy reaches897/1090; no overflow occurs. Saturation/reclaim and
broader malformed/ragged/nonfinite fixtures remain mandatory.

[Diagnostic](results/hardware/pooled_controller_diagnostic_v1/verified_diagnostic.json),
[corpus](results/hardware/controller_transition_corpus_v1/verified_corpus.json),
[next phase plan](results/hardware/cpu_state_transition_v1/plan.json).
**Full CPU state-transition redesign is not implemented yet.** Existing459
unit tests remain passing; this checkpoint adds executable replay evidence,
not a speed/quality/adoption claim. All owned jobs are terminal; wrappers,
hooks and pinned roots release. Production defaults and failed-candidate
stops remain unchanged. Full P0/P1/P2 remains incomplete; day estimate withdrawn.


**Native CPU state phase checkpoint (3 October):** **489 tests pass**, including
30 focused phase checks. Fixed shared CPU owners hold hot/cold positions,
grace, shadow/resident flags, streaks and logical/free slot order. Native batch
operations perform promotion, hot append, complete demotion metadata updates
and cold compaction/reclaim. All malformed batch inputs reject before any
layer mutates; version and owner checks reject stale/foreign GPU commands.

All **1600 recorded layer transitions** replay exactly in50 native batches,
including2560 paid rows,23872 restored backups, F32 metadata commands and
physical slot order. Five GPU handoff fixtures across20 layers match original
cache payload/metadata bits, roots and padding: shadow-first reclaim, stable
LRU overflow, live-floor cover, exclusive promotion and eight-layer compaction.
Victim/cold-keep decisions are supplied; these fixtures do not independently
prove retention selection. GPU slot tensors emulate storage, not native host
transfers. Declared32-layer CPU owners are **1116896 bytes (1.065 MiB)**;
container/output/Python workspace and whole-model peaks remain unmeasured.

[Phase proof](results/hardware/cpu_state_transition_v1/verified_stage.json).
**Decode-controller integration remains incomplete.** Next attach canonical
CPU owners and consume these commands through promotion, demotion, native KV
transfers, visibility and cold reclaim, preserving unsupported fallback; then
run recorded model parity, actual resource and preregistered speed gates.
No speed/quality/adoption claim is established. All owned jobs are terminal;
production defaults and failed-candidate stops remain unchanged. Full P0/P1/P2
remains incomplete; day estimate withdrawn.


**Current checkpoint — early shared prefill (3 October):** 501 tests pass. Tiny GPU full-logit/KV parity and partial-failure cleanup pass; full-model4K/12 and16K/50 preserve predictions, state, counters and native transfers with all32 early roots and no fallback. Whole-prefill peak falls11.22% to16.5376GB; strict decode GPU active falls5.47%, scoped active including owned pinned/CPU is378.60MiB. Faithful Snap prefill ratio0.9840 passes. [Resource proof](results/hardware/early_shared_cpu_phase_v1/verified_resources.json). Initial resident KV matches341MiB at hot649/cold1982; candidate remains341MiB while Snap grows341–366MiB. Full-trajectory equality remains unresolved. Faithful-baseline quiet3ABBA timing **fails**: CPU54.59 vs Snap25.25ms/token (2.162x), p95CPU59.94 vs Snap25.47ms. TTFT+7.73% and prefill guards pass; median and p95 fail. All300 measured forwards/arm reproduce frozen predictions/state; CPU counters/native transfers and25 quiet observations pass. [Timing proof](results/hardware/early_shared_cpu_phase_v1/verified_cost.json), [figures](results/hardware/early_shared_cpu_phase_v1/figures/manifest.json). Candidate expansion/adoption stops under the preregistered gate; no favorable retry or final-holdout tuning. All owned jobs are terminal. Physical controller measurements, independent quality, generality and final delivery remain open. Repeated10–20day estimate withdrawn; full goal incomplete.


**CPU phase attribution diagnostic (3 October):** Existing full-loop data isolates29.80ms required policy work while CPU/Snapforwardmedians24.79/25.11ms match approximately. Frozen current649/1982CPUphase16K50 replay under cProfile; no selector/state/default change. Exact predictions/state/counters/nativeKV and cleanup required. Instrumented costs rank hypotheses only; no new gain/adoption claim. Plan: `results/hardware/cpu_phase_policy_profile_v1/plan.json`.

**Score stage optimistic ceiling (3 October):** Before implementation, current CPUphase-property/pooledGPU scorestage is charged against zero work at32layers/hot649or991/cold1982or1090/exposed32. ThreeABBAblocks,4warmup/20measured perrow. Require>=4ms possible saving before score-only development; zero-work never a candidate. Positive/zero/sparse metadata and attention-map exact parity required. Plan `results/hardware/score_stage_ceiling_v1/plan.json`.

**Bulk GPU payload phase (3 October):** Preregistered bounded group8 executor merges kept/paid KV gathering, exact new-token conversion, F32metadata gather, timestamp touch and hot scatter. Same CPU ownership/selection/transfers remain outside. Malformed-input-before-mutation, full bit parity including65536BF16patterns and charged32layer3ABBA>=4ms/p95 guards required before any model integration. Plan `results/hardware/bulk_payload_phase_v1/plan.json`.

**Bulk payload outcome (3 October):**503tests,4GPUbitparitycases including65536BF16patterns,6atomicrejections pass. Empty-hot/null-data-pointer boundary detected before model integration and rejected; original sources/runs preserved. Corrected same3ABBA cases save7.6217/8.0601/7.6332ms, p95 improves; advance to separately preregistered model integration. No model/default/fullmemory/quality/physicalSTT claim. Proof `results/hardware/bulk_payload_phase_v1/verified_stage.json`.

**Bulk payload controller integration (3 October):** Checked group8GPUphase after unchangedCPUownership/selection; exactpacked paidKV sharednativeD2H queue. Promotioncopies remain charged. CPUregressions/fullsuite, tinyrealGPU fullparity/fallback/errorcleanup, fullmodel replay, freshmemory andquiet3ABBA>=4ms/5% gates required. No ordinarydefaults orfaithfulbaseline claim. Plan `results/hardware/bulk_payload_controller_v1/plan.json`.


**Bulk controller completed checkpoint:**512tests, scoped402.47MiB, sameCPUcontrol59.92→53.62ms (10.52%,6.30ms), p95/TTFTpass.8K31.5K/recycling307,700developmentgenerationsteps/12docs and3unsupportedboundaries pass. Allownedjobs terminal; fullscope and defaultsoff unchanged. Proof `results/hardware/bulk_payload_controller_v1/verified_checkpoint.json`.

**Fresh-process bulk headline reproduction / 2026-10-03T16:15:37.231491+00:00:** Preregister before driver creation/launch. Same frozen capacities/prompt/teachers/model/profiler and3ABBA;≥5% median gain AND≥4ms,p95≤2%worse,TTFT≤10%worse, perarm exact state/pred/counters/nativeKV,25quietchecks. Separate raw output/job/archive. A failure is reported and stops expansion; no favorable retry. Component reproduction only, no resource remeasurement or faithful-baseline/quality/full-goal claim. Plan `results/hardware/bulk_payload_reproduction_v1/cost_plan.json`.


**Fresh-process bulk reproduction outcome:**61.52→56.04ms,8.91%,5.48ms saved; p95−13.36%,TTFT−0.32%; all3ABBA gates,300 measured forwards/arm,25quietchecks andfrozenperarmreplay pass. Separate run, samecode/data/seed; notseparateinvestigator/fullheadline-baseline reproduction. `results/hardware/bulk_payload_reproduction_v1/verified_cost.json`.

**Warmed bulk policy attribution / 2026-10-03T16:21:47.492098+00:00:** Before driver creation, freeze current integrated reference. First16K50trial warms native/model; only second50step policy/scores profiled, no resource observer or statehash insideprofile. Require full frozenpred/state/counters/nativebytes/calls andcleanup. Diagnostic only; no favorable speed rerun. `results/hardware/bulk_payload_profile_v1/profile_plan.json`.


**Cold visibility optimistic screen / 2026-10-03T16:43:18.493339+00:00:** Real frozen current16K50 finalstate, fullcoldboundary includingranking/physicalH2D/visiblecomposition charged againstzero work in3ABBA,4warmup20measured/row. Require>=4ms potential beforecandidateimplementation. Cache/visiblebits/nativeCPUownersunchanged;exact4MiBH2D percurrentcall. Stationarydiagnostic,zeroworkneversemancticcandidate. `results/hardware/visibility_stage_ceiling_v1/screen_plan.json`.


**Warmed profile and visibility screen outcomes:** Exactcurrent16K50 profile after warmup excludescoldimports/resourceobservers;50policy+50scorecalls preservefrozenstate/pred/nativeKV. Stationary fullcoldboundary3ABBA:7.5171ms vszerowork0.0059ms,7.5112ms optimistic ceiling;120measuredcalls/arm,144chargednativeH2D/576MiB,cache/visiblebits/CPUownersunchanged andcleanup pass. This is potentialroom only. Next separately preregister boundednativecold-boundary prototype andrequireactual≥4ms beforemodelintegration. No newgain/adoption/fullgoalclaim. Allownedjobs terminal. `results/hardware/visibility_stage_ceiling_v1/verified_screen.json`.


**Native cold boundary / 2026-10-03T17:07:12.656597+00:00:** Preregister beforeimplementation. FixedGPUtimestamp gather + NumPy canonicalselectedposition/address planes + existingmappedH2D + nativecold-tail scatter; originalgroupedTorchargsort ties preserved. CPU/fullsuite, fullGPUvisible/meta/owners/selectedparity, malformedatomic/streamlifetime required. Fullcharged3ABBA4warm20measured perrow actual>=4ms AND>=5% median saving,p95<=2%worse beforemodelintegration. Failedprimary stopsmechanism, nofavorable retry. No quality/default changes. Plan `results/hardware/native_cold_boundary_v1/plan.json`.


**Native cold-boundary stage outcome:**516suite,4GPUcompletecache/metadata/selectioncases includingragged/tiedNaN andsmall exposure,3atomicrejections andnondefaultstreamhandoff pass. Fullcharged3ABBA saves6.49/6.14/4.87ms,p95improves;nativephysicalH2D bytes/calls unchanged. Advance onlynewmodelintegrationgates. `results/hardware/native_cold_boundary_v1/verified_stage.json`.

**Cold-boundary controller integration / 2026-10-03T17:35:06.575355+00:00:** Preregister beforeclass creation. Thin opt-in override onBulkPayloadPolicy; preflightunsupported usesoriginalvisiblepath. FullCPU suite,tinyGPUfullparity/multitoken/queuedcleanup,4K12/16K50 exact,prefill/GPUactive/reserved/ownedmemory/cleanup andsamecontrolquiet3ABBA≥5% AND≥4ms/p95/TTFT required. Failedgate stops expansion,no favorable retry; no policy/quality/default tuning. `results/hardware/cold_boundary_controller_v1/plan.json`.

Cold-boundary controller: exact full replay, late-H2D cleanup and scoped424.154MiB pass; preregister same-bulk-control quiet3ABBA whole-loop speed gate. No favorable retry on failure. Plan: results/hardware/cold_boundary_controller_v1/cost_plan.json


## Audit 2026-10-13 correctness remediation

Frozen initial source: results/audit_20261013/initial_source_manifest.json; 518 initial tests pass. Eight independently executable core correctness checks fail before fixes (core_before.json). Fix hot/cold capacity input validation, missed-hit hysteresis, multi-query per-forward score reduction, target-bearing prompts and versioned target-document identities. Bounded prefill remains experimental and requires absolute identity proof. These are correctness fixes, not performance candidates. Historical raw evidence is immutable; changed protocol/source requires new experiments. Cold-boundary frozen timing verified before edits: 49.1732→44.2350ms, 10.0424%, 4.9382ms saving, all original guards pass; mandatory stress not yet complete. Physical STT hardware is not required by clarified user scope: analytical simulations must be labeled and validated. Paper work paused by user until audit/fixes/improvement validation finish.


## Audit corrected-score reproduction v2
Independent review found H2O and adapted SnapKV real-score loss and cost-boundary errors after first current-protocol reproduction. Fixes now retain observations and score/KV alignment; attention bill uses actual forward hot/cold widths, summary uses storage precision, empty sketches cost zero. Previous development outputs preserved; their derived costs and affected baseline scores are superseded rather than relabeled. New source snapshot and exact same development sampling/config at results/audit_20261013/dev_reproduction_v2/plan.json and source.tar.gz. All five arms rerun under corrected code; no final holdout data is used. Paper remains paused.


## GQA-head residency architecture pilot
Actual-query prefill passed development +4.1646 points/cluster95%[0.4847,8.2478]. Independent architecture review verified per-KV-head packed attention/score-scale equivalence. New opt-in GroupedRetentionPolicy has no-drop tiny-model/logit/KV and head-specific identity tests; full suite555 passes. Quantitative six-row QA falsification gate registered before real model results, after initial CPU prototype proofs: results/audit_20261013/grouped_pilot/plan.json. Payload capacities fixed; metadata/repacking overhead not hidden. Reject/stop if gain<3 or any task mean loss>10. No claimed novelty/adoption/performance or final holdout use.
