"""Read live caching-host block capacity; no allocator replacement or mutation."""
import argparse
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
import sys
import torch
from provenance import atomic_json, runtime_identity


@lru_cache(maxsize=1)
def kernel():
    if str(torch.__version__)!='2.5.1+cu124' or sys.version_info[:2]!=(3,10):
        raise ValueError('HostBlock audit requires the inspected Torch2.5.1/Python3.10 ABI')
    from torch.utils.cpp_extension import load
    build=Path('/data/nishant/tieredkv_external/host_block_audit_build_20261002')
    build.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('MAX_JOBS','1')
    return load(name='tieredkv_host_block_audit_v1',sources=[str(Path(__file__).with_name('native_host_block.cpp'))],
        build_directory=str(build),with_cuda=True,extra_cflags=['-O0'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    root=Path(torch.__file__).resolve().parent/'include'
    paths=[Path(__file__),Path(__file__).with_name('native_host_block.cpp'),
        root/'ATen/core/CachingHostAllocator.h',root/'ATen/cuda/CachingHostAllocator.h']
    report=dict(passed=False,runtime=runtime_identity(),checks=[],source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    try:
        module=kernel();report['binary_sha256']=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
        for size in (1,31,32,33,151257088,276824064):
            tensor=torch.empty(size,dtype=torch.uint8,pin_memory=True)
            result=module.block_info(tensor)
            assert result['requested_storage_bytes']==size
            assert result['allocator_block_bytes']==1<<(size-1).bit_length()
            view=tensor[1:] if size>1 else tensor[:]
            assert module.block_info(view)==result
            report['checks'].append(dict(bytes=size,view_storage_alias_exact=True,**result))
            del tensor,view
            torch._C._host_emptyCache()
        try:module.block_info(torch.empty(16))
        except RuntimeError:report['nonpinned_rejection']=True
        else:raise AssertionError('Unpinned storage accepted')
        report.update(passed=True,limitations='Read-only private HostBlock ABI under inspected Torch2.5.1/Python3.10; validates pinned storage and allocator deleter before context read. Measures live root block capacity, not process-wide cached totals, RSS, GPU temporaries or physical STT.')
    except BaseException as error:
        report['error']=f'{type(error).__name__}: {error}';raise
    finally:atomic_json(args.output,report)


if __name__=='__main__':main()
