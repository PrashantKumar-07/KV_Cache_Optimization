"""Research-only packing of the original post-promotion metadata projection."""
import ast
import hashlib
import inspect
import textwrap
from types import SimpleNamespace
import torch
import probe_batched_eviction_selection as selection
from batched_eviction_policy import BatchedEvictionPolicy
from native_reuse_visible import NativeReusePolicy


def reference_projection(rows, n_new):
    result = []
    for cache, positions in rows:
        zeros = torch.zeros(n_new, device=cache.cfg.device, dtype=cache.cfg.dtype)
        result.append(SimpleNamespace(cfg=cache.cfg, sram_pos=positions,
            sram_cum=torch.cat((cache.sram_cum, zeros)),
            sram_age=torch.cat((cache.sram_age + 1, zeros)),
            sram_grace=torch.cat((cache.sram_grace, torch.zeros(n_new, dtype=torch.bool)))))
    return result


def packed_projection(rows, n_new):
    if not rows: return []
    caches = [cache for cache, _ in rows]
    first = caches[0]
    if not all(c.cfg.dtype == torch.float32 and c.cfg.device == first.cfg.device
               and c.sram_cum.ndim == c.sram_age.ndim == 1
               and c.sram_cum.shape == c.sram_age.shape == first.sram_cum.shape
               and c.sram_cum.dtype == c.sram_age.dtype == torch.float32
               and c.sram_cum.device == c.sram_age.device == first.sram_cum.device
               and c.sram_cum.device.type == 'cuda' for c in caches):
        return reference_projection(rows, n_new)
    zeros = torch.zeros((len(caches), n_new), device=first.cfg.device, dtype=first.cfg.dtype)
    cumulative = torch.cat((torch.stack([c.sram_cum for c in caches]), zeros), dim=1)
    age = torch.cat((torch.stack([c.sram_age for c in caches]) + 1, zeros), dim=1)
    return [SimpleNamespace(cfg=c.cfg, sram_pos=positions,
                sram_cum=cumulative[i], sram_age=age[i],
                sram_grace=torch.cat((c.sram_grace, torch.zeros(n_new, dtype=torch.bool))))
            for i, (c, positions) in enumerate(rows)]


def stack_or_pad(sequences, *, batch_first, padding_value=0):
    if batch_first and sequences and all(t.shape == sequences[0].shape
            and t.dtype == sequences[0].dtype and t.device == sequences[0].device for t in sequences):
        return torch.stack(sequences)
    return selection.pad_sequence(sequences, batch_first=batch_first, padding_value=padding_value)


def stacked_selector():
    tree = ast.parse(inspect.getsource(selection.batched_victims))
    original = ast.dump(tree, include_attributes=False)
    changed = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'pad_sequence':
            node.func.id = 'stack_or_pad'; changed.append(node)
    assert len(changed) == 4
    modified = ast.dump(tree, include_attributes=False)
    for node in changed: node.func.id = 'pad_sequence'
    assert ast.dump(tree, include_attributes=False) == original
    for node in changed: node.func.id = 'stack_or_pad'
    namespace = vars(selection).copy(); namespace['stack_or_pad'] = stack_or_pad
    exec(compile(ast.fix_missing_locations(tree), '<stacked-original-selection>', 'exec'), namespace)
    return namespace['batched_victims'], original, modified


STACKED_VICTIMS, CONTROL_SELECTION_AST, STACKED_SELECTION_AST = stacked_selector()


def projection_method():
    tree = ast.parse(textwrap.dedent(inspect.getsource(BatchedEvictionPolicy._prepare_decode_reads)))
    original = ast.dump(tree, include_attributes=False)
    function = tree.body[0]
    loop = next(n for n in function.body if isinstance(n, ast.For) and isinstance(n.target, ast.Tuple))
    assert isinstance(loop.body[-2], ast.Assign) and loop.body[-2].targets[0].id == 'zeros'
    assert ast.unparse(loop.body[-1]).startswith('projections.append(SimpleNamespace(')
    original_tail = loop.body[-2:]
    loop.body[-2:] = ast.parse('projections.append((cache, positions))').body
    index = function.body.index(loop) + 1
    addition = ast.parse('projections = packed_projection(projections, n_new)').body[0]
    function.body.insert(index, addition)
    # Preserve the original method's lexical super class after standalone compilation.
    supers = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'super']
    assert len(supers) == 1 and not supers[0].args
    supers[0].args = ast.parse('super(BatchedEvictionPolicy, self)', mode='eval').body.args
    modified = ast.dump(tree, include_attributes=False)
    supers[0].args = []; function.body.remove(addition); loop.body[-1:] = original_tail
    assert ast.dump(tree, include_attributes=False) == original
    loop.body[-2:] = ast.parse('projections.append((cache, positions))').body
    function.body.insert(index, addition)
    supers[0].args = ast.parse('super(BatchedEvictionPolicy, self)', mode='eval').body.args
    namespace = vars(__import__('batched_eviction_policy')).copy()
    namespace.update(packed_projection=packed_projection, batched_victims=STACKED_VICTIMS)
    exec(compile(ast.fix_missing_locations(tree), '<batched-original-projection>', 'exec'), namespace)
    return namespace['_prepare_decode_reads'], original, modified


PREPARE_PROJECTED, CONTROL_PREPARE_AST, BATCHED_PREPARE_AST = projection_method()


class ProjectedMetadataPolicy(NativeReusePolicy):
    _prepare_decode_reads = PREPARE_PROJECTED


def source_identity():
    return {name: hashlib.sha256(value.encode()).hexdigest() for name, value in (
        ('control_selection_ast', CONTROL_SELECTION_AST), ('stacked_selection_ast', STACKED_SELECTION_AST),
        ('control_prepare_ast', CONTROL_PREPARE_AST), ('batched_prepare_ast', BATCHED_PREPARE_AST))}
