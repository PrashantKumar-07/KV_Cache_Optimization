// Read-only, Torch-2.5-specific audit of a live CUDA caching-host allocation.
#include <torch/extension.h>
#include <ATen/cuda/CachingHostAllocator.h>

pybind11::dict block_info(const torch::Tensor& tensor) {
  TORCH_CHECK(tensor.device().is_cpu() && tensor.is_pinned(), "Expected pinned CPU storage");
  const auto& pointer = tensor.storage().data_ptr();
  // Validate the allocator's deleter before interpreting its private context.
  auto anchor = at::cuda::HostAlloc(1);
  TORCH_CHECK(pointer.get_deleter() == anchor.get_deleter() && pointer.get_context(),
              "Expected the installed CUDA caching-host allocator");
  auto* block = static_cast<at::HostBlock<c10::cuda::CUDAStream>*>(pointer.get_context());
  std::lock_guard<std::mutex> guard(block->mutex_);
  TORCH_CHECK(block->ptr_ == pointer.get() && block->allocated_ &&
              block->size_ >= tensor.storage().nbytes(), "Unexpected allocator context");
  pybind11::dict result;
  result["requested_storage_bytes"] = tensor.storage().nbytes();
  result["allocator_block_bytes"] = block->size_;
  result["allocated"] = block->allocated_;
  result["event_count"] = block->event_count_;
  return result;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, module) {
  module.def("block_info", &block_info);
}
