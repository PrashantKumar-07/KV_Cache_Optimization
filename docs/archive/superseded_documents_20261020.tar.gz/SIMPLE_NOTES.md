# TieredKV, explained simply

**Current checkpoint — early shared prefill (3 October):** 501 tests pass. Tiny GPU full-logit/KV parity and partial-failure cleanup pass; full-model4K/12 and16K/50 preserve predictions, state, counters and native transfers with all32 early roots and no fallback. Whole-prefill peak falls11.22% to16.5376GB; strict decode GPU active falls5.47%, scoped active including owned pinned/CPU is378.60MiB. Faithful Snap prefill ratio0.9840 passes. [Resource proof](results/hardware/early_shared_cpu_phase_v1/verified_resources.json). Initial resident KV matches341MiB at hot649/cold1982; candidate remains341MiB while Snap grows341–366MiB. Full-trajectory equality remains unresolved. Faithful-baseline quiet3ABBA timing **fails**: CPU54.59 vs Snap25.25ms/token (2.162x), p95CPU59.94 vs Snap25.47ms. TTFT+7.73% and prefill guards pass; median and p95 fail. All300 measured forwards/arm reproduce frozen predictions/state; CPU counters/native transfers and25 quiet observations pass. [Timing proof](results/hardware/early_shared_cpu_phase_v1/verified_cost.json), [figures](results/hardware/early_shared_cpu_phase_v1/figures/manifest.json). Candidate expansion/adoption stops under the preregistered gate; no favorable retry or final-holdout tuning. All owned jobs are terminal. Physical controller measurements, independent quality, generality and final delivery remain open. Repeated10–20day estimate withdrawn; full goal incomplete.

**CPU phase boundary and score-fallback checkpoint (3 October):** **498 tests pass**. Two reproduced regressions exposed a shared batched-score crash on multi-token attention. A single-query shape guard restores the ordinary scorer fallback. Real GPU appends of2/32 tokens preserve exact logits, KV data, metadata and slot order across7 boundaries, then return to native single-token phases. Transformers-owned lazy capture hooks are initialized before ownership checks; both failed harness attempts are preserved. [Fallback proof](results/hardware/cpu_phase_append_fallback_v1/verified_fallback.json).

Three full-model4K/50 checks preserve all predictions/state/counters/native KV: exclusive promotion24832 rows, floor-above-capacity protection, and50 write-aware fallback steps. Native cold reclaim executes1152 times. [Boundary proof](results/hardware/cpu_phase_boundaries_v1/verified_boundaries.json). Fresh current-source4K/12 parity also passes; current-source16K/50 resource and geometry proofs pass, scoped memory433.33 MiB. Fresh current-source3ABBA speed passes: **58.76 to54.12 ms median,7.89% gain/4.64 ms saved**, p95 improves8.87%, TTFT+1.37%. All300 measured predictions/arm, state/counters/native KV and25 quiet observations match. All owned jobs are terminal. The multi-query guard preserves existing ordinary scoring fallback; it does not redesign multi-query attention accumulation. [Current proof](results/hardware/cpu_phase_score_guard_v1/verified_status.json), [figures](results/hardware/cpu_phase_score_guard_v1/figures/manifest.json). Historical speed evidence below remains tied to its archived source.

The ownership audit confirms resident KV roots272.25 MiB constant across51 candidate boundaries versus faithful SnapKV487–512 MiB, growing0.5 MiB/step. Attention width1024 differs on49/50 steps. No fixed SnapKV prompt capacity can equal that constant allocation vector throughout decode. This is an unresolved comparison-design requirement, not permission to claim equality or pad allocations. [Geometry proof](results/hardware/cpu_phase_geometry_v1/verified_geometry.json). Full P0/P1/P2 remains open; no new day estimate.

**CPU phase controller integration (3 October):** **496 tests pass**, including seven integration checks. Native canonical CPU promotion, append and demotion are integrated with pooled GPU metadata and native KV transfers. Recorded 4K/12 matches all predictions, 13 state/visibility snapshots, counters and native KV traffic. All 384 layer transitions use the new CPU phases, with zero fallback. [Correctness proof](results/hardware/cpu_phase_controller_v1/verified_correctness.json).

Fresh 16K/50 matches frozen output/state/counters/native KV and passes scoped memory: **433.33 MiB including owned pinned and CPU array roots**, versus ordinary541.08 MiB. Prefill peak is unchanged. Quiet preregistered3ABBA speed gate **passes: 58.93 to54.09 ms median (8.22%,4.84 ms saved)**, p95 improves8.76%, TTFT+1.40%. All300 measured predictions/arm and frozen state/counters/native KV match;25 GPU quiet observations pass. Longer-context8K/31.5K teacher parity and forced cold256-row slot-recycling parity pass, each50 steps with native CPU phases and no fallback. Free-generation parity passes on all12 reused development documents across six tasks: exact tokens, scores, state, trajectory, counters and native KV. **597 native CPU phase steps/19104 layer transitions** execute with no fallback;174 additional native cold reclaims occur. All owned jobs are terminal. Joint faithful-baseline/quality gates remain open. Candidate remains research-only. Production defaults are unchanged. Full P0/P1/P2 remains incomplete; the unsupported day estimate is withdrawn. This checkpoint supersedes earlier statements that controller integration is unimplemented.

**Native CPU state phase checkpoint (3 October):** **489 tests pass**, including
30 focused phase checks. Fixed shared CPU owners hold hot/cold positions,
grace, shadow/resident flags, streaks and logical/free slot order. Native batch
operations perform promotion, hot append, complete demotion metadata updates
and cold compaction/reclaim. All malformed batch inputs reject before any
layer mutates; version and owner checks reject stale/foreign GPU commands.

All **1600 recorded layer transitions** replay exactly in50 native batches,
including2560 paid rows,23872 restored backups, F32 metadata commands and
physical slot order. Five GPU handoff fixtures across20 layers match original
cache payload/metadata bits, roots and padding: shadow-first reclaim, stable
LRU overflow, live-floor cover, exclusive promotion and eight-layer compaction.
Victim/cold-keep decisions are supplied; these fixtures do not independently
prove retention selection. GPU slot tensors emulate storage, not native host
transfers. Declared32-layer CPU owners are **1116896 bytes (1.065 MiB)**;
container/output/Python workspace and whole-model peaks remain unmeasured.

[Phase proof](results/hardware/cpu_state_transition_v1/verified_stage.json).
**Decode-controller integration remains incomplete.** Next attach canonical
CPU owners and consume these commands through promotion, demotion, native KV
transfers, visibility and cold reclaim, preserving unsupported fallback; then
run recorded model parity, actual resource and preregistered speed gates.
No speed/quality/adoption claim is established. All owned jobs are terminal;
production defaults and failed-candidate stops remain unchanged. Full P0/P1/P2
remains incomplete; day estimate withdrawn.

**CPU transition diagnostic and corpus (3 October):** Both fresh policy
profiles preserve all50 frozen predictions, final state, counters and native KV.
The0.836-second first extension load is already excluded by benchmark warmup;
it does not reverse the pooled controller's failed speed decision. Native
backup classification costs3.009 inclusive instrumented ms/step across1600
calls. Isolated backup batching is not justified as a4ms whole-loop fix.
Broader CPU state-transition work is the next mechanism, not another wrapper.

A recorded ordinary GPU run freezes **1600 layer transitions**. Independent
CPU/F32/slot replay is exact:2560 paid rows,23872 restored backups and1600
queued compactions. Positions, flags/streaks, metadata bits, logical/free slots
and outcomes match. The native backup classifier matches every record. This
corpus supports CPU-stage validation without repeated model launches per edit.
Cold occupancy reaches897/1090; no overflow occurs. Saturation/reclaim and
broader malformed/ragged/nonfinite fixtures remain mandatory.

[Diagnostic](results/hardware/pooled_controller_diagnostic_v1/verified_diagnostic.json),
[corpus](results/hardware/controller_transition_corpus_v1/verified_corpus.json),
[next phase plan](results/hardware/cpu_state_transition_v1/plan.json).
**Full CPU state-transition redesign is not implemented yet.** Existing459
unit tests remain passing; this checkpoint adds executable replay evidence,
not a speed/quality/adoption claim. All owned jobs are terminal; wrappers,
hooks and pinned roots release. Production defaults and failed-candidate
stops remain unchanged. Full P0/P1/P2 remains incomplete; day estimate withdrawn.

**Current pooled controller result:** 459 tests pass. Fixed GPU metadata
owners and fused transitions preserve 4K/12 and16K/50 recorded model behavior.
Scoped active memory is432.10 MiB (432.27 with CPU array bound), below512 MiB.
Quiet3ABBA median is58.06 to61.54 ms:6.00% slower. Both speed primaries fail;
p95 andTTFT pass. Stop expansion/adoption; no favorable timing retry.
All owned jobs are terminal. Full P0/P1/P2 remains incomplete; day estimate
withdrawn. Primitive/controller integration is now verified, but the combined
latency/memory/quality/faithful-baseline gate remains open.
[Evidence](results/hardware/pooled_controller_v1/README.md).

**Current native controller result:** 437 tests pass. Native promotion,
backup and address calculations preserve recorded model behavior. Scoped
active memory is432.12 MiB (432.29 with CPU array bound), but quiet3ABBA median
is57.92 to62.80 ms (8.43% slower), and p95 fails. Stop expansion/adoption.
All owned jobs are terminal. The complete controller/retention layout remains
open; wrapper consolidation has not closed the joint latency/memory/quality
gate. Full project incomplete; unsupported day estimate withdrawn.
[Evidence](results/hardware/native_controller_v1/README.md).

**Current bounded transition result:** 401 tests pass. Scoped active memory
is 432.12 MiB versus 541.08 MiB (20.14% less), but quiet 3ABBA median decode is
58.33 to 63.09 ms (8.15% slower), and p95 fails. Stop expansion/adoption.
Predictions, state, counters and native KV transfers match. All owned jobs are
terminal. Descriptor uploads are additional; the copied zero metadata scalar
is corrected in a separate artifact. Full project incomplete; day estimate
withdrawn. Next target: broader controller consolidation.
[Evidence and correction](results/hardware/bounded_deferred_ownership_v1/README.md).

**Current diagnostic:** the slowdown is localized to 1600 per-layer gathers
replacing 50 batched native gathers, plus shared-buffer checks/copies. Both
fresh GPU profiles preserve frozen behavior and release owned resources.
Controller consolidation remains the next target. The failed memory-only
design stays experimental. Full project incomplete; day estimate withdrawn.
[Diagnostic](results/hardware/shared_transition_diagnostic_v1/verified_diagnostic.json).

**Current measured progress:** 385 tests pass. Shared decode ownership cuts
scoped active memory from 541.08 to 415.16 MiB (23.27%), passing the 512 MiB gate.
Predictions, state, counters and transfers match on the frozen 50-step run.
Quiet 3ABBA median decode is 58.84 to 64.13 ms: 8.98% slower; p95 also fails.
Stop unified-transition expansion/adoption. All owned jobs are terminal.
The joint latency/memory/quality gate remains open. The unsupported 10–20-day
forecast remains withdrawn. Full project incomplete.
[Proof](results/hardware/shared_decode_transition_v1/verified_resource.json).

**Latest ordinary-backend test:** **358 tests pass**. CPU timestamp updates
with originalGPU tie sorting preserve model/cache behavior, but quiet3ABBA
improvesmedian only **0.88% / 0.51ms** (57.85→57.34ms), failingrequired5%/4ms.
**Stop standalone CPUtimestamp expansion/adoption.** Scopedmemory541.19MiB
still exceeds512MiB; extra metadatauploads5.692MB are charged. All owned jobs
are terminal. Broader transition/ownership restructuring remains; fullP0/P1/P2
open, unsupported10–20-day forecast withdrawn.
[Verified decision](results/hardware/cpu_lru_metadata_v1/verified_cost.json).

**Current critical-path diagnostic:** the GPU0 ordinary-bulk16K/50-step
profile replays every frozen prediction, finalcache, logicalcounter and native
payload/call total. All owned jobs are terminal; hooks and pinned roots release.
About967,000 policy calls take1.920s under instrumentation. Eviction/demotion
is11.48ms/decode; read preparation11.10ms and visibility9.94ms are overlapping
cumulative ranges, not additive speed estimates. Native visible gathering is
0.76ms/decode. Next preregister cross-layer eviction/demotion bookkeeping
consolidation on the ordinary backend and require preserved state/selection/
transfers plus whole-loop/resource gates. Fullquery derivatives remain stopped.
[Verified critical path](results/hardware/completion_critical_path_v1/verified_audit.json).

**Completion plan correction (3 October):** the repeated **10–20 days** estimate
is withdrawn; it was not recalculated from the remaining gates. Earlier
estimates below are historical and must not be treated as a current forecast.
[Critical-path audit](results/hardware/completion_critical_path_v1/audit.json)
separates failed research gates from incomplete deliverables and external hardware.
The existing ordinary CPU backend is541.08MiB versus528.74MiB SnapKV; both
exceed512MiB and attention widths differ on49/50steps. A frozen older faithful
latency study is60.56 versus25.83ms (2.34×); its independent quality comparison
also fails NI. These studies do not prove current bulk quality or a joint win.
PhysicalSTT/controller energy/endurance remains unavailable and unproven.

Execution priority: profile the current ordinary bulk/lastlogits backend with
frozen50-step state/prediction/payload replay; address one structural bottleneck
that can close a main memory/latency gate. Keep failed fullquery derivatives
stopped. Then verify actual resources before expanding independentquality and
baselines; prepare reproducibility/manuscript artifacts alongside those gates.
No full completion date is supported until the research and hardware gates resolve.

**Current result (3 October):** **328 tests pass**. Reading all cold keys but
only selected cold values preserves the model's predictions and cache state.
Copied K/V payload falls **45.53%** (5.826→3.173GB), but decode improves only
**4.57%** (97.48→93.02ms), below the required5%. **Stop standalone channel-reader
expansion/adoption.** Memory remains545.17MiB, above512MiB. All owned jobs are
terminal. PhysicalSTT, matched baselines and independentquality remain open;
estimate **10–20 working days**, conditional on hardware/research outcomes.
[Verified decision](results/hardware/query_channel_reads_v1/verified_cost.json),
[current status](PROJECT_STATUS.md). Older checkpoints below are historical.

**Latest ownership decision:** forward-owner release preserves all four
shared-budget pairs and 1,536 layer releases/restorations. Active decode
envelopes fall **3.29–3.86%**, below the 10% gate, and remain **518–521 MiB**.
The 4K diagnostic locates the peak during first pre-forward validation;
release then removes about128 MiB of live GPU allocation. Reject advancement.
Next investigate duplicate ownership at the compressed-prefill boundary.
**Current suite:227 tests pass.** [Verified decision](results/hardware/forward_owner_release_v1/verified_report.json).

**Latest memory decision:** the isolated raw-input-reuse prototype preserves
all four shared-budget context pairs, but decode active envelopes stay about
**539 MiB**; every 10% memory primary fails. A 4K phase audit confirms
384 bindings/compactions and about128 MiB released after forward. The peak is
already reached during forward (step2), so post-forward reuse is insufficient.
Stop before usual-budget/timing/generation/CLI expansion. **Suite at that milestone:
217 tests passed.** [Verified rejection](results/hardware/raw_input_reuse_screen_v1/verified_report.json).

**Latest verified diagnosis:** 3,072 layer checks across 4K/8K/16K/31.5K
and both capacities confirm the incoming raw KV already contains the exact hot
prefix and has room for actual promotions plus new tokens. All 16 rows replay
frozen outputs/state/counters/transfers; **206 tests passed at that milestone**. This supports an
isolated buffer-reuse prototype, not a memory gain or safe in-place mutation
claim. [Prefix/ownership proof](results/hardware/decode_prefix_audit_v1/verified_report.json).

**Latest screen decision:** charged per-token CUDA cache release is rejected.
It releases **104 MiB at the final boundary**, but lowers decode reserved
**peak by 0%**. The observed reserved envelope stays **519.74 MiB**, above
512 MiB. State, predictions, transfers and counters match; both host roots
release; **206 tests passed at that milestone**. Stop before timing/generation/CLI advancement.
[Verified decision](results/hardware/decode_reclaim_screen_v1/verified_report.json).

**Latest resource audit:** six GPU 0 processes are finished and independently
verified. Bulk/control outputs, cache state and fresh-process GPU peaks match.
Current ordinary paths exceed the 512 MiB target: allocated decode envelopes
are about **539 / 804 MiB** in the legacy caller and **1537 / 1800 MiB** in the
fresh caller. Both reserved scopes exceed 6 GiB. The fresh caller retains
1000 MiB of prefill logits through its first decode; model-only allocator slack
is just 3.49 MiB. These callers differ, so their difference is not a causal
saving. No new memory/default claim; [resource proof](results/hardware/bulk_resource_audit_v1/verified_report.json).

**Latest verified progress:** optional bulk promotion planning preserves the
model's state and outputs. At 16K it improves the same CPU backend by
**5.23% / 6.54%** at two cache capacities. Generation, lifetime, recycling and
ordinary evaluator checks pass; **206 tests passed at that milestone**. Add `--cpu-bulk-promotion`
to the existing native-reuse CPU options. Defaults stay unchanged.
Complete memory, quality, SnapKV speed and physical hardware goals remain open.
Estimate **10–20 working days**, conditional on research outcomes and hardware
access. [Current result and remaining work](PROJECT_STATUS.md).

**New to the project?** Read [START_HERE.md](START_HERE.md) first; it gives a
short explanation and defines the basic words. This page describes
what the current code does. You do not need to know computer architecture to
read it. For the current done/remaining checklist, open
[PROJECT_STATUS.md](PROJECT_STATUS.md). For exact code details, open
[explanation.md](explanation.md) after this page.

**A 15-minute reading path:** Read “The idea in one minute,” “Five basics,”
and “A small example” (about 7 minutes). Then read “Why the results are mixed”
(about 5 minutes). Finally, open [PROJECT_STATUS.md](PROJECT_STATUS.md) and
read only “Current state” and “Remaining work” (about 3 minutes). Stop there
for a first pass. Use the words table below whenever a term is new. The
detailed implementation guide is a reference, not required reading today.

**One sentence to remember:** TieredKV keeps a limited set of old tokens
available to the model and tests whether a backup copy can avoid writing the
same token to slow memory again. The current main program simulates that slow
memory on the GPU.

## The idea in one minute

A language model reads a prompt and then writes an answer one word-piece at a
time. To avoid rereading the whole prompt for every new piece, it saves small
pieces of information about earlier tokens. Those saved pieces are called the
**key–value cache**, or **KV cache**.

A long prompt creates a large KV cache. The fast memory attached to the graphics
processor (**GPU memory**, also called **VRAM**) is limited. TieredKV tries to
keep the most useful saved tokens in a small *fast* group and retain some other
tokens in a larger *slow* group. If a slow token becomes useful, the policy can
bring it back to the fast group. If both groups are full, some tokens are lost.

**The crucial reality:** in the normal evaluated program, both groups are
physically stored on the same GPU. “Slow STT-RAM” is currently a *model of a
future device*, not an installed device. An opt-in backend stores cold KV in ordinary CPU memory and batches transfers
and score updates. It improves speed over the same-placement GPU version,
but the corrected shared-ceiling comparison remains slower than SnapKV
(about 71 versus 26 ms/token). CPU DRAM is not physical STT-RAM.

## Five basics before the algorithm

1. **Token:** a small piece of text. A word may contain one or several tokens.
2. **Attention:** the model's way of using relevant earlier tokens when
   predicting the next token. Each model layer has its own saved keys and
   values for earlier tokens.
3. **Prefill:** the first pass over the prompt. The current default computes
   the complete prompt KV on the GPU *before* deciding what to retain.
4. **Decode:** the repeated steps that generate the answer. Each step uses
   saved KV, produces a new token, and adds new KV.
5. **Capacity:** the maximum number of saved tokens permitted in a group.
   The common experiment allows 1,024 fast tokens and up to 2,048 slow tokens
   *per layer*. These are controlled research budgets, not the GPU's full size.

A **layer** is one stage of the model. The model has many stages; each keeps
its own K/V. A **key** helps attention decide which earlier tokens matter.
A **value** carries the information attention uses from a chosen token. You
do not need the equations to follow the cache policy: think of each token as
having a paired K and V that must stay together.

**Three different things that can be easy to mix up:**

| Word in a result | What it tells us | What it does not tell us |
| --- | --- | --- |
| Logical fast/slow slots | How many token positions the *policy* allows in each group | How much physical GPU or CPU memory a run uses |
| Logical writes saved | How many slow-tier write events the policy avoids | How many writes an STT-RAM chip actually performs |
| Measured GPU memory | Memory used by this running program | Memory a future STT-RAM device would need |

## What actually happens

```text
Prompt arrives
  → model creates all prompt K/V on GPU
  → policy scores prompt tokens
  → some K/V goes into the fast group, some into the slow group, rest is dropped
  → model starts generating one token at a time
  → attention sees fast tokens plus at most 32 selected slow tokens
  → attention scores can make an exposed slow token eligible for promotion
  → new token enters fast group; an old fast token may be demoted
  → repeat
```

The policy always keeps a few tokens at the beginning (called **attention
sinks**) and a recent window in the fast group. It ranks other prompt tokens
using an approximate importance score. At generation time, it uses the
model's measured attention to update importance. Each model layer makes its
own placement decisions.

A slow token is **not automatically searched every step**. The code selects
up to 32 slow tokens to expose to attention, largely using their recorded
recent access. An unexposed token cannot gain new attention evidence in that
step. This helps explain why retaining a token does not guarantee that the
model will use it at the right time.

## A small example you can simulate

Imagine a toy fast group with room for 3 tokens and a slow group with room for
2. After scoring a six-token prompt, suppose the policy keeps tokens A, B, C
fast; D, E slow; and drops F. The actual program uses sink, recent-window and
importance rules to make this choice; these letters are only an illustration.

1. The next answer step attends to A, B, C and perhaps D. It cannot attend to
   E unless E is among the selected slow tokens. It can no longer use F.
2. Suppose the model pays high attention to D. On the following cache update,
   D can be **promoted** to the fast group. Because the fast group has a hard
   limit of 3, another token must leave it.
3. Suppose B leaves. B is **demoted** to the slow group. If the slow group is
   full, the policy first tries to remove a duplicate backup; otherwise a
   slow token must be dropped.
4. When D moved up, TieredKV may have kept its old slow copy as a **shadow**.
   If D later moves down again and that shadow still exists, the policy can
   reuse it without writing D's K/V a second time. This is the project's
   measured *logical write-saving* mechanism.

The code's exact ordering, tie rules and per-layer tensors are documented in
[explanation.md](explanation.md). The example above is for understanding, not
an experimental result.

## Why the results are mixed

| Question | What we know today |
| --- | --- |
| Does shadowing save writes? | **Yes, in the logical cache counter and an opt-in CPU copy test.** On one fixed 50-step input stream it recorded 2,690 writes with shadows versus 26,432 without (89.82% fewer). In ordinary CPU memory, explicit decode K/V copied from GPU fell from 108.27 MB to 11.02 MB. This does not measure STT-RAM hardware writes or device lifetime. |
| Is answer quality better than faithful SnapKV? | **Not proven.** Across 135 selected requests the difference was about −0.046 task-balanced points; the uncertainty interval spans both a loss and a gain. |
| Is it faster? | **No in the current comparison.** On one 16,000-token prompt and 50 generated tokens, TieredKV took 82.76 milliseconds per generated token versus 25.77 for SnapKV. |
| Does it reduce the highest GPU memory use? | **Not yet in the default path.** The full prompt KV is created before compression, so the measured prefill peak stayed about 18.59 GB in the 16K probe. |
| Does a real CPU tier work? | **Functionally, in a small opt-in test.** The same predictions and cache decisions were observed; final GPU allocation fell about 219 MB, but decoding slowed. CPU memory is not STT-RAM. |

“Task-balanced” means each tested task gets equal weight when scores are
averaged. It does not mean every individual example improved. The source
artifacts and limitations are linked from [PROJECT_STATUS.md](PROJECT_STATUS.md).

The speed result is **time per new token**. Lower is better: 82.76
milliseconds is slower than 25.77 milliseconds. The 89.82% write reduction
is a different measurement; saving writes did not make this program faster.

The quality number is a benchmark score, **not** the percentage of answers
that were correct. A difference near zero means the methods scored similarly
on this sample. The reported 95% interval includes both a TieredKV loss and
a gain, so the test has not settled which method is better. “3.21× slower”
refers to one specified speed test; it is not a universal speed ratio.

## What we still need before a strong paper claim

The priority is to make an actual second memory tier useful *after* counting
its transfer and policy costs. Then we need a fair comparison at comparable
real memory use and comparable attention work; quality checks on new documents
and another model; whole-request latency and throughput; and evidence about
physical traffic, energy and endurance. The complete checklist is in
[PROJECT_STATUS.md](PROJECT_STATUS.md). A date on a paper plan is not proof
that these results exist.

Another published method, [FlexiCache](https://proceedings.mlsys.org/paper_files/paper/2026/file/94bcb01789fccf15afe2764d8fe0f40e-Paper-Conference.pdf),
also keeps a CPU copy and avoids repeatedly sending the same saved page to
CPU memory. Our write-saving number is therefore an interesting result to
test further, not enough by itself to claim a new invention.

**A recent concrete failure:** One long question asked for five names.
TieredKV answered only three because the sentence listing all five had been
dropped from its saved cache in every model layer. Forcing that known sentence
to stay fixed this one answer, but a real system cannot know the answer in
advance. A method that searched for a useful sentence using only the question
looked promising on 24 questions, then failed to confirm the gain on 24 new
questions. It has **not** replaced the current method. This is why we test
new ideas on different documents before calling them improvements.

## Words and abbreviations

| Term | Plain meaning here |
| --- | --- |
| LLM | Large language model: the program generating text. |
| KV / KV cache | Saved **k**eys and **v**alues for earlier tokens, used by attention. |
| GPU | Graphics processing unit: runs most model calculations. |
| VRAM | Memory attached to the GPU; fast, but limited. |
| CPU DRAM | Ordinary system memory attached to the processor, used only in an opt-in cold-tier experiment. |
| STT-RAM | A real memory technology proposed as TieredKV's future slow tier. No such device is used in current model runs. |
| Hot / cold | A token currently kept in the fast / slow cache group. |
| Promotion / demotion | Moving a retained token from slow to fast / fast to slow. In the default runs these are moves between GPU tensors. |
| Shadow | An extra slow copy retained when a token is promoted, so a later demotion may reuse it. |
| Eviction / drop | Removing a token because capacity is full. Once dropped, this implementation cannot fetch it back. |
| bf16 | A two-byte number format used to store model K/V in the main comparison. |
| ITL / TPOT | Time per generated token during decoding; lower is faster. |
| TTFT | Time to the first generated token, including prompt processing. |
| p95 | A value at or below which 95% of measured cases fall; shows slow-tail behavior. |
| SOTA | “State of the art,” meaning the strongest published results; TieredKV has not established such a claim. |
| Baseline | Another method measured on the same task so we have something to compare against. |
| SnapKV | A published KV-cache method used as one of our comparison methods. |
| Logical write | A cache-policy counter saying that a K/V copy would be written to the slow group; it does not prove that physical memory hardware performed a write. |
| Paired comparison | The two methods answer the same test requests, so their scores can be compared request by request. |
| 95% interval | A range showing uncertainty in an estimated difference from the tested sample; if it crosses zero, this result alone does not establish a winner. |
| Attended width | How many stored token positions attention can use in a step. More positions can help quality but can add work. |
| Resident bytes | The actual memory occupied by stored K/V. Comparing equal token counts can still use unequal bytes. |

The previous, outdated version of these notes is preserved at
`results/archive/SIMPLE_NOTES_20260921.txt` for history. Do not use its old
scores or speed numbers as current evidence.
