#!/usr/bin/env python3
# longbench_eval.py — unified LongBench evaluation for TieredKV vs SOTA baselines
#
# FIXED VERSION: 
#   - TieredKVPolicy now ACTUALLY uses src/tiered_kv_cache.py (real promote/demote)
#   - H2O baseline fixed (proper score initialization, no degenerate behavior)
#   - Budget allocation is now memory-fair
#   - Hardcoded paths removed
#   - Quest baseline added
#
# Methods:
#   full          — no eviction (oracle upper bound)
#   streamingllm  — sinks + sliding window
#   h2o           — cumulative-attention heavy-hitter eviction
#   snapkv        — observation-window importance + H2O decode eviction
#   quest         — query-aware sparse attention (page-level sketching)
#   tieredkv      — our VRAM + STT-RAM victim cache (REAL implementation)
#
# All eviction methods use the same total KV budget for memory-fair comparison.
import os, sys, json, argparse, math, glob, hashlib, time
from pathlib import Path
import torch
from provenance import runtime_identity, atomic_json, read_jsonl, model_artifact_identity
import numpy as np

# Setup paths
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from tiered_kv_cache import TieredKVCache, TieredConfig
from attention import gqa_causal_importance, snapkv_importance
from metrics import StepRecord
from cost_model import CostModel

# Shared cost model for every non-TieredKV policy's modeled latency/energy
# (see generate_with_policy) -- TieredKV prices its own multi-tier moves
# through TieredKVCache's own CostModel instance instead.
_BASELINE_COST_MODEL = CostModel(bytes_per_elem=2)

# Use environment variable or default, no hardcoded personal paths
if "HF_HOME" not in os.environ:
    os.environ["HF_HOME"] = os.path.expanduser("~/.cache/huggingface")

from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM
from transformers.cache_utils import DynamicCache
from longbench_metrics import (
    DATASET_TO_METRIC, DATASET_TO_MAXGEN, DATASET_TO_PROMPT,
)

# ---------------------------------------------------------------------------
# DynamicCache helpers
# ---------------------------------------------------------------------------
def _get_layer_kv(layer):
    """Extract (k, v) tensors from a DynamicCache layer."""
    return layer.keys, layer.values

def to_tuple_kv(past_kv):
    """Convert DynamicCache or legacy tuple to tuple-of-(k,v) pairs."""
    if past_kv is None:
        return None
    if isinstance(past_kv, DynamicCache):
        return tuple(_get_layer_kv(layer) for layer in past_kv.layers)
    return tuple((k, v) for k, v in past_kv)

def apply_tuple_kv_inplace(past_kv, tuple_kv):
    """Write trimmed (k,v) pairs back into DynamicCache.layers in-place."""
    if isinstance(past_kv, DynamicCache):
        for i, (k, v) in enumerate(tuple_kv):
            past_kv.layers[i].keys = k
            past_kv.layers[i].values = v
    return past_kv

# ---------------------------------------------------------------------------
# Attention-implementation switching
# ---------------------------------------------------------------------------
from contextlib import contextmanager

def prefill_logit_kwargs(model, enabled=False):
    """Opt in only when the model explicitly supports native logit slicing."""
    if not enabled:
        return {}
    import inspect
    if "logits_to_keep" not in inspect.signature(model.forward).parameters:
        raise ValueError("--prefill-last-logits requires native forward(logits_to_keep=...)")
    return {"logits_to_keep": 1}

@contextmanager
def _attn_impl(model, impl):
    """Temporarily switch the model's attention implementation.

    H2O/SnapKV/TieredKV need output_attentions=True during DECODE, which only
    the eager path produces -- so the model is loaded as "eager". But eager
    materialises the full (batch, heads, q_len, k_len) score matrix, and at
    PREFILL q_len is the whole prompt: for a 31500-token document that is
    32 heads x 31500^2 x 2 bytes = 59.1 GiB in a single allocation, which OOMs
    on a 44.5 GiB L40S before the first layer finishes.

    Prefill never asks for attention weights (see generate_with_policy), so it
    can run under SDPA, which never materialises that matrix. Decode keeps
    eager, where q_len=1 makes the same tensor (1, heads, 1, k_len) -- a few
    hundred KB. The KV cache produced is identical either way; only the
    intermediate is avoided.
    """
    prev = model.config._attn_implementation
    model.config._attn_implementation = impl
    try:
        yield
    finally:
        model.config._attn_implementation = prev

# ---------------------------------------------------------------------------
# KV cache eviction policies
# Each policy receives tuple[(K, V)] per layer, K/V: (batch, heads, seq, dim)
# and returns a trimmed tuple[(K, V)].
# ---------------------------------------------------------------------------
class _ModeledCostMixin:
    """Shared modeled-latency/energy accumulator for the non-TieredKV
    policies. generate_with_policy measures each step's attended-token
    count off the KV tensor and prices it with baseline_attention_cost,
    so every method reports comparable modeled_latency_us/energy_nj.

    reset() folds the outgoing sample into the accumulator before
    clearing live counters; stats() reports accumulator + live. (An
    earlier version zeroed without folding and silently reported only
    the last sample — caught because identical latency across methods
    on one task is impossible when the formula only sees
    budget/heads/steps, never the policy.)
    Call _init_modeled_cost() once from __init__ (never
    reset_modeled_cost() there — nothing live exists yet to fold).
    """
    def _init_modeled_cost(self):
        self._modeled_accum_latency_us = 0.0
        self._modeled_accum_energy_nj = 0.0
        self._modeled_accum_steps = 0
        self._modeled_latency_us = 0.0
        self._modeled_energy_nj = 0.0
        self._modeled_steps = 0

    def reset_modeled_cost(self):
        self._modeled_accum_latency_us += self._modeled_latency_us
        self._modeled_accum_energy_nj += self._modeled_energy_nj
        self._modeled_accum_steps += self._modeled_steps
        self._modeled_latency_us = 0.0
        self._modeled_energy_nj = 0.0
        self._modeled_steps = 0

    def stats(self):
        return {
            "modeled_latency_us": round(self._modeled_accum_latency_us + self._modeled_latency_us, 1),
            "modeled_energy_nj": round(self._modeled_accum_energy_nj + self._modeled_energy_nj, 1),
            "decode_steps": self._modeled_accum_steps + self._modeled_steps,
        }


class FullCachePolicy(_ModeledCostMixin):
    """No eviction — oracle baseline."""
    name = "Full"
    def __init__(self):
        self._init_modeled_cost()

    def reset(self):
        self.reset_modeled_cost()

    def __call__(self, past_kv):
        return past_kv

class StreamingLLMPolicy(_ModeledCostMixin):
    """Sinks + sliding window. Intermediate tokens are permanently dropped.
    Ref: Xiao et al., "Efficient Streaming Language Models with Attention Sinks", ICLR 2024.
    """
    name = "StreamingLLM"
    def __init__(self, start_size=4, recent_size=60):
        self.start_size = start_size
        self.recent_size = recent_size
        self.cache_size = start_size + recent_size
        self._init_modeled_cost()

    def reset(self):
        self.reset_modeled_cost()

    def __call__(self, past_kv):
        if past_kv is None:
            return None
        seq_len = past_kv[0][0].size(2)
        if seq_len <= self.cache_size:
            return past_kv
        return tuple(
            (
                torch.cat([k[:, :, :self.start_size], 
                          k[:, :, seq_len - self.recent_size:]], dim=2),
                torch.cat([v[:, :, :self.start_size], 
                          v[:, :, seq_len - self.recent_size:]], dim=2),
            )
            for k, v in past_kv
        )

class H2OPolicy(_ModeledCostMixin):
    """Heavy-Hitter Oracle: evict lowest cumulative-attention token per step.

    FIXED:
    - Proper score initialization using attention from observation window
    - Sequential eviction (one token at a time, not bulk)
    - Scores are initialized BEFORE first eviction decision

    Ref: Zhang et al., "H2O: Heavy-Hitter Oracle for Efficient Generative
    Inference", NeurIPS 2023.
    """
    name = "H2O"
    def __init__(self, budget=64, start_size=4, recent_size=16):
        self.budget = budget
        self.start_size = start_size
        self.recent_size = recent_size
        self.cum_scores = {}  # layer -> Tensor(seq,)
        self.initialized = {}
        self._init_modeled_cost()

    def reset(self):
        self.cum_scores = {}
        self.initialized = {}
        self.reset_modeled_cost()
    
    def _initialize_scores(self, k, v, layer_idx):
        """Initialize cumulative scores using observation-window attention.
        
        This is called BEFORE the first eviction to ensure H2O makes
        informed decisions from the start, not random ones.
        """
        seq_len = k.size(2)
        w = min(self.recent_size, seq_len)
        
        # Use the last `w` tokens' keys as proxy for queries
        # (in a proper implementation, we'd capture actual Q values)
        q_win = k[:, :, seq_len - w:, :].float()  # (batch, heads, w, dim)
        k_float = k.float()  # (batch, heads, seq, dim)
        
        # Compute attention from observation window to all tokens
        scale = 1.0 / math.sqrt(k.size(-1))
        scores = torch.matmul(q_win, k_float.transpose(-2, -1)) * scale
        attn = torch.softmax(scores, dim=-1)
        
        # Sum attention received per token (average over window and heads)
        importance = attn.sum(dim=2).mean(dim=(0, 1))  # (seq,)
        
        # Keep on k's device -- eviction masks/indices below are built on
        # k.device, and everything here must stay on one device or index
        # ops crash (this used to force .cpu(), which crashed on GPU runs).
        self.cum_scores[layer_idx] = importance
        self.initialized[layer_idx] = True
    
    def update_scores(self, past_kv, attn_weights):
        """Accumulate attention mass from a single decode step.
        attn_weights: list of (batch, heads, 1, seq) tensors, one per layer.
        """
        if attn_weights is None:
            return
        for layer_idx, (k, v) in enumerate(past_kv):
            if layer_idx >= len(attn_weights) or attn_weights[layer_idx] is None:
                continue
            w = attn_weights[layer_idx]  # (batch, heads, 1, seq)
            seq_len = k.size(2)
            
            if layer_idx not in self.cum_scores:
                if seq_len > self.budget:
                    # Initialize the existing proxy prior BEFORE adding the
                    # first real observation (also used by adapted SnapKV).
                    self._initialize_scores(k, v, layer_idx)
                else:
                    self.cum_scores[layer_idx] = torch.zeros(seq_len,
                        device=w.device, dtype=torch.float32)
            
            cum = self.cum_scores[layer_idx]
            if cum.device != w.device:
                cum = cum.to(w.device)
            
            # Average attention over heads, sum over batch
            attn_sum = w.float().squeeze(2).mean(dim=(0, 1))
            if attn_sum.ndim == 2:
                attn_sum = attn_sum.mean(dim=0)
            attn_sum = attn_sum[:seq_len]
            
            # Extend cum if needed
            if cum.size(0) < seq_len:
                cum = torch.cat([cum, 
                    torch.zeros(seq_len - cum.size(0), 
                    device=cum.device, dtype=cum.dtype)])
            
            cum[:seq_len] += attn_sum
            self.cum_scores[layer_idx] = cum
            # Real incremental observations must survive first budget overflow.
            self.initialized[layer_idx] = True
    
    def __call__(self, past_kv):
        if past_kv is None:
            return None
        
        result = []
        for layer_idx, (k, v) in enumerate(past_kv):
            seq_len = k.size(2)
            if seq_len <= self.budget:
                result.append((k, v))
                continue
            
            # Initialize scores if not yet done (FIXED: was using zeros before)
            if layer_idx not in self.initialized:
                self._initialize_scores(k, v, layer_idx)
            
            cum = self.cum_scores[layer_idx]
            if cum.device != k.device:
                cum = cum.to(k.device)

            # Sync size
            if cum.size(0) < seq_len:
                cum = torch.cat([cum,
                    torch.zeros(seq_len - cum.size(0), device=cum.device, dtype=cum.dtype)])
            elif cum.size(0) > seq_len:
                cum = cum[:seq_len]

            # Build eviction scores: protected positions get +inf
            score = cum.clone()
            score[:self.start_size] = float("inf")
            score[max(0, seq_len - self.recent_size):] = float("inf")

            # FIXED: Evict tokens one at a time (sequential, like the paper)
            # This is more faithful to H2O than bulk topk eviction
            n_evict = seq_len - self.budget
            keep = torch.ones(seq_len, dtype=torch.bool, device=k.device)

            # Get unprotected indices sorted by score (lowest first)
            unprotected_mask = torch.ones(seq_len, dtype=torch.bool, device=k.device)
            unprotected_mask[:self.start_size] = False
            unprotected_mask[max(0, seq_len - self.recent_size):] = False
            
            unprotected_indices = torch.where(unprotected_mask)[0]
            unprotected_scores = score[unprotected_indices]
            
            # Sort by score (lowest = most likely to be evicted)
            sorted_indices = torch.argsort(unprotected_scores)
            
            # Evict the n_evict lowest-scoring unprotected tokens
            keep[unprotected_indices[sorted_indices[:n_evict]]] = False
            
            result.append((k[:, :, keep], v[:, :, keep]))
            self.cum_scores[layer_idx] = cum[keep]
        
        return tuple(result)

class SnapKVPolicy(_ModeledCostMixin):
    """SnapKV: compress prompt using observation-window importance, then H2O decode.

    Ref: Li et al., "SnapKV: LLM Knows What You are Looking for Before Generation",
    NeurIPS 2024.
    """
    name = "SnapKV"
    def __init__(self, budget=64, start_size=4, recent_size=16, pool_kernel=5):
        self.budget = budget
        self.start_size = start_size
        self.recent_size = recent_size
        self.pool_kernel = pool_kernel
        self.compressed = False
        self._h2o = H2OPolicy(budget=budget, start_size=start_size,
                              recent_size=recent_size)
        self._init_modeled_cost()

    def reset(self):
        self.compressed = False
        self._h2o.reset()
        self.reset_modeled_cost()

    def __call__(self, past_kv):
        if past_kv is None:
            return None
        seq_len = past_kv[0][0].size(2)
        if seq_len <= self.budget:
            return past_kv
        if not self.compressed:
            self.compressed = True
            return self._compress_prompt(past_kv)
        # Single-token decode step during generation
        if seq_len - self.budget == 1:
            return self._h2o(past_kv)
        # Multi-token chunk input (PPL evaluation or chunked prefill):
        # Apply SnapKV pooled observation-window compression
        return self._compress_prompt(past_kv)
    
    def update_scores(self, past_kv, attn_weights):
        """Delegate to internal H2O for decode-phase score updates."""
        self._h2o.update_scores(past_kv, attn_weights)
    
    def _compress_prompt(self, past_kv):
        result = []
        for layer_idx, (k, v) in enumerate(past_kv):
            seq_len = k.size(2)
            if seq_len <= self.budget:
                result.append((k, v))
                continue
            
            w = min(self.recent_size, seq_len)
            q_win = k[:, :, seq_len - w:, :].float()
            k_float = k.float()
            scale = 1.0 / math.sqrt(k.size(-1))
            
            scores = torch.matmul(q_win, k_float.transpose(-2, -1)) * scale
            attn = torch.softmax(scores, dim=-1)
            importance = attn.sum(dim=2).mean(dim=(0, 1))  # (seq,)
            
            if self.pool_kernel > 1 and seq_len >= self.pool_kernel:
                pad = self.pool_kernel // 2
                importance = torch.nn.functional.avg_pool1d(
                    importance.view(1, 1, -1).float(),
                    kernel_size=self.pool_kernel, stride=1, padding=pad
                ).view(-1)[:seq_len]
            
            sink_idx = set(range(min(self.start_size, seq_len)))
            win_idx = set(range(max(0, seq_len - w), seq_len))
            pinned = sink_idx | win_idx
            extra = max(0, self.budget - len(pinned))

            score = importance.clone()
            score[:min(self.start_size, seq_len)] = -float("inf")
            score[max(0, seq_len - w):] = -float("inf")

            if extra > 0:
                _, topk = torch.topk(score, k=min(extra, seq_len - len(pinned)))
                pinned_t = torch.tensor(sorted(pinned), device=k.device)
                all_idx = torch.cat([pinned_t, topk])
                idx_t, _ = torch.sort(all_idx)
            else:
                pinned_t = torch.tensor(sorted(pinned), device=k.device)
                idx_t, _ = torch.sort(pinned_t)

            result.append((k[:, :, idx_t], v[:, :, idx_t]))
            # Incremental/PPL observations refer to the uncompressed rows.
            # Preserve their identity when prompt/chunk compression reorders KV.
            previous = self._h2o.cum_scores.get(layer_idx)
            if previous is not None:
                previous = previous.to(k.device)
                if previous.numel() < seq_len:
                    previous = torch.cat((previous, previous.new_zeros(seq_len - previous.numel())))
                self._h2o.cum_scores[layer_idx] = previous[idx_t]
                self._h2o.initialized[layer_idx] = True
        
        return tuple(result)

class QuestPolicy:
    """UNIMPLEMENTED. Ref: Tang et al., "Quest: Query-Aware Sparsity for
    Efficient Long-Context LLM Inference", ICML 2024.

    This was a stub: __call__ returned past_kv completely unchanged, so
    running --methods quest silently produced Full-KV's own numbers
    mislabeled as "Quest" (no eviction, no top-k page sparsification ever
    applied -- attend_top_pages/page_size were stored but never read).
    Raises instead of running, so a bogus "Quest" score can't end up in a
    results table by accident. The sketch-based top-k page selection this
    would need already exists and IS exercised for real in
    TieredKVCache.sketch_check() (src/tiered_kv_cache.py) -- a real Quest
    baseline could reuse that rather than reimplementing it here.
    """
    name = "Quest"
    def __init__(self, page_size=16, attend_top_pages=4,
                 start_size=4, recent_size=16):
        raise NotImplementedError(
            "QuestPolicy is an unimplemented stub (see class docstring) -- "
            "not a real Quest reproduction. Remove this guard only after "
            "wiring real top-k page sparsification into __call__."
        )

class TieredKVPolicy:
    """VRAM + STT-RAM victim cache — the ONE canonical integration of
    src/tiered_kv_cache.py into the LongBench harness. (There used to be a
    second, diverging copy of this in run_tieredkv_only.py with its own
    bug fixes; that file has been retired and its fixes folded in here so
    there is a single implementation to report numbers from.)

    This policy:
    1. After prefill: one TieredKVCache per layer over the full prompt KV,
       entirely on the model's device (the old CPU-tensor version was too
       slow per layer per step for full LongBench runs to finish).
    2. During decode: takes (VRAM working set + new token), runs the real
       promote/sketch/evict/demote pipeline, returns the new working set.

    Query approximation: capturing the real Q via SDPA doesn't work here
    (H2O/SnapKV need output_attentions=True, which forces eager attention
    and bypasses scaled_dot_product_attention entirely). So:
      - Prefill bifurcation uses K as the Q proxy — same approximation the
        H2O/SnapKV policies above use. Capturing the true observation-window
        Q would need the full (seq x seq) prefill matrix, infeasible at
        LongBench lengths.
      - Decode promotion scores the attention-weighted average of attended
        VRAM keys from update_scores() — strictly better information than
        the K-proxy, and the model's own weights, not a fabrication.

    Peek vs. promote: promotion physically moves a page STT-RAM -> VRAM
    (contends for a VRAM slot, eventually costs a write-back) just to let
    the model glance at it once -- measured to be the dominant source of
    promote/evict churn. _decode_step() below asks
    TieredKVCache.resolve_promotions() which sketch-check candidates
    should actually be promoted (page has never been VRAM-resident before,
    or has cleared repeated re-candidacy) versus merely peeked, gating
    repeated re-promotion of pages that already proved not durably
    valuable once. Real-model attention visibility for peeked pages (so
    the model's output could benefit from that content even without a
    residency move) was implemented and validated on real Mistral-7B, then
    rolled back: it requires every layer to promote/peek the same token
    count each step (HF builds one shared causal mask per forward call),
    and enforcing that measurably collapsed promotion volume and cost
    double-digit F1 points on some tasks -- see _decode_step()'s docstring
    for the full account. That extension remains implemented and
    unit-tested in the CPU simulator (TieredKVCache.step()) but is
    disabled here pending a proper heterogeneous-length attention-mask
    solution.
    """
    name = "TieredKV"

    def __init__(self, sram_budget=128, stt_budget=256,
                 start_size=4, recent_size=16,
                 page_size=16, promote_top_pages=2,
                 promotion_budget=None,
                 sttram_bifurcation_frac=1.0, stt_expose_quota=None,
                 kv_dtype=None, stt_kv_dtype=None, stt_live_floor=1, write_aware_lambda=0.0,
                 inclusive=True, prefill_chunk_size=0, batch_backup_updates=True,
                 bool_live_gather=True, bool_hot_compaction=True):
        # Dtype the tiered cache stores K/V in. None keeps the float32 that
        # every result so far used. torch.bfloat16 matches the model and the
        # baselines, making the resident footprint equal to what the
        # equal-VRAM comparison claims -- see TieredConfig.kv_dtype.
        self.kv_dtype = kv_dtype
        self.stt_kv_dtype = stt_kv_dtype
        self.batch_backup_updates = batch_backup_updates
        self.bool_live_gather = bool_live_gather
        self.bool_hot_compaction = bool_hot_compaction
        self.prefill_chunk_size = prefill_chunk_size
        self.sram_budget = sram_budget
        self.stt_budget = stt_budget
        self.start_size = start_size
        self.recent_size = recent_size
        self.page_size = page_size
        self.promote_top_pages = promote_top_pages
        self.promotion_budget = (promote_top_pages * page_size
                                 if promotion_budget is None else promotion_budget)
        if self.promotion_budget < 0:
            raise ValueError("promotion_budget must be nonnegative")
        self.sttram_bifurcation_frac = sttram_bifurcation_frac
        # Cap on slow-tier tokens entering the REAL softmax per step,
        # regardless of how many are resident. Without it the visible pool
        # balloons to sram_budget + stt_budget while baselines attend
        # exactly `budget` — an apples-to-oranges comparison that also
        # showed up directly as a wall-clock latency regression (more
        # attended tokens = more real FLOPs). Default is the sketch
        # check's own candidate quantum: STT stays a large pool to search,
        # only its top-k page hits get real attention (Quest-style).
        self.stt_expose_quota = (
            stt_expose_quota if stt_expose_quota is not None
            else promote_top_pages * page_size
        )
        # Live-row floor per layer (see TieredConfig.stt_live_floor): stops
        # one fully-shadowed layer vetoing slow-tier exposure everywhere.
        self.stt_live_floor = stt_live_floor
        self.write_aware_lambda = write_aware_lambda
        self.inclusive = inclusive

        self.layer_caches = {}  # layer_idx -> TieredKVCache
        self.prompt_q_by_layer = {}  # opt-in experiment; empty by default
        self.initialized = False
        self.decode_step_count = 0
        # Zero-exposure steps are counted and reported: a run whose slow
        # tier never shows up must not be mistaken for a real tiered result.
        self._stt_starved_steps = 0
        self._stt_unused_steps = 0
        self._stt_exposed_total = 0
        self._stt_exposure_samples = 0
        self._stt_attn = {}        # layer -> {stt position: real attention received}
        self._stt_attn_idx = {}    # same scores keyed by still-valid STT index
        self._vis_sram_keep = {}   # layer -> VRAM indices in the visible set
        self._vis_stt_pos = {}     # layer -> STT positions in the visible set
        self._vis_stt_idx = {}     # indices used to build _vis_stt_pos
        self._vis_len = {}         # layer -> number of visible tokens from previous step

        # reset() runs before every sample and clears layer_caches, so
        # without this accumulator stats() would report only the LAST
        # sample's totals. reset() folds each outgoing sample in here
        # first; stats() reports accumulator + still-live totals.
        self._accum = dict.fromkeys(
            ("promoted", "promotions_deferred", "demoted", "paid_writes",
             "writes_saved", "dropped", "decode_steps", "latency_us",
             "energy_nj", "stt_starved_steps", "stt_unused_steps",
             "stt_exposed_total", "stt_exposure_samples"), 0
        )

    def _live_totals(self):
        """Sum of the CURRENT (not-yet-reset) sample's per-layer metrics."""
        caches = self.layer_caches.values()
        return {
            "promoted": sum(c.metrics.total_promoted for c in caches),
            "promotions_deferred": sum(c.metrics.total_promotions_deferred for c in caches),
            "demoted": sum(c.metrics.total_demoted for c in caches),
            "paid_writes": sum(c.metrics.total_paid_writes for c in caches),
            "writes_saved": sum(c.metrics.total_writes_saved for c in caches),
            "dropped": sum(c.metrics.total_dropped for c in caches),
            "decode_steps": self.decode_step_count,
            "latency_us": sum(c.metrics.total_latency_us for c in caches),
            "energy_nj": sum(c.metrics.total_energy_nj for c in caches),
            "stt_starved_steps": self._stt_starved_steps,
            "stt_unused_steps": self._stt_unused_steps,
            "stt_exposed_total": self._stt_exposed_total,
            "stt_exposure_samples": self._stt_exposure_samples,
        }

    def reset(self):
        if self.layer_caches:
            live = self._live_totals()
            for k, v in live.items():
                self._accum[k] += v
        self.layer_caches = {}
        self.prompt_q_by_layer = {}
        self.initialized = False
        self.decode_step_count = 0
        # NOTE: stt_starved_steps / stt_unused_steps / stt_exposed_total /
        # stt_exposure_samples are already folded via _live_totals() above — do NOT add them again
        # (a prior revision double-counted them here, ~2x inflated stats).
        self._stt_starved_steps = 0
        self._stt_unused_steps = 0
        self._stt_exposed_total = 0
        self._stt_exposure_samples = 0
        self._stt_attn = {}
        self._stt_attn_idx = {}
        self._vis_sram_keep = {}
        self._vis_stt_pos = {}
        self._vis_stt_idx = {}
        self._vis_len = {}

    def resident_positions(self):
        """Absolute positions in the chronological bounded-prefill handoff."""
        return {layer: sorted(cache.sram_pos + [p for p, shadow in
                    zip(cache.stt_pos, cache.stt_shadow) if not shadow])
                for layer, cache in self.layer_caches.items()}

    def resident_tuple(self):
        """Chronological retained KV for approximate bounded prefill."""
        result = []
        for layer in sorted(self.layer_caches):
            cache = self.layer_caches[layer]
            live = torch.where(~cache.stt_shadow)[0].tolist()
            cold_k, cold_v = cache.select_stt_pair(live)
            positions = cache.sram_pos + [cache.stt_pos[i] for i in live]
            order = sorted(range(len(positions)), key=positions.__getitem__)
            result.append((torch.cat([cache.sram_k, cold_k], dim=1)[:, order].unsqueeze(0),
                           torch.cat([cache.sram_v, cold_v], dim=1)[:, order].unsqueeze(0)))
        return tuple(result)

    def __call__(self, past_kv):
        if past_kv is None:
            return None
        if not self.initialized:
            self.initialized = True
            return self._bifurcate(past_kv)
        return self._decode_step(past_kv)

    def _bifurcate(self, past_kv, *, token_positions=None, prompt_length=None):
        """Initialize tiered caches after prefill (vectorized, on-device).

        Routes prompt tokens into VRAM and STT-RAM by SnapKV importance
        (K-as-Q-proxy — see class docstring):
        - VRAM: sinks + recent window + top-importance tokens
        - STT-RAM: next-importance tokens (warm victim cache)
        - dropped: everything else, discarded for good (same as H2O/SnapKV)
        """
        result = []

        for layer_idx, (k, v) in enumerate(past_kv):
            if k.size(0) != 1:
                raise ValueError("TieredKVPolicy currently supports batch size 1 only")
            heads, seq_len, head_dim = k.size(1), k.size(2), k.size(3)

            cfg = TieredConfig(
                num_heads=heads,
                head_dim=head_dim,
                sink_size=self.start_size,
                window_size=self.recent_size,
                sram_capacity=self.sram_budget,
                sttram_capacity=self.stt_budget,
                page_size=self.page_size,
                promote_top_pages=self.promote_top_pages,
                inclusive=self.inclusive,
                sttram_bifurcation_frac=self.sttram_bifurcation_frac,
                stt_live_floor=self.stt_live_floor,
                write_aware_lambda=self.write_aware_lambda,
                batch_backup_updates=self.batch_backup_updates,
                bool_hot_compaction=self.bool_hot_compaction,
                dtype=torch.float32,
                kv_dtype=self.kv_dtype,
                stt_kv_dtype=self.stt_kv_dtype,
                device=k.device,
            )
            cache = getattr(self, 'cache_cls', TieredKVCache)(cfg)

            k_2d = k[0].to(torch.float32)   # (H, seq, D), on model device
            v_2d = v[0].to(torch.float32)
            q_proxy = k_2d                  # K-as-Q-proxy (see class docstring)
            q_real = self.prompt_q_by_layer.pop(layer_idx, None)
            importance = None
            if q_real is not None:
                if q_real.ndim != 3 or q_real.size(1) != min(self.recent_size, seq_len) \
                        or q_real.size(0) % heads:
                    raise ValueError('Captured prompt query shape does not match KV cache')
                if getattr(self, 'prompt_query_score_mode', 'chunked') == 'expanded':
                    expanded_k = k_2d.repeat_interleave(q_real.size(0) // heads, dim=0)
                    importance = snapkv_importance(q_real.float(), expanded_k,
                                                   cfg.pool_kernel, causal=True)
                else:
                    importance = gqa_causal_importance(q_real.float(), k_2d,
                                                       cfg.pool_kernel,
                                                       getattr(self, 'prompt_query_chunk', 128))
            cache.initial_bifurcation(k_2d, v_2d, q_proxy,
                                      importance_override=importance,
                                      token_positions=None if token_positions is None else token_positions[layer_idx],
                                      prompt_length=prompt_length)
            self.layer_caches[layer_idx] = cache

        return self._visible_tuple(past_kv)

    def _visible_tuple(self, past_kv):
        """Build what the model actually attends over: the VRAM working set
        PLUS the live (non-shadow) STT-RAM tier.

        The slow tier is slower, not invisible: it is read for real
        attention at its own bandwidth/energy (see cost_model.py). An
        earlier version exposed VRAM only, silently cutting TieredKV's
        effective context to ~3x below baselines at equal nominal budget
        and finishing last everywhere. Promotion therefore means "move
        this where future reads are cheap" — the classic cache meaning.

        Shadow rows are excluded: each shadows a VRAM-live token, so
        attending both would double-count it in the softmax.

        One shared HF causal mask covers all layers, so every layer must
        present the same KV length. Per-layer live-STT counts differ, so
        the exposed set takes the per-step minimum across layers, capped
        at stt_expose_quota — while each layer contributes its OWN hottest
        tokens. Layers agree on COUNT, never on identity. (Two earlier
        designs failed here: expose-everything-live attended ~3x the
        baseline budget — unfair and slow; per-page intersection across
        layers collapsed to ~0.) Bounding by count keeps exposure fair
        without demanding cross-layer agreement.
        """
        idxs = [i for i in range(len(past_kv)) if i in self.layer_caches]
        if not idxs:
            return tuple(past_kv)

        # Bool-tensor selection, no list rebuilds (the old enumerate loop
        # dominated wall-clock at realistic STT sizes).
        live_by_layer = {
            i: torch.where(~self.layer_caches[i].stt_shadow)[0].tolist()
            for i in idxs
        }
        n_sram_uni = min(len(self.layer_caches[i].sram_pos) for i in idxs)
        # Capped at stt_expose_quota: never expose more than the quota no
        # matter how much STT is live.
        #
        # Watch the min() across layers: one fully-shadowed layer zeroes
        # exposure for all 32 at once, silently degrading TieredKV to a
        # VRAM-only policy for that step. Count it (stt_starved_steps) so
        # the degenerate state shows up in stats instead of hiding inside
        # an accuracy number.
        n_stt_live_min = min(len(live_by_layer[i]) for i in idxs)
        n_stt_uni = min(self.stt_expose_quota, n_stt_live_min)
        # Record what was actually exposed, not just the hard-zero case. The
        # common degradation is not starvation but the min() itself: one layer
        # with a handful of live tokens throttles all 32 layers down to that
        # handful, so the slow tier can be nominally full (2048 resident) while
        # contributing 1 token to the softmax. That looks like a weak accuracy
        # result rather than a throttled configuration, so stats() reports mean
        # exposure against the quota.
        self._stt_exposed_total += n_stt_uni
        self._stt_exposure_samples += 1
        if n_stt_uni == 0:
            # Two distinct states share "min live == 0" and only one of them
            # is a real problem. If NO layer holds live slow-tier content
            # (short document: STT never populated because VRAM never
            # overflowed), the veto hides nothing -- VRAM already holds the
            # whole document -- so counting it as starvation cries wolf
            # (this is where the old "7 starved steps on hotpotqa" came
            # from: short samples' entire decodes, all harmless). Count it
            # separately as unused, silently. Only when some layer DOES hold
            # live content that this step hides do we count starvation and
            # warn: that is genuine retrieval loss.
            total_live = sum(len(live_by_layer[i]) for i in idxs)
            if total_live == 0:
                self._stt_unused_steps += 1
            else:
                self._stt_starved_steps += 1
                if self._stt_starved_steps == 1:
                    starved = [i for i in idxs if not live_by_layer[i]]
                    print(f"  [WARNING] TieredKV: slow tier fully shadowed on "
                          f"layer(s) {starved[:4]}{'...' if len(starved) > 4 else ''} "
                          f"-- no STT tokens exposed to attention this step. "
                          f"TieredKV is running VRAM-only until this clears.")

        selections = {i: self._visible_cold_indices(self.layer_caches[i], live_by_layer[i],
                                                   n_stt_uni, self.bool_live_gather)
                      for i in idxs}
        self._prepare_visible_reads(selections)

        result = []
        self._vis_sram_keep = {}
        self._vis_stt_pos = {}
        self._vis_stt_idx = {}

        for layer_idx, (k, v) in enumerate(past_kv):
            cache = self.layer_caches.get(layer_idx)
            if cache is None:
                result.append((k, v))
                continue

            # VRAM part: normally already uniform (hard capacity cap), but if
            # it ever drifts, keep the highest cumulative-attention tokens.
            n_sram = len(cache.sram_pos)
            if n_sram > n_sram_uni:
                keep = torch.argsort(cache.sram_cum, descending=True)[:n_sram_uni].tolist()
                keep.sort()
            else:
                keep = list(range(n_sram))

            sel = selections[layer_idx]

            self._vis_sram_keep[layer_idx] = keep
            self._vis_stt_pos[layer_idx] = [cache.stt_pos[j] for j in sel]
            self._vis_stt_idx[layer_idx] = sel

            # The normal path keeps the complete, already ordered fast tier.
            # Advanced indexing would copy all S rows before torch.cat copies
            # them again into the visible cache. Reuse the tensor directly;
            # only the rare non-uniform fallback needs a gather.
            if len(keep) == n_sram and (not keep or keep[0] == 0 and keep[-1] == n_sram - 1):
                fast_k, fast_v = cache.sram_k, cache.sram_v
            else:
                fast_k, fast_v = cache.sram_k[:, keep, :], cache.sram_v[:, keep, :]
            cold_k, cold_v = cache.select_stt_pair(sel)
            vis_k = torch.cat([fast_k, cold_k], dim=1)
            vis_v = torch.cat([fast_v, cold_v], dim=1)
            self._vis_len[layer_idx] = vis_k.size(1)
            result.append((vis_k.unsqueeze(0).to(k.dtype), vis_v.unsqueeze(0).to(v.dtype)))

        return tuple(result)

    def _promotion_plan(self, layer_idx, cache):
        """Resolve measured-attention candidates once, in original order."""
        stt_attn = (self._stt_attn or {}).get(layer_idx)
        stt_attn_idx = (self._stt_attn_idx or {}).get(layer_idx)
        if stt_attn:
            if stt_attn_idx:
                scored = [(a, i) for i, a in stt_attn_idx.items()
                          if i < len(cache.stt_pos) and not cache.stt_shadow[i]]
            else:
                # Compatibility for tests and external hooks that inject
                # position-keyed attention directly.
                pos_to_idx = {p: i for i, p in enumerate(cache.stt_pos)}
                scored = [(a, pos_to_idx[p]) for p, a in stt_attn.items()
                          if p in pos_to_idx and not cache.stt_shadow[pos_to_idx[p]]]
            if scored:
                scored.sort(reverse=True)
                budget = self.promotion_budget
                candidate_idx = [i for _, i in scored[:budget]]
                promote_idx, deferred_idx = cache.resolve_promotion_indices(candidate_idx)
                return [(i, i + 1) for i in promote_idx], len(deferred_idx)
        # A missed candidate breaks the consecutive re-entry hysteresis.
        cache.resolve_promotion_indices([])
        return None, 0

    def _prepare_decode_reads(self):
        """Physical backends may batch cold reads before any layer mutation."""

    def _prepare_visible_reads(self, selections):
        """Physical backends may batch independently selected cold rows."""

    @staticmethod
    def _visible_cold_indices(cache, live, count, bool_live_gather):
        if count < len(live):
            access = (cache.stt_last_access[~cache.stt_shadow] if bool_live_gather
                      else cache.stt_last_access[live])
            order = torch.argsort(access, descending=True)[:count].tolist()
            return sorted(live[o] for o in order)
        return live

    def _decode_step(self, past_kv):
        """One decode step: promote hot slow-tier tokens into VRAM, then
        evict/demote the new token in.

        Promotion is driven by the model's REAL measured attention on the
        STT-RAM tokens from the step just completed (recorded by
        update_scores), not by the K-as-Q sketch upper bound. That became
        possible once the slow tier was made attendable -- we now observe
        exactly how much attention each slow-tier token actually received,
        so promotion is a straightforward "this is hot, move it to the fast
        tier so future reads are cheap" cache policy with no query
        approximation in the loop at all. TieredKVCache.resolve_promotions'
        hysteresis still gates RE-promotion of tokens that already proved
        not durably valuable once, which is what keeps promote/evict churn
        down.
        """
        result = []
        first_idx = next(iter(self.layer_caches.keys()), None)
        if first_idx is not None and first_idx in self._vis_len and past_kv is not None:
            n_new = past_kv[0][0].size(2) - self._vis_len[first_idx]
            if n_new <= 0:
                n_new = 1
        else:
            n_new = 1

        self.decode_step_count += n_new
        self._prepare_decode_reads()

        for layer_idx, (k, v) in enumerate(past_kv):
            cache = self.layer_caches.get(layer_idx)
            if cache is None:
                result.append((k, v))
                continue

            new_k = k[0, :, -n_new:, :].to(torch.float32)  # (H, n_new, D)
            new_v = v[0, :, -n_new:, :].to(torch.float32)

            cache._t += 1

            promote_hits, deferred_count = self._promotion_plan(layer_idx, cache)
            promoted = 0
            if promote_hits is not None:
                promoted = cache.promote(promote_hits)
                deferred_count += cache.last_floor_deferred

            # sram_cum is updated by update_scores() from the model's REAL
            # attention weights; sram_age still needs its once-per-step bump
            # (previously done inside compute_attention).
            cache.sram_age += 1

            n_vis_stt = len((self._vis_stt_pos or {}).get(layer_idx, []))
            n_attended_hot = len((self._vis_sram_keep or {}).get(layer_idx, [])) + n_new

            base_pos = cache.metrics.prompt_len + self.decode_step_count - n_new
            new_pos = list(range(base_pos, base_pos + n_new)) if n_new > 1 else base_pos

            demoted, dropped, writes_saved, reclaimed = cache.evict_and_demote(
                new_k, new_v,
                new_pos=new_pos,
            )

            rec = StepRecord(step=cache._t)
            rec.promoted_tokens = promoted
            rec.promotions_deferred = deferred_count
            rec.demoted_tokens = demoted
            rec.dropped_tokens = dropped
            rec.writes_saved = writes_saved
            rec.backups_reclaimed = reclaimed
            rec.sram_tokens = len(cache.sram_pos)
            rec.sttram_tokens = len(cache.stt_pos)

            # Cost model, mirroring TieredKVCache.step()'s accounting but
            # adapted: attention reads BOTH tiers (STT-RAM is attendable at
            # its own bandwidth/energy, not free), and there is no separate
            # sketch cost since promotion is driven by real measured
            # attention rather than a sketch upper bound.
            elems_per_tok = cache.cfg.num_heads * cache.cfg.head_dim
            paid_writes = demoted - writes_saved
            lat_p, eng_p = cache.cm.promote_cost(promoted * 2 * elems_per_tok)
            lat_d, eng_d = cache.cm.demote_cost(paid_writes * 2 * elems_per_tok)
            # Dropped tokens are freed, not migrated anywhere.
            lat_dd, eng_dd = cache.cm.drop_cost(dropped * 2 * elems_per_tok)
            lat_vr, eng_vr = cache.cm.gpu_vram_read_cost(n_attended_hot * 2 * elems_per_tok)
            lat_sr, eng_sr = cache.cm.read_latency_us("STT-RAM", n_vis_stt * 2 * elems_per_tok), \
                             cache.cm.read_energy_nj("STT-RAM", n_vis_stt * 2 * elems_per_tok)

            rec.lat_promote_us = lat_p
            rec.lat_attention_us = lat_vr + lat_sr
            rec.lat_demote_us = lat_d + lat_dd
            rec.latency_us = lat_p + lat_vr + lat_sr + lat_d + lat_dd
            rec.energy_nj = eng_p + eng_vr + eng_sr + eng_d + eng_dd

            cache.metrics.add(rec)

        result = self._visible_tuple(past_kv)
        return tuple(result)

    def update_scores(self, past_kv, attn_weights):
        """Fold the model's real attention weights back into the tiered
        cache's bookkeeping.

        The sequence the model just attended over is exactly what
        _visible_tuple() built: the kept VRAM tokens first, then the
        selected live STT-RAM tokens, then the new token. So the attention
        row splits cleanly into a VRAM segment and a slow-tier segment,
        and both are REAL measured attention -- no query approximation.
        The VRAM segment accumulates into sram_cum (eviction scoring); the
        slow-tier segment is recorded per position for the next step's
        promotion decision and refreshes stt_last_access, which is what
        keeps a hot slow-tier token in the visible set and away from LRU
        reclaim.
        """
        if attn_weights is None:
            return

        self._stt_attn = {}
        self._stt_attn_idx = {}
        for layer_idx, (k, v) in enumerate(past_kv):
            if layer_idx >= len(attn_weights) or attn_weights[layer_idx] is None:
                continue
            cache = self.layer_caches.get(layer_idx)
            if cache is None:
                continue

            keep = (self._vis_sram_keep or {}).get(layer_idx)
            stt_pos = (self._vis_stt_pos or {}).get(layer_idx)
            stt_idx = (self._vis_stt_idx or {}).get(layer_idx)
            if keep is None or stt_pos is None:
                continue
            n_sram, n_stt = len(keep), len(stt_pos)
            if n_sram == 0:
                continue

            w = attn_weights[layer_idx]  # (batch, heads, 1, cache_seq)
            attn_full = w[0].to(torch.float32).squeeze(1).mean(dim=0)
            if attn_full.ndim == 2:
                # One policy observation per forward, averaged over queries.
                # This is not equivalent to intermediate per-token eviction.
                attn_full = attn_full.mean(dim=0)
            if attn_full.shape[0] < n_sram + n_stt:
                continue  # defensive: shouldn't happen given the invariant above

            attn_vram = attn_full[:n_sram]
            keep_t = torch.tensor(keep, device=cache.sram_cum.device)
            cache.sram_cum.index_add_(0, keep_t, attn_vram.to(cache.sram_cum.device))

            if n_stt > 0:
                attn_stt = attn_full[n_sram:n_sram + n_stt]
                attn_values = attn_stt.tolist()
                self._stt_attn[layer_idx] = dict(zip(stt_pos, attn_values))
                # A slow-tier token that actually drew attention is freshly
                # relevant: refresh its LRU stamp so it stays visible.
                indices_still_match = (
                    stt_idx is not None and len(stt_idx) == len(stt_pos)
                    and all(i < len(cache.stt_pos) and cache.stt_pos[i] == p
                            for i, p in zip(stt_idx, stt_pos))
                )
                if indices_still_match:
                    self._stt_attn_idx[layer_idx] = dict(zip(stt_idx, attn_values))
                    touched = [i for i, a in zip(stt_idx, attn_values) if a > 0]
                else:
                    # Query-selection hooks may replace positions after the
                    # base visible set is built. Resolve only in that path.
                    pos_to_idx = {p: i for i, p in enumerate(cache.stt_pos)}
                    touched = [pos_to_idx[p] for p, a in zip(stt_pos, attn_values)
                               if a > 0 and p in pos_to_idx]
                if touched:
                    cache.stt_last_access[touched] = cache._t

    def stats(self):
        """Aggregate statistics across every sample seen so far in this task
        (all reset()-folded samples in self._accum, plus the still-live
        current sample from self._live_totals()) -- see the accumulator
        note in __init__ for why this must combine both, not just one.
        """
        live = self._live_totals()
        t = {k: self._accum[k] + live[k] for k in self._accum}

        total_writes = t["paid_writes"] + t["writes_saved"]
        pct = (t["writes_saved"] / total_writes * 100) if total_writes > 0 else 0
        return {
            "demoted": t["demoted"],
            "promoted": t["promoted"],
            "promotions_deferred": t["promotions_deferred"],
            "paid_writes": t["paid_writes"],
            "writes_saved": t["writes_saved"],
            "dropped": t["dropped"],
            "write_savings_pct": round(pct, 1),
            "decode_steps": t["decode_steps"],
            "stt_starved_steps": t["stt_starved_steps"],
            "stt_unused_steps": t["stt_unused_steps"],
            "mean_stt_exposed": (
                round(t["stt_exposed_total"] / t["stt_exposure_samples"], 2)
                if t["stt_exposure_samples"] else 0
            ),
            "stt_expose_quota": self.stt_expose_quota,
            "stt_exposed_total": t["stt_exposed_total"],
            "stt_exposure_samples": t["stt_exposure_samples"],
            # Modeled (cost_model.py) latency/energy -- the paper's real
            # latency claim: real wall-clock on this GPU has no separate
            # slow-memory hardware, so attending more tokens costs
            # proportionally more compute regardless of tier. The cost
            # model prices STT-RAM reads at their own (cheaper) simulated
            # NVM bandwidth, which is what the tiered-hierarchy argument
            # actually claims.
            "modeled_latency_us": round(t["latency_us"], 1),
            "modeled_energy_nj": round(t["energy_nj"], 1),
        }

# ---------------------------------------------------------------------------
# Token-by-token generation with KV policy
# ---------------------------------------------------------------------------
@torch.inference_mode()
def generate_with_policy(model, tokenizer, input_text, max_gen, policy, device,
                         max_ctx=31500, task_name="", *, prefill_last_logits=False):
    """Generate text token-by-token, applying cache policy after each step.

    Position-id note: every eviction policy here trims `past_key_values` in
    place (that's the whole point of a cache policy). Left to its default,
    HF derives the next token's RoPE position as
    `arange(new_tokens) + past_key_values.get_seq_length()`, and for a
    `DynamicLayer` (this model has no sliding window, so that's what it
    uses -- confirmed against the real config) `get_seq_length()` returns
    the CURRENT, already-trimmed cache length, not the token's true
    position in the document. Sink/window/kept-prompt tokens still carry
    the RoPE rotation baked in at prefill using their true, large absolute
    position, so the very next generated token would get rotated at
    (trimmed-cache-size) while sitting right next to a token rotated at
    (true document position) -- the model reads them as a huge, false
    relative distance apart. Full-KV never trims anything, so it's immune
    to this; every sparse policy shares the exact same bug otherwise,
    equally. The fix is to explicitly pass each token's TRUE absolute
    document position as `position_ids`, for every policy alike --
    documents are truncated to `max_ctx` (default 31500, the reference
    LongBench protocol length for this model) here, well inside
    Mistral's 32768 trained range, so true positions are always safe to
    use directly (no need for StreamingLLM-style position renumbering,
    which exists only to handle documents *longer* than the trained
    context). NOTE: middle-split truncation below stitches [:half]+[-half:]
    but assigns contiguous position ids, creating a false adjacency at the
    seam. The reference LongBench protocol also middle-splits; record the
    complete prompt, wrapping, tokenizer and truncation protocol for comparisons. This requires
    no change to any individual policy: a kept
    token's baked-in RoPE rotation is immutable and already correct from
    whenever it was originally computed; only the position assigned to
    the newly generated token at each step needs fixing.
    """
    # max_ctx note: the reference LongBench protocol truncates to the model's
    # own trained length -- 31500 for mistral-7B-instruct-v0.2, per
    # sota/snapkv/experiments/LongBench/config/model2maxlen.json. This used to
    # be pinned at 8192 with no way to change it, which had two consequences:
    # absolute scores were not comparable to published LongBench/SnapKV/H2O
    # numbers, and, worse, it worked against the result being claimed -- at 8k
    # with a 1024-token budget the compression ratio is only 8:1, where the
    # reference length gives ~31:1. Eviction hurts far more at 31:1 and a
    # victim cache has correspondingly more to recover, so truncating to 8k
    # systematically shrank the very gap TieredKV exists to close.
    if max_gen <= 0:
        return ""
    if max_ctx < 2:
        raise ValueError("max_ctx must be at least 2")
    toks = tokenizer(input_text, truncation=False, return_tensors="pt")
    input_ids = toks.input_ids

    # Standard middle-split truncation for long contexts
    if input_ids.size(1) > max_ctx:
        half = max_ctx // 2
        input_ids = torch.cat([input_ids[:, :half], input_ids[:, -(max_ctx - half):]], dim=1)

    input_ids = input_ids.to(device)
    prompt_len = input_ids.size(1)
    policy.last_prompt_identity = {
        "prompt_sha256": hashlib.sha256(input_text.encode()).hexdigest(),
        "input_ids_sha256": hashlib.sha256(input_ids.detach().cpu().numpy().tobytes()).hexdigest(),
        "max_ctx": max_ctx,
    }

    # Prefill (position_ids matches the default here since the cache starts
    # empty -- passed explicitly anyway for clarity and to keep prefill and
    # decode on the same explicit-position code path).
    prefill_pos = torch.arange(prompt_len, device=device).unsqueeze(0)
    # SDPA for prefill: no attention weights are requested here, and eager
    # would allocate a (heads, prompt_len, prompt_len) score matrix -- 59 GiB
    # at the reference 31500-token context. See _attn_impl.
    chunk_size = getattr(policy, "prefill_chunk_size", 0)
    prefill_options = prefill_logit_kwargs(model, prefill_last_logits)
    if not chunk_size or chunk_size >= prompt_len:
        with _attn_impl(model, "sdpa"):
            out = model(input_ids, use_cache=True, position_ids=prefill_pos, **prefill_options)
        raw_past = out.past_key_values
        apply_tuple_kv_inplace(raw_past, policy(to_tuple_kv(raw_past)))
    else:
        # Experimental bounded prefill: later chunks attend to the compressed
        # cache from earlier chunks. Absolute position_ids preserve RoPE, but
        # this is approximate prefill and must be quality-tested separately.
        raw_past = None
        carried_positions = {}
        for start in range(0, prompt_len, chunk_size):
            end = min(prompt_len, start + chunk_size)
            positions = torch.arange(start, end, device=device).unsqueeze(0)
            with _attn_impl(model, "sdpa"):
                out = model(input_ids[:, start:end], past_key_values=raw_past,
                            use_cache=True, position_ids=positions, **prefill_options)
            raw_past = out.past_key_values
            absolute_positions = {layer: carried_positions.get(layer, []) + list(range(start, end))
                                  for layer in range(len(to_tuple_kv(raw_past)))}
            policy.reset()
            policy.initialized = True
            visible = policy._bifurcate(to_tuple_kv(raw_past),
                token_positions=absolute_positions, prompt_length=end)
            carried_positions = policy.resident_positions()
            if end < prompt_len:
                # Storage precision may differ from the model attention dtype.
                carried = tuple((keys.to(raw_keys.dtype), values.to(raw_values.dtype))
                    for (keys, values), (raw_keys, raw_values) in
                    zip(policy.resident_tuple(), to_tuple_kv(raw_past)))
            else:
                carried = visible
            apply_tuple_kv_inplace(raw_past, carried)
    past_kv = raw_past

    next_tok = out.logits[:, -1:].argmax(dim=-1)
    generated = [next_tok.item()]
    policy.last_generation = {"prompt_tokens": prompt_len, "generated_tokens": 1}
    if generated[0] == tokenizer.eos_token_id:
        return tokenizer.decode(generated, skip_special_tokens=True)

    # The cache and next token own everything needed by decode.
    del out

    # Decode loop
    for step in range(max_gen - 1):
        true_pos = torch.tensor([[prompt_len + step]], device=device)

        # Modeled cost for the attention this forward call is about to do,
        # measured directly off the KV tensors it will attend (their
        # current, already-trimmed length) -- same VRAM-read cost formula
        # TieredKV uses for its own VRAM tier, giving every baseline a
        # directly comparable modeled_latency_us/modeled_energy_nj instead
        # of leaving that number TieredKV-only (see _ModeledCostMixin).
        # TieredKVPolicy prices its own multi-tier moves separately and has
        # no _modeled_latency_us attribute, so it's naturally excluded here.
        if hasattr(policy, "_modeled_latency_us"):
            for k, v in to_tuple_kv(past_kv):
                heads, seq_len, head_dim = k.size(1), k.size(2), k.size(3)
                lat, eng = _BASELINE_COST_MODEL.baseline_attention_cost(seq_len + next_tok.size(1), heads, head_dim)
                policy._modeled_latency_us += lat
                policy._modeled_energy_nj += eng
            policy._modeled_steps += 1

        out = model(next_tok, past_key_values=past_kv, use_cache=True,
                   output_attentions=True, position_ids=true_pos)
        raw_past = out.past_key_values
        tuple_kv = to_tuple_kv(raw_past)
        
        # Update policy scores with actual attention weights
        if hasattr(policy, "update_scores"):
            policy.update_scores(tuple_kv, out.attentions)
        
        # Apply cache policy (this is where promote/demote happens for TieredKV)
        tuple_kv = policy(tuple_kv)
        apply_tuple_kv_inplace(raw_past, tuple_kv)
        past_kv = raw_past
        
        next_tok = out.logits[:, -1:].argmax(dim=-1)
        tok_id = next_tok.item()
        generated.append(tok_id)
        
        if tok_id == tokenizer.eos_token_id:
            break
    
    policy.last_generation["generated_tokens"] = len(generated)
    return tokenizer.decode(generated, skip_special_tokens=True)

# ---------------------------------------------------------------------------
# Task evaluation
# ---------------------------------------------------------------------------
def task_data_path(data_dir, task):
    for suffix in ("_e", ""):
        path = Path(data_dir) / f"{task}{suffix}.jsonl"
        if path.is_file():
            return path
    raise FileNotFoundError(f"No JSONL for {task} in {data_dir}")


NO_CHAT_TASKS = {"trec", "triviaqa", "samsum", "lsht", "lcc", "repobench-p"}

def load_task_data(task_name, data_dir=None):
    """Resolve a task once; callers share exact rows across comparison arms."""
    data = None
    if data_dir is not None:
        path = task_data_path(data_dir, task_name)
        data = read_jsonl(path)
    else:
        # Try loading from HuggingFace datasets. Any failure (auth, network,
        # missing split -- can't tell which without looking) falls through to
        # the next source; logging it means a real error (e.g. corrupted cache,
        # auth failure) isn't silently indistinguishable from "this task just
        # doesn't have an _e split."
        try:
            data = load_dataset("THUDM/LongBench", f"{task_name}_e",
                              split="test", trust_remote_code=True)
        except Exception as e:
            print(f"  [dataset] {task_name}_e unavailable ({type(e).__name__}: {e}), trying {task_name}")
    
    if data is None:
        try:
            data = load_dataset("THUDM/LongBench", task_name,
                              split="test", trust_remote_code=True)
        except Exception as e:
            print(f"  [dataset] {task_name} unavailable via HF datasets "
                  f"({type(e).__name__}: {e}), trying local JSONL fallback")
    
    # Local JSONL fallback (uses HF_HOME or default cache path)
    if data is None:
        hf_cache = os.environ.get("HF_HOME", 
                                  os.path.expanduser("~/.cache/huggingface"))
        local_matches = glob.glob(
            os.path.join(hf_cache, "**", f"{task_name}_e.jsonl"), 
            recursive=True
        )
        if not local_matches:
            local_matches = glob.glob(
                os.path.join(hf_cache, "**", f"{task_name}.jsonl"), 
                recursive=True
            )
        
        if local_matches:
            local_items = []
            with open(local_matches[0], "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        local_items.append(json.loads(line))
            data = local_items
        else:
            raise RuntimeError(f"Could not load dataset for task: {task_name}")
    
    return list(data)


def evaluate_task(model, tokenizer, task_name, policy, device, 
                  max_samples=None, is_instruct=False, max_ctx=31500, data_dir=None,
                  *, prefill_last_logits=False, dataset_rows=None):
    """Evaluate one LongBench task, return (avg_score, sample_results)."""
    data = load_task_data(task_name, data_dir) if dataset_rows is None else dataset_rows

    prompt_fmt = DATASET_TO_PROMPT[task_name]
    max_gen = DATASET_TO_MAXGEN[task_name]
    metric_fn = DATASET_TO_METRIC[task_name]
    
    results = []
    policy.sample_records = []
    
    for i, item in enumerate(data):
        if max_samples and i >= max_samples:
            break
        
        input_text = prompt_fmt.format(**item)
        if is_instruct and task_name not in NO_CHAT_TASKS:
            input_text = f"[INST] {input_text} [/INST]"
        
        answers = item["answers"]

        # Reset per-sample state
        if hasattr(policy, "reset"):
            policy.reset()

        started = time.perf_counter()
        pred = generate_with_policy(
            model, tokenizer, input_text, max_gen, policy, device,
            max_ctx=max_ctx, task_name=task_name, prefill_last_logits=prefill_last_logits
        )

        # Matches the reference LongBench eval protocol (THUDM/LongBench,
        # vendored at sota/snapkv/experiments/LongBench/eval.py:52-53): for
        # these four tasks the model tends to echo the question or add
        # commentary after the answer, so only the first line is scored.
        # Applied before metric_fn, identically for every policy -- doesn't
        # change relative ranking, but the earlier omission here (only
        # classification_score did an internal first-line trim) made
        # triviaqa/samsum numbers not directly comparable to published
        # LongBench/SnapKV/H2O results.
        scored_pred = pred
        if task_name in ("trec", "triviaqa", "samsum", "lsht"):
            scored_pred = pred.lstrip("\n").split("\n")[0]

        score = max(
            metric_fn(scored_pred, gt, all_classes=item.get("all_classes", []))
            for gt in answers
        )
        results.append(score)
        policy.sample_records.append({
            "sample_id": hashlib.sha256(json.dumps(item, sort_keys=True).encode()).hexdigest(),
            "prediction": pred, "score": float(score) * 100,
            "elapsed_s": time.perf_counter() - started,
            **policy.last_generation,
            **getattr(policy, 'last_prompt_identity', {}),
        })
        
        if (i + 1) % 5 == 0 or (i + 1) == (max_samples if max_samples else len(data)):
            print(f"  [{policy.name}] {task_name} {i+1}/"
                  f"{(max_samples if max_samples else len(data))}  "
                  f"Score={np.mean(results)*100:.2f}")
        
        # Proactive memory hygiene
        if (i + 1) % 10 == 0 and torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    # Return per-sample scores as well as the mean: without them no
    # standard error / confidence interval is computable after the fact,
    # which is what left the old headline's +5.26 margin uninterpretable
    # against a measured ±7.29 run-to-run spread on a fixed config.
    if not results:
        raise ValueError(f"No samples evaluated for {task_name}")
    sample_scores = [round(float(s) * 100, 2) for s in results]
    return round(np.mean(results) * 100, 2), sample_scores

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def make_policy(name, args, sink=4):
    recent = args.recent_size if args.recent_size is not None else max(16, args.budget // 8)
    tiered_vram = args.tiered_vram_budget if args.tiered_vram_budget is not None else args.budget // 3
    tiered_stt = args.tiered_stt_budget if args.tiered_stt_budget is not None else args.budget - tiered_vram
    if name == "full":
        return FullCachePolicy()
    elif name == "streamingllm":
        return StreamingLLMPolicy(
            start_size=sink,
            recent_size=args.budget - sink
        )
    elif name == "h2o":
        return H2OPolicy(
            budget=args.budget,
            start_size=sink,
            recent_size=recent
        )
    elif name == "snapkv":
        return SnapKVPolicy(
            budget=args.budget,
            start_size=sink,
            recent_size=recent
        )
    elif name == "quest":
        return QuestPolicy(
            page_size=16,
            attend_top_pages=4,
            start_size=sink,
            recent_size=recent
        )
    elif name == "tieredkv":
        # FIXED: Now uses the REAL TieredKVCache from src/
        # The total budget (VRAM + STT) equals args.budget
        # This is memory-fair: same total memory as baselines
        return TieredKVPolicy(
            sram_budget=tiered_vram,
            stt_budget=tiered_stt,
            start_size=sink,
            recent_size=recent,
            page_size=16,
            promote_top_pages=2,
            promotion_budget=getattr(args, "tiered_promotion_budget", None),
            sttram_bifurcation_frac=args.sttram_bifurcation_frac,
            stt_expose_quota=args.tiered_stt_expose,
            stt_live_floor=args.stt_live_floor,
            write_aware_lambda=args.write_aware_lambda,
            inclusive=args.tiered_inclusive,
            kv_dtype=(None if args.tiered_kv_dtype == "float32"
                      else getattr(torch, args.tiered_kv_dtype)),
            stt_kv_dtype=(None if getattr(args, "tiered_stt_kv_dtype", "same") == "same"
                          else getattr(torch, args.tiered_stt_kv_dtype)),
            prefill_chunk_size=getattr(args, "tiered_prefill_chunk_size", 0),
        )
    else:
        raise ValueError(f"Unknown method: {name}")


def main():
    parser = argparse.ArgumentParser(
        description="Run LongBench evaluation with fixed TieredKV implementation"
    )
    parser.add_argument("--model", required=True,
                        help="HF model id or local path")
    parser.add_argument("--tasks", nargs="+",
                        default=["multifieldqa_en", "qasper", "narrativeqa", 
                                "hotpotqa", "gov_report", "triviaqa"])
    parser.add_argument("--methods", nargs="+",
                        default=["full", "streamingllm", "h2o", "snapkv", 
                                "tieredkv"])
    parser.add_argument("--budget", type=int, default=1024,
                        help="Total KV budget in tokens for eviction methods")
    parser.add_argument("--max-samples", type=int, default=None,
                        help="Limit samples per task for quick runs")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--prefill-last-logits", action="store_true",
                        help="Compute only the last prefill logits; requires native logits_to_keep support")
    parser.add_argument("--data-dir", help="Local LongBench JSONL directory (preferred for reproducibility)")
    parser.add_argument("--max-ctx", type=int, default=31500, dest="max_ctx",
                        help="Prompt truncation length (middle-split), shared "
                             "by every method. Default 31500 matches the "
                             "reference LongBench protocol for "
                             "mistral-7B-instruct-v0.2. Lowering this shrinks "
                             "the compression ratio and is NOT comparable to "
                             "published LongBench numbers -- report the value "
                             "you used.")
    parser.add_argument("--tiered-kv-dtype", default="float32",
                        choices=["float32", "bfloat16", "float16"],
                        dest="tiered_kv_dtype",
                        help="Dtype TieredKV stores its K/V tiers in. Default "
                             "float32 reproduces every result measured so far, "
                             "but doubles the real footprint versus the "
                             "bfloat16 baselines it is compared against. Use "
                             "bfloat16 for a footprint-honest equal-VRAM run. "
                             "Eviction scores stay float32 either way.")
    parser.add_argument("--tiered-stt-kv-dtype", default="same",
                        choices=["same", "float8_e4m3fn"],
                        dest="tiered_stt_kv_dtype",
                        help="Experimental cold-tier storage dtype. 'same' uses "
                             "--tiered-kv-dtype; float8_e4m3fn stores one byte "
                             "per element and converts selected rows before attention.")
    parser.add_argument("--tiered-prefill-chunk-size", type=int, default=0,
                        dest="tiered_prefill_chunk_size",
                        help="Experimental TieredKV-only bounded prefill chunk size. "
                             "0 keeps exact full-prompt prefill; positive values "
                             "compress the cache after every chunk.")
    parser.add_argument("--seed", type=int, default=0,
                        help="Seed for torch/numpy, recorded in the results "
                             "config so a run is identifiable.")
    parser.add_argument("--sttram-bifurcation-frac", type=float, default=1.0,
                        dest="sttram_bifurcation_frac",
                        help="Fraction of TieredKV's STT-RAM budget that bifurcation "
                             "may fill with cold prompt tokens; the rest is reserved "
                             "headroom for decode-time victim-cache backups. 1.0 = "
                             "original behavior (STT-RAM starts full, write savings "
                             "measure ~0%% on long documents). Lower values trade "
                             "prompt-token recall for genuine write savings -- see "
                             "TieredConfig.sttram_bifurcation_frac in src/tiered_kv_cache.py.")
    parser.add_argument("--stt-live-floor", type=int, default=1,
                        dest="stt_live_floor",
                        help="Minimum live (non-shadow) STT rows promote() leaves "
                             "per layer. Prevents one fully-shadowed layer from "
                             "vetoing slow-tier exposure for all layers (measured "
                             "starvation on hotpotqa). See TieredConfig.stt_live_floor.")
    parser.add_argument("--write-aware-lambda", type=float, default=0.0,
                        dest="write_aware_lambda",
                        help="Write-aware demotion weight: victim score = "
                             "avg_attention - lambda * has_backup, preferring "
                             "zero-write re-demotions among near-tied cold "
                             "tokens. 0.0 = pure recall eviction. See "
                             "TieredConfig.write_aware_lambda.")
    parser.add_argument("--no-tiered-inclusive", action="store_false",
                        dest="tiered_inclusive", default=True,
                        help="Paired no-shadow ablation: remove the slow-tier "
                             "copy on promotion, so re-demotion pays a write. "
                             "All other budgets and policy settings stay fixed.")
    parser.add_argument("--json", default="results/longbench_comparison.json")
    parser.add_argument("--checkpoint", default=None,
                        help="checkpoint file to resume from")
    parser.add_argument("--allow-checkpoint-mismatch", action="store_true",
                        dest="allow_checkpoint_mismatch",
                        help="Resume from a checkpoint even if its recorded "
                             "config (model/budget/tiered-vram/tiered-stt/"
                             "stt-expose/bifurcation-frac) doesn't match "
                             "this run's args. Without this flag, a "
                             "mismatch raises instead of silently blending "
                             "scores from two different configs into one "
                             "results table.")
    parser.add_argument("--tiered-vram-budget", type=int, default=None,
                        dest="tiered_vram_budget",
                        help="Override TieredKV's VRAM (fast-tier) budget directly, "
                             "instead of deriving it as --budget // 3. Use this "
                             "together with --tiered-stt-budget to run the "
                             "equal-VRAM comparison (same fast-tier bytes as a "
                             "baseline's full --budget, plus a slow tier on top) "
                             "rather than the equal-total-budget comparison.")
    parser.add_argument("--tiered-stt-budget", type=int, default=None,
                        dest="tiered_stt_budget",
                        help="Override TieredKV's STT-RAM (slow-tier) budget "
                             "directly. See --tiered-vram-budget.")
    parser.add_argument("--recent-size", type=int, default=None,
                        dest="recent_size",
                        help="Sliding-window (recent-token) size, shared by "
                             "all sink/window-based methods. Default: "
                             "max(16, budget // 8).")
    parser.add_argument("--tiered-stt-expose", type=int, default=None,
                        dest="tiered_stt_expose",
                        help="Cap on how many STT-RAM tokens TieredKV actually "
                             "attends to per decode step (independent of "
                             "--tiered-stt-budget, which is how many are "
                             "physically resident). Bounds TieredKV's final "
                             "attention pool to sram_budget + this value, so "
                             "it can be matched exactly against a baseline's "
                             "--budget for a fair equal-attention comparison. "
                             "Default: promote_top_pages*page_size (32).")
    parser.add_argument("--tiered-promotion-budget", type=int, default=None,
                        dest="tiered_promotion_budget",
                        help="Maximum slow-tier rows promoted into VRAM per "
                             "layer and policy step. Attention exposure remains "
                             "controlled independently by --tiered-stt-expose. "
                             "Default 32 preserves the corrected control; 0 "
                             "disables migration while retaining slow attention.")

    args = parser.parse_args()
    
    # Checkpoint file lives next to the final JSON
    ckpt_path = args.checkpoint or (args.json + ".ckpt")
    os.makedirs(os.path.dirname(ckpt_path) or ".", exist_ok=True)
    
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    # Resolve and freeze the actual content before any comparison/resume.
    task_rows = {task: load_task_data(task, args.data_dir) for task in args.tasks}
    dataset_identity = {task: {
        "row_count": len(rows),
        "resolved_source": str(task_data_path(args.data_dir, task)) if args.data_dir else "hf_or_cached_fallback",
        "content_sha256": hashlib.sha256(json.dumps(rows, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
    } for task, rows in task_rows.items()}
    print(f"Loading model: {args.model}")
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        device_map=args.device,
        trust_remote_code=True,
        # Eager is required for output_attentions during DECODE (H2O/SnapKV/
        # TieredKV all score on real attention weights). Prefill runs under
        # SDPA instead -- see _attn_impl for why that is not optional.
        attn_implementation="eager"
    )
    model.eval()
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # FIXED: Budget allocation is now memory-fair
    # All methods get the same effective budget
    sink = 4
    recent = args.recent_size if args.recent_size is not None else max(16, args.budget // 8)
    
    # For TieredKV: split the budget between VRAM and STT-RAM. Default
    # (equal-TOTAL-budget comparison): VRAM gets 1/3, STT-RAM 2/3 of
    # args.budget -- same total memory as baselines, but only the VRAM
    # third was ever attendable in earlier runs of this harness, silently
    # giving TieredKV a 3x smaller effective context at "the same budget".
    # STT-RAM is now attendable too (see TieredKVPolicy._visible_tuple),
    # so pass --tiered-vram-budget/--tiered-stt-budget explicitly to run
    # the equal-VRAM comparison instead: same fast-tier bytes as a
    # baseline's full --budget, with a slow tier on top for genuinely more
    # visible context per VRAM byte -- the tiered design's actual thesis.
    tiered_vram = args.tiered_vram_budget if args.tiered_vram_budget is not None else args.budget // 3
    tiered_stt = args.tiered_stt_budget if args.tiered_stt_budget is not None else args.budget - tiered_vram
    
    # Config fingerprint: a checkpoint used to be resumed unconditionally --
    # any (task, method) pair already in the file was skipped with no check
    # that it was produced under the SAME --budget/--tiered-vram-budget/
    # --tiered-stt-budget/--tiered-stt-expose/--sttram-bifurcation-frac/
    # --model as the current run. Re-pointing --json at the same file after
    # changing one of those silently blended stale scores from the old
    # config into a results table whose "config" block claims the new one.
    config_fingerprint = {
        "model": args.model,
        "model_identity": model_artifact_identity(args.model),
        "aggregation": "sampled_task_mean; not official LongBench-E length-bin aggregation",
        "prefill_last_logits": args.prefill_last_logits,
        "budget": args.budget,
        "tiered_vram_budget": tiered_vram,
        "tiered_stt_budget": tiered_stt,
        "tiered_stt_expose": args.tiered_stt_expose,
        "tiered_promotion_budget": args.tiered_promotion_budget,
        "sttram_bifurcation_frac": args.sttram_bifurcation_frac,
        "sink": sink,
        "recent": recent,
        # max_samples and tasks were NOT fingerprinted before. Resuming a
        # checkpoint after changing --max-samples silently blended scores
        # computed over different numbers of samples into one table -- which
        # is exactly what happened to the sttram_bifurcation_frac sweep, where
        # frac=1.0 was measured on 25 samples/task and frac=0.25/0.5/0.75 on
        # 15, making the comparison uninterpretable. max_ctx matters for the
        # same reason: it changes every score.
        "max_samples": args.max_samples,
        "tasks": sorted(args.tasks),
        "max_ctx": args.max_ctx,
        "seed": args.seed,
        "tiered_kv_dtype": args.tiered_kv_dtype,
        "tiered_stt_kv_dtype": args.tiered_stt_kv_dtype,
        "tiered_prefill_chunk_size": args.tiered_prefill_chunk_size,
        # page_size / promote_top_pages are hardcoded in make_policy() above
        # and determine the DEFAULT stt_expose_quota (promote_top_pages x
        # page_size = 32). Fingerprint them so a future change of the
        # hardcodes cannot silently blend with old checkpoints.
        "page_size": 16,
        "promote_top_pages": 2,
        "tiered_promotion_budget": args.tiered_promotion_budget,
        "stt_live_floor": args.stt_live_floor,
        "write_aware_lambda": args.write_aware_lambda,
        "tiered_inclusive": args.tiered_inclusive,
        "runtime": runtime_identity(),
        "protocol": "reference_prompts_task_chat_v3",
        "data_dir": args.data_dir,
        "dataset_identity": dataset_identity,
        "dataset_sha256": ({t: hashlib.sha256(task_data_path(args.data_dir, t).read_bytes()).hexdigest()
                            for t in args.tasks} if args.data_dir else None),
    }

    # Load checkpoint so we can skip already-finished work
    all_results = {}
    if os.path.exists(ckpt_path):
        with open(ckpt_path) as f:
            all_results = json.load(f)
        stored_fp = all_results.get("_config_fingerprint")
        if stored_fp is not None:
            stored_fp = {"prefill_last_logits": False, **stored_fp}
        if stored_fp is None and not args.allow_checkpoint_mismatch:
            raise RuntimeError("Checkpoint has no fingerprint; use a new output path or explicitly allow mismatch")
        if stored_fp is None:
            print(f"  [WARNING] checkpoint {ckpt_path} predates config "
                  f"fingerprinting -- cannot verify it matches this run's "
                  f"config. Proceeding (will fingerprint from now on).")
        elif stored_fp != config_fingerprint and not args.allow_checkpoint_mismatch:
            raise RuntimeError(
                f"Checkpoint {ckpt_path} was produced with a different "
                f"config than this run:\n  stored:  {stored_fp}\n  "
                f"current: {config_fingerprint}\nResuming would silently "
                f"blend scores from two configs into one results table. "
                f"Pass --allow-checkpoint-mismatch to resume anyway, or "
                f"use a different --json/--checkpoint path."
            )
        print(f"Resuming from checkpoint: {ckpt_path}")
        for t, methods in all_results.items():
            if t == "_config_fingerprint":
                continue
            for m in methods:
                print(f"  [SKIP] {t} / {m} (already done, "
                      f"score={methods[m].get('score')})")
    
    # Run evaluation
    for task in args.tasks:
        print(f"\n{'='*60}\nTask: {task}\n{'='*60}")
        task_res = {}
        
        for mname in args.methods:
            # Skip if already completed
            if task in all_results and mname in all_results[task]:
                print(f"\n--- {mname} [SKIPPED — already in checkpoint] ---")
                continue
            
            policy = make_policy(mname, args)
            print(f"\n--- {policy.name} ---")
            
            is_instruct = "instruct" in args.model.lower()
            score, sample_scores = evaluate_task(
                model, tokenizer, task, policy, args.device,
                args.max_samples, is_instruct, max_ctx=args.max_ctx, data_dir=args.data_dir,
                prefill_last_logits=args.prefill_last_logits, dataset_rows=task_rows[task]
            )

            if task not in all_results:
                all_results[task] = {}
            all_results[task][mname] = {"score": score,
                                        "n": len(sample_scores),
                                        "sample_scores": sample_scores,
                                        "samples": policy.sample_records}
            
            # Store cache statistics if available
            if hasattr(policy, "stats"):
                all_results[task][mname]["cache_stats"] = policy.stats()
            
            print(f"  {policy.name} → {task}: {score:.2f}")

            # Save checkpoint immediately (fingerprint stamped every save so
            # a later resume can detect a config change -- see above)
            all_results["_config_fingerprint"] = config_fingerprint
            atomic_json(ckpt_path, all_results)
            print(f"  [checkpoint saved → {ckpt_path}]")

            # Long documents under eager attention (needed for output_attentions)
            # materialize an O(seq^2) attention matrix at prefill; across many
            # samples/methods in one long-running process this fragments
            # CUDA's allocator until a legitimate allocation fails even with
            # memory nominally free. Release cached-but-unused blocks between
            # methods -- doesn't change any result, just avoids a spurious OOM.
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
    
    # Print summary table
    print(f"\n{'='*60}\nLONGBENCH RESULTS (F1 × 100)\n{'='*60}")
    col_w = 14
    hdr = f"{'Task':<22}" + "".join(f"{m:>{col_w}}" for m in args.methods)
    print(hdr)
    print("-" * len(hdr))
    
    for task in args.tasks:
        row = f"{task:<22}"
        for m in args.methods:
            s = all_results[task].get(m, {}).get("score", 0)
            row += f"{s:>{col_w}.2f}"
        print(row)
    
    print("-" * len(hdr))
    avg_row = f"{'Average':<22}"
    for m in args.methods:
        avg = np.mean([all_results[t].get(m, {}).get("score", 0) 
                      for t in args.tasks])
        avg_row += f"{avg:>{col_w}.2f}"
    print(avg_row)
    
    # Save final results
    os.makedirs(os.path.dirname(args.json) if os.path.dirname(args.json) else ".", 
                exist_ok=True)
    output = {
        "config": {**config_fingerprint, "tasks": args.tasks, "methods": args.methods},
        "results": {k: v for k, v in all_results.items() if k != "_config_fingerprint"},
    }
    
    atomic_json(args.json, output)
    print(f"\nSaved → {args.json}")

if __name__ == "__main__":
    main()
