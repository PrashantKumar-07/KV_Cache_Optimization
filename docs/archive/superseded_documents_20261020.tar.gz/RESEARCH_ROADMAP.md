# TieredKV research roadmap (2026-09-24)

**Current checkpoint — early shared prefill (3 October):** 501 tests pass. Tiny GPU full-logit/KV parity and partial-failure cleanup pass; full-model4K/12 and16K/50 preserve predictions, state, counters and native transfers with all32 early roots and no fallback. Whole-prefill peak falls11.22% to16.5376GB; strict decode GPU active falls5.47%, scoped active including owned pinned/CPU is378.60MiB. Faithful Snap prefill ratio0.9840 passes. [Resource proof](results/hardware/early_shared_cpu_phase_v1/verified_resources.json). Initial resident KV matches341MiB at hot649/cold1982; candidate remains341MiB while Snap grows341–366MiB. Full-trajectory equality remains unresolved. Faithful-baseline quiet3ABBA timing **fails**: CPU54.59 vs Snap25.25ms/token (2.162x), p95CPU59.94 vs Snap25.47ms. TTFT+7.73% and prefill guards pass; median and p95 fail. All300 measured forwards/arm reproduce frozen predictions/state; CPU counters/native transfers and25 quiet observations pass. [Timing proof](results/hardware/early_shared_cpu_phase_v1/verified_cost.json), [figures](results/hardware/early_shared_cpu_phase_v1/figures/manifest.json). Candidate expansion/adoption stops under the preregistered gate; no favorable retry or final-holdout tuning. All owned jobs are terminal. Physical controller measurements, independent quality, generality and final delivery remain open. Repeated10–20day estimate withdrawn; full goal incomplete.

**CPU phase boundary and score-fallback checkpoint (3 October):** **498 tests pass**. Two reproduced regressions exposed a shared batched-score crash on multi-token attention. A single-query shape guard restores the ordinary scorer fallback. Real GPU appends of2/32 tokens preserve exact logits, KV data, metadata and slot order across7 boundaries, then return to native single-token phases. Transformers-owned lazy capture hooks are initialized before ownership checks; both failed harness attempts are preserved. [Fallback proof](results/hardware/cpu_phase_append_fallback_v1/verified_fallback.json).

Three full-model4K/50 checks preserve all predictions/state/counters/native KV: exclusive promotion24832 rows, floor-above-capacity protection, and50 write-aware fallback steps. Native cold reclaim executes1152 times. [Boundary proof](results/hardware/cpu_phase_boundaries_v1/verified_boundaries.json). Fresh current-source4K/12 parity also passes; current-source16K/50 resource and geometry proofs pass, scoped memory433.33 MiB. Fresh current-source3ABBA speed passes: **58.76 to54.12 ms median,7.89% gain/4.64 ms saved**, p95 improves8.87%, TTFT+1.37%. All300 measured predictions/arm, state/counters/native KV and25 quiet observations match. All owned jobs are terminal. The multi-query guard preserves existing ordinary scoring fallback; it does not redesign multi-query attention accumulation. [Current proof](results/hardware/cpu_phase_score_guard_v1/verified_status.json), [figures](results/hardware/cpu_phase_score_guard_v1/figures/manifest.json). Historical speed evidence below remains tied to its archived source.

The ownership audit confirms resident KV roots272.25 MiB constant across51 candidate boundaries versus faithful SnapKV487–512 MiB, growing0.5 MiB/step. Attention width1024 differs on49/50 steps. No fixed SnapKV prompt capacity can equal that constant allocation vector throughout decode. This is an unresolved comparison-design requirement, not permission to claim equality or pad allocations. [Geometry proof](results/hardware/cpu_phase_geometry_v1/verified_geometry.json). Full P0/P1/P2 remains open; no new day estimate.

**CPU phase controller integration (3 October):** **496 tests pass**, including seven integration checks. Native canonical CPU promotion, append and demotion are integrated with pooled GPU metadata and native KV transfers. Recorded 4K/12 matches all predictions, 13 state/visibility snapshots, counters and native KV traffic. All 384 layer transitions use the new CPU phases, with zero fallback. [Correctness proof](results/hardware/cpu_phase_controller_v1/verified_correctness.json).

Fresh 16K/50 matches frozen output/state/counters/native KV and passes scoped memory: **433.33 MiB including owned pinned and CPU array roots**, versus ordinary541.08 MiB. Prefill peak is unchanged. Quiet preregistered3ABBA speed gate **passes: 58.93 to54.09 ms median (8.22%,4.84 ms saved)**, p95 improves8.76%, TTFT+1.40%. All300 measured predictions/arm and frozen state/counters/native KV match;25 GPU quiet observations pass. Longer-context8K/31.5K teacher parity and forced cold256-row slot-recycling parity pass, each50 steps with native CPU phases and no fallback. Free-generation parity passes on all12 reused development documents across six tasks: exact tokens, scores, state, trajectory, counters and native KV. **597 native CPU phase steps/19104 layer transitions** execute with no fallback;174 additional native cold reclaims occur. All owned jobs are terminal. Joint faithful-baseline/quality gates remain open. Candidate remains research-only. Production defaults are unchanged. Full P0/P1/P2 remains incomplete; the unsupported day estimate is withdrawn. This checkpoint supersedes earlier statements that controller integration is unimplemented.

**Native CPU state phase checkpoint (3 October):** **489 tests pass**, including
30 focused phase checks. Fixed shared CPU owners hold hot/cold positions,
grace, shadow/resident flags, streaks and logical/free slot order. Native batch
operations perform promotion, hot append, complete demotion metadata updates
and cold compaction/reclaim. All malformed batch inputs reject before any
layer mutates; version and owner checks reject stale/foreign GPU commands.

All **1600 recorded layer transitions** replay exactly in50 native batches,
including2560 paid rows,23872 restored backups, F32 metadata commands and
physical slot order. Five GPU handoff fixtures across20 layers match original
cache payload/metadata bits, roots and padding: shadow-first reclaim, stable
LRU overflow, live-floor cover, exclusive promotion and eight-layer compaction.
Victim/cold-keep decisions are supplied; these fixtures do not independently
prove retention selection. GPU slot tensors emulate storage, not native host
transfers. Declared32-layer CPU owners are **1116896 bytes (1.065 MiB)**;
container/output/Python workspace and whole-model peaks remain unmeasured.

[Phase proof](results/hardware/cpu_state_transition_v1/verified_stage.json).
**Decode-controller integration remains incomplete.** Next attach canonical
CPU owners and consume these commands through promotion, demotion, native KV
transfers, visibility and cold reclaim, preserving unsupported fallback; then
run recorded model parity, actual resource and preregistered speed gates.
No speed/quality/adoption claim is established. All owned jobs are terminal;
production defaults and failed-candidate stops remain unchanged. Full P0/P1/P2
remains incomplete; day estimate withdrawn.

**CPU transition diagnostic and corpus (3 October):** Both fresh policy
profiles preserve all50 frozen predictions, final state, counters and native KV.
The0.836-second first extension load is already excluded by benchmark warmup;
it does not reverse the pooled controller's failed speed decision. Native
backup classification costs3.009 inclusive instrumented ms/step across1600
calls. Isolated backup batching is not justified as a4ms whole-loop fix.
Broader CPU state-transition work is the next mechanism, not another wrapper.

A recorded ordinary GPU run freezes **1600 layer transitions**. Independent
CPU/F32/slot replay is exact:2560 paid rows,23872 restored backups and1600
queued compactions. Positions, flags/streaks, metadata bits, logical/free slots
and outcomes match. The native backup classifier matches every record. This
corpus supports CPU-stage validation without repeated model launches per edit.
Cold occupancy reaches897/1090; no overflow occurs. Saturation/reclaim and
broader malformed/ragged/nonfinite fixtures remain mandatory.

[Diagnostic](results/hardware/pooled_controller_diagnostic_v1/verified_diagnostic.json),
[corpus](results/hardware/controller_transition_corpus_v1/verified_corpus.json),
[next phase plan](results/hardware/cpu_state_transition_v1/plan.json).
**Full CPU state-transition redesign is not implemented yet.** Existing459
unit tests remain passing; this checkpoint adds executable replay evidence,
not a speed/quality/adoption claim. All owned jobs are terminal; wrappers,
hooks and pinned roots release. Production defaults and failed-candidate
stops remain unchanged. Full P0/P1/P2 remains incomplete; day estimate withdrawn.

**Pooled controller integration checkpoint (3 October):** **459 tests pass**.
The research controller now uses fixed GPU metadata owners, fused age/tail
preparation and bounded KV/F32 compaction. Recorded 4K/12 preserves all
predictions, 13 visibility/state frames, counters and native KV traffic;
12 pooled preparations and 48 compaction groups execute with no fallback.
Fresh 16K/50 also matches frozen predictions/state/counters/native KV.
Scoped active memory is **432.10 MiB** versus ordinary541.08 MiB (20.14% less);
with conservative CPU array roots it is432.27 MiB, below512 MiB. The417792-byte
GPU arena and descriptor work are charged by GPU peaks. Pooled descriptors
upload6457600 logical bytes per50-step trial, separately from KV traffic and
5555328 timestamp-rank descriptor bytes. Prefill peak is unchanged.

[Correctness proof](results/hardware/pooled_controller_v1/verified_correctness.json),
[resource proof](results/hardware/pooled_controller_v1/verified_resource.json).
Quiet3ABBA is complete: median **58.06 to61.54 ms (6.00% slower,3.48 ms
added)**. Both speed primaries fail; p95 +0.67% and TTFT +0.87% pass. All300
measured forwards per arm replay frozen predictions/state/counters/native KV;
all25 quietGPU0 observations pass. **Stop pooled controller expansion/adoption.**
No favorable timing retry or wider quality/baseline expansion for this candidate.
[Timing decision](results/hardware/pooled_controller_v1/verified_cost.json).
All owned jobs are terminal and hooks/leases/pinned roots release. Production
defaults are unchanged. Full P0/P1/P2 remains incomplete; day estimate is
withdrawn. Primitive proof remains historical component evidence, not full
model proof. Two failed startup attempts are retained, including the corrected
generated-helper name collision; neither measured candidate timing.

**Native controller prototype (3 October):** **437 tests pass**, including
36 focused native core/integration checks. A native CPU module, built with
existing Torch headers and system g++, computes cross-layer promotion plans,
hysteresis/live-floor transitions, backup classification and read addresses.
The research policy also groups timestamp ranking by identical live length,
using the verified fused gather and original unstable CUDA argsort. Grouped
sorting matches separate GPU sorting in 44 fixtures, including ties/nonfinite
values. No process-global patch, retention change or new dependency is used.

The recorded 4K/12-step GPU pair preserves all predictions, 13 cache/visibility
frames, counters and native KV transfers. There are 12 native plans, 384 backup
classifications, 25 address calculations and no planning fallback. Fresh
16K/50 matches all predictions, final state, counters and native KV traffic.
Scoped active memory is **432.12 MiB** versus ordinary 541.08 MiB (20.14% less),
passing the 512 MiB ceiling; with conservative CPU array roots it is432.29 MiB.
Prefill peak is unchanged; C++/Python allocator internals remain unmeasured.
Timestamp rank descriptors upload **5.555 MB** per measured trial; bounded
ownership descriptors derive12.864 MB. These are separate from native KV and
are charged by timing/GPU peaks. Quiet3ABBA is complete: median **57.92 to 62.80 ms (8.43% slower, 4.88 ms
added)**; p95 **64.38 to 66.79 ms (3.74% worse)**. TTFT +0.25% passes. All
300 measured forwards per arm replay frozen predictions, final state, counters
and native KV traffic; all25 quietGPU0 observations pass. **Stop native
controller expansion/adoption:** both speed primaries and p95 fail. No favorable
timing retry or wider quality/baseline expansion for this implementation.
[Timing decision](results/hardware/native_controller_v1/verified_cost.json).
All owned jobs are terminal; hooks, leases, methods and pinned roots release.

The native core proves promotion, backup and address calculations, not the full
controller gate. Promotion/address/ranking are grouped; backup classification
still enters native code once per layer. Complete transition pooling remains
unimplemented. Combining wrappers around the existing layer state has failed
the joint gate; the next mechanism must redesign the complete hot/cold state
layout and account for retention/quality, rather than expand these wrappers. Descriptor uploads and CPU arrays
must be reported separately from native KV transfers. Failed ownership-only
candidates remain stopped; production defaults are unchanged. Full P0/P1/P2
remains incomplete; the unsupported day estimate stays withdrawn.

**Bounded deferred ownership checkpoint (3 October):** **401 tests pass**,
including 16 focused checks. A distinct research transition defers compaction
when cold reclamation is unnecessary; overflow preserves immediate compaction.
Two passes of the existing verified native kernel gather to separate scratch
and copy back safely. Groups contain at most eight layers. GPU 4K/12 matches
all 12 predictions, 13 cache/visibility frames, counters and native KV traffic.
There are 384 deferred compactions in 48 groups, no immediate compactions or
append fallbacks, and scratch is bounded at **30.97 MiB**. Fresh 16K/50 exactly replays frozen predictions, final state, counters and
transfers. Scoped active memory is **432.12 MiB**, **20.14% lower** than ordinary
541.08 MiB, passing both the 512 MiB ceiling and 10% reduction gate. Prefill
peak is unchanged. Quiet 3ABBA is complete: median **58.33 to 63.09 ms (8.15% slower)**,
p95 **64.77 to 70.88 ms (9.43% worse)**; TTFT +0.36% passes. All 300 measured
forwards per arm exactly replay predictions, state, counters and native KV
traffic; 25 quiet GPU0 process checks pass. **Stop bounded deferred ownership
expansion/adoption:** speed primaries and p95 fail. No favorable timing retry.
[Timing decision](results/hardware/bounded_deferred_ownership_v1/verified_cost.json).

Reporting correction: the copied timing verifier's zero extra metadata scalar
is false. The native wrapper uploads descriptors: fixed geometry/source derives
**12.864 MB and 1200 upload calls per measured candidate trial**. These are
separate from native KV manager bytes/calls; total extra versus ordinary was
not independently instrumented. Timing and memory charge the descriptor work.
The original artifact remains retained and the failed decision is unchanged.
[Correction](results/hardware/bounded_deferred_ownership_v1/verified_descriptor_reporting_v2.json).
All owned jobs are terminal; hooks, instance methods and pinned roots release. Failed predecessors remain
stopped. [Correctness](results/hardware/bounded_deferred_ownership_v1/verified_correctness.json).
Next target is broader controller consolidation; bounded grouping alone has
failed to deliver a joint win. Do not expand this failed implementation. Production defaults are
unchanged; full P0/P1/P2 remains incomplete and the day estimate is withdrawn.

**Current regression diagnostic (3 October):** fresh paired GPU0 policy profiles
preserve all 50 predictions, final state, counters and native transfers in each
arm. Shared ownership performs **1600 per-layer in-place gathers**; ordinary
bulk performs **50 batched native gathers**. Instrumented compaction is
6.76 ms/decode versus 3.12 ms for ordinary compaction preparation; ordinary
native gathering adds 0.75 ms in its visibility boundary. Shared reservation
and hot extension also add validation/copy work. These overlapping profile
ranges are localization evidence, not a causal savings estimate or timing gate.

The code trace establishes the ordering constraint: after demotion, cold
reclaim requires compacted hot positions and scores; it does not read compacted
hot KV. A distinct ownership implementation could defer payload gathering with
bounded, alias-safe scratch. However, the ordinary controller still spends
instrumented time in preparation (10.96 ms), eviction (11.75 ms) and visibility
(9.86 ms); these ranges overlap and cannot be added as savings. Nearly one
million calls per 50 steps remain. Removing this regression alone would not
prove the required speed win or close the faithful-baseline gap.
[Verified diagnostic](results/hardware/shared_transition_diagnostic_v1/verified_diagnostic.json).

Next target is broader controller consolidation, with a preregistered complete
mechanism and actual whole-loop/resource/quality gates. Do not repeat the failed
shared implementation or promote a profile as a benchmark. All owned jobs are
terminal; production defaults are unchanged. Full P0/P1/P2 remains incomplete;
the unsupported day estimate remains withdrawn.

**Shared ownership milestone (3 October):** **385 tests pass**, including 11 focused
unified-transition checks. The GPU 4K/12-step pair matches all predictions,
13 cache/visibility-state frames, counters and native KV traffic. Fresh 16K/50
matches the frozen ordinary predictions, final state, counters and transfers.
Unified model append, promotion and immediate compaction share consumed buffers.
Scoped active memory falls **541.08 to 415.16 MiB (23.27%)**, passing both the
512 MiB ceiling and 10% reduction gate. This includes the owned 256 MiB pinned
allocator block; it excludes constant model storage and unowned process memory.
Whole reserved envelope remains 5089.49 MiB; prefill peak remains 18.62783 GB.
[Resource proof](results/hardware/shared_decode_transition_v1/verified_resource.json).

The standalone append reservation was stopped at **531.00 MiB**, below neither
512 MiB nor a 10% reduction. Its failure is preserved separately.
[Standalone stop](results/hardware/reserved_decode_append_v1/verified_resource.json).
Quiet 3ABBA timing is complete: median decode **58.84 to 64.13 ms (8.98%
slower, 5.28 ms added)**; p95 **64.55 to 69.32 ms (7.38% worse)**. TTFT +0.78%
passes. All 300 measured forwards per arm replay predictions, final state,
counters and native KV transfers; 25 quiet GPU0 observations pass. **Stop
unified-transition expansion/adoption:** both speed primaries and the p95 guard
fail. No favorable timing retry or wider quality/baseline run for this failed
candidate. [Timing proof](results/hardware/shared_decode_transition_v1/verified_cost.json),
[measured tradeoff](results/hardware/shared_decode_transition_v1/ownership_tradeoff.pdf).
All owned jobs are terminal; leases, hooks and pinned roots release.

The memory obstacle is resolved only for this experimental design and measured
scope. The joint memory/latency/quality acceptance gate remains open. Next
localize the added cost of consumed-buffer compaction before proposing another
mechanism; do not widen this failed implementation. Independent quality, current
faithful baselines and physical hardware evidence remain open. Full P0/P1/P2
is incomplete; the unsupported 10–20-day forecast remains withdrawn.

**Current CPU timestamp decision (3 October):** **358 tests pass**, including
11 focused checks. Cold timestamp transitions move toCPU; oneGPU snapshot
pervisibility boundary preserves the originalGPU unstabletie sorting.
GPU4K12 matches12predictions,13cache/visibility-state frames, counters and
nativeKVbytes/calls; eightGPU tie-order cases pass. Native kernels, ranking,
retention, cache storage and ordinary source/CLI/defaults are unchanged.
[Correctness](results/hardware/cpu_lru_metadata_v1/verified_correctness.json).

Fresh16K50 replays all frozenpred/state/counters/nativeKVpayload/calls.
Extra timestamp H2D **5.692MB** / initialD2H **0.1046MB** are charged separately;
newCPU timestamp+temporarypacked tensor peak is229632bytes. Scoped active
memory becomes **541.19MiB** versus541.08MiB ordinary; reserved5089.71MiB and
prefill18.62783GB. This passes576MiB pilot, **fails512MiB**; CPUmallocrounding/
otherhostretention remains unmeasured.
[Resource proof](results/hardware/cpu_lru_metadata_v1/verified_resource.json).

Quiet3ABBA whole-loop median **57.85→57.34ms (0.88% faster,0.51ms saved)**;
p95 **64.46→61.51ms**, TTFT+0.09% pass. All300 measuredforwards/arm replay
pred/state/counters/nativeKVtraffic/calls and candidate timestampcopies;
25 before/after quietGPU0 checks pass. **Both >=5% and >=4ms primaries fail.
Stop standalone CPUtimestamp expansion/adoption**, with no favorabletiming
retry or widergeneration/quality/faithfulbaseline run for this candidate.
[Timing/stop proof](results/hardware/cpu_lru_metadata_v1/verified_cost.json),
[figure](results/hardware/cpu_lru_metadata_v1/timestamp_tradeoff.pdf).

All owned jobs are terminal; temporarymirrors and pinned roots release.
The failed projection/timestamp-only screens leave broader hot/cold transition
and ownership restructuring as the target; require a preregistered complete
mechanism with whole-loop/resources and eventualfaithfulbaseline/quality gates.
FullP0/P1/P2 remains open; the unsupported10–20-day forecast stays withdrawn.

**Current ordinary-backend screen (3 October):** **347 tests pass**, including
19 focused projectedscore/victim cases. The research coordinator prepares
victim score/age projections once across layers rather than creating temporary
CUDA tensors per layer. SixGPU cases preserve projection bits/victims for
ragged/nonfinite/grace inputs and1/4/32-token appends. Original ranking, stable
ties, protection, promotion, cache types and unsupported fallback stay intact.

Charged complete preparation+selection 3ABBA yields **3.419→2.686ms**,
only **0.733ms saved** against the >=4ms gate. Candidatep95 **5.831ms** versus
control3.502ms (**1.665×**) fails its guard; all three medians improve and
25 before/after quietGPU0 checks pass. **Stop this projection-only candidate**
before fullmodel/resource/timing/quality expansion. CPU/GPU stage equality
is not proof of fullmodel candidate preservation or a mainlatency-gate win.
Ordinary source/CLI/defaults are unchanged; all owned jobs are terminal.
[Verified screen](results/hardware/batched_eviction_projection_v1/verified_stage.json).

The screen localizes preparation's limits: the broader eviction/demotion,
layer-state transitions and synchronization remain the structural target.
Next preregister a complete state-transition mechanism; do not retry this
failed stage or widen failed fullquery candidates. FullP0/P1/P2 remains open;
the unsupported10–20-day forecast stays withdrawn.

**Current critical-path diagnostic:** the GPU0 ordinary-bulk16K/50-step
profile replays every frozen prediction, finalcache, logicalcounter and native
payload/call total. All owned jobs are terminal; hooks and pinned roots release.
About967,000 policy calls take1.920s under instrumentation. Eviction/demotion
is11.48ms/decode; read preparation11.10ms and visibility9.94ms are overlapping
cumulative ranges, not additive speed estimates. Native visible gathering is
0.76ms/decode. Next preregister cross-layer eviction/demotion bookkeeping
consolidation on the ordinary backend and require preserved state/selection/
transfers plus whole-loop/resource gates. Fullquery derivatives remain stopped.
[Verified critical path](results/hardware/completion_critical_path_v1/verified_audit.json).

**Completion plan correction (3 October):** the repeated **10–20 days** estimate
is withdrawn; it was not recalculated from the remaining gates. Earlier
estimates below are historical and must not be treated as a current forecast.
[Critical-path audit](results/hardware/completion_critical_path_v1/audit.json)
separates failed research gates from incomplete deliverables and external hardware.
The existing ordinary CPU backend is541.08MiB versus528.74MiB SnapKV; both
exceed512MiB and attention widths differ on49/50steps. A frozen older faithful
latency study is60.56 versus25.83ms (2.34×); its independent quality comparison
also fails NI. These studies do not prove current bulk quality or a joint win.
PhysicalSTT/controller energy/endurance remains unavailable and unproven.

Execution priority: profile the current ordinary bulk/lastlogits backend with
frozen50-step state/prediction/payload replay; address one structural bottleneck
that can close a main memory/latency gate. Keep failed fullquery derivatives
stopped. Then verify actual resources before expanding independentquality and
baselines; prepare reproducibility/manuscript artifacts alongside those gates.
No full completion date is supported until the research and hardware gates resolve.

**Current channel-reader decision (3 October):** **328 tests pass**. An exact
native reader scans existing cold keys and fetches only selected cold values;
query/ranking math is unchanged. GPU4K/12-step pairs replay all predictions,
13 logit/cache/counter frames,384 selections and both arms' destination/prefix
ownership. Native BF16/FP16/F32 and36 metadata guards, stream/pool/root cleanup
pass. [Correctness](results/hardware/query_channel_reads_v1/verified_correctness.json).

Fresh16K/50-step replay verifies **45.53% less copied K/V payload**
(**5.826→3.173GB**), unchanged D2H115.86MB and index copies75.33MB. NativeH2D
calls increase1701→3301. Active decode remains **545.17MiB**, above512MiB but
within the576MiB pilot; reserved5089.49MiB, prefill18.62783GB and roundedhost
256MiB are unchanged. This measures copied nativeKV payload, not all library
transfers or physicalPCIe/STT reads.
[Resource proof](results/hardware/query_channel_reads_v1/verified_resource.json).

Quiet3ABBA component comparison yields **97.48→93.02ms (4.57% faster,
4.46ms saved)**; p95100.49→95.90ms and TTFT+0.05% pass. All300 measured
forwards/arm replay frozenpred/state/counters and each arm's payload/calls;
25 quiet-process checks pass. **The >=5% primary fails. Stop standalone
channel-reader expansion/adoption.** No fresh ordinaryLRU or independentquality
expansion follows this failed gate; no favorable timing retry.
[Timing/stop proof](results/hardware/query_channel_reads_v1/verified_cost.json),
[figure](results/hardware/query_channel_reads_v1/channel_tradeoff.pdf).

Ordinary source/CLI/defaults are unchanged by this mechanism; all owned jobs
are terminal and own hooks/index metadata/pinned roots release. Full512MiB,
matched baselines, independentquality, physicalSTT and P0/P1/P2 remain open.
Next preregister a distinct mechanism targeting the remaining query-loop or
synchronization cost, then require correctness/resources/component/LRU gates.
Estimate **10–20 working days**, conditional on hardware/research outcomes.
Earlier checkpoints below are historical evidence, not current next actions.

**Current visible-buffer decision (3 October):** **306 tests pass**. The
research selector retains the existing visible hot prefix and writes only
selected cold rows. GPU4K/12-step pairs exactly replay predictions, all logit/
cache/counter frames,384 visible-K/V selections and transfer metadata;384
candidate destinations retain their identity, offset and strides. Canonical
hot K/V remain unchanged and own hooks/index metadata release.
[Correctness](results/hardware/query_visible_suffix_v1/verified_correctness.json).

Fresh16K/50-step resource replay passes the576MiB pilot at **545.17MiB**,
versus547.49MiB query concat. This still exceeds512MiB; reserved5089.49MiB,
prefill18.62783GB and roundedhost256MiB are unchanged. NativeKV H2D remains
5.826GB, plus75.33MB of separately charged index copies. Three omitted native
source files were added in a SHA-matched supplemental archive; original source
archive and verifier are preserved. [Resource proof](results/hardware/query_visible_suffix_v1/verified_resource_v2.json).

Quiet3ABBA component comparison passes: **105.32→97.05ms (7.85% faster,
8.27ms saved)**, p95108.21→99.88ms; TTFT+0.34% passes. Frozen states, predictions,
counters, native bytes/calls and metadata replay;25 quiet-process checks pass.
But fresh ordinaryLRU comparison fails: **57.87→97.56ms (1.686×)**,
p9564.51→100.59ms (1.559×); TTFT+0.46% passes. **Stop standalone suffix-query
expansion/adoption.** The component improvement remains research-only.
[Component proof](results/hardware/query_visible_suffix_v1/verified_cost.json),
[LRU stop decision](results/hardware/query_visible_suffix_v1/verified_lru.json),
[comparison figure](results/hardware/query_visible_suffix_v1/suffix_tradeoff.pdf).

Next preregister a distinct lower-traffic reader: keys for ranking, values only
for selected rows, preserving existing Q/ranking/selection math. Ordinary source/
CLI/defaults are unchanged; all four owned GPU jobs are terminal. Full512MiB,
actual matched baselines, independent quality, physicalSTT and P0/P1/P2 remain
open. Estimate **10–20 working days**, conditional on hardware/research outcomes.

**Current diagnostic decision (3 October):** **287 tests pass**. The saved
16K/50-step GPU-query diagnostic replays the frozen prediction/state/counter/
transfer assertions. A corrected summary verifies **eight CPU phases, 1,600
observations each**, excluding six duplicate GPU annotation spans. All owned
jobs are terminal and own hooks/index metadata are released.

Visible-K/V composition is the largest instrumented CPU range: **15.89 ms per
decode**, including launch/waiting/profiler overhead. This is localization,
not a speedup estimate. Chrome export did not run; native GPU-kernel attribution
is incomplete. Failed reports and source archives are preserved.
[Diagnostic evidence](results/hardware/query_phase_profile_v1/verified_summary.json).

Next: preregister visible-buffer reuse with cold-row-only updates, then prove
ownership/parity/resources before component and ordinary-LRU latency gates.
The standalone fullscan candidate stays stopped at **1.810× median / 1.679×
p95** despite its **24.61%** read-index component improvement. Full512MiB,
actual matched baselines, independent quality, physical STT and P0/P1/P2 remain
open. Estimate **10–20 working days**, conditional on hardware/research outcomes.

**Current status (3 October):** batchedGPU native read indices preserve
query behavior and pass **283tests**, native3dtype/stream/pool/cleanup and
547.488MiB/576pilot resource checks. Component3ABBA median improves24.61%,
but freshordinaryLRU guard fails1.810×median/1.679×p95. **Stop standalone
full-query expansion/adoption.** KVreads5.826GB plus75.33MBcandidate metadata
charged; no totalH2D saving claim. Next inspect fusedranking/lower-traffic
retrieval/GPU selected-row indices. Ordinary source/CLI/defaults unchanged;
full512MiB/actualmatching and P0/P1/P2 remain open. Estimate10–20 working days,
conditional on hardware/research. [Current evidence](PROJECT_STATUS.md).

**Verified actual-resource audit (3 October):** fresh full-model GPU runs
with the adopted last-prefill-logit option reproduce all 50 frozen predictions
for ordinary bulk TieredKV and faithful SnapKV. Direct observations cover
**3200 layer-forward widths**: TieredKV uses1024 rows throughout, while SnapKV
grows975–1024;49/50 steps differ. Measured decode GPU allocation excluding
constant model storage is285.08MiB for TieredKV plus256MiB owned pinned capacity,
versus528.74MiB GPU-only for SnapKV. Combined active envelopes are therefore
**541.08 / 528.74MiB**; both exceed512MiB. Combined reserved envelopes are
**5089.49 / 2881.49MiB**, and whole-prefill peaks **18.6278 / 16.9583GB**.
CPU state/counters/transfers/phase peaks exactly replay its frozen ordinary run;
adapter groups/hooks and all owned roots are released. Both GPU jobs finished.
**Actual bytes and widths are unequal: the matched-resource P0 gate remains open.**
This audit supplies no new timing or independent quality result; the frozen
older DirectCPU NI failure remains separate evidence. Ordinary source is
unchanged and262-test validation remains current. Next preregister a comparison
that controls actual allocation ceilings and observed attention geometry before
quality/latency reruns. Full P0/P1/P2 remains open. Estimate **10–20 working days**,
conditional on hardware access and research outcomes.
[Verified actual-resource comparison](results/hardware/snap_actual_envelope_v1/verified_report.json).
[Diagnostic figure](results/hardware/snap_actual_envelope_v1/resource_gap.pdf).

**Verified layerwise-prefill experiment (3 October):** placing future KV
one layer at a time, while returning full raw KV to current prefill attention,
reduces the measured whole-prefill peak **18.6278 → 16.7095 GB (10.30%)**.
Eight tiny real-Mistral pairs preserve full prefill/decode logits, cache/state
and counters; partial-error reset and hook cleanup pass. The full GPU control
replays frozen ordinary results, and the candidate preserves all 50 predictions,
state, counters and transfer bytes/calls. Both jobs finished and roots/hooks
released. The 10% memory primary passes, but GPU-only decode active allocation
excluding constant model storage increases **285.08 → 291.65 MiB (2.31%)**,
failing the 2% guard. Including the unchanged 256 MiB pinned host capacity gives
**541.08 → 547.65 MiB (1.22%)**; that wider denominator does not establish the
stricter guard. **Research tradeoff only: stop expansion and ordinary adoption.**
Second geometry, GPU generation and timing runs are not launched. Ordinary
source is unchanged; existing **262-test** validation remains current. Next
return to P0 actual-resource matched quality/latency. Full P0/P1/P2 remains open;
estimate **10–20 working days**, conditional on hardware and research outcomes.
[Verified tradeoff and stop decision](results/hardware/layerwise_prefill_placement_v1/verified_guard_review.json).

**Verified GPU allocation diagnosis (3 October):** the unchanged 16K
Mistral prefill reaches **18.6278 GB** at the final MLP multiplication,
while retaining **2048 MiB** of full prompt KV. Each MLP operand/product
is **448 MiB**. Query scoring is not the origin of the first global peak.
Two accepted observers replay all 50 predictions, policy state, counters,
transfers and phase peaks against the frozen uninstrumented ordinary run.
Diagnostic hooks and roots are released; two initial cleanup assertion failures
are preserved and traced to 64 native Transformers output-capture hooks.
The accepted run establishes those native hooks before the strict baseline.
All four owned GPU jobs finished. Ordinary source is unchanged; the existing
**262-test** validation still applies. This is allocation diagnosis, not a
measured optimization. The layerwise experiment above now tests that mechanism
and stops on its decode-memory guard; continue actual-resource comparisons. Actual resource equality, matched
quality/latency, physical STT and full P0/P1/P2 remain open. Estimated remaining
effort: **10–20 working days**, conditional on hardware and research outcomes.
[Verified allocation audit](results/hardware/prefill_allocation_audit_v1/verified_report.json).

**Verified fixed-stream profiler fix:** FullCache, StreamingLLM, H2O and
SnapKV now profile fixed teacher tokens without requiring TieredKV's STT
counter keys. Policy counter deltas are emitted when available; `decode_steps`
counts measured model forwards. Only counter reporting changed. **262 tests
pass** after reproducing all four failures. Full Mistral GPU validation covers
five policies, both prefill-logit settings, warmup and repeated trials, with
**390 observed forwards** following the exact token stream and positions.
The ordinary bulk path replays archived predictions, cache/state histories,
transfer bytes/calls and counter deltas. The owned GPU job finished. These are
schema/preservation checks; budget-matched quality/latency and full resource
equality remain open. The allocation audit above resolves the next diagnosis;
continue actual-resource comparisons after the stopped layerwise experiment. Full P0/P1/P2 remains
open; estimate **10–20 working days**, conditional on hardware/research gates.
[Verified profiler fix](results/hardware/baseline_profile_counters_v1/verified_report.json).

**Verified ordinary opt-in integration:** `--prefill-last-logits` is wired
through the LongBench evaluator, ordinary bulk/query evaluator, latency profiler
and fresh-memory caller. It requires explicit native `logits_to_keep` support;
the default remains disabled. The evaluator fingerprints the option and treats
legacy checkpoints without it as disabled. **252 tests pass**, including chunk,
EOS, token-limit, unsupported-model and profiler cases; all four CLI help checks
pass. Real ordinary-bulk Qasper runs with the flag off/on preserve the answer,
score and transfer/payload counts. Real fresh-memory CLI runs at both capacities
preserve the frozen prototype predictions/state/counters/transfers. The guarded
research memory results are **64.36% / 54.72%** reductions of active decode
scope; whole-request prefill remains **18.6278 GB**. Both monitored 3-ABBA timing
runs passed median/p95/TTFT/peak regression guards on a quiet GPU. All **24
actual API generation pairs** preserve 16 fields and replay **48 frozen rows**;
all owned jobs finished. The option is **adopted as an ordinary opt-in**, with
legacy-disabled checkpoint resume and enabled-mismatch rejection verified.
Shared/usual active envelopes remain **541.08 / 806.50 MiB**, and reserved scope
**5089.49 / 5345.49 MiB**; complete 512 MiB equality is not achieved. Full
P0/P1/P2 remains open. The fixed-teacher baseline counter error was
subsequently resolved in the current proof above; continue actual-resource
matched quality/latency work. Estimate **10–20 working days**,
conditional on hardware access and research gates.
[Verified ordinary integration](results/hardware/prefill_last_logits_integration_v1/verified_final_status.json).
[Verified prototype timing](results/hardware/prefill_last_logits_v1/verified_timing.json).

**Frozen last-prompt-logit pilot:** a preregistered research wrapper uses
Mistral's native `logits_to_keep=1` for prefill only. The frozen pilot left ordinary source/defaults
unchanged. Seven tiny-Mistral branch cases preserve outputs/cache/counters.
Two fresh GPU processes at 991/1090 capacities preserve all 50 predictions,
state, counters and transfers, replaying frozen ordinary controls. The active
decode envelope falls **1518.29 to 541.08 MiB (64.36%)**, passing the 10%
primary. Reserved scope falls **6089.49 to 5089.49 MiB**. Whole-request prefill
peak stays **18.6278 GB**, and complete 512 MiB equality is still unproved.
Usual capacities 1024/2048 also pass: **1781.31 to 806.50 MiB (54.72%)**;
reserved scope is **5345.49 MiB**. All **24 generation pairs** across six tasks
and both geometries preserve 16 fields and replay **48 frozen ordinary rows**.
All six untimed GPU jobs finished. Both preregistered monitored 3-ABBA TTFT/decode
checks subsequently passed on a quiet GPU; ordinary integration is verified
above. Full P0/P1/P2 and complete resource equality remain open.
[Preservation proof](results/hardware/prefill_last_logits_v1/verified_preservation.json).
[Verified shared resources](results/hardware/prefill_last_logits_v1/verified_resources_shared.json).

**Verified caller lifetime fix:** the ordinary generator releases the unused
prefill output after selecting its first token; the fresh teacher-stream caller
releases it before decode. A tiny Mistral regression reproduced the bug in
normal and chunked prefill; **243 tests now pass**. Two fresh GPU processes
preserve all 50 predictions, state, counters and transfers. Weak storage handles
confirm the **1000 MiB** prefill logits expire before the first decode.
The unchanged phase peak improves only **1536.64 to 1518.29 MiB (1.19%)**,
failing the 10% primary: its scope includes the handoff before output release.
Reserved scope remains **6089.49 MiB** and prefill peak **18.6278 GB**.
Keep the lifetime fix; stop its expansion as a phase-memory optimization.
All **24 archived/current generation pairs** across six tasks and both
geometries match in all 16 integrity fields and replay **48 frozen ordinary
bulk rows**. All four owned GPU jobs finished. Ownership prototypes remain
research-only. Local Mistral source supports computing only the last prompt
logits; that option is not implemented or measured. Preregister its independent
preservation/resource gates next. Full P0/P1/P2 completion remains open.
[Combined preservation proof](results/hardware/prefill_output_release_v1/verified_report.json).
[Verified caller resources](results/hardware/prefill_output_release_v1/verified_resources.json).

**Previous frozen caller portability decision:** the frozen ownership prototype
preserves all 50 fixed-stream predictions, final state, counters and transfer
bytes/calls in the fresh generation caller. Its active decode envelope falls
**1536.64 to 1410.90 MiB (8.18%)**, below the 10% primary; both exceed 512 MiB.
Reserved scope stays 6089.49 MiB and prefill peak stays 18.6278 GB. Both arms
retain 1000 MiB of prefill logits through the first decode. Stop usual-caller,
timing and ordinary integration expansion for this variant. The earlier
20.7–21.2% legacy-caller result remains valid within its narrower scope.
Next investigate unused prefill-output ownership in the generation caller.
Both owned audit jobs finished; frozen helpers and ordinary defaults unchanged.
[Verified fresh-caller decision](results/hardware/fresh_prefill_owner_v1/verified_report.json).

**Latest prefill ownership pilot:** all eight paired contexts preserve outputs,
state and transfers. Sharing the initial hot payload lowers the measured active
decode envelope **20.7–21.2%** at 991/1090 capacities and **14.0–14.1%** at
1024/2048. Shared active storage is about **411 MiB**; usual active storage is
**672–673 MiB**. Reserved scopes exceed 512 MiB in both geometries, and prefill
peaks are unchanged. **236 tests pass.** Mandatory timing checks remain; this is a serial research prototype with no ordinary/default change.
GPU 0 has an unrelated workload, so timing awaits a quiet measurement window.
[Verified pilots](results/hardware/prefill_owner_share_v1/verified_pilot.json).

**Generation preservation:** all 24 pairs across six tasks and both geometries
match the ordinary bulk path and replay all 48 frozen rows. All 1,213 candidate
forwards restore ownership and request hooks are removed. Reused development
data only; timing and complete-resource gates remain open. Scoped GPU lifetime
is verified below.
[Generation proof](results/hardware/prefill_owner_share_v1/verified_generation.json).

**Boundary/recycling preservation:** all 40 saturation and append cases and
six serialized interleaved/recycled requests pass. All 102 boundary frames
match; all 18 request rows replay frozen controls. Every scoped lease restores
its active request and hooks are removed. All owned preservation jobs finished.
Quiet-GPU timing remains open; scoped GPU lifetime is verified below. No
ordinary adoption or complete 512 MiB claim.
[Batch proof](results/hardware/prefill_owner_share_v1/verified_report.json).

**Scoped GPU lifetime gate passes:** 14 checks preserve every BF16/F32 payload
bit, untouched tails, released owners under allocation pressure, and GPU hook
restoration after normal and partial toy DynamicCache forwards. Two consumers
run serially with explicit caller events and `record_stream`. This does not
establish automatic stream handoff, concurrent serving or full Mistral exception
compute. Frozen prototype sources stay unchanged. Clean timing remains pending.
[Lifetime proof](results/hardware/prefill_owner_share_v1/verified_lifetime.json).

**Previous ownership decision:** forward-owner release preserves all four
shared-budget pairs and 1,536 layer releases/restorations. Active decode
envelopes fall **3.29–3.86%**, below the 10% gate, and remain **518–521 MiB**.
The 4K diagnostic locates the peak during first pre-forward validation;
release then removes about128 MiB of live GPU allocation. Reject advancement.
That diagnosis supported the prefill ownership pilot reported above.
**Suite at that milestone:227 tests pass.** [Verified decision](results/hardware/forward_owner_release_v1/verified_report.json).

**Previous memory decision:** the isolated raw-input-reuse prototype preserves
all four shared-budget context pairs, but decode active envelopes stay about
**539 MiB**; every 10% memory primary fails. A 4K phase audit confirms
384 bindings/compactions and about128 MiB released after forward. The peak is
already reached during forward (step2), so post-forward reuse is insufficient.
Stop before usual-budget/timing/generation/CLI expansion. **Suite at that milestone:
217 tests passed.** [Verified rejection](results/hardware/raw_input_reuse_screen_v1/verified_report.json).

**Earlier verified diagnosis:** 3,072 layer checks across 4K/8K/16K/31.5K
and both capacities confirm the incoming raw KV already contains the exact hot
prefix and has room for actual promotions plus new tokens. All 16 rows replay
frozen outputs/state/counters/transfers; **206 tests passed at that milestone**. This supports an
isolated buffer-reuse prototype, not a memory gain or safe in-place mutation
claim. [Prefix/ownership proof](results/hardware/decode_prefix_audit_v1/verified_report.json).

**Earlier screen decision:** charged per-token CUDA cache release is rejected.
It releases **104 MiB at the final boundary**, but lowers decode reserved
**peak by 0%**. The observed reserved envelope stays **519.74 MiB**, above
512 MiB. State, predictions, transfers and counters match; both host roots
release; **206 tests passed at that milestone**. Stop before timing/generation/CLI advancement.
[Verified decision](results/hardware/decode_reclaim_screen_v1/verified_report.json).

**Earlier resource audit:** six GPU 0 processes are finished and independently
verified. Bulk/control outputs, cache state and fresh-process GPU peaks match.
Current ordinary paths exceed the 512 MiB target: allocated decode envelopes
are about **539 / 804 MiB** in the legacy caller and **1537 / 1800 MiB** in the
fresh caller. Both reserved scopes exceed 6 GiB. The fresh caller retains
1000 MiB of prefill logits through its first decode; model-only allocator slack
is just 3.49 MiB. These callers differ, so their difference is not a causal
saving. No new memory/default claim; [resource proof](results/hardware/bulk_resource_audit_v1/verified_report.json).

**Latest verified opt-in:** `--cpu-bulk-promotion` preserves decisions/state
and improves 16K decode **5.23% / 6.54%** against the same CPU backend at
1024/2048 and 991/1090 capacities. All three ABBA blocks per geometry and
p95/TTFT/GPU peak guards pass. Four-context parity, native lifetime, saturation,
24 generation pairs, six recycled requests and ordinary CLI checks pass;
**206 tests passed at that milestone**. Requires the existing native-reuse CPU chain; defaults
unchanged. Full-resource, quality, faithful SnapKV speed and hardware gates
remain open. See [current status and evidence](PROJECT_STATUS.md).

**Latest experimental allocator:** exact pinned roots reduce measured host
ranges 256→144.25 MiB / 512→264 MiB. Parity, timing, 24 generation pairs and
request recycling pass; full suite **199 tests**. GPU peak is unchanged.
Active decode envelopes are 427.40 / 556.25 MiB; usual active and both
reserved scopes fail the 512 MiB target. Candidate stays research-only.
See [current status and verified evidence](PROJECT_STATUS.md).

This is an experiment plan, not a claim of improvement. Keep the corrected
Mistral/bf16 evaluation under `results/remediation_v3/` as the control. The
research target is a measured quality–latency–capacity–write-cost Pareto
improvement against faithful implementations at matched conditions. A top-tier
submission also needs a distinct mechanism and evidence that it works beyond
one model, task sample, and machine.

## Current evidence and blockers

- Direct public CUDA host ranges are256/512 MiB behind 144.25/264 MiB pinned
  requests. Corrected shared known-KV lower bound 518.00 MiB still fails 512 MiB;
  whole-request GPU peak 18.6278 GB unchanged. Twelve fresh memory runs/six
  public-private capacity checks verify preservation; active reader needs no
  compiler/private layout. Two weak runs identify1000 MiB prefill logits held
  through the fresh driver's first decode; legacy profile lifetime differs.
  Next excess-root/workspace candidate before equal-resource claims.
  [Public memory proof](results/hardware/actual_reuse_memory_20261002/public/verified_report.json).

- New research-only raw-buffer reuse: known policy KV −23.1%, whole-request GPU
  peak unchanged; four-context parity and three-ABBA regression guards pass
  (median +1.34%/+1.76%). Fifteen new native lifetime checks, generation,
  saturation, recycling and CLI gates pass;187tests. Actual allocator/process
  memory remains open. Advance for storage only:
  stage saving0.26–0.34ms fails4ms speed gate. No new holdout/default change.
  [Verified resource and timing](results/hardware/reuse_visible_model_20261002/verified_timing.json).

- On the source-matched 135-example upstream-selector SnapKV comparison, the
  task-balanced TieredKV−SnapKV quality difference is −0.0457 points with
  conditional paired 95% interval [−1.3573,+1.3621]. This demonstrates
  neither superiority nor equivalence. Actual resident bytes and attended
  widths differ (`results/baseline_fidelity/snap_exante_full_currenthot_report.json`).
- The first fresh disjoint 30-example actual-query/LRU screen scored +5.17
  task-balanced points over K-as-Q/LRU, but its conditional interval
  [−1.60,+12.95] crossed zero. The fixed second 30-example tranche passed its
  stricter 97.5% replication gate: +7.30, interval [+1.54,+15.12]. Across both
  tranches (descriptive pooled estimate), the difference is +6.24
  [1.48,+11.48], with 10/60 regressions and three losses >10 points. The
  gain is concentrated in MultiFieldQA/HotpotQA; TriviaQA and GovReport are
  near zero. Stress bins show +5.41 for 4K–16K prompts but −0.15 above 16K;
  outputs longer than 128 tokens were +0.11 with 6/10 regressions. Candidate
  median prefill time and peak allocation rose in every task group, while
  pooled paid writes/step fell only 1.1%. This supports a conditional quality
  tradeoff, not an all-metric Pareto gain. Keep opt-in; require a long-output
  retrieval fix, second-model and paired end-to-end systems validation
  (`results/baseline_fidelity/real_query_holdout_20260929/`).
- The latest one-prompt 16K/50-forward ABBA measures complete-loop median
  ITL 82.76 ms/token for TieredKV and 25.77 for SnapKV (3.21× slower), p95
  86.34/26.03 ms, and TTFT 2194.82/2086.69 ms. TieredKV's decode allocation
  peak is lower (15.234/16.522 GB), while prefill peak is higher
  (18.796/17.958 GB); actual final payload is 425/512 MiB. This is not a
  throughput or physical-tier result (`snap_tier_loop_currenthot_report.json`).
- The final-source 16K/10-step profile measured about 25.37 ms/token model
  forward and 84.40 ms/token total under cProfile. The latest rerun recorded
  `evict_and_demote()` at 0.269 s over 320 layer calls, `_visible_tuple()`
  at 0.120 s over 11 calls, and `update_scores()` at 0.076 s over 10 calls.
  These profiler totals overlap
  and include instrumentation effects (`results/baseline_fidelity/tier_policy_16k_10.txt`).
  Boolean hot-row compaction is a parity-proven 4% improvement over the prior
  gather source. Fused hot append regressed, guarded top-k always fell back
  because of ties, and batched stable sorting saved only 3.70 ms/step in a
  10-step microbenchmark, below its preregistered 4 ms screen. No new cache
  implementation passed the current latency gate. A ~35 ms/token compact
  baseline leaves little room for policy work; larger structural changes to
  attention and policy execution remain necessary.
- Every method reaches about 18.59 GB peak PyTorch allocation during prefill.
  The prototype's hypothetical slow tier is also on GPU.
- A read-only 16k real-text, 50-decode-step visibility probe in
  `results/shadow_ablation_full/stt_visibility_probe.json` found only
  **115 distinct slow-tier tokens per layer on average** (range 111–131)
  exposed across the 51 visible-set builds, out of roughly 1,620 resident
  rows at the end (~7.1%). The quota was fully used (32 each build), but
  selections repeated heavily. `TieredKVPolicy._visible_tuple()` ranks
  currently live rows by last access, and `update_scores()` refreshes every
  exposed row with positive softmax weight. Unexposed rows receive no score
  or promotion signal. This supports a concrete retrieval-coverage bottleneck,
  not proof that the unexposed rows would help quality. A candidate query-aware
  selector should be judged by full-attention retrieval recall, new distinct
  useful tokens reached, quality, and its own selection/transfer cost.
- The 88.1% avoided decode-demotion write counter omits prompt placement and
  is not physical device traffic. The current 50/12.5 GB/s STT scenario is
  unvalidated. [Everspin's 1Gb product states 2.7 GB/s in both directions per
  device](https://investor.everspin.com/news-releases/news-release-details/next-generation-ibm-flashcore-modules-feature-everspins-persyst).
- A **capacity-matched commercial-device anchor** would need two such 1Gb
  chips for 256 MiB raw capacity (the configured 2048-token bf16 cold tier).
  Perfect striping would give at most 5.4 GB/s read **and** write before
  controller, link, contention, and nonsequential-access losses. The current
  50 GB/s assumed read input would require at least 19 independently usable
  2.7 GB/s devices, or 2.375 GiB of raw capacity; it is not a natural
  256 MiB configuration. At the 32-token exposure quota across 32 Mistral
  layers, one decode step reads up to 4.19 MB of cold bf16 KV, implying an
  ideal serial-transfer floor of 0.78 ms at 5.4 GB/s versus 0.084 ms at
  50 GB/s. This is arithmetic from [Everspin's product specification](https://www.everspin.com/products/series/emd4e001g)
  and [bandwidth statement](https://investor.everspin.com/news-releases/news-release-details/next-generation-ibm-flashcore-modules-feature-everspins-persyst),
  **not** a measured GPU-attached implementation; access granularity and
  staging costs for a physical STT controller remain unknown.
- A pinned CPU-DRAM transfer probe on the actual model GPU (L40S, PCIe
  Gen4×16, local NUMA node; 30 measured repeats per case) now isolates one
  part of that missing path. Transferring the 4 MiB for 32 exposed bf16
  rows across 32 layers took **9.38 ms** as 1,024 separate 4 KiB H2D copies,
  **0.299 ms** in 32 layer-sized 128 KiB copies, or **0.171 ms** as one packed
  copy. A contiguous 256 MiB H2D transfer took **10.02 ms** (26.8 GB/s).
  These are synchronous-completion timings of PyTorch copies from pinned
  CPU DRAM, **not STT-MRAM**; no controller, random-access STT timing,
  concurrent inference, or whole-request energy was measured. Raw data and
  capacity-matched arithmetic: `results/hardware/host_transfer_gpu0_v3.json`
  and `host_transfer_report.json`. The 4 MiB read has a **0.777 ms ideal
  STT-device floor** at two-chip 5.4 GB/s, before any link/controller cost.
  The nominal 50 GB/s read input also exceeds this GPU's PCIe Gen4×16
  nominal one-way ~32 GB/s (NVIDIA lists 64 GB/s bidirectional), so it
  cannot describe an uncompressed GPU-attached tier on this link. GPU1's
  observed Gen4×8 link reached only ~13 GB/s on large copies, confirming
  that topology matters. [NVIDIA L40S specification](https://www.nvidia.com/en-in/data-center/l40s/),
  [Everspin 1Gb product](https://www.everspin.com/products/series/emd4e001g),
  [Everspin bandwidth statement](https://www.everspin.com/sites/default/files/pressdocs/IBM%20Release%204.28.24.pdf).
  The analytical model now exposes `commercial_2x1gb_ideal` (5.4/5.4
  GB/s) as an explicit **interface upper-bound** scenario. Its pJ/bit
  values remain unvalidated assumptions; it is not a calibrated device.
- A cost-model audit found that dropping a cold row was billed as an STT
  payload read despite no such operation in the policy. `drop_cost()` now
  records zero payload traffic; allocator/controller metadata energy is
  unmeasured. The corrected six-task equal-VRAM control had no dropped
  layer-rows, so its historical modeled totals are unchanged. The
  equal-total GovReport control had 25,920 drops; subtract **2.123 ms** and
  **0.001699 J** from that old report's *aggregate modeled* latency/energy.
  Measured quality, GPU latency and write counters do not change. Old JSON
  remains immutable; exact source-linked arithmetic is in
  `results/hardware/drop_cost_correction.json`.
- The [EMD4E001GAS2 datasheet](https://www.everspin.com/sites/default/files/EMD4E001GAS2_1.3_10102022.pdf)
  specifies **10^10 cycles per single page**, defines a cycle as a *page
  access*, and recommends system ECC after warning that the bit-error rate
  may rise beyond this limit. Its pages are 1,024 bits (x8) or 2,048 bits
  (x16). Thus the measured logical demotion-write reduction cannot be
  converted into device lifetime: the simulator has no physical page map,
  read-access counts, controller write amplification, hot-spot distribution,
  or wear-leveling trace. A physical-tier experiment must log page-level
  accesses per address, including reads and writes, before an endurance
  claim or lifetime projection is defensible.
- The 2,510,023 saved **layer-token** writes represent 10.28 GB of bf16 KV
  payload across 135 requests, or 72.6 MiB per request. At the assumed
  12.5 GB/s STT write bandwidth this is only 0.822 seconds of ideal transfer
  across all 5,331 decode steps (0.154 ms/step). At the capacity-matched
  two-chip 5.4 GB/s ideal interface it is 1.904 seconds total, or 0.357
  ms/step; neither figure includes controller/link or random-write cost.
  At the assumed 8 pJ/bit
  it is 0.658 J, less than 1% of the run's modeled decode dynamic energy.
  Prompt placement would add about 25.90 GB of slow-tier writes under the
  policy's actual capacities; including it reduces the avoided fraction of
  *potential total slow-tier writes* from 88.1% to about 27.4%. This is a
  derived counterfactual, not physical traffic or measured power.
- KV migration and write policies have prior art: [CachedAttention](https://www.usenix.org/system/files/atc24-gao-bin-cost.pdf)
  spans GPU, host and disk; [vLLM tiered offloading](https://vllm-project.github.io/2026/09/10/tiered-kv-offloading.html)
  retains host copies on reload; [HiCache/Mooncake](https://github.com/kvcache-ai/Mooncake/blob/main/docs/source/design/hicache-design.md)
  supports selective/write-back policies and skips data already present in
  the next tier. **FlexGen does move KV data:** its ICML 2023 paper chooses
  tensor-granularity placement for KV and schedules cache load/store across
  GPU, CPU and disk; it also delegates attention-score computation to CPU
  when KV is CPU-resident. Its objective is throughput for large batches and
  offloaded model inference, rather than an online per-token hotness and
  write-aware residency policy. Therefore “moving KV between tiers” and
  “avoiding a redundant write” are not stand-alone novelty claims
  ([FlexGen paper](https://proceedings.mlr.press/v202/sheng23a/sheng23a.pdf),
  Sec. 4.1–4.3).
- **Direct 2026 novelty check:** [FlexiCache (MLSys 2026)](https://proceedings.mlsys.org/paper_files/paper/2026/file/94bcb01789fccf15afe2764d8fe0f40e-Paper-Conference.pdf)
  holds the full KV of its stable attention heads in CPU memory and only
  their current top pages on GPU. Section 3.3 explicitly says each such page
  is offloaded to host **exactly once**; later GPU promotions reload only
  newly selected pages. This is the same broad *retain host copy and avoid
  another demotion write* principle as TieredKV's inclusive shadow, although
  FlexiCache chooses pages/head groups and TieredKV chooses tokens/layers.
  Therefore the 88.1% logical write reduction is a useful implementation
  result, **not by itself a novel write-saving mechanism**. FlexiCache also
  has a vLLM implementation with asynchronous transfers and Mistral-7B
  evaluation, making it a stronger systems comparator than an in-harness
  SnapKV policy alone. [IceCache (ICLR 2026)](https://github.com/yuzhenmao/IceCache)
  is another direct comparator: its released Mistral-capable code keeps
  offloaded KV on CPU, selects pages using the decode query, and supplies a
  LongBench benchmark. The two systems use different page selection, host
  hardware, and software stacks, so published headline numbers cannot be
  compared directly to this project's numbers.
- Dynamic placement is also already an explicit research topic. A 2025
  heterogeneous-memory paper formalizes KV placement across HBM and
  off-package DRAM and reports a simulated-annealing upper bound with
  future-importance information; it does not provide a deployable online
  placement policy. A September 2026 arXiv preprint studies recency, reuse,
  predicted-reuse and EWMA placement across GPU/CPU/SSD for long-lived
  sessions in a discrete-event simulator; it reports that capacity explains
  most of the concurrency/cost gain while placement mainly changes migration
  traffic and TTFT. This overlaps conceptually with tier placement, but its
  multi-session reuse problem differs from TieredKV's within-request
  attention-driven token policy. Both sources make a generic “adaptive
  placement” novelty claim untenable without direct comparison
  ([Fang et al., 2025](https://arxiv.org/abs/2508.13231),
  [Tumkur et al., 2026 preprint](https://arxiv.org/abs/2609.16215)).
- Newer systems narrow the systems claim further:
  [DirectKV (OSDI 2026)](https://www.usenix.org/conference/osdi26/presentation/luo)
  directly accesses CPU-resident KV over NVLink-C2C and fuses attention with
  fetching; [KVDrive (2026 preprint)](https://arxiv.org/abs/2605.18071)
  jointly manages GPU/host/SSD placement and transfer overlap; and
  [TensorRT-LLM's host offloading](https://nvidia.github.io/TensorRT-LLM/features/kvcache.html)
  already supports secondary KV blocks and priority-based admission.
  A [2026 Harvard seminar](https://systems.seas.harvard.edu/seminar/2026-09-08-anshvardhan-shetty/)
  also studies KV flash write-budget admission; it is a seminar description,
  not evidence that this prototype's STT endurance result is known. **Inference:**
  a defensible TieredKV contribution would have to demonstrate a distinct
  *joint* quality/latency/write-budget policy for immutable token KV on a
  physical tier, with measured page traffic and wins against these baselines.
  The differentiating hypothesis must now be narrower: a **measured joint
  quality/latency/physical-write benefit** from a write-constrained residency
  policy on an actual asymmetric-write device, relative to host-retaining
  systems such as FlexiCache and retrieval systems such as IceCache. Token
  granularity alone is a design difference, not proof of benefit. This
  remains unproven: the current prototype keeps
  both tiers on GPU, and its write counters are logical policy events rather
  than physical page writes or endurance measurements.
- Query-aware token retrieval is also established prior art:
  [Quest (ICML 2024)](https://proceedings.mlr.press/v235/tang24l.html)
  scores compact page min/max metadata with the current query;
  [RetrievalAttention (NeurIPS 2025)](https://proceedings.nips.cc/paper_files/paper/2025/hash/4e36d4049fb0fea195a8267c8dcd0824-Abstract-Conference.html)
  uses CPU-side approximate nearest-neighbor indexing;
  [RocketKV (ICML 2025)](https://proceedings.mlr.press/v267/behnam25a.html)
  combines two-stage KV compression and an improved GQA-compatible SnapKV
  component. The full-scan true-query hook should be treated as an oracle
  diagnostic for this project, not a novel retrieval method.

## Ranked experiments

| Priority | Hypothesis and implementation | Proof required |
|---|---|---|
| 1 | **Bound prefill memory:** process prompt in chunks or layer segments and place cold pages without first materializing the full prompt KV. [SparseServe](https://arxiv.org/abs/2509.24626) uses layer-segmented prefill; [PagedAttention](https://arxiv.org/abs/2309.06180) provides a systems baseline. | Peak allocated/reserved HBM, TTFT, exact quality, page traffic; same prompt lengths and model. |
| 1 | **Remove decode policy overhead:** profile promotion, demotion, sorting, concatenation and GPU synchronization; batch decisions/page transfers and use a serving-compatible attention path. [SPIN](https://arxiv.org/abs/2604.26837) shows why hierarchical metadata and irregular transfers matter. | Full-loop TPOT, throughput at multiple batch sizes, p50/p95 tail latency, CPU/GPU profile, transfer bytes. |
| 1 | **Improve retrieval quality:** use the actual decode query and compact page metadata to select candidates per layer/head, rather than relying only on past attention of the 32 exposed rows. Compare with [Quest](https://arxiv.org/abs/2406.10774), [RetrievalAttention](https://proceedings.nips.cc/paper_files/paper/2025/hash/4e36d4049fb0fea195a8267c8dcd0824-Abstract-Conference.html), and [RazorAttention](https://proceedings.iclr.cc/paper_files/paper/2025/hash/2a98af4fea6a24b73af7b588ca95f755-Abstract-Conference.html). | Retrieval recall versus full-attention top tokens, held-out task scores, matched attended width and HBM, selection/transfer cost. |
| 2 | **Compress the cold tier:** first test native FP8 KV storage/attention on L40S, then 4-bit only if it improves the Pareto frontier. [KIVI](https://arxiv.org/abs/2402.02750), [KVQuant](https://arxiv.org/abs/2401.18079), and [TurboQuant](https://proceedings.iclr.cc/paper_files/paper/2026/hash/5c802ef38ab6e366c2ea06eee554c088-Abstract-Conference.html) are quality baselines; a [vLLM evaluation](https://vllm-project.github.io/2026/05/11/turboquant.html) shows low-bit dequantization can hurt speed and harder-task accuracy. | Actual packed bytes including scales, peak HBM during prefill, quality, dequantization cost, TPOT and throughput. |
| 2 | **Validate write-aware value:** choose a capacity-matched physical slow-tier topology and measure host/GPU transfers, sustained read/write behavior, write amplification, energy and thermal behavior. Keep device/cell, interface and system numbers separate. | Measured write bytes and energy/latency under a real device or clearly labeled emulator; include prompt placement and lifetime workloads. |

**Go/no-go comparator gate:** Before making a write-saving novelty claim,
reproduce a Mistral workload from [IceCache's released LongBench runner](https://github.com/yuzhenmao/IceCache)
and one feasible [FlexiCache](https://github.com/NazmulTakbir/FlexiCache)
configuration. Record model version, prompt/output lengths, actual GPU and
host KV bytes, attended positions, CPU/GPU hardware, transfer bytes,
whole-request latency, quality, and write counters. If the hardware/software
stacks cannot be matched, label that limitation and use an in-system
host-copy/one-time-offload control rather than comparing headline figures.
The claim advances only if TieredKV improves a predeclared quality–latency–
memory–write trade-off against this control and passes the stress gates.

**IceCache input gate, corrected 2026-09-30:** The released copy matches all
1,150 rows of our *standard* LongBench files, but the corrected TieredKV
control selects LongBench-E files for five of six tasks. Those five selected
files do **not** match the bundled IceCache data. NarrativeQA alone uses the
same selected data. All six generation limits match; NarrativeQA and Qasper
prompt templates differ. IceCache's runner defaults to fp16 while the
corrected TieredKV control uses bf16, and its `parse_args()` resets `--e` to
false. A direct run therefore requires an explicit same-request wrapper,
aligned prompt/dtype/model settings, and actual resource measurements.
IceCache's isolated CUDA/M-DCI environment has now compiled and a 1,024-token
Mistral two-token smoke test generated successfully on this L40S; this is
build feasibility, **not** baseline quality or performance evidence. See
`results/baseline_fidelity/icecache_input_audit_v2_20260930.json` and the
timestamped experiment log; do not cite IceCache's paper numbers as if they
were measured on our hardware.

The first **selected-request** feasibility pilot also passed: the official
IceCache adapter generated the same prediction and score twice on corrected
MultiFieldQA-E request index 9 with exactly the control's 1,440 prompt token
IDs. It scored 10/100 and took 4.68 seconds per request in its isolated
fp16 configuration. This is not a resource-matched result: the released
path has a float32 CPU cache, 16-page GPU budget (two unlimited layers),
and 1 GiB GPU / 4 GiB pinned CPU pool capacities. Match precision, actual
live bytes, per-layer attended positions, selected requests and output
limits before plotting IceCache against TieredKV. Raw paired repeat:
`results/baseline_fidelity/icecache_matched_input_pilot_20260930.json` and
`icecache_matched_input_pilot_repeat_20260930.json`.
IceCache's official `bf16` branch is a separate code variant (commit
`f2afaffcd0959444b778daccbb327fead89e24ca`), not a one-line dtype
toggle: its CPU indexing and CUDA source differ, and its CMake file targets
compute capability 9.0 while this L40S is 8.9. Any L40S build would need
a documented architecture-target change in an isolated checkout and fresh
validation; do not mix fp16-main and bf16-branch outputs as one baseline.

**bf16 feasibility update (2026-09-30):** That official branch and its
matching bf16 M-DCI dependency now compile and run on L40S after the sole
IceCache source edit `sm_90 → sm_89` in CMake. Two fresh-process runs on one
selected corrected-control request had identical prompt IDs, prediction,
score (10/100), model/GPU/CPU K/V dtype (bf16), and 15.788 GB GPU peak.
This closes the *precision feasibility* gate only. A repeated one-request
page-accounting snapshot now finds 668 active GPU cache pages, 2,220 GPU
prefill pages awaiting lazy release, and 3,581 occupied pinned-CPU pages
(64 KiB per page). The 1 GiB GPU and 4 GiB CPU pools are fully preallocated;
occupied-page counts are not equal to allocated process memory or peak live
KV. The next meaningful baseline test must match actual GPU/CPU K/V payload
budgets and attended positions across multiple identical requests, then
measure whole-request latency and uncertainty. The result and exact build patch are under
`results/baseline_fidelity/`; see the experiment log for hashes and limits.

**Long-prompt capacity check (2026-09-30):** On a separate 15,789-token
MultiFieldQA-E row, the released 1 GiB GPU page pool failed during full-prompt
prefill because it could not allocate contiguous pages. Raising only that
pool's capacity to 4 GiB let the same bf16/page-policy run finish. Its final
GPU pool occupancy was 2,460 active cache pages plus 29,130 deferred prefill
pages; the pinned CPU pool held 33,420 pages (64 KiB each). Peak PyTorch GPU
allocation was 20.839 GB. This is a **single feasibility row outside the
frozen 25-row control**, not a paired win/loss; it establishes that the
released 1 GiB setting is insufficient for this workload and that equal
*declared* pool size is a poor proxy for equal useful KV capacity. Future
comparisons must record full prefill peak and the actual pool size needed to
finish, as well as active attention pages and CPU occupancy.

A same-row TieredKV probe used the exact same 15,789 prompt token IDs. It
named only three of the five orders requested (50/100) while IceCache named
all five (100/100). This is a **specific TieredKV answer-quality failure to
debug**, not an equal-resource result: IceCache retained far more CPU-side
context and had two unlimited GPU layers. The next targeted diagnosis is to
trace whether the five-order source span survived prompt compression and was
visible to attention at decode; if it survived, inspect selection rather than
assuming an eviction failure. The raw paired row and provenance are in
`results/baseline_fidelity/icecache_tiered_row138/` and the experiment log.
The targeted prefill trace has now answered the first diagnostic question:
**all 35 tokens in the five-order source sentence were dropped in every one
of TieredKV's 32 layers**. Promotion cannot recover permanently dropped
tokens. This supports a prompt-retention problem on this row, while causality
of the generated answer remains unproven. The next controlled candidate
should use only information available at inference time (for example,
question-to-passage relevance), compare against unchanged placement at equal
fast/slow capacity, and stress previously observed query-aware regressions.
Do not use reference-answer spans as the deployed selector.
An explicit fixed-capacity oracle intervention tested the mechanism: the
no-boost wrapper exactly reproduced TieredKV's 50/100, three-name answer;
forcing the 35 known source tokens into fast cache in all 32 layers yielded
the full five-name answer and 100/100. Thus retaining that passage was
sufficient to fix **this one case**, while the oracle is not a usable method
or evidence of general quality. The next algorithmic experiment must rank
passages without reference answers and pass the existing Qasper/document-
disjoint regression gates before it can replace the default.
A first answer-free lexical screen was **rejected before model execution**:
its best 128-token question-overlap window covered only 12 of the 35 source
tokens because it cut the sentence at its boundary. The preregistered gate
was ≥30/35. This rejects that fixed-window variant, not lexical retrieval in
general. Do not tune its width or offset on this already diagnosed row;
specify a passage-aware variant and evaluate on disjoint examples if pursued.
A sentence-centered 128-token selector then passed a cheap retrieval proxy
and a first 24-question same-budget model pilot (+8.84 task-balanced points,
conditional interval [+2.25,+16.86]; no >10-point loss). Selection overhead
was only 0.52% of control model-loop time at the median in a CPU screen.
But a **second frozen, document-disjoint 24-question set did not replicate**:
only +1.22 task-balanced points, paired 95% interval [−0.43,+3.27], with
no Qasper exact-answer retrieval advantage. Its preregistered replication
gate failed. Keep the selector experimental and reject it as the default or
paper's quality mechanism; do not tune against that second set. Both sets,
source hashes and per-row outputs are under `results/baseline_fidelity/`.

**Physical host-copy screen (2026-09-29):** The opt-in CPU-DRAM TieredKV path
completed a fixed-input, 16,384-token/50-step two-block ABBA test of
inclusive shadows against no shadows. Initial CPU placement and CPU→GPU
payload were equal. Explicit decode GPU→CPU K/V payload fell from 108.265
to 11.018 MB per run (89.82%); median prototype decode time was 164.82
versus 93.69 ms/token (no-shadow versus inclusive). This demonstrates that
the software write-saving events correspond to fewer **explicit host-copy
bytes** in this Python path, but it is not STT-RAM device traffic, an
endurance measure, or a novel mechanism relative to FlexiCache. The policies
disagreed on one of 50 predicted IDs, so quality parity is not established.
See `results/hardware/cpu_shadow_copy_16384_50_20260929.json` and the
registered experiment log.

### Decode metadata fast path (2026-09-27)

Profiling showed that promotion hysteresis repeatedly scanned singleton
candidates and that score handling rebuilt a full slow-position map even
though only 32 slow rows were exposed. The real-model path now updates all
candidate streaks in one tensor operation and carries the already-known STT
indices from visibility through score update to the next policy call. The
generic simulator page path and position-keyed compatibility path remain.

The first two-block 16K comparison reported 96.08 versus 115.09 ms/token,
but used a 16-row recent window and did not meet the protocol's three-block
or p95 gate. It is superseded by the current same-process three-block ABBA
with the corrected 128-row window and a fixed real-text prompt. At 16K,
median full-loop ITL was **106.17 versus 120.48 ms/token** (fast versus
legacy, **11.9% lower**) and p95 was **129.53 versus 180.36 ms/token**.
At 8K, medians were **106.41 versus 120.50 ms/token** (**11.7% lower**) and
p95 **142.60 versus 180.04 ms/token**. Every paired block favored the fast
path; median model forward remained ~25.2 ms/token and decode peak was equal.
Evidence: `results/decode_overhead/fastpath_abba_16k_v3.json` and
`fastpath_abba_8k_v3.json`. The benchmark wrapper's first three-block attempt
was discarded because it retained bound-method references to GPU caches;
the corrected wrapper releases them, and every trial now has the same peak.

The fast path also reproduced all 15 predictions and per-example scores in
the selected Qasper/NarrativeQA/GovReport exact-control artifacts. Unit tests
cover hysteresis state and capacity boundaries. This is a promising systems
improvement on one Mistral model, machine, prompt source and seed; it does not
establish serving throughput or cross-model generality. The project still
misses the ~35 ms/token compact-cache target. Avoiding an additional full
fast-tier gather measured 94.71 ms/token in a separate two-trial screen
(`visible_nocopy_16k.json`), but was not isolated in a three-block ABBA and
is retained only as a behavior-preserving copy removal.

### Bounded residency admission screen (2026-09-27)

The real-model policy now allows a per-layer `promotion_budget` independent
of its 32-row slow attention exposure. Default 32 preserves the corrected
control. A fixed 16K/32-step screen swept admission budgets 0, 2, 4, 8, 16,
and 32 (`results/decode_overhead/promotion_budget_sweep_16k.json`). Budget 4
cut promoted layer-token events from 15,904 to 1,934 and paid decode writes
from 2,391 to 1,316 on that prompt. Its ITL was 88.85 ms/token versus
105.92 ms/token for the first 32-row control, but a repeated 32-row control
measured 127.25 ms/token after GPU drift. These timings are a screen, not a
controlled speedup estimate.

The paired first-five-example pilot on Qasper, NarrativeQA and GovReport
used the same Mistral, source/runtime, input IDs, bf16 capacities, seed, and
32-row attention exposure; only admission changed from 32 to 4. Qasper and
NarrativeQA predictions were identical on all ten selected examples.
GovReport changed all five predictions and fell from 28.25 to 27.32 ROUGE-L.
The task-balanced difference was −0.31 points, conditional 95% interval
[−1.56,+0.94] (`results/promotion_budget/report4_15.json`). This fails the
predeclared −0.5 point quality non-inferiority gate, so budget 4 remains
opt-in and the default stays 32. Write-savings percentage also fell from
87.5/80.8/91.9% to 57.1/61.0/53.6% across the three tasks: simply reducing
migration volume is not the same research result as retaining high reuse.
The next candidate should reduce movement cost while retaining an effective
32-row admission policy, e.g. preallocated/page-based storage and batched
data movement, rather than tuning the admission cap on this small pilot.

### Deferred slow-tier compaction: rejected (2026-09-27)

An experimental path delayed appending newly demoted rows until after slow-tier
overflow victims were chosen, then wrote the final survivors into one output
tensor. CPU cache-state tests showed identical trajectories for float32 and FP8
storage; a tiny Mistral test showed identical generations and counters. A
same-process three-block ABBA 16K/16-step comparison measured **107.24 versus
106.89 ms/token median ITL** (candidate versus control) and **145.46 versus
135.38 ms/token p95**. Peak decode allocation fell only **7.45 MB**.
The change missed the ≥5% latency gate and worsened the tail, so its code was
removed. The result rules out this one-pass PyTorch `index_select(out=...)`
variant; it does not rule out preallocated pages or a fused kernel. Raw timing
and source fingerprint remain in
`results/decode_overhead/deferred_stt_abba_16k.json`.

The experiment exposed a separate defect: the standalone simulator attempted
`torch.cat` and min/max directly on float8 cold tensors, unsupported by this
PyTorch build. The simulator now converts cold keys to its compute dtype before
building page sketches. The real Mistral path never calls that sketch; this
fix restores simulator coverage without changing real-model outputs.

### Bounded-prefill prototype (2026-09-27)

`--tiered-prefill-chunk-size 512` now processes the prompt incrementally,
compressing to the full 1024-fast + 1536-prefill-cold resident set between
chunks and applying the 32-row cold exposure cap only after the final chunk.
Absolute position IDs preserve RoPE. This is approximate prefill: later
chunks cannot attend evicted prompt tokens. A regression check proves that a
chunk size at least as large as the prompt is identical to the exact path.

The corrected same-GPU ABBA 16k pilot (`results/bounded_prefill/pilot_v3.json`)
retains exactly 1024+1536 rows in every layer for both arms. Chunking reduces
peak allocated HBM from **18.594 to 15.804 GB** (−2.790 GB, −15.0%) but raises
median TTFT from **2.245 to 4.449 s** (+98%). Both arms produce the same first
token on this fixed prompt. An earlier `pilot.json`/`pilot_v2.json` result is
rejected because intermediate chunks accidentally carried only 32 exposed
cold rows; those files remain as debugging provenance, not evidence.

On the first five Qasper examples, exact prefill scores 6.91 and chunked
prefill 15.77. The paired difference is +8.87 with conditional interval
[−0.03, +17.84], and all five generated strings differ. This selected tiny
pilot neither establishes a quality gain nor preservation; it shows that
the approximation materially changes behavior. Next gate: broader paired
quality across diverse tasks and chunk-size sensitivity before treating the
15% peak-HBM reduction as usable.

Chunk-size sensitivity on the same 16k prompt shows the expected tradeoff:

| Chunk | Peak HBM | Median TTFT | Qasper-5 score | Difference vs exact | Identical predictions |
|---:|---:|---:|---:|---:|---:|
| Exact | 18.594 GB | 2.24 s | 6.91 | — | 5/5 |
| 512 | 15.804 GB | 4.45 s | 15.77 | +8.87 | 0/5 |
| 1024 | 15.901 GB | 3.08 s | 11.72 | +4.82 | 0/5 |
| 2048 | 16.113 GB | 2.42 s | 8.19 | +1.29 | 1/5 |

The 2048-token point cuts peak allocation by 13.3% with 8.0% TTFT overhead
and moves the small-sample score closer to exact prefill, but four predictions
still differ and its paired interval [−8.26, +14.06] is uninformative. Use
2048 for the next multi-task pilot; do not claim quality preservation.

For the write-aware experiment, include a paired **no-shadow** policy under
the same total capacity and task samples. The current 88.1% numerator is a
counterfactual on one execution trace; disabling shadows can change the
cache's future decisions and quality. Also compare with a conventional
write-back/inclusive hierarchy and a selective-write policy, rather than only
with permanent eviction.

### Native FP8 cold-tier feasibility (2026-09-27)

`TieredConfig.stt_kv_dtype` now supports `torch.float8_e4m3fn` cold storage
while the hot tier and selected attention rows remain bf16. PyTorch lacks
native float8 indexing and concatenation on this L40S stack, so the cache
gathers/appends/removes through one-byte `uint8` views and converts only
selected rows. CPU and CUDA storage checks pass; the full suite currently has
71 tests.
At the configured 2048-token cold capacity, Mistral's 8 KV heads × 128
dimensions × K/V × 32 layers require 256 MiB in bf16 or 128 MiB in FP8,
excluding policy metadata. This is real tensor storage, not packed-byte
accounting applied to bf16 tensors.

A source/runtime/sample-matched one-example Qasper feasibility pair under
`results/fp8_cold_pilot/` scored **10.53 bf16 versus 8.57 FP8** and generated
46 versus 67 tokens. This single selected sample is only a fail-fast signal:
it demonstrates that native FP8 changes output and may hurt quality, but
cannot estimate an average effect. It provides no latency or peak-memory
claim. Next gate is a paired multi-example quality pilot plus isolated
conversion/selection timing and measured peak/steady allocated memory. Do
not expand to 4-bit until FP8 either reaches acceptable quality or a scaled
format is justified.

The preregistered next gate is complete on the first five Qasper examples
(`results/fp8_cold_pilot/report_5.json`). Bf16 scored **6.91** and FP8
**6.51**; paired FP8−bf16 difference **−0.39**, conditional bootstrap interval
**[−1.17, 0.00]**. Four of five predictions are byte-identical; the first
sample causes the entire observed difference. This supports basic stability
on four cases while preserving the quality warning. Five selected examples
remain too small for an accuracy claim. Proceed next to isolated latency and
allocated-memory measurement before spending on a wider quality matrix.

The same-GPU 16k/20-token ABBA check is complete
(`results/fp8_cold_pilot/latency.json`). Median full-loop time was 118.33
ms/token for bf16 and 117.23 for FP8. The two blockwise differences disagree
in magnitude/sign after drift, so this does not establish a speedup. Final
resident cold tensors measured 208,023,552 bytes bf16 versus 104,011,776
bytes FP8; hot tensors were identical at 134,217,728 bytes. Allocated memory
after the profile was lower by about 89 MB with FP8, and decode peak was
15.053 versus 15.136 GB. Prefill peak remained exactly 18.594 GB because the
full prompt KV is materialized before compression. Thus FP8 improves steady
residency but does not solve peak memory, and wider quality testing should
remain secondary to bounded prefill.

### First paired no-shadow pilot (2026-09-24)

`results/shadow_ablation_v2/` holds source- and dataset-matched inclusive and
no-shadow Mistral runs on the first five samples each of Qasper, NarrativeQA,
and GovReport, with identical bf16 budgets and seed. The inclusive arm's
predictions match the first five samples of the frozen v3 control exactly.
`experiments/report_shadow_ablation.py` checks that the only configuration
difference is `tiered_inclusive` and that the samples pair by ID.

Inclusive shadows reduced paid decode-demotion writes from 830,240 to 73,270
layer-token writes (−756,970; **91.2%**), a derived 3.10 GB of bf16 KV payload
across 15 requests. At the assumed 12.5 GB/s write rate this is 0.248 seconds
of ideal transfer across 1,525 generated tokens (~0.163 ms/token); at the
assumed 8 pJ/bit it is 0.198 J. Neither number is a physical measurement.
The task-balanced quality difference was **+0.16 points**, paired conditional
95% interval **[−0.50, +0.76]**. Thus this pilot supports a write-count
effect, but no quality improvement claim; the 15 selected requests and three
tasks are too small for a general result. The 19.95 vs 21.16 J analytical
decode-energy totals include changed attention traffic and must not be
attributed entirely to avoided writes. The full test below supersedes this
pilot for decision-making.

### Full paired no-shadow test (2026-09-24)

`results/shadow_ablation_full/` contains 25 samples per short task and 10
GovReport samples under the same Mistral revision, source and dataset hashes,
seed, bf16 precision, budgets, and prompts. The only policy setting changed
is inclusive shadows. All inclusive scores, predictions, and cache counters
match the frozen v3 control exactly. `report.json` checks configuration and
sample IDs and reports paired conditional bootstrap intervals.

| Outcome | Inclusive shadows | No shadows | Interpretation |
|---|---:|---:|---|
| Paid decode-demotion writes | 339,097 | 2,922,944 | 88.4% lower in aggregate; 88.1% lower per decode step (63.6 vs 534.6 layer-token writes/step). |
| Decode steps | 5,331 | 5,468 | Generation lengths differ; normalized rate is the fairer traffic comparison. |
| Six-task balanced quality | 38.38 | 38.58 | Inclusive −0.20 points, paired 95% interval [−0.47, +0.07]; no established quality advantage. |
| GovReport ROUGE-L | 26.93 | 28.36 | Inclusive −1.44 on 10 samples; task-level interval [−2.97, +0.06], a concerning direction needing more data. |
| 16k same-GPU full-loop ITL | 117.17 ms | 135.82 ms | Median of two ABBA blocks/arm, 50 fixed decode tokens, two measured trials/block; inclusive faster in this Python/GPU prototype. |
| 16k prefill peak allocation | 18.59 GB | 18.59 GB | No peak-memory improvement. |

The aggregate paid-write difference is 2,583,847 layer-token writes, or 10.58
GB of bf16 KV payload over 135 matched input requests. At the *assumed*
12.5 GB/s write rate it represents 0.847 seconds of ideal transfer across
the run, about 0.159 ms per inclusive decode step; at the capacity-matched
two-chip 5.4 GB/s theoretical maximum it represents 1.96 seconds, about
0.368 ms/step. At an *assumed* 8 pJ/bit it is 0.677 J. These are arithmetic
estimates, not measurements. The observed 18.65 ms/token prototype speed
difference is mostly software-path behavior and must not be credited to an
STT device. The no-shadow arm generated 137 more decode steps; its absolute
write count also reflects that output-length difference.

**Decision:** Retain inclusive shadows as an experimental design point for
write count and prototype runtime, but do not claim superior quality,
whole-request energy, peak memory, or physical STT speed. Repeat the
GovReport comparison on more examples and independent tasks/models, then
measure actual tier traffic and serving latency before promoting the
mechanism to a publication contribution.

### True-query retrieval pilot (2026-09-24)

`experiments/probe_query_recall.py` used the actual rotary-positioned decode
query and all live STT keys on a 16k real-text prompt. Across 50 steps and
32 layers, access-time selection overlapped the query-scored top 32 by only
0.14 tokens/layer/step and captured 3.1% of the mass of that top 32. The
probe uses the current model hidden states and a softmax over VRAM plus live
STT without the new self token; it is a diagnostic, not a counterfactual
quality score.

`experiments/evaluate_query_selection.py` then tried a same-step, per-layer
true-query selector in a forward pre-hook. It replaces only the 32 slow-tier
rows in each layer's visible cache and preserves the shared causal-mask
length. A 15-request, three-task paired pilot (`results/query_selection_pilot/`)
scored Qasper 12.86 vs 6.91, NarrativeQA 18.77 vs 18.53, and GovReport
34.25 vs 28.25 against access-time selection. The task-balanced difference
was +4.07 points, paired conditional interval [+0.85, +7.39]. This is a
selected small pilot, not generalization. Paid writes per decode step rose
from 48.5 to 70.7 layer-token writes, with different generated lengths.

The same-GPU ABBA 16k/50-token fixed-decode comparison measured **158.91
ms/token** for query selection versus **115.53 ms/token** for the old policy.
The forward timing includes the selection hook (59.6 vs 25.1 ms); prefill
peak stayed 18.59 GB. Thus the candidate is not a quality–latency Pareto
improvement.

The full six-task test (`results/query_selection_full/report.json`) now
reports **42.73 vs 38.38** task-balanced points, a paired difference of
**+4.35** with conditional 95% interval **[+2.12, +6.61]** on the fixed
135 requests. Per-task query scores were MultiFieldQA 59.68, Qasper 20.44,
NarrativeQA 21.28, HotpotQA 43.73, TriviaQA 78.30, GovReport 32.94; all
task means were at least as high as the access-time control. The control is
the source-matched inclusive run whose scores, predictions and counters
exactly reproduce v3. Query selection increased paid writes from 63.6 to
95.4 layer-token writes per decode step (+50%), while its inclusive policy
still avoided 80.8% of its own potential decode-demotion writes. The two
arms generated different lengths, so aggregate writes alone are misleading.

The matched-attended run (`results/query_selection_matched/report.json`)
uses 992 fast slots plus 32 exposed slow slots, so both arms attend at most
1024 cached tokens. On the same six tasks and source-matched inputs, query
selection scored **41.53** versus **37.80** for the in-harness SnapKV
approximation: paired task-balanced **+3.73** with conditional 95% interval
**[+1.85, +5.70]**. The selector still has 2048 additional simulated slow
slots, and SnapKV is not an upstream-faithful replication. This is a
controlled policy-family result, not a SOTA comparison. A same-GPU ABBA
16k/50-token latency check at these 992+2048 capacities measured 156.16
ms/token for query selection versus 113.75 ms/token for access-time selection
(`results/query_selection_matched/latency.json`), so the quality gain remains
a large latency tradeoff. Both arms reached 18.59 GB prefill peak allocation.

The completed equal-total run (`results/query_selection_equal_total/report.json`)
uses 341 fast + 683 slow slots and scores **36.31** versus **37.80** for
the source-matched in-harness SnapKV approximation. The paired difference
is **−1.49**, conditional 95% interval **[−3.73, +0.44]**. This does not
establish an advantage or equivalence. Its maximum attended width is 373
versus 1024, so this comparison does not isolate residency from attention
width. Source, selector/driver hashes, datasets, and sample pairing passed
the report checks on 2026-09-27.

**Decision:** The quality gain survives the full selected six-task sample
and matched attended width, but the candidate remains an expensive
diagnostic, with no demonstrated equal-total advantage. Next verify independent examples/models,
and faithful Quest, RetrievalAttention and SnapKV baselines. Optimize the selection path and
re-measure full-loop latency before any Pareto or SOTA claim. Query-aware KV
retrieval itself has prior art; the present hook is not a novelty claim.
More critically, the hook scans every live slow-tier **key** on the GPU each
step. At the observed 1,560.5 live rows/layer, 32 layers, and 2,048 bf16
K bytes/layer-token, it reads about **102 MB per decode step** just to rank
candidates, before fetching selected K/V. The capacity-matched two-chip
5.4 GB/s STT anchor gives an ideal serial-transfer floor of **18.9 ms/step**
for that scan alone (2.0 ms even at the unvalidated 50 GB/s scenario),
excluding controller, link, and random-access costs. This estimate is not
the measured GPU timing. A deployable selector must score compact page
summaries kept in fast memory, compute near the slow tier, or otherwise
avoid reading the entire cold key pool per token; compare Quest-style
bounds and measure recall-versus-summary-bytes and actual traffic.

An offline page-candidate diagnostic is now available in
`probe_query_recall.py --page-size 16 --candidate-pages 8`, using
`page_candidates.py`. CPU checks verify per-head logit upper bounds, partial
pages, unique row IDs, and full coverage when all pages are requested.
The diagnostic ranks pages by maximum head bound and measures exact top-32
recall and metadata bytes on the frozen access-time trajectory. Real-model
measurements remain pending. Its exact reranking uses full-key softmax
denominators and rebuilds summaries, so it is an optimistic retrieval
diagnostic, not a deployable replacement or a latency result. Persistent
metadata maintenance and candidate-only scoring still need implementation
and quality validation before claiming a reduced physical key scan.

The first real-model page probe (`results/page_recall/p16_k8.json`) covers
20 decode steps × 32 layers on the fixed 16k prompt. With 16-row pages and
8 selected pages, it reads candidates for a mean 127.24 of 1545.5 live rows.
It recovers only 6.9/32 oracle tokens (21.6%) and 40.7% of oracle top-32
attention mass, despite optimistic exact reranking. FP32 min/max summaries
cost about 795,443 bytes per layer (25.45 MB across layers), about one quarter
of the live bf16 key payload. This setting is not ready for quality or speed
claims. The completed 32-page follow-up recovers 59.9% of top-32 tokens
and 80.4% of their mass while selecting 33.0% of live keys (~33.46 MB
across layers). Both runs have identical recorded decode trajectories and
pass source/coverage checks (`results/page_recall/report.json`). This remains
an offline diagnostic: stable metadata maintenance and a deployable
reranker are open. Neither setting yet justifies a production replacement.

A follow-up fixed-trajectory diagnostic compared three page rankings at
16-row pages. Query-dot-page-centroid ranking used **12.14 MiB** fp32
summaries across 32 layers versus **24.27 MiB** for the box bound. With
eight pages, top-32 oracle recall rose **21.56→41.41%** and mass captured
**40.73→55.09%**; with 32 pages, recall rose **59.92→72.35%** and mass
**80.37→82.54%**. The mean-plus-L2-radius bound used similar metadata
to centroid but lost to the box bound, so it was rejected. Reranking
using only fast and candidate slow keys reproduced the centroid recall
and mass to within 0.03 percentage points. All 640 layer-step trajectories
matched exactly (`results/page_recall/centroid_report.json`).

The quality stress is mixed. With 32 centroid-ranked pages and actual-query
prompt placement, first-two Qasper averaged **53.97**, matching full-query
and exceeding access-time **28.03**. On ten GovReport requests, centroid
scored **29.33** versus access-time **27.00** and full-query **32.97**;
paid writes rose 96,890→104,832 but stayed below full-query's 121,762.
The loop implementation took a descriptive **251.01 ms/output token** on
GovReport. Vectorized page means reproduced all 640 offline selections,
but a same-process 16K/50-token ABBA pilot still measured **150.80** versus
**142.95 ms/token** for full-query selection, with similar memory peaks.
Thus centroid routing is a quality/metadata clue, not yet a usable fast
selector (`results/page_recall/centroid_quality_gov10.json`,
`centroid_latency_abba_pilot.json`). The current packed slow tensor
compacts on promotions and evictions, changing row-based page membership;
maintaining summaries requires stable page IDs or carefully updated
per-page aggregates. That architectural work is unimplemented and must be
measured before claiming fewer cold-key reads or better latency.

The first stable-ID prerequisite was tested on the identical 640 layer-step
trajectory. Fixed absolute-position pages failed because retained prompt
tokens are sparse: eight pages supplied only 22.7 candidate rows on average
and underfilled 85.9% of layer-steps. Assigning dense 16-row page IDs at
initial cold placement, then retaining each token's ID through row
compaction, preserved retrieval: eight pages gave **41.87%** top-32 recall
and **55.82%** oracle mass, versus **41.41%/55.08%** for re-formed row pages;
32 pages gave **73.17%/82.52%** versus **72.33%/82.53%**. No exposure
underfilled. Estimated fp32 centers/counts plus page IDs cost **12.51 MiB**
across 32 layers, close to the row-page diagnostic's **12.14 MiB**
(`results/page_recall/stable_page_report.json`). This validates *grouping*
only. The next implementation must incrementally update page sums/counts
when a row becomes a shadow, a backup is restored, a new demotion is
appended, or a live row is evicted; compare its centers with a full rebuild
after every transition. Only then can it be timed and evaluated for quality.

An opt-in incremental index was implemented and tested against full rebuilds
after every step in three 100-step synthetic transition regimes, including
backup restoration, shadow reclaim, paid demotion and live eviction. The
index also passed final-state validation on four real requests. On two
Qasper examples its score matched rebuilt centroid pages (53.97); on two
GovReport examples it scored 33.46 versus 27.09, reflecting the different
stable grouping but too few requests for a quality claim. This prototype
reads only changed K payload for summary maintenance, but those reads
totalled **170.42 MiB** across the two Qasper requests and **1,052.60 MiB**
across the two GovReport requests. Its estimated logical index reached
**22.41 MiB** across layers, excluding Python dictionary overhead. The
same-process 16K/50-token ABBA latency gate failed: **533.47** versus
**146.72 ms/token** for full-query selection, a **263.6%** regression.
The Python metadata scans, many small GPU updates and synchronizations need
profiling and a batched/native redesign; no broader quality evaluation is
justified for this runtime path (`results/page_recall/indexed_report.json`).
An 8K/5-token cProfile then attributed 1.826 s cumulative to 320 page
reconciliation calls, with 1.684 s self-time in the two full position-map
comprehensions; page candidate ranking used 0.249 s. A narrower set-delta
replacement preserved transition parity but improved one same-process 16K
ABBA median only **525.15→522.46 ms/token (−0.51%)**. It was reverted.
The profile is descriptive and includes CUDA waits; the paired timing
rejects Python-level bookkeeping micro-optimization as the route to a
competitive selector (`results/page_recall/indexed_cprofile_8k.txt`,
`index_set_delta_abba.json`).

## Evaluation and publication gates

### Completed upstream-selector adapter comparison (2026-09-27)

All 135 requests now pass source/dataset checks, exact sample pairing,
recomputed prediction scores, and final KV payload accounting. Scores:
MultiFieldQA 61.99, Qasper 23.29, NarrativeQA 20.35, HotpotQA 44.17,
TriviaQA 78.30, GovReport 30.32; task-balanced mean **43.07**.
`results/snapkv_adapter_full/comparison.json` reports candidate-minus-adapter:

| Query-aware candidate | Paired difference | Conditional 95% interval |
|---|---:|---:|
| 1024 fast + 2048 slow | −0.34 | [−2.13, +1.56] |
| 992 fast + 2048 slow | −1.54 | [−3.50, +0.29] |
| 341 fast + 683 slow | −6.76 | [−9.64, −4.07] |

The configuration labels describe the candidate, not fairness relative to
the adapter: expanded query heads, growing decode KV, window 32, and SDPA
make this a whole-policy comparison. No candidate superiority is established.
Next: byte-matched capacity controls and measured peak/steady memory, followed
by isolated timing; retain the approximation results as historical controls.
The reporting loader was corrected to read physical JSONL lines rather than
splitting Unicode line separators embedded in text. Evaluation inputs and
predictions were unaffected; all saved scores recompute successfully.

### SnapKV fidelity diagnostic (2026-09-27)

`experiments/probe_snapkv_fidelity.py` directly executes the vendored
`SnapKVCluster.update_kv` on deterministic CPU tensors and compares its
selected token IDs with the harness. Its runnable checks verify actual-query
sensitivity, distinct per-head selections, observation-window retention,
and stored KV bytes. Evidence: `results/baseline_fidelity/snapkv_probe.json`.
The vendored repository revision is
`e216ddc84c5bd210378cbdbbba12ba02102aa640`; the report hashes the source file.

The differences go beyond K-as-Q scoring: upstream masks future keys within
the observation window, pools only older-token scores, selects independently
per expanded query head, and appends generated KV during decode. The harness
averages heads, pools the entire sequence, pins sinks, and uses fixed-budget
H2O decode eviction. The synthetic check disables sink pinning to isolate
other differences. This is a semantic diagnostic, not a quality experiment.

The vendored Mistral integration expands KV heads before cache storage.
For Mistral's 32 query heads / 8 KV heads, equal retained token counts can
therefore cost four times as many KV payload bytes in that implementation.
A faithful adaptation must report actual bytes and growing decode residency,
in addition to prompt token capacity. Do not silently average GQA heads or
add fixed-budget eviction while labeling the result upstream SnapKV.
Next gate: adapt actual rotary-query capture and per-head prompt selection
to the installed Transformers cache interface; match gathered tensors to
the vendored function on a tiny Mistral, then run source-matched quality
and memory measurements before making a baseline claim.

The first integration gate now passes: `experiments/snapkv_adapter.py`
captures rotary queries, calls the vendored selector, stores expanded-head
KV, returns full KV for prefill attention, and appends generated KV during
decode. `experiments/check_snapkv_adapter.py` passes with both `eager` and
`sdpa` on a two-layer randomly initialized CPU Mistral. It checks unchanged
prefill logits, reference-selected tensors, three decode steps with absolute
positions, finite outputs, cache growth, and restoration of attention hooks
and head-group configuration. This is an experimental adapter for a single
full prefill followed by single-token decode; it is not yet wired into the
LongBench evaluation. Real-model quality, short-prompt coverage, long-context
memory, numerical precision, and timing remain open. The hook duplicates
Q/K projections for selection capture, so timing would include that overhead.

The adapter is now connected through `evaluate_snapkv_adapter.py` to the
existing LongBench prompt/scoring protocol. Short-prompt, capacity-boundary,
and bf16 tiny-model checks pass. A five-example Qasper pilot completed at
20.02, with mean final expanded-head KV payload 552,284,979 bytes. The
report at `results/snapkv_adapter_pilot/qasper_report.json` verifies runtime,
source and dataset hashes, exact sample IDs, counts, and aggregate score.
This is not an equal-byte comparison or a speed result. A 25-example run
on each of the five short tasks has been launched under
`results/snapkv_adapter_full/`; its completion and results remain unverified.
The report now independently checks every sample's KV payload against
524,288 bytes per retained token for this model's expanded bf16 heads;
all pilot samples pass. The tiny-model gate also compares three short-prompt
decode logits with ordinary GQA when compression removes no tokens (bf16
SDPA passes). GovReport and equal-byte/growing-residency controls remain
pending; the five-task run alone does not complete the baseline milestone.
The ten-example GovReport job has now also been launched (`gov.json` when
complete). Both jobs use upstream-default observation window 32, capacity
1024, bf16, and SDPA for prefill/decode. Earlier harness SnapKV used window
128 and fixed-budget H2O decode; its comparison with these runs is therefore
a comparison of complete policies, not a one-variable attribution. The
report verifier now recomputes each score from the prediction and dataset
answers, including the task-specific first-line normalization. The pilot
passes this check. No latency conclusion is allowed from concurrent jobs.
GovReport has completed: 30.32 over 10 examples, with mean final KV payload
706,687,795 bytes. Source, dataset, sample, recomputed-score, and byte checks
pass (`results/snapkv_adapter_full/gov_report.json`). The five-task run has also completed; the verified six-task aggregate
and comparisons are recorded above.

The completed byte audit (`python experiments/report_baseline_bytes.py`,
`results/baseline_fidelity/snapkv_byte_comparison.json`) checks every saved
SnapKV final KV payload against its token count and source-file hashes.
Expanded-head SnapKV uses 524,288 bf16 KV bytes per row; TieredKV uses
131,072 bytes per row and has a configured 3,072-row/402,653,184-byte
(384 MiB) steady resident ceiling. SnapKV final payload exceeds that
ceiling on 134/135 examples; its GovReport mean is 706,687,795 bytes.
This quantifies the byte mismatch but does not measure TieredKV's exact
per-example residency or full prefill peak. It does not establish a
capacity-matched quality winner: the compared policies also differ in
attention width, selection, and growing versus fixed decode residency.

A four-example controlled screen then set TieredKV to 992 fast + 3,104 cold
bf16 rows, exposing 32 cold rows, versus the expanded-head SnapKV adapter's
1,024-row prompt capacity. Both have a configured **512 MiB prompt KV
ceiling** and at most 1,024 attended rows; both were rerun on GPU0 with
eager attention, the same runtime, model, datasets, and sample IDs.
Qasper was **13.12 vs 30.62** (TieredKV vs SnapKV), while GovReport was
**37.31 vs 32.08**; the four-example task-balanced paired difference was
**−6.13 points**. Crucially, measured *final* TieredKV resident KV payload
was only **68.5–83.1%** of SnapKV's final payload because the policies fill
and grow differently. The pilot is a negative screen for this candidate,
not an equal-byte or statistically powered comparison. The query scan also
reads more cold keys than a serving implementation can afford. Artifact and
reproducer: `results/baseline_fidelity/matched_pilot_report.json` and
`experiments/report_matched_pilot.py`. Four predictions reproduced exactly
after adding TieredKV byte accounting. Do not scale this candidate before
measuring and matching actual per-request bytes and eliminating the scan.

A later actual-query-prompt/access-time-decode TieredKV screen compared the
first five examples each of Qasper, NarrativeQA and GovReport against the
upstream-selector SnapKV adapter. Fixed 768 expanded-head SnapKV prompt
rows left Qasper/NarrativeQA at ~0.94/0.93 times TieredKV's measured final
KV bytes but GovReport at **1.38 times** because SnapKV grows during decode.
An eager-attention NarrativeQA attempt OOMed on a 59.14 GiB prompt
attention allocation; the successful adapter run used SDPA, so no equal-
mode prefill latency/peak inference is valid.

As a resource diagnostic, task-level SnapKV capacities 832/832/500 were
chosen from the already observed output-length regime, yielding mean final
Snap/Tiered KV byte ratios **1.020/1.011/1.014**. Quality was mixed:
Qasper Tiered 15.65 vs Snap 20.30 (**−4.64**), NarrativeQA 20.03 vs 16.45
(**+3.58**), GovReport 28.17 vs 29.13 (**−0.96**). Task-balanced paired
difference was **−0.68** with conditional 95% interval **[−4.93,+3.36]**.
GovReport per-request byte ratios still ranged **0.806–1.840** despite
matched task means. SnapKV's final attended rows were 709–870 here, below
TieredKV's 1,024-row ceiling; capacities were selected using prior
observations, not an ex-ante common budget. Thus this is neither an equal-
resource SOTA comparison nor evidence of a quality lead. The exact
verified scores, sample IDs, payloads and ratios are in
`results/baseline_fidelity/snap_task_bytes_report.json`.

The stricter follow-up fixed the *configured maximum final resident KV*
before generation: **512 MiB** for both policies. TieredKV kept 4,096
compact GQA rows; SnapKV's expanded-head prompt capacity was
`1025 − task_max_generation` so its growing decode cache could never
exceed 1,024 rows. Current-source TieredKV was rerun on all 135 examples
and reproduced every archived prediction, score, final resident byte count
and task cache counter; both arms shared the same runtime source hash.
The verified six-task Tiered−Snap quality difference was **−0.05 points**
(conditional paired 95% CI **[−1.36,+1.36]**). Qasper remained **−3.46**;
NarrativeQA −0.21, MultiFieldQA +1.14, HotpotQA +2.67, TriviaQA −0.91,
GovReport +0.50. Actual mean Snap/Tiered KV byte ratios were 1.121,
1.085, 1.296, 1.234, 1.268 and 0.944 in that order. The ceiling is
matched, but actual bytes, attended row counts, prefill peak, cache layout
and runtime attention implementations are not. The upstream adapter passed
independent tiny-model SDPA/eager cache/logit checks. This establishes no
TieredKV superiority, latency advantage, physical STT result or SOTA claim
(`results/baseline_fidelity/snap_exante_full_report.json`).

A paired two-Qasper screen reallocated 96 fast attended rows to cold query
selection (896 fast + 3,200 cold, 128 exposed; unchanged 4,096-row resident
and 1,024-row attention ceilings). Mean actual cold exposure rose from
32 to 128 without starvation, yet Qasper fell **13.12→10.82**. The
preregistered +5-point screen failed, so this candidate is rejected
(`results/baseline_fidelity/expose128_report.json`). The next isolated
quality hypothesis is prompt placement: `TieredKVPolicy._bifurcate()` still
feeds **K as a Q proxy** into `initial_bifurcation()`, whereas the
upstream-selector SnapKV adapter captures actual rotary queries. Test
actual-query, causally masked prompt importance with the same byte/width
controls before changing the default policy.

The opt-in actual-query placement pilot is now implemented. It captures only
the final 128 rotary-positioned prompt queries, masks future keys, and uses
the model's real GQA queries to rank a shared token set; the ordinary
K-as-Q default remains unchanged. A 27-example paired screen across all six
tasks found **+4.45 task-balanced points**, conditional 95% bootstrap interval
**[+0.81,+8.86]**, but **4/27** individual examples regressed and GovReport
fell **1.72** points. Logical paid demotion writes fell in every task,
**109,660→60,643 (−44.7%)** across the
27 examples; this is a simulator counter, not physical device traffic.
Single-run median prefill time increased **5.5–11.4%** and peak allocation increased
**54–506 MB** by task. The change is an **opt-in quality/write trade-off**,
not a default or SOTA result. The likely source of the gain is repairing
the prior K-as-Q prompt-scoring approximation; actual-query selection is
already part of SnapKV prior art. The full score/source/sample audit is
`results/baseline_fidelity/real_q_prefill_six_task_report.json`; boundary
and K/V integrity tests are in `tests/test_real_query_prefill.py`.
The initial expanded-head score path unnecessarily duplicated GQA keys.
The revised opt-in path broadcasts the eight KV heads across 32 query heads
in one score pass. It reproduced **all 27 predictions and cache counters
exactly** while lowering separate-run median prefill peak by **57–473 MB**
and prefill time by **0.3–3.7%** versus expanded scoring. Those timings are
descriptive across separate processes. A three-block same-process ABBA
benchmark of the optimized path against the K-as-Q default found
**+7.53%** prefill+placement time and **+16 MiB** peak allocation on the
4,895-token Qasper prompt, and **+5.07%** time/**+32 MiB** peak on the
31,500-token NarrativeQA prompt. Every paired block agreed on the timing
direction. This is below the protocol's 10% prefill-time guard for these
two prompts, but remains a real latency and memory cost. The measured
ABBA artifact is `results/baseline_fidelity/real_q_prefill_abba_report.json`.
The quality and GovReport limitations above remain; full-loop decode and
held-out performance are not established.

The preregistered **135-example** same-source six-task comparison then found
**+2.34 task-balanced points** for actual-query prompt placement versus the
K-as-Q proxy, conditional paired 95% CI **[+0.30,+4.42]**. Qasper gained
5.45, NarrativeQA 2.02, HotpotQA 4.09, TriviaQA 2.40, and GovReport 2.29;
MultiFieldQA **fell 2.22**, and **19/135** examples regressed. Logical paid
demotion writes fell **581,067→298,543 (−48.6%)**. This supersedes the
27-example quality screen above; that screen's GovReport decline did not
persist on the ten-example task sample. The verifier recomputed scores from
predictions/answers and checked sample IDs, dataset hashes, code/runtime,
and resident-byte bounds. Raw/model provenance and statistics are in
`results/baseline_fidelity/real_q_prefill_full_report.json` and
`model_sha256.txt`. An unrelated Ollama process overlapped candidate
Qasper/NarrativeQA on GPU0, so **full-run elapsed and peak comparisons are
invalid**; the earlier isolated prefill ABBA remains the applicable timing
evidence. A separate same-process, three-block ABBA on one 16K real-text
prompt and 50 fixed decode tokens measured complete-loop median ITL
**−1.23%** and p95 ITL **−1.21%** for actual-query placement, while median
TTFT rose **6.22%** and prefill peak allocation rose **0.199 GB (1.07%)**.
All three blocks agreed; GPU0 showed only the benchmark process during the
run. The raw/report artifacts are `results/baseline_fidelity/real_q_full_loop_abba.json`
and `real_q_full_loop_abba_report.json`. This is a modest decode improvement
with a real prefill cost, not a throughput or general latency claim. The
quality gain is conditional on selected tasks/model/seed, not held-out
generality. It cannot be a default or publication claim without stronger
stress, faithful baselines and a physical tier.

With the cheaper access-time decode policy held fixed, the same actual-query
prompt placement gained **+5.20 task-balanced points** over K-as-Q on the
frozen 135 examples (conditional paired 95% interval **[+2.84,+7.69]**),
and reduced logical paid demotion writes **359,473→292,996 (−18.49%)**.
Qasper, NarrativeQA, MultiFieldQA, HotpotQA and TriviaQA improved by
8.97, 4.29, 6.34, 10.98 and 1.98 points, respectively; **GovReport fell
1.35** and **22/135** individual examples regressed. The verifier checks
source/runtime/data hashes, sample IDs, scores and a 512 MiB resident-byte
ceiling (`results/baseline_fidelity/real_q_lru_full_report.json`). A separate
16K/50-token three-block ABBA found effectively neutral decode latency
(median block ITL **−0.50%**, p95 **−0.13%**, one median block slower), but
median TTFT **+6.89%** and prefill peak **+0.199 GB**
(`real_q_lru_full_loop_abba_report.json`). This is a stronger practical
selected-sample result than the expensive query-scan path, though its
absolute six-task quality is 2.87 points lower; neither establishes SOTA.
The significant gain requires an immediate edge-case stress audit before
further optimization or default promotion.

That audit found gains in all three prompt-length bins (≤4K +5.23,
4K–16K +6.16, >16K +6.50), but the >128 generated-token bin, consisting
of ten GovReport summaries, averaged **−1.35** and had **6/10** regressions.
Six of 135 examples lost more than ten score points; two positive control
scores became zero. The worst TriviaQA example fell 100→40 when the
candidate added an incorrect answer qualifier. The sampled boundary and
cache-policy tests pass (40/40), but adversarial/OOD/temporal/concurrent,
physical-tier and multi-model stress are still absent. The exact IDs,
lengths and paired scores are in `results/baseline_fidelity/real_q_lru_stress_report.json`.
Keep the policy opt-in. A targeted long-generation retrieval fix and a
regression guard need paired evidence before tuning or default promotion;
truncating answers merely to improve the benchmark metric is not a
valid fix.

A targeted late-query selector activated after 32 decode steps recovered
GovReport 27.00→30.98 on the same ten examples, but raised logical paid
writes 10.8% and descriptive wall time/generated token 94.05→136.54 ms
(+45.2%). Its experimental hook was removed. This confirms that current
query access can restore some long-output quality, while a full cold-key
scan conflicts with the latency goal (`results/baseline_fidelity/late_query32_gov10.json`).

1. **Freeze a control and preregister the comparison.** Fix model revision,
   task samples, context lengths, budgets, precision, software stack and
   hardware. Vary one mechanism at a time. Re-run both candidate and baseline
   on the same protocol after any source change.
2. **Use faithful competitors.** Replicate upstream SnapKV/H2O, Quest or
   RetrievalAttention where applicable, FP8/quantized KV, and a modern
   paged-serving control. Internal approximations may remain diagnostics but
   cannot support SOTA claims.
   The vendored `sota/snapkv/snapkv/monkeypatch/snapkv_utils.py` uses the
   model's actual rotary-positioned observation-window queries and top-k
   selection per expanded attention head; the current in-harness SnapKV
   instead uses K-as-Q and one head-averaged token set. Its Mistral patch
   repeats GQA KV heads before selection, which also changes the actual
   cached byte budget. A faithful adaptation must report both attended-token
   count and physical KV bytes and use the same model/harness protocol.
3. **Test quality beyond a small LongBench slice.** Use full/held-out examples,
   multiple seeds and model families, retrieval, reasoning, summarization and
   multi-turn/shared-context workloads. [SCBench](https://proceedings.iclr.cc/paper_files/paper/2025/hash/a540b17fb2295c736d5afd6c507acf66-Abstract-Conference.html)
   specifically probes cache generation, compression, retrieval and loading.
   Report paired uncertainty and all regressions, not only mean wins.
4. **Measure the entire request.** Include TTFT, prefill and decode peak HBM,
   TPOT distribution, single-request latency, batched throughput, CPU/GPU
   utilization, PCIe/CXL traffic, and whole-request energy when hardware is
   available. State whether the slow tier is simulated, CPU DRAM, or STT-MRAM.
5. **Go/no-go.** Advance a mechanism only if it offers a repeatable Pareto
   improvement, or a clearly quantified tradeoff valuable for a stated
   workload. A publication claim needs independent test tasks/models and a
   credible implementation of the tier it names. Otherwise keep it as an
   ablation or negative result and revise the hypothesis.

Combining existing quantization, paging and retrieval methods without a new
mechanism is unlikely to be sufficient novelty. The most promising distinct
question here is whether an *inclusive, write-aware, query-retrievable* cold
tier can reduce real device writes and GPU capacity while retaining quality
and competitive serving speed. That is a hypothesis to test, not a current
result.

### Recycled slow-tier slot screen (2026-09-27)

`experiments/probe_slot_storage.py` compares the existing packed append plus
survivor compaction with overwriting freed physical slots and maintaining a
logical-order index. It copies **both K and V** for 32 layers of 8 heads ×
2,048 slow rows × 128 dimensions in bf16. Both arms replace 32 rows and read
32 identical logical rows each step. Final K/V tensors match exactly. On a
second L40S, two ABBA blocks gave median isolated step time 2.037 ms packed
versus 0.937 ms slots (54.0% lower); peak PyTorch allocation was 0.600 versus
0.587 GB. Raw timings, hardware, runtime and probe hash are in
`results/decode_overhead/slot_storage_probe.json`.

**Decision after integration check:** the guarded full-tier candidate passed
bf16/FP8 logical-parity tests, but it never activated in the existing 16-step
8K/16K ABBA protocol. Prefill occupies 75% of 2,048 slow slots, leaving
~512 slots before overwrite can happen. The 8K/16K timing differences are
therefore not causal evidence; the candidate was removed. Raw timings remain
in `results/decode_overhead/slot_recycling_abba_{8k,16k}.json` for audit.
The probe omits model forward, policy selection, attention, physical STT
traffic and mixed fill levels. A follow-up **reserved append** screen at the
actual 1,536→1,552-row operating point preserved exact K/V but regressed
isolated median step time from 1.191 to 1.424 ms (+19.5%) and increased
peak allocation by 58.7 MB. It is rejected; see
`results/decode_overhead/reserved_append_probe.json`. A >512-step
instrumented decode could test full-tier recycling if long-generation
workloads matter, but the current short-decode control gives no reason to
roll it out. The higher-priority latency problem is policy selection and
per-layer Python/GPU synchronization in the *currently active* path.

A source-fingerprinted 8K/16-token CPU profile of the current packed path
identifies 512 `evict_and_demote` calls at 0.751 s cumulative host time,
`_visible_tuple` at 0.249 s and `update_scores` at 0.153 s. These are
profiling-perturbed, overlapping totals; they identify where to inspect,
not additive latency attribution. The PyTorch trace showed thousands of
small launches and host/device synchronizations, while prefill dominated
aggregate GPU `mm` time. Summary and raw cProfile artifact:
`results/decode_overhead/policy_cprofile_8k_summary.json` and
`policy_cprofile_8k.prof`. A line trace localized 6,900 shadow backup
restorations over 16 decode steps, with row-by-row GPU LRU assignments a hot
line (`demotion_line_trace_8k.json`). The finite-count shortcut was tested
and removed: 8K timing looked favorable but p95 worsened, while 16K pooled
median regressed and paired blocks disagreed.

The retained change batches shadow reactivation metadata writes within each
layer call. It does **not** reduce modeled STT payload writes; it removes
host launches for metadata updates. Final-source three-block ABBA full-loop
medians were 109.22→98.13 ms/token at 8K (−10.2%) and 108.30→97.80 at 16K
(−9.7%); p95 improved from 174.44→152.04 and 152.40→126.80 ms. Two of
three paired blocks favored batching at each length; decode peak was equal.
The first five Qasper, NarrativeQA and GovReport prompts gave 15/15 exact
32-token generations and equal paid/saved-write counters, with 162,591
shadow reuse events in each arm. The timing and parity artifacts share the
same source fingerprint (`batch_backup_abba_{8k,16k}_final.json`,
`batch_backup_parity_15_final.json`). This justifies retaining a local
behavior-preserving optimization, not a serving-speed or SOTA claim. Next
measure longer generations, throughput/batching, and remaining active
policy operations; do not assume a 16-token result generalizes.

### Faithful SnapKV loop comparison (2026-09-29)

The upstream-query SnapKV adapter and best actual-query TieredKV candidate
were timed in one process on the same real 16K prompt with 50 fixed decode
forwards, six measured trials per arm in three ABBA blocks. Both had a
configured 512 MiB maximum final KV payload; actual payload was 512 MiB
SnapKV and 425 MiB TieredKV. TieredKV's median complete-loop decode was
95.08 ms/token versus SnapKV's 25.74 (3.69× slower), with p95 100.56 versus
25.96 ms. TTFT was 2217.22 versus 2097.99 ms. Its decode allocation peak
was lower (15.234 versus 16.522 GB), but prefill peak was higher (18.796
versus 17.958 GB). This one-prompt result rejects any claim that the current
candidate improves all measured dimensions or beats this faithful baseline.
The arms require different attention outputs and generate different tokens;
the result is not a throughput or serving workload comparison. Full raw
trials and verification are in `results/baseline_fidelity/snap_tier_loop_abba.json`
and `snap_tier_loop_abba_report.json`.

The same-source 16K/10-step profile measured 97.89 ms/token complete loop
and 25.38 ms/token model forward. Within the profiling trace,
`evict_and_demote` took 0.334 s cumulative over 320 layer calls,
`_visible_tuple` 0.201 s over 11 calls, and `update_scores` 0.076 s. These
overlap and are profiling-perturbed, but point to per-layer Python policy
work, victim maintenance, and visible-cache construction. The next candidate
must preserve exact KV selection and predictions before paired latency
testing. Do not stack more quantization or query heuristics onto this
unresolved runtime bottleneck.

A parity-preserving opt-in hot-tier deferred append was tested next: it
removed an initial hot K/V concatenation before victim selection, then
built the final hot K/V after eviction. Synthetic inclusive/non-inclusive
transitions and 4K/8K/16K real-model cache/prediction parity all passed.
Three-block 16K ABBA still regressed median full-loop decode from 92.43 to
96.19 ms/token (+4.1%) and p95 from 100.07 to 103.87 ms, with unchanged
425 MiB final KV payload. All blocks favored control. The candidate was
removed. This is evidence that simply rearranging the same tensor gathers
and concatenations cannot close the ~70 ms/token policy gap. The next
architecture must reduce the *number* of per-layer copies/synchronizations
or avoid rebuilding the visible cache; it needs exact attention semantics,
prediction parity, and paired p50/p95 plus peak-memory proof before adoption.

The first retained post-profile speedup is an ordered boolean gather of
`stt_last_access` using the existing CPU shadow mask. The old Python list
index was converted to a long GPU index every layer and consumed 76.22 ms
over eight traced decode steps. On real Mistral 4K/8K/16K prompts, every
visible cold-row selection, generated text, final cache tensor, and counter
matched exactly. Same-process three-block 16K ABBA reduced median
full-loop decode from 93.88 to 86.34 ms/token (−8.0%) and p95 from
100.26 to 93.08 ms (−7.2%); all blocks favored the change, and prefill
peak, decode peak, and final KV bytes were unchanged. It is the default
path; the old list-gather switch remains for reproducible control runs.
This removes one bottleneck but does not close the larger faithful SnapKV
gap or prove a new research contribution. See
`results/baseline_fidelity/bool_live_gather_{parity,abba}.json`.

With that accepted path as the default, a new-source three-block 16K/50-step
ABBA against the faithful SnapKV adapter measures Tiered/Snap median
86.73/25.76 ms/token (3.37× slower) and p95 93.01/26.11 ms. Tiered's
decode allocation peak remains lower (15.234/16.522 GB), while its prefill
peak remains higher (18.796/17.958 GB); actual final KV payload is
425/512 MiB. This is a one-prompt single-request comparison, not serving
throughput. The next target must remove more per-layer Python decisions and
visible-cache rebuilds without changing selected content or paying in peak
memory. Artifact: `results/baseline_fidelity/snap_tier_loop_bool_default_report.json`.

A follow-up tried batching all 32 per-layer recency-sort indices into one
CPU transfer. Every selected row, cache state, and output still matched, but
the preregistered first three blocks averaged only a 4.96% median reduction,
just below its 5% gate. Three more preregistered blocks resolved the
boundary: across six blocks/12 trials per arm, pooled median moved only
89.61→88.49 ms/token (−1.26%); p95 improved 92.80→91.40 ms, but one full
block regressed. Peak allocation and 425 MiB final payload were equal.
The extra synchronization batch was removed. The improvement does not
justify another code path; current per-layer sorting/compaction remains the
larger architectural problem. Raw trials are in
`results/baseline_fidelity/batched_visible_{abba,followup}.json`.

The full quality provenance gap after enabling boolean live-row gather is
closed. Re-running all 135 frozen TieredKV requests reproduced every prior
prediction, per-example score, final KV byte count, and cache counter. The
SnapKV adapter was also rerun under the same current source fingerprint and
the same task IDs, capacities, model and package versions. Task-balanced
Tiered−Snap quality remains −0.0457 points, with conditional bootstrap
95% interval [−1.3573,+1.3621]; per-task differences remain Qasper −3.46,
NarrativeQA −0.21, MultiFieldQA +1.14, HotpotQA +2.67, TriviaQA −0.91,
GovReport +0.50. The interval supports neither a superiority claim nor an
equivalence claim, and actual resident bytes/attended widths still differ.
This is stronger source-matched evidence, but does not change the negative
quality conclusion or close the 3.37× decode-latency gap. Artifacts:
`results/baseline_fidelity/currentbool_*` and
`snap_exante_full_currentbool_report.json`.

The next parity-preserving optimization uses a boolean keep mask to compact
surviving hot K/V rows. Real 4K/8K/16K parity checks and the 135-example
source-matched quality run preserve selected rows, outputs, cache state, and
scores. On the same one-prompt 16K/50-forward three-block ABBA, current-source
complete-loop median ITL is now 82.76 ms for TieredKV versus 25.77 ms for
SnapKV (3.21× slower); p95 is 86.34/26.03 ms and TTFT 2194.82/2086.69 ms.
TieredKV remains lower in decode allocation peak but higher in prefill peak,
with 425 versus 512 MiB actual final KV. This reduces TieredKV's median from
86.73 ms after the prior gather optimization, but the large baseline gap and
quality near-tie remain. It is not evidence of serving throughput or physical
slow-memory performance. Keep the compaction default for its parity and
measured speedup; next investigate the remaining per-layer policy and
attention-weight overhead before changing cache semantics. Artifacts:
`results/baseline_fidelity/snap_tier_loop_currenthot_report.json`,
`snap_exante_full_currenthot_report.json`, and
`bool_hot_compaction_parity.json`.

A copy-fusion candidate deferred hot K/V payload append until after victim
selection, intending to copy surviving cache rows once. Exact rows, output,
state, and counters matched at 4K/8K/16K, but three-block 16K ABBA median ITL
regressed 78.51→79.66 ms (+1.46%) and p95 82.31→84.07 ms. The candidate was
removed. This falsifies the simple copy-fusion hypothesis for the current
PyTorch path; future copy reduction needs a different storage/layout strategy
and must clear a preregistered latency gate before entering the default.
Artifact: `results/baseline_fidelity/fused_hot_append_abba.json`.

The next preregistered screen tested stable `argsort` replacement with
tie-guarded `topk`. In 320 hot-eviction selections captured from the real
16K decode path, every boundary was tied. The guarded path fell back on every
call and took 34.76 ms versus 8.33 ms for stable sorting across the captured
set, so no implementation or full ABBA was justified. The current eviction
scores have too many ties for this shortcut. Future latency work should
reduce per-layer policy launches or change the data layout while preserving
the existing stable selection semantics. Artifacts:
`results/baseline_fidelity/stable_topk_probe.json` and
`experiments/probe_stable_topk.py`.

A preregistered batched-sort screen captured real 16K hot-eviction and cold
recency vectors. Stable batched argsort with neutral padding reproduced every
selected prefix, but grouped sorting and transfer saved only 3.70 ms per
decode step in a 10-step capture, below the 4.00 ms screen and full-loop 5%
gate. No cache code was changed and no ABBA was run. This simple batching
does not justify the cross-layer eviction refactor; pursuing launch reduction
now needs a mechanism with more headroom than sorting alone.
Artifacts: `experiments/probe_batched_stable_sort.py` and
`results/baseline_fidelity/batched_stable_sort_probe.json`.

The current-source 16K/10-step cProfile was rerun after the boolean hot-row
compaction was accepted. It again localizes cost in per-layer policy work:
320 `evict_and_demote()` calls took 0.269 s cumulative, `update_scores()`
0.076 s across 10 calls, and `_visible_tuple()` 0.120 s across 11 calls;
704 `argsort` calls account for 0.067 s. These figures include cProfile and
GPU-wait effects and overlap, so they are not additive or a latency claim.
The prior sort-only batching screen recovered just 3.70 ms per step, under
the 5% full-loop progression gate. Do not retry finite-count removal (already
rejected at 8K and 16K) or sort batching alone. The next code experiment, if
any, must reduce cross-layer policy synchronization/update work as a whole,
first prove exact victim/cache-state parity, and show ≥4 ms/step screening
headroom before a full ABBA. Raw current-source profile:
`results/baseline_fidelity/tier_policy_16k_10.txt` and `.prof`.

A host hot-score arithmetic screen on October 1 preserved float32 scores,
ages and stable victim lists across 32 synthetic layers, including tied and
protected-boundary cases. It kept the proposed cold-LRU path on GPU because
the harness's unstable tie ordering must be preserved. With the bulk
131,200-byte attention transfer charged to the host arm, median bookkeeping
was 6.009 ms on GPU versus 3.277 ms on CPU: only 2.732 ms headroom, below
the preregistered 4 ms screen. No real-cache implementation or full-loop
ABBA followed, and the default remains unchanged. This rejects the isolated
arithmetic mechanism; it does not establish real-model parity or test a
complete batched policy architecture. Artifact:
`results/baseline_fidelity/host_hot_score_screen_20261001.json`.

Two preregistered fresh actual-query/LRU tranches are complete (30 disjoint
examples each, five per each of six tasks). Tranche 1 was +5.17 with a 95%
interval [−1.60,+12.95], while tranche 2 passed its stricter 97.5% gate at
+7.30 [1.54,+15.12]. The pooled 60-example estimate is +6.24 with a
descriptive 95% interval [1.48,+11.48]; this interval is descriptive because
tranche 2 was added after tranche 1 did not resolve the question. Score gains
are concentrated in MultiFieldQA and HotpotQA. Manual review classified the
Qasper precision/recall omission as content loss, while a repeated correct
HotpotQA answer and an acronym-only NLMS answer appear format-sensitive under
ROUGE/token-F1. Stress bins show near-zero quality change above 16K context
and for >128-token generations, with six regressions among ten long outputs.
Prefill time/peak rose in all six tasks; pooled logical writes/step fell only
1.1%. This passes a quality-direction replication but fails the broader stress
and Pareto gates. Keep the path opt-in; no cross-model, adversarial/OOD,
concurrent-serving or physical-tier result exists. Verification checks source
and slice hashes, selected IDs, runtime, recomputed scores, and KV-byte caps.
Artifacts: `results/baseline_fidelity/real_query_holdout_20260929/`.

## Document-overlap audit correction (2026-09-29)

The two recent 30-row evaluations are disjoint by sample ID, **not by
document**. Exact context hashes show that 9/10 NarrativeQA and 3/10
MultiFieldQA evaluation rows reuse contexts in the original development
prefix. NarrativeQA also has only eight unique contexts among its ten rows.
The reported score differences remain valid for these examples, but the
row-wise bootstrap ignores shared-document dependence. Crossing tranche 2’s
97.5% numerical threshold is not evidence of calibrated independent-document
replication. Earlier “independent replication” wording is superseded by this
audit. Near-duplicate contexts and model-training overlap were not assessed.

Before another generalization claim, freeze groups by document identity,
exclude development documents and near duplicates, and use paired bootstrap
resampling of document groups. Keep the current policy opt-in. Evidence:
`results/baseline_fidelity/real_query_holdout_20260929/context_overlap_audit.json`;
reproduce with `python experiments/audit_holdout_contexts.py`.

### Document-group holdout correction (2026-09-29)

A new frozen 24-row check sampled one question from each of four distinct
normalized source-context groups in each of the same six tasks. No selected
group occurs in the earlier development prefix or either prior holdout.
Actual-query placement with LRU decode gained +4.14 task-balanced quality
points over K-as-Q/LRU, but the paired document-group 95% bootstrap interval
was [−0.84,+9.01]; it **did not pass** the preregistered positive lower-bound
gate. NarrativeQA fell −6.25, three rows regressed, and two rows lost >10
points. Median prefill time and peak allocation increased in all six tasks.
This weakens any prior replication interpretation and does not establish a
Pareto improvement. Keep actual-query placement opt-in. With only four groups
per task, the interval is unstable; semantic near duplicates and model-training
overlap are not excluded. A new candidate must be developed without tuning on
these held-out rows, then assessed on truly new documents/model/workloads with
matched-output systems and write measurements. Evidence and reproduction:
`results/baseline_fidelity/real_query_document_holdout_20260929/` and
`python experiments/report_real_query_document_holdout.py`.

The first loss mechanism check distinguishes cache selection from prompt
truncation. In the Qasper fact-loss case, actual-query placement permanently
dropped an average 3/18 answer-span tokens per layer versus 0.03/18 for
K-proxy placement, and none of the cold-held span was exposed at the first
attention step. This supports a coverage/retrieval hypothesis, not a proof of
which layer caused the wrong answer. In the NarrativeQA loss, the exact meeting
scene was in the middle of a 77,403-token prompt and was removed by the
shared 31,500-token benchmark truncation before cache placement. A policy
change cannot recover evidence absent from the prompt. Keep future candidate
selection on development data; diagnose answer-span coverage and distinguish
truncation misses from policy misses. Reproducible diagnostic:
`experiments/diagnose_prompt_placement.py` and
`real_query_document_holdout_20260929/placement_diagnosis.json`.

A fixed 50/50 mix of actual-query and K-proxy prompt scores was screened on
six development rows, never on the document holdout. It lost 1.56
task-balanced quality points, raised median prefill time in both tested tasks,
and increased logical paid writes. The +2 pilot gate failed, so the mix was
removed from the live code. This is a rejected engineering ablation, not a
novelty path (`results/baseline_fidelity/prompt_score_mix_dev_20260929/`).
Coverage-aware importance and fine-grained query retrieval are already
studied by [MixKV](https://arxiv.org/abs/2510.20707) and
[Fier](https://aclanthology.org/2025.findings-emnlp.515/), respectively;
simply mixing selectors would not distinguish TieredKV for a top-tier paper.

The write-saving result now has a matched-output check. On one fixed 16K
real-text prompt and the same 51-token full-cache teacher stream, four paired
inclusive/no-shadow ABBA comparisons each counted 2,690 versus 26,432 paid
layer-token demotion writes per 50 decode forwards (**89.82% fewer**).
Prototype median ITL was 82.58 versus 100.99 ms, but this two-block result
is descriptive. Prefill peak was equal at 18.594 GB and inclusive decode
peak was slightly higher (15.118 versus 15.114 GB). This removes differing
generation length/content as a write-counter confound on this trace, while
remaining a logical GPU-resident simulator result. It does not resolve
the physical STT page-traffic/endurance gap or the 3.21× SnapKV decode gap.
Artifacts: `results/shadow_ablation_full/fixed_stream_20260929.json` and
`fixed_stream_report_20260929.json`.

The current decode profile also rules out two small Python edits as a path
to the required speedup. A CPU NumPy construction of the protected-row mask
projects only ~2.6 ms/step saving across 32 layers, below the predeclared
4 ms screen; reusing an output buffer for visible-KV concatenation was
slower than fresh `torch.cat` in an isolated 32-layer GPU benchmark
(0.276 versus 0.236 ms). No live policy change was made. The matched
50-step trace promotes 15.52 cold rows per layer per step on average, so
simple delayed eviction would need substantial fast-tier headroom or would
violate the hard capacity; it is not a free batching optimization. Focus
on a structural attention/policy integration rather than repeated local
allocation tweaks.

An **opt-in physical CPU-DRAM cold-tier probe** now separates capacity from
the simulator's GPU-resident payload without changing placement decisions.
It leaves policy metadata on GPU and copies K/V synchronously between pageable
CPU memory and the model GPU; it does not emulate an STT-RAM controller or
change the agreed STT bandwidth assumption. A 4K/5-step pilot passed fixed-
input prediction/counter parity. In a 16K/10-step GPU/CPU/CPU/GPU sequence
with one warm-up per arm, every measured trial matched predicted tokens and
promotion/demotion/write counters. Final GPU allocation fell from 14.847 to
14.628 GB (219 MB), and decode peak from 15.136 to 14.909 GB (227 MB), but
the **18.594 GB prefill peak was unchanged** because full prompt KV is still
materialized before offload. The CPU arms measured 122.19/99.59 ms/token
median ITL, versus 79.35/78.33 on GPU; p95 was 221.52/122.58 versus
85.78/85.93 ms/token. Explicit cold-K/V payload counters recorded 66.58 MB
host-to-GPU and 206.64 MB GPU-to-host per CPU arm, including prompt placement;
they exclude controller amplification and CPU compaction traffic. This proves
the current token policy *can* operate over physical CPU memory and save
steady/decode GPU allocation, but the synchronous per-layer layout **fails
the latency advancement gate**. It is neither a serving win nor an STT device
measurement. Keep the default GPU tier; next require a batched/paged transfer
architecture with bounded prefill before claiming a useful physical-tier
Pareto point. Raw/provenance:
`results/hardware/cpu_cold_pilot_4k_20260929.json` and
`results/hardware/cpu_cold_probe_20260929.json`.

The CPU probe profile identified list-based host row gathers and repeated
host K/V concatenation as major *profiled* costs (0.983 and 0.844 s over
20 profiled decode steps; cProfile perturbs timings and inclusive totals
overlap). An opt-in subclass changed only the CPU gather to
`torch.index_select`. A 4K parity pilot and a 16K/10-step paired screen
passed. On a separate 16K/50-step three-pair stress run, the native gather
improved median ITL by 6.8%, 8.7%, and 8.2% in the three matched pairs;
p95 improved in each. Predictions, placement/write counters, transfer-payload
counts, and measured memory matched exactly across all six arms. The 50-step
CPU-fast medians were 94.86/92.15/92.90 ms/token, still above the
GPU-resident TieredKV result (~82.76 ms/token) and far above faithful SnapKV
(~25.77 ms/token) from a different benchmark session. This is a useful
implementation result for the CPU surrogate, **not** a competitive serving
or physical STT-RAM result. Host K/V append/compaction remains the next
architecture issue; do not spend time tuning STT bandwidth. Raw:
`results/hardware/cpu_cold_cprofile_16k_{cpu,gpu}.prof`,
`cpu_gather_pilot_4k_20260929.json`, `cpu_gather_abba_16k_20260929.json`,
and `cpu_gather_stress_16k_50_20260929.json`.

A reserved host buffer under the existing `[heads, rows, dimension]` tensor
shape failed an isolated screen: appending 32 rows would improve from 0.080
to 0.007 ms per K or V copy, but the active view becomes noncontiguous;
gathering 32 rows then worsened from 0.003 to 0.086 ms per call. Because the
read path is frequent, no reserved-buffer code was added. A real improvement
needs a storage layout that preserves contiguous selection and avoids repeated
whole-tier copies, rather than preallocating the present layout.

**Correction after a five-block recheck:** the first 0.080 ms host-`cat`
reading was unrepresentative on this machine. Repeated append medians were
0.629 ms `cat` versus 0.0079 ms reserved copy; gather medians were 0.0033 ms
contiguous versus 0.0868 ms reserved-view. The mixed effect cannot be decided
from isolated timings, so the above rejection is superseded by an opt-in
full-loop parity/latency test. Raw microbenchmark:
`results/hardware/cpu_reserved_layout_screen_20260929.json`.

The required full-loop check rejected that reopened candidate. On 16K/10
fixed decode steps in CPU-fast/reserved/reserved/fast order, median ITL moved
91.77→99.16 and 91.62→99.39 ms/token (both regressions of about 8%); one
p95 pair also exceeded the +2% guard. Outputs, cache decisions, write counts,
explicit host/GPU payload and GPU allocation matched, but the reserved host
buffer occupied 272.76 MB for 206.64 MB of live cold K/V. The active view's
read-layout penalty dominates in the real policy. Keep the native CPU gather;
do not promote or tune this buffer layout. Artifacts:
`results/hardware/cpu_reserved_pilot_4k_20260929.json` and
`cpu_reserved_abba_16k_20260929.json`.

Another possible shortcut, running decode attention with PyTorch SDPA and
recomputing the policy's attention probabilities afterward, failed an early
correctness gate. A captured rotary query and returned keys reproduced the
eager weights exactly on the *same* one-token eager forward (max error 0),
so the score formula itself is sound. Across a five-token 4K full-loop pilot,
however, the SDPA arm changed final cache placement and counted 1,213 paid
writes versus eager's 1,211 despite matching generated token IDs. Its one-run
median ITL was 87.84 versus 84.53 ms/token; no speed win was indicated.
The exact source of the between-kernel decision difference was not isolated;
different model/score numerics are a plausible mechanism, not a proven cause.
Because the preregistered exact policy parity gate failed, the candidate was
removed before a 16K/50-step run. The ordinary eager benchmark and default
policy are restored. Evidence and executed source snapshots:
`results/decode_overhead/sdpa_score_parity_1k_20260929.json` and
`sdpa_scores_pilot_4k_20260929.json`.

### Pinned physical host-slot transfer screen (2026-10-01)

A corrected storage-only comparison reused the unchanged, source-verified
FlexiCache CUDA transfer kernels with one-token pages and a pinned host
slot pool. It retained exact reads/final K/V for growing and recycled slots,
including empty reads. Three per-layer ABBA blocks measured packed / slot
medians of 20.254/6.767, 13.803/6.737 and 13.803/6.772 ms, charging GPU
packing, mapping uploads, launches and completion. Pooled median was
13.891/6.759 ms and p95 27.166/6.841 ms. Allocated host capacity was
272.76 MB for 203.95 MB useful payload. Four warmup steps per arm were
excluded but retained in the raw artifact. An earlier unqualified screen
omitted packing cost and had a slow first control arm; it is preserved
separately and cannot justify the decision.

This passes a cheap architecture screen, not the P0 physical-tier gate.
A real-cache adapter must own logical-to-physical mapping at every cold
read, append and compaction seam; preserve stream and pinned-pool lifetime;
and expose actual occupied versus reserved bytes. The native read module
has a single cached host pointer, so a shared pool or explicit registration
is required across layers. Do not substitute physical slot shape for logical
row count. Require exact policy/placement/output/counter parity before the
standard full-loop latency and quality trials. No STT-RAM, energy, model
latency or overlapping-transfer claim follows from this screen.
Raw: `results/hardware/cpu_slot_transfer_screen_v2_20261001.json`;
source: `experiments/probe_cpu_slots.py`.

The native host-slot mechanism subsequently **failed** its full-loop gate.
Synthetic growth/saturation/alternating-pool and 4K/8K/16K real-model
parity passed; twelve 16K/50-step arms preserved tensors, placement,
predictions, counters and payload. Median decode was 88.918 versus
89.228 ms (0.35% faster), below the required 5%; p95 was 101.850 versus
110.828 ms. Reserved real-cache host capacity was 402.78 MB versus
212.34 MB occupied. The active adapter and storage hooks were removed;
cache/harness source was restored byte-for-byte to pre-trial snapshots.
Exact sources are archived in
`results/hardware/cpu_slots_rejected_source_20261001/` and the complete
`cpu_slots_executed_source_20261001.tar.gz` bundle. Raw:
`results/hardware/cpu_slots_abba_16k_50_20261001.json`.
This reinforces the requirement to eliminate structural whole-loop costs;
fast storage operations alone did not make the CPU cold tier useful.

FlexiCache's unchanged engine has now completed its isolated native build
and strict source/native/version import gate. Its first identical-token
request failed before model loading: the released worker's ctypes resolver
selected host CUDA 13, whose stream-priority query returned error 35 on this
driver, then treated the unchanged zero outputs as an unsupported priority
range. The isolated CUDA 12.4 runtime succeeds with (0,-5). A documented
resolver-only adapter now pins that worker query to the validated torch
runtime; no upstream cache/head-selection/attention source change. The
failed raw request remains separate from the v2 pilot/repeat. Model
feasibility, actual pool allocation and resource matching are not proved
by the native import gate.

The resolver-only FlexiCache retry proved full bf16 pool allocation:
24.71 GB GPU K/V, 193.27 GB pinned CPU K/V and 5.35 GB GPU minmax,
with 44.60 GB initialization peak GPU allocation. It then failed inference
because its three-stage 128x128 prefill kernel required 163,840 shared
bytes versus L40S's 101,376-byte limit. A launch-only one-stage screen,
keeping kernel source/tiles/warps/masks/dtypes fixed, compiled with 65,536
shared bytes and passed float32 causal/GQA reference tolerances on
512/1440 no-prefix and 64-prefix-plus-512 cases. Fresh v3 model attempts
record both portability adapters. Pool allocation and small attention
reference agreement do not establish model execution, fair resource use,
quality or speed. Failed original/v2 artifacts remain separate evidence.

The two adapted FlexiCache model requests now pass their feasibility gate:
identical 1,440 input IDs, 64 generated IDs/text, score 10/100, source/runtime/
adapter/binary identities, bf16 pools and submitted transfers. D2H payload
was 146.28 MB and H2D 42.94 MB. Scheduled-token allocation traces agree;
full traces differ only by idle polling (three versus seven empty frames).
Generation peak GPU allocation was 44.77 GB in both, and peak process RSS
about 279.7 GB. Request time differs markedly (11.205 versus 1.968 seconds)
with compilation/runtime warmth, so no latency comparison follows. Original
unsupported launches and the two documented L40S adapters remain separate
from an untouched-release execution claim. The frozen source worktree is
clean; the released 180 GiB pinned pool is not a matched TieredKV budget.
Evidence: `results/baseline_fidelity/flexicache_matched_input_pair_report_20261001.json`.
Next baseline gate is a preregistered resource/attention-work comparison,
not more uncontrolled one-request quality ranking.


The opt-in batched CPU backend now passes exact synthetic lifecycle and
4K/8K/16K model parity, then the 16K/50-step three-block ABBA CPU-control
gate: 80.017 versus 90.685 ms/token (11.76% improvement), with lower p95,
identical useful payload and exact fixed-stream predictions/state. It batches
promotion reads before layer mutations, paid writes at the visibility
boundary and visibility reads after independent layer selections. Pool
ownership includes synchronization and duplicate-destination write ordering.
The extra host reservation (402.78 versus 212.34 MB occupied), initial
pool consolidation (up to 805.57 MB host tensors), ~3.98% TTFT increase,
unchanged prefill GPU peak and +3.09 MB decode GPU peak are explicit costs.
Evidence: `results/hardware/cpu_batched_gate_report_20261001.json`.
Retain as opt-in; physical CPU implementation is now faster than its packed
CPU control. Broad P0/P1 gates remain open: independently compare the GPU
path, quality/long contexts/concurrency, allocator/process peaks and useful
physical hardware traffic, then matched-resource faithful baselines.


Fresh same-policy GPU control now limits the batched CPU claim: exact
4K/8K/16K parity and all twelve fixed-stream 16K/50-step arms pass, but
79.941 versus 81.515 ms/token is only 1.93% pooled improvement and loses
two of three blocks. GPU speed gate fails. Final GPU allocation saving
229.91 MB is only 1.55% of total, below the memory gate; prefill peak is
unchanged, and extra CPU reservation is explicit. Keep opt-in for the
11.76% improvement over packed CPU storage, without GPU superiority.
Evidence: `results/hardware/cpu_batched_gpu_gate_report_20261001.json`.
Policy-only profiling now ranks eviction/demotion, repeated tensor
construction and score updates above grouped native transfers. Implicit
GPU waits and overlapping stacks preclude direct savings estimates. The
next structural candidate needs a charged screen before integration.
Broader quality/concurrency, matched resources and physical STT evidence
remain open; no broad checklist item is closed by this diagnostic.


Cross-layer attention-score bookkeeping passes its charged exact screen
(4.79 ms saved), full 4K/8K/16K state parity, then the three-block 16K/50
CPU-control gate: 75.560 versus 80.956 ms/token (6.66% gain), lower p95
and identical cache/prediction/payload/dispatch histories. Resource peaks,
final GPU allocation and occupied/reserved host tensors match the control;
TTFT increases 0.85%. Preserve as an opt-in policy. Evidence:
`results/hardware/batched_scores_gate_report_20261001.json`.
The prior GPU-control failure tested transfer batching alone, so a fresh
GPU comparison is required for this variant. Independent workload/seed,
free-generation quality, concurrent serving and matched-resource SnapKV
checks remain open; this local gain does not close the broad decode gap.


The score-batched physical CPU variant now clears a fresh GPU-control speed
gate: 75.646 versus 80.475 ms/token (6.00%), all three paired blocks faster,
lower p95 and exact state/prediction/logical counters. Final GPU allocation
saving is 229.91 MB (1.55%), not a memory-gate win; prefill peak is unchanged,
TTFT +4.23% and extra host reservation is explicit. Evidence:
`results/hardware/batched_scores_gpu_gate_report_20261001.json`.
Free-generation QA/summarization on 12 reused frozen distinct documents and
two seeds now preserves every generated ID, score, final state and selection/
shadow trajectory for all 24 pairs. Actual prompts reach 21,202 tokens and
summaries stop at up to 449 generated tokens; quality delta/interval 0/[0,0]
is systems-only non-inferiority, not improved or unseen-corpus quality.
Evidence: `results/hardware/batched_scores_generation_stress_20261001/verified_report.json`.
Keep opt-in while boundaries/needles/rare spans/full saturation and bursts,
max context, process peaks, second model/concurrency when supported and an
independent headline run remain incomplete. Matched-resource faithful
SnapKV/FlexiCache comparisons and physical STT/controller evidence stay open.


Boundary integrity now holds for 16 exact-ID GPU/CPU pairs, including a
one-token model input, hot/total-budget thresholds, true cold saturation
(all32 layers at2048 rows), 1024-promotion/1056-write bursts and max31500
context. Retrieval remains a substantive limitation: both sparse paths miss
all six rare-code needles with similar-key repeated distractors, while
full-cache recovers all six. Every layer loses at least part of the12-token
answer span; 29–32 layers drop it entirely. CPU batching is semantically
faithful, but its speed gain does not repair common prefill retention.
Evidence: `results/hardware/batched_scores_boundary_retrieval_20261001/verified_report.json`.
Keep backend opt-in and wider quality/robustness gates open. Next retention
work must use information available at deployment and independent quality
evaluation; oracle answer knowledge and these six development cases cannot
justify a promoted selector. The full-cache quality check has unequal
resources and no comparable post-return steady KV ownership.


A faithful SnapKV selector diagnostic on the same six development needles now
recovers6/6, with complete answer spans retained in429–594 of1024 layer/head
pairs. Tiered's two storage paths recover0/6 and full-cache6/6. This motivates
retention investigation, but does not isolate ranking from expanded-head
layout/resources: SnapKV owns524 MiB and grows during decode. Its AST callback
is read-only and CPU-tested to preserve bitwise selection. No promoted
selector or independent/matched-resource quality gate follows from this.
Evidence: `results/baseline_fidelity/snapkv_needles_verified_v2_20261001.json`.


Actual three-arm resource accounting now covers51 cache boundaries on the
same16K prompt/50 fixed teacher inputs. Final distinct owned KV storage,
including the attention cache copy, is512 MiB GPU SnapKV,462.5 MiB GPU Tiered,
and260 MiB GPU+384.125 MiB reserved CPU batched Tiered. Useful cold occupancy
is202.508 MiB; the shared pinned pool is counted once across32layer views.
Tiered attention sees1057rows versus975–1024 SnapKV. GPU/CPU Tiered row
geometry and predictions agree exactly. None of these arms has equal actual
resources; logical-tier bytes alone undercount owned allocation. This is
observational accounting, not a latency/quality gate or full process peak
measurement. Source/data hashes and storage equations are verified in
`results/baseline_fidelity/snap_tier_resource_trajectory_verified_20261001.json`.


A Tiered-only paired diagnostic isolates the existing actual-query prefill
option on the six rare-code development probes:6/6 recovered versus0/6 proxy,
with equal initial1024hot/1536cold/1056visible rows and320 MiB hot+cold KV.
All32query captures are consumed, complete answer spans survive in22–29layers,
and fresh controls reproduce frozen state/output/trajectory. Additional
prefill work/peak and final free-generation resource changes remain relevant.
Keep the option experimental: the earlier24-document held-out quality
interval crossed zero despite a positive point estimate, with severe losses;
earlier two-prompt prefill guards passed. This synthetic diagnosis does not
justify default promotion, tuning the holdout, or equal-total-resource claims.
Evidence: `results/baseline_fidelity/tiered_query_needles_verified_v2_20261001.json`.


The actual-query option now also reproduces all six GPU needle requests
exactly on the batched CPU+score backend, including final full cache/metrics,
IDs, trajectories, initial payload and retention. Host reservation remains
384.125 MiB; this is integration integrity at unequal physical resources.
A source audit found no unused NarrativeQA documents in its current20-document
slice. Before inference,100distinct normalized unused documents were frozen
across five other tasks (20each), excluding recorded IDs, earlier manifests/
prefixes and standard/E context matches. The three-arm evaluation is not yet
started. Additional unseen NarrativeQA documents and semantic/training overlap
checks remain required. Evidence:
`results/baseline_fidelity/cpu_query_needles_verified_20261001.json` and
`results/baseline_fidelity/realq_cpu_fresh_documents_20261001/verified_manifest.json`.


The larger preregistered independent-document run is complete:100distinct
unused normalized contexts across five tasks,300three-arm generations.
CPU/GPU actual-query match every output/score/final cache/metric/trajectory.
Actual-query minus defaultproxy quality is+5.8658task-balanced points,
paired10000-draw document CI95[3.1641,8.8280]; NI−.5 and aggregate superiority
pass. Seventeen documents regress, five by>10points. This is conditional
placement evidence on one model/seed/five tasks at equal configured Tiered
budgets, not uniform quality, equal physical resources, faithful baseline or
SOTA. Fresh sources/metrics/caps/identities are independently verified:
`results/baseline_fidelity/realq_cpu_fresh_documents_20261001/verified_report.json`.
Combined actual-query CPU/GPU4K/8K/16Kfive-step fullstate parity also passes;
its preregistered whole-loop ABBA remains a separate systems gate.


The combined actual-query path now passes its same-placement systems gate:
GPU81.3295ms/token versus batchedCPU75.2703 (7.4502%gain), p9589.4505/84.6981,
allthreeABBA blocks improve. TTFT+3.4604%passes10%guard. Full state/prediction/
selection/counter parity and source identity are verified. Final GPU allocation
~223.18 MB lower, host211.81 MB occupied/402.78 MB reserved; physicalresources differ
and model-wide10% memory gate is not met. This does not establish faithful
baseline throughput or STT/controller benefit. Evidence:
`results/hardware/realq_cpu_systems_20261001/verified_gate_report.json`.
Together with the100-document conditional quality result, this supports an
opt-in integrated research path; defaults and broader P0/P1/P2 gates remain.


### NARRATIVEQA-CONDITIONAL-QUALITY (verified outcome, 2026-10-01 IST)

All48arms complete normally; ownedPID3995768 gone,tool91534 terminalexit0,
GPU0returned16 MiB. Independentreporter/tool29687 terminalexit0 verifies source
bundle/runtime/hash, all frozen selectedQA/answers/raw/text, exact truncated
inputIDhash/prompt/counts, nativeF1/EOS/cap, rotationorder, all16CPU/GPU
actual-query IDs/quality/fullstate/trajectory/counters. Originalprompt14066–52345
tokens;6of16standardmiddletruncatedto31500.

Mean CPUactualquery−GPUproxy **+0.3648905**,proxy/candidate21.71897/22.08386,
10000draw storybootstrap seed20261005 CI95**[−7.7963173,+9.0604204]**.
**NI−.5 andsuperiority gates bothfail; inconclusive**, not proven harmful
aggregate and not proven noninferior. **6/16regress,4losses>10**. Descriptive
books10delta+4.81653/scripts6delta−7.05450; no subgroup population claim.
Four sourcefailedoriginalselections remain missing/no replacement, so outcome
conditional16/20currentadapted officialteststories, not LongBenchpublished
slice/intention-to-evaluate20quality. No tuning on this now-inspected holdout.
Severe losses include one untruncatedbook16.67points and three scripts15.38/
31.75/15points; standardtruncation is not a demonstrated sole cause.

Outcome supports exact physicalCPUplacementimplementation; positivefive-task
quality does not establish uniform NarrativeQAquality. Keep path opt-in, broad
quality/stress requirement open. No speed/resources/Snap/physicalSTT claim.
Artifacts `results/baseline_fidelity/narrativeqa_conditional_quality_20261001/`:
frozenmanifest/sourcebundle,raw48arms,prepared/executedreporter and immutable
`verified_report.json`. Next: fair actualresource/processallocator measurement
and supportedmultirequest integrity; diagnose quality only on development or
preregistered causal probes rather than tuning this holdout.


### CPU request isolation outcomes (verified, 2026-10-01 IST)

Cold storage768delayedK/Vchecks pass2/4requestpools×2layers×1/2CUDAstreams,
48overlapflushes and4queuedwritereset/recreation/idempotentcleanupcases.
Model-levelthreefixedlength greedy requestsA4K12/B8K24/Cdistinct4K12decode
allmatchacrossisolatedGPU/isolatedCPU/interleavedCPU:generatedIDs,51full
cacheboundaryhashesperschedule,finalfullstate/history/logicalcounters. A/B
liveconcurrentlyinPython;retire/resetA at12thenprefillC whileBcontinues.
CPU transfer/backendunchanged. Interleavedmodel executionserialized ondefault
stream;complete-stateobservers synchronizeso not asynchronousserving. No
threadedregister/launchatomicity, batchedmodelthroughput, saturation, allocator
peaks, EOSfreegenerationquality or physicalSTT claim.

Artifacts `results/hardware/cpu_multi_pool_20261001/` and
`results/hardware/cpu_interleaved_model_20261001/` contain frozenexecuted
runners/backends/raw andindependenthash/count/equality summaries. Tools84685
and30715 terminalexit0;GPU0returned16 MiB,otherGPUuntouched. Pythoncompile/
diffcheckpass;lastfullsuite127pass remainsapplicable becauseproduction/core/
backend unchanged;newresearchharnessescheckedbyactualGPUexecution.
Do not closebroadconcurrency/physicalresourcescheckbox: storageintegrity and
serializedmodelrequestisolation proven, throughput/generality stillpending.
Next concreteevidence: freshprocessRSS/VmHWM/GPUreserved/pinnedallocator
accounting and actual-resource faithfulbaseline comparisons.


### REALQ-FRESH-PROCESS-MEMORY (verified outcome, 2026-10-01 IST)

GPU/CPU tools65865/74991 terminalexit0, distinctfreshprocesses, identical16K
inputs/50teachers/predictedIDs/finalfullstate/logicalcounters. Samefrozen
source; no backend/corechange. Independentverifierchecks52boundaries/arm,
GPUreserved≥allocated/peaks, RSS≤lifetimeHWM, explicitpinnedownershipevent
accounting and cleanup. Native transfer binariesremain sameverifiedbuild.

GPUpeakallocation18696433664/18627830784B =**.3669303%lower**, not10%gate;
peakGPUreservation20600324096B both. Finalgenerationallocation14993305088/
14768592384B (lastout/logits/attentions still live; do not conflateolder
posthelperreturnfinalallocation scope). RSSsampledpeaks1574887424/2674638848B
(lowerbounds20mssampler). LifetimeVmHWM15195963392/15191769088B dominated
by import/model-loadhistory; not phase-resettable.

CPUroottrace33allocations:32perlayerpools+oneconsolidatedsharedpool,
requestedownedpeak805568512B/final402784256B/occupied211812352B. Weakref
root ownershipzeroafterGPUcompletion/reset/gc, no rootleak. CPUprocessRSS
afterreset2680774656B, afterinternalhostcacheflush1604935680B (drop1075838976B).
GPUcontrolRSSdrop2097152B. InstalledTorch2.5CachingHostAllocator.h:131 uses
PowerOf2Ceil(size); explicittraceinfers32×16 MiB+512 MiB=**1GiB** capacity at
consolidation, consistentwithmeasuredRSSdrop. Thisis source/traceinference,
notdirectphysicalallocatorreservedmetric; nopublichostallocatorstats here.
CUDApinnedallocations notshowninVmLck (0), so do not useVmLck asinventory.
GPUemptycache afterwardreducesreservation14.50810 GB both; modelstillowned.

Evidence `results/hardware/fresh_process_memory_20261001/`: frozenexecuted
runner/backend, rawfreshprocessoutputs, independentverify_result.py/report,
installedheader snapshots/hashes andallocator_rounding_audit.json. Noquality
promotion (NarrativeQANIunproven), latency/fairSnapbaseline/physicalSTTclaim.
Current CPU path adds materially morehostmemorythanlogicalcoldoccupancy;
future directsharedpoolinitialization mayavoidperlayerpoolconsolidationpeak,
but requires preregisteredfreshprocess/parity/TTFT guards beforeimplementation.
Memory measurement completed narrowly; broadphysicalresources/alllengths/
concurrency/saturation/controllerhardware gates remain open.


### CPU-DIRECT-SHARED-INIT (verified outcome, 2026-10-01 IST)

New experimental DirectScorePolicy/DirectCpuCache/DirectSharedPool initializes
one shared pinned root before the first layer, then dispatches each layer's
initial selected KV directly into its view. Existing SharedPool read/decode/
event ownership and batched_update reused unchanged; oldbackend/core remain
controls. Source frozen in source.tar.gz; dispatch-count reporting correction
only recorded before separate abba_source.tar.gz.

Full4K/8K/16Kfive-step model cache-boundary/state/IDs/history/payload parity
passes;32syntheticcases (1,31,32,33,95,96,97,256tokens×inclusive/exclusive×
75/100%fill,2layers/12steps) match allK/V/metadata/counters andcleanup. Direct
multiplepool/stream extension passes768delayedK/Vchecks/48overlapflushes/
4queuedwrite reset/recreation cases. No threadedmodel serving proof yet.
Freshprocesscontrol/candidate match IDs/fullstate/counters. Explicit pinned
rootpeak805568512→402784256B **50% lower**, allocations33→1, finalowned
402784256Bsame, roots0afterreset. Trace/header rounding infers1GiB→512 MiB
capacity, not allocator telemetry. Sampled generation RSS2674462720→
2130558976B (~543.9 MB lower), GPUpeak18627830784Bsame.

3ABBAblocks16K50,warmup1/repeat1, twelvearms allfullstate/history/IDs/logical
counters/transferpayload equal. MedianTTFT2237.6935→2285.306ms **+2.12775%**,
within10%guard. Decode median76.02024→75.88255ms **−.18112%**, p95
85.54104→85.62958ms **+.10350%**, bothwithin2%regressionguard, allblocks
reported. No5%newdecodegain claim. Prefillpeak18627831296Bsame, ≤2% guard.
Independent memory/parity/source/timing verifier and multistream verifier pass.

Evidence `results/hardware/direct_shared_init_20261001/` retains frozen old
runner snapshots, two sourcebundles/manifests, rawparity/memory/synthetic/ABBA/
multiplepool results and independent verify_result.py/verified_report.json/
verified_multi_pool.json. Tools5303/parity,6963/controlmemory,60105/candidate
memory,88037/synthetic,71137/ABBA,57576/multipool terminalexit0. GPU0returned
16 MiB; unrelatedGPU1untouched. Fullsuite127pass beforemeasurements; subsequent
comparatorchange dispatch-reportingonly; newharnesses compiled/GPUexecuted.

Decision: opt-in conditionalhostmemory engineering improvement; noquality
placement change, model-wideGPUmemorygate or defaultpromotion. NarrativeQA
NI remains unproven. Normal evaluation CLI integration/direct modelinterleaving
proof stillpending; faithful resource/width-matched baselines, saturation,
secondmodel, actualSTT/controller and independentheadline remain broadopen.


### CPU-DIRECT-INTEGRATION (verified outcome, 2026-10-01 IST)

Added --cpu-direct-shared to query-selection CLI, requiring existing
--cpu-batched-scores/strategyLRU. MeasuredDirectCpuPolicy reuses existing
MeasuredTieredPolicy timing/host payload reporting/taskcleanup around unchanged
DirectScorePolicy. Config records direct backendSHA and flag. Unsupported
missingCPUflag/nonLRU combinations exit2 beforemodel load. Defaults retained.

Rerun modelchecker with --direct only for interleavedarms: isolatedGPU/oldCPU
controls sameharness, A4K12/B8K24/Cdistinct4K12, all51boundaries/schedule plus
generatedIDs/finalfullstate/history/counters match. ResetA/recreateC whileB
continues proves serializedmodelrequest ownership for directinitializer.
NativeEOS CLI oldCPU/directCPU reusedQasper item match prediction/score/token
counts/logicalcounters/logicalhot+coldpayload/hostreservedoccupied/submitted
transferbytes. CLI stilldoesnotexport tokenIDs; dedicated modelchecker does.
No new quality/timing/throughput/threadsafety/physicalSTT headline claim.

Fullsuite127passed (oneexistingdependencywarning), invalidflagproof and
independent sourcebundle/hash/9armmodel/2CLI verifier pass. Tools67765/tests,
55578/interleaving,17339/controlCLI,23089/directCLI terminalexit0;GPU0idle,
otherGPUuntouched. Frozen before/executed sourcebundle plus rawoutputs and
verify_result.py/verified_report.json:
`results/hardware/direct_integration_20261001/`.

Direct initializer now usable and verified through normalexperimentCLI;
its50%host-ownedpeak improvement/TTFT+2.13%guard remain conditional evidence.
Broad resource/quality/stress/physicalSTT/paper requirements stayopen. Next
priority: current decode overhead and faithfulbaseline actualresource/attended
width controls; avoid any defaultpromotion based on these narrow successes.


### DIRECT-DECODE-LOCALIZATION / PROTECTED-MASK-NUMPY-SCREEN (verified outcome)

Current directactual-query16K20fixedteacher policy profile completesnormally
(tool27539exit0). Frozen sourcehashes/profilerbinary/textchecked.20_decode_step
calls cumulative1019.95ms,640evictions540.64ms,640protectedmasks97.96ms;
visible178.05ms,score68.62ms,sharedread91.81ms,flush6.23ms. These are nested
instrumentedhosttimes withGPUwaits, notadditive causal savings.
Source/prof/text/raw/independent summary:
`results/hardware/direct_decode_profile_20261001/`.

NumPyint64 protectedmask candidate:initialharnessimport failure exitsbefore
measurement (36945exit1), source/error preserved. v2 checkerassumed bool
positions valid, butexistingcontrolrejects bool subtraction; error/source/raw
preserved (92000exit1). v3 correctly requiresmatchingcontrol/candidate input
rejection ratherthandroppingthecase.33validmaskcases+3matchingrejections
pass; then3ABBAblocks×20calls/arm,warmup4,32layerspositions~1057 charged.
Baseline/NumPy medians3.726568/1.348185ms, saving**2.378383ms<4ms**, allblocks
faster/p95better butheadroomgatefails. Independenthash/case/count/ABBA/
statistics verifierpass. **Reject; no cache/helper integration or modeltrial.**
No architecture/backend/core/source tuning based on finaldata; thissynthetic
maskmicrobenchmark is notquality orfullmodel latency evidence.

Evidence `results/hardware/protected_mask_screen_20261001/`:allthreeexecuted
sources, initial_import_failure.json,v2failure/v3raw,verify_result.py and
verified_report.json. Tool31554terminalexit0. GPU0idle/otherGPUuntouched.
Existing cache code unchanged; profile/probeharnessesexecuted, diffcheckpass.
Next meaningful candidate needs larger cross-layer eviction-stage savings,
not another isolatedmask rewrite; preserve stableties/precision/floor/shadow/
positions/paidwrites and require charged4ms screen beforemodel. Broadgoalopen.


### BATCHED-EVICTION-SELECTION / NUMPY-PREPARATION (verified screen outcome)

Initial fullselectionbatching:productionAST reference10.286845ms vs
6.368612ms, saving3.918233ms<4ms, failsheadroom. Preserve initial
probe_executed.py/result.json. Its nonfinitefixture valueswere sinkmasked,
so do not claimunprotectednonfinitecoverage fromthat initialrun.

Distinctpreregisteredcombinedcandidate fullycharges NumPyint64CPU masks
plus paddedGPUcum/age/division/stableargsort/finitecounts/bulkhostreturn/
conditionalhard/gracefallback. SamebaselineproductionAST. Source/control
conditions/thresholdretained;unprotectednonfinitecases added beforecombined
execution. Combined baseline10.369330/batched2.654512ms; saving**7.714817ms**,
all3blocksfaster,p9510.469845→2.708761ms; **4msheadroomgatepasses**.
Primary32×1057 postpromotion/postappendfixture and6edgegroups (zerooverflow,
raggedties,gracefallback,allprotected,nonfiniteoutside sinks,subnormalF32)
matchallvictimIDs. Conditionalwriteawarelambda0 only.

Independent sourcehash/productionASTidentity/7casegroups/ABBAorder/counts/
stats/gatesverifierpasses. GPUtools32765initial/73180combined terminalexit0,
GPU0idle/otherGPUuntouched. Freezeoriginalcorecontrol andbothscreenrunners/
NumPyhelper/raw/verify_result.py/verified_report.json in
`results/hardware/batched_eviction_selection_20261001/`. Cache/model/core
unchanged. No fullsuite repeat because only syntheticprobe added/changed and
actuallyexecuted; last127pass stillapplies tocore. No model speed/quality/
faithfulbaseline/physicalSTT claim fromscreen.

Next meaningful implementation: opt-in cross-layer coordinator prepares
promotions and projected append/age states, uses bulk victimselection, then
existing physicaldemotion/compaction. Must preserveexact_t/LRU timestamps,
floor/deferredpromotioncounts, stableties/nonfinite behavior, grace/sinks/
recentpositions, shadowrestoration/paidwrites andresets. Preregister and
verifyisolated source-preserving selector extraction beforechangingruntime;
4K/8K/16K/maxcontext/syntheticboundaries/fullstateparity before ABBA≥5%
median/p95≤2%/allblocks/TTFT≤10%guards. Broaddecodegap and quality/resource
researchgoal staysopen.


Cross-layer eviction coordinator gate (1 October 2026): archived verifier
recomputes exact source hashes, whole-body selector AST preservation,
32 synthetic cases, all four context boundaries, 12 ABBA arms and gates.
Median 74.8154 → 72.5004 ms = 3.0942% gain, below preregistered 5%:
REJECT performance promotion. All three blocks faster; p95 84.4049 →
77.1335 ms, TTFT 2271.9265 → 2271.7845 ms, prefill peak 18.627831296 GB
unchanged. All states/IDs/counters/payloads exact. No normal evaluator flag
added. Further free-generation/interleaved candidate gates are deferred
because this candidate failed the required speed gate. CPU/direct defaults
stay unchanged; prior independent NarrativeQA NI remains unresolved.
Artifact: results/hardware/batched_eviction_coordinator_20261001/verified_report.json.
Next research gate: matched resident resources and attended width against
faithful SnapKV, with joint quality/timing/peak evidence.


Shared owned-KV envelope systems result (2 October 2026): all12ABBAarms
and source/resource/repeatability verified. Snap median25.7417/p9525.9552ms;
directCPU median71.2026/p9578.6061ms, 2.7660×slower. All3blocks slower;
decode/p95 gates fail. TTFT2074.8358→2239.9855ms (+7.9597%) passes10%guard.
Prefill GPU peak16.958269→18.627831 GB; decode15.037793→14.901711 GB:
no10%modelwide memory improvement. These configurations share512 MiB boundary
owned-KV ceiling and1024forward-row ceiling, actualresources/widthdiffer.
CPU991hot/1090cold/32quota differs from prior default1024/2048quality study;
priorquality cannottransfer tothese capacities. No jointquality gate yet.
Artifact: results/baseline_fidelity/snap_tier_owned_envelope_20261002/verified_timing.json.
Refreshunused inventory:65Qasper/37Multi/241Hotpot/241Trivia/256Gov document
groups remain; NarrativeQA standardcorpus exhausted. Broad P0/P1/P2open.


Allocator boundary clarification (2October2026), capacities unchanged:
shared512 MiB is liveKV tensor-storage, not physicalallocator reservation.
SameinstalledTorch2.5coreheaderSHA34433351...a43c7 usesPowerOf2Ceil(size)
atline131. DirectCPU rootrequest260.25 MiB roundsbythat source to512 MiB;
with251.75MiBGPUKV, inferred763.75 MiB beforecachedblocks/otherallocations.
This is source/geometryinference, not measuredactivehost-reservationtelemetry.
Do not claim equalphysicalmemory. Frozenquality/timing continueunchanged.
Artifact: results/baseline_fidelity/snap_tier_owned_envelope_20261002/allocator_capacity_note.json.


Shared-ceiling independent quality gate (2 October2026) completed:
100new normalized unused documents/five tasks/200arms, all source/data/seed/
exclusion/sampling/prompt/nativecap/EOS/counters/geometry verified. CPUactualquery
991hot/1090cold/32quota/directshared minusfaithfulSnap task-balanced−2.56985,
paired95CI[−5.293844,−0.507108], bootstrap10000/seed20261005. NI−.5 and
superiorityfail; 33regressions/10losses>10. TaskmeansQasper−1.7946/Multi−5.1511/
Hotpot−2.0519/Trivia−5.0/Gov+1.1482. All resource-boundary guards pass for
liveKV tensor-storage; activeallocatorroundingexcluded (inferred763.75 MiB
rootcapacity+GPUKV, not512 MiB physicalparity). ThreeABBA systems comparison
alsofailed speedguards (2.766×slower). No advancement/defaultpromotion or
SOTAclaim. This is a result for these frozen capacities/one model/seed, not
all Tiered configurations. Do not tune inspected100documents. Standard
NarrativeQA exhausted; prior adapted-storyNI and broader P0/P1/P2stillopen.
Fullsuite128passes after optional experimentalmeasurefactory extension;
all ownedmodeljobs terminal, GPU0idle. Artifact:
results/baseline_fidelity/snap_tier_envelope_fresh_quality_20261002/verified_report.json.
Next: allocator-reservation efficiency and structural retention/eviction
costs on development inputs, preserve full-model gates.


Boundedpool milestone verified (2October2026): primary44.57%ownedhostroot
reduction andp95/TTFT/prefillguards pass,36nativecases/full1154slots,24free
generationpairs/6tasks,768delayedstreamobservations/48overlapflushes/4resets,
3interleavedrecycledrequests/51frames, CLIoutput/counts/score/payload/counters
match and3invalidflag combinations rejectbeforeload. Final143tests pass.
Opt-in--cpu-bounded-pool requires--cpu-direct-shared --cpu-batched-scores
--strategy lru, hot>=132; defaultsunchanged. Verified991/1090scope.
Before nextgeneralization no ownedGPUjoblive. Existingquality/speedfailures
remain; no globalpromotion/model GPU peak/physicalSTT/completion claim.
Evidence: results/hardware/bounded_pinned_pool_20261002/verified_stress_report.json.


Defaultgeometry boundedpool result (2October2026) independentlyverified:
1024/2048 unchangedlogicalcapacities, root402784256→276824064bytes (31.27%
requestedreduction), sampledRSS2129731584→2128539648(~1.19 MB difference).
Bothrootactivecapacitiesinfer512 MiB frominstalledallocator; GPUpeakunchanged
18627830784bytes. Exact4K8K16K31500cacheboundarystate+50teacherfreshprocess
outputs/counters/payload;4nativefullfill/inclusioncases reach2112transient
slots and33appendrejectedbeforemutation. ThreeABBA16K50median75.2151→
75.1726ms, p9584.6353→84.1376ms, TTFT2302.8145→2296.769ms, prefillpeak
same18.627831296 GB. Regressionguardspass; no5%speedgain or substantial
RSS/backingallocation gain. Special991/1090memorybenefit notgeneralized.
Defaultgeometry freegeneration/interleaved notyetverified; retainopt-in.
No defaultpromotion/qualitywin/physicalSTT/broadP0/P1/P2completion.
Artifact: results/hardware/bounded_pool_default_geometry_20261002/verified_report.json.
AllownedGPUjobs terminal; fullsuite143passes fromintegration, onlyexperimental
nativechecker optionalgeometryflag addedsince; no modelalgorithmchanges.


50stepNVTX/CUDAtrace (2October2026) disprovescoldoverflowhypothesis: all
32layers end1616/2048coldrows, nosaturation anyboundary. Trace142645kernel
launches,37037cudaMemcpyAsync,25837cudaStreamSynchronize. Innermosthost
range attribution: hotselection17600kernels/36800APIcalls; remainingevict
24768kernels/47040APIcalls; visible8176kernels/19826APIcalls. Evictexcluding
hotselection hostAPI4.447ms/step/devicekernels1.385ms, overlappingdiagnostic
notadditive. CProfile/NVTX/CUPTI perturbations; nofull-loop speedclaim.
Nextcandidate screenhotstatecompaction usingoneGPUintindex reusedacross
KV/cum/age replacingrepeatedCPUbooladvancedindexing. Currentpurebool path
wasalreadybetterthanPythonlist indexing; this isdistinctindex_select stage.
Require entiremask/keepindices/CPUpositionbuild/GPUindexupload/gathers
charged, exactstate,≥4ms saving andp95≤2%; no backendeditbeforepasses.
Evidence: results/hardware/full_decode_trace_20261002/verified_trace_analysis.json.


Sharedhotindex screen outcome2October2026: charged full32layer hotcompaction
control6.52006→candidate4.38838ms, saving2.13168ms<4msminimum. All12edge
checks and primary/ABBApostarmKV/metadata/positions bit-equal, all3blocks
better/p956.75623→4.60991, but REJECT modeladvancement. No backend/core edit.
CandidateisoneGPUintkeepindex reusedbyK/V/cum/age, CPUgrace+position list;
notcurrentCPUlist/booleanvariant. Cannotaddthisisolatedsaving toprior
hotselection savings orcallitfullloop speedgain. ExactarchivedproductionAST
and allrawtimings/hash independentlyverified. Verifier firstfailedabsolute
__file__key vsrelativearchive name; normalizedrepo paths, before/errorretained.
Raw/source unchanged. Diagnosticrunner compiles; no newproductiontestsneeded.
Artifact: results/hardware/shared_hot_index_screen_20261002/verified_report.json.
Nsight50trace falsifiescoldoverflowexplanation, instead manytinyAPIlaunches/
metadata/visibility operations. Profiler times perturb andoverlap. Future
architecturalstage should combine complete update/materialization with
chargedcausalproof; no defaultpromotion or tuningoftestedqualityholdouts.
AllownedGPUjobs terminal; broadP0/P1/P2 stillopen.


### 2026-10-02 — Pooled-head maximum fails broader development gate

Independent verification confirms all 12 previous bounded-CPU control outputs,
IDs, states, trajectories, counters, task-native caps/EOS and transfer payloads.
Source archives, JSON-key comparison repair, dataset/sample/prompt hashes and
recomputed metrics pass. Candidate uses the unchanged global-token GQA layout.
Six-task task-balanced difference: −0.6012 points, paired within-task bootstrap
95% CI [−3.0922,1.8898], 10,000 draws/seed20261006. Two regressions; one loss
over 10 points (NarrativeQA −17.2727). The −.5 noninferiority screen and
individual-loss screen fail. This reused development set is not independent
quality evidence. Different initial importance also changes later cumulative
eviction scores; no pure prompt-retention causal isolation is claimed.

Three ABBA blocks, one warmup per arm, charge complete model SDPA prefill,
rotary-query capture and bounded CPU placement. At16K, median2.25558→2.25637s
(+.0351%); at31.5K, 5.06368→5.06438s (+.0139%). Peaks are identical within
length (18.62783/22.41822 GB), initial geometry and151257088-byte root request
match, and placements repeat within each arm. Prefill guards pass; no decode
or speed superiority claim. Quality failure rejects this frozen candidate
before unused evaluation documents. Defaults stay unchanged. Owned GPU0
process exited; last full suite153passed.

Evidence: `results/baseline_fidelity/head_max_retention_dev_20261002/` and
`results/baseline_fidelity/head_max_broader_dev_20261002/verified_report.json`.
Next: close the explicitly open usual-budget free-generation/interleaved
integrity checks; then screen a complete update/materialization architecture.


### 2026-10-02 — Usual-budget bounded pool free generation and isolation verified

At1024hot/2048cold, 12 direct-versus-bounded CPU free-generation pairs across
six tasks are exact in predictions, IDs, native caps/EOS, scores, state,
trajectories, counters, query shapes and submitted transfer payloads. Same
reused development documents, one greedy seed; occupied host data match.
Reserved roots differ402784256→276824064bytes as frozen. This establishes
storage preservation rather than independent quality superiority.

Three requests A4K12/B8K24/Cdistinct4K12 match isolated grouped-GPU and
old-CPU controls exactly at all51 complete boundary frames per mode. A is
reset/recycled into C while B remains live; all request roots reset cleanly.
Serialized Python/default model stream and fixed lengths ignore EOS in this
isolation test. No threaded/asynchronous serving, concurrency throughput,
saturation, physical STT or default-budget host-RSS gain is established.

Independent verifier checks executed source archive, dataset/sample/prompt/
input hashes, task metrics, caps/EOS, unchanged policy-class ASTs and all
per-boundary outputs. Generic experimental runner now reads frozen manifest
budgets and seed count. Its historical two-seed limitation string was fixed
for future runs after verification; raw/source are retained and exact
metadata-only text preservation is proved separately. No cache-policy or
default change. GPU0 owned jobs exited; last full suite153passed.

Evidence: `results/hardware/bounded_pool_default_stress_20261002/verified_report.json`
and `metadata_fix_report.json`. These explicitly close usual-budget
free-generation/interleaved integrity gaps, while broad P0/P1/P2 remain open.
Next: charged screen of complete update/materialization, then causal/actual
resource quality and wider systems gates. Estimate remains10–20workingdays,
contingent on hardware access and research outcomes.


### 2026-10-02 — Fused CPU coordinator/compaction integrated after all gates

The new opt-in combines the existing exact cross-layer eviction coordinator
with one CUDA gather of all hot BF16 keys/values and F32 score/age metadata.
CPU positions/grace compact immediately; GPU gathers complete before the
visible cache is materialized. Cold overflow and unsupported geometry use
the original eager compaction. The complete original eviction AST is
preserved outside its compaction hook; token ranking and budgets are unchanged.

The first charged prototype saved only0.3663ms and was rejected. Diagnosis
measured0.5232ms for the kernel and identified per-index Python checks/list
conversion as CPU overhead. Vectorizing CPU preparation, with the shader and
binary unchanged, saved4.0310ms (6.5361→2.5051) in the complete-stage screen;
all3ABBAblocks/p95/13bitwise cases pass. Initial missing-Ninja failure and all
original sources/results/logs are retained.

Independent model verification: all13boundaries at4K8K16K31500 exact,32
synthetic cases with442fused/222eager paths exact. Three ABBA16K50teacher-step
blocks, one whole-request warmup per arm, same CPU backend/query capture/
observer/synchronization: median75.4689→66.4404ms (11.9632% faster), p95
85.0156→72.1715ms; TTFT2281.77→2292.29ms (+.461%); prefillpeak 18.627831296 GB
identical, decodepeak14.91440→14.91133 GB. Both coordinator and compaction are
measured together; do not attribute this whole gain to the kernel alone.

Mandatory native proof includes all65,536BF16bit patterns, F32 signed zero,
subnormal/infinity/quiet+signalingNaN payloads, full/strided/reordered+duplicate
keeps, and12delayed gather/allocator-pressure rounds using one producer/two
consumer streams with explicit event waits. All15checks pass. Twelve reused
free-generation document pairs across six tasks/one greedy seed/native caps
and EOS have identical predictions/IDs/scores/state/trajectory/counters/
transfers. Three serialized interleaved/recycled requests match isolated GPU
and old CPU controls at all51boundaries per mode; roots reset cleanly. These
are integrity/ownership checks, not asynchronous model serving/throughput proof.

Ordinary CLI: add `--cpu-fused-compaction` to
`--strategy lru --real-query-prefill --cpu-batched-scores --cpu-direct-shared`.
Requires hot>=132; combining with bounded pool is explicitly rejected until
verified. Cached loader checks shader/binary hashes and measured Torch2.5.1+
cu124/Python3.10 ABI, then imports the verified binary without Ninja or a
recompile. Gather/compaction AST and shader are unchanged; one Qasper CLI
control/candidate matches predictions, score35.8974, token counts, payloads
and counters, with768fused compactions. Five invalid combinations fail before
model loading. Final full suite154passed (one dependency deprecation warning).

Evidence: `results/hardware/fused_hot_compaction_screen_20261002/`,
`fused_eviction_model_20261002/`, `fused_eviction_stress_20261002/`, and
`fused_cli_integration_20261002/` under `results/hardware/`.

No normal-policy default, STT bandwidth, quality ranking or capacity changes.
This12%improvement is within one CPU surrogate configuration; the earlier
shared-ceiling quality/SnapKV failures remain authoritative and have not been
rerun with this backend. No model-wide memory-gain, physical STT/controller,
energy/endurance, second-model or serving superiority is established. Broad
P0/P1/P2 remain open. Next: verify bounded+fused combination and shared-ceiling
resource/speed accounting, then broader research gates. Remaining estimate
10–20workingdays, conditional on hardware access and research outcomes.


### 2026-10-02 — Composition closed; live-storage and baseline gaps remain

Bounded/fused composition now passes both 1024/2048 and991/1090 systems,
free-generation/isolation and ordinary CLI gates; both opt-in flags can be
combined. Requested roots fall31.3%/44.6%; no allocator/RSS gain is inferred.
Full suite168passes. See the matching date in [EXPERIMENT_LOG.md](EXPERIMENT_LOG.md).

Frozen SnapKV rerun remains2.34× slower (60.56 versus25.83ms/token), p95 and
all-block speed gates fail, TTFT+8.45% passes. Known transient KV528.25 MiB
exceeds512 MiB despite396 MiB boundaries. Actual resources are unequal and peak
ownership is only partially sampled. The prior quality failure remains;
selection and shader are unchanged, no inspected holdout was retuned.

Next gate: establish live KV ownership through visible assembly, queued
transfers and compaction, then evaluate one minimal candidate against the
charged-stage and whole-model gates. Do not infer savings from a sum of
overlapping stages or change frozen capacities to hide a resource failure.
Physical STT, model2, wider independent quality and serving remain open;
all broad P0/P1/P2 boxes stay unchecked. Estimate10–20working days.
Evidence: [verified diagnostic](results/baseline_fidelity/snap_fused_bounded_envelope_20261002/verified_report.json).
