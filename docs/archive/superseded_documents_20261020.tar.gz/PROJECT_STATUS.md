> **Superseded current-state notice, 13 October:** the prior GPU blocker cleared; physical STT hardware is outside the clarified simulation scope. Current audit/fixes/stress evidence: [AUDIT_20261013.md](AUDIT_20261013.md). The following 3 October status is retained as history, not current completion evidence.

# TieredKV project status and next steps

Updated 3 October 2026. **Project incomplete. No defensible completion date.**
The repeated 10–20 working-day estimate is withdrawn.

**Execution blocked:** the same unrelated GPU0 process remains live across three consecutive goal turns; the required quiet speed gate has zero measured rows. GPU1 is also occupied. No physical STT measurement interface has been supplied. All owned jobs are terminal. Resume needs a quiet dedicated GPU window/alternate host; physical requirements additionally need device/controller access. [Blocking audit](results/status_audit_20261003_blocked/blocking_audit.json).

The full original scope remains binding. [Original requirements and history](results/status_archive/20261003/PROJECT_STATUS.md), [archive hashes](results/status_archive/20261003/manifest.json), [experiment protocol](EXPERIMENT_PROTOCOL.md).

## Current verified results

- **518 tests pass.** Native CPU state owns positions, shadows, grace, streaks and physical slot order; pooled GPU state owns scores/ages/timestamps. Default-off research paths preserve ordinary behavior on tested cases.
- **Earlier stopped early-shared candidate:** full-model 4K/12 and 16K/50 predictions, state, counters and native KV transfers match. All 32 early roots are consumed; no fallback. Tiny GPU tests also compare full logits/KV and verify partial-failure cleanup.
- **Earlier early-shared memory gate passes:** prefill peak 18.6278 → 16.5376 GB (**11.22% reduction**); strict decode GPU allocation falls **5.47%**. Measured scope including owned pinned blocks and CPU arrays is **378.60 MiB**. Unowned host and driver allocations remain outside this scope.
- **Earlier early-shared faithful-baseline timing fails:** TieredKV **54.59 ms/token**, SnapKV **25.25**; p95 **59.94 versus 25.47 ms**. TTFT +7.73% and prefill guards pass. Three ABBA blocks, 300 measured forwards per arm and 25 quiet GPU observations pass per-arm frozen replay checks. Candidate expansion/adoption is stopped.
- **Comparison design is partial:** initial resident KV equals **341 MiB** at TieredKV hot649/cold1982 and faithful Snap prompt682. TieredKV remains341 MiB; Snap grows341–366 MiB. Attention width682 versus683–732 stays within the pilot's1.075 ratio, but full trajectory equality is false.

Evidence: [resource proof](results/hardware/early_shared_cpu_phase_v1/verified_resources.json), [timing proof](results/hardware/early_shared_cpu_phase_v1/verified_cost.json), [figures](results/hardware/early_shared_cpu_phase_v1/figures/manifest.json), [full requirement ledger](results/status_audit_20261003_quality_readiness/completion_ledger.json).

## Requirements still open

| Requirement | Current evidence | Remaining acceptance condition |
|---|---|---|
| P0 — Implementable tier and whole-loop cost | CPU DRAM, native transfers, occupancy and synchronization measured | Combined systems claim; CPU DRAM cannot prove physical STT behavior |
| P0 — Complete memory envelope and comparable resources | Latest cold-boundary scoped424.15MiB; initial341MiB KV match | Full resource/attention comparison design; unmeasured scopes explicit |
| P0 — Close decode gap | Current faithful-baseline median/p95 fail | Preregistered median/p95/prefill/resource gates, followed by required stress checks |
| P0 — Independent quality at matched resources | Historical DirectCPU NI failed; current candidate has development preservation only | Genuinely unused document-group data after architecture/resource gates; no tuning on consumed final holdout |
| P1 — Physical writes, amplification, energy/endurance | No accessible controller/device measurements | Device access and measured physical pages/amplification/energy; logical bytes do not prove endurance |
| P1 — Robustness, generality and faithful broader baselines | Existing boundary, generation and portability pilots | Required disjoint tasks, second model/seeds, longer outputs, concurrency/saturation and fair FlexiCache/IceCache comparison |
| P2 — Supported paper and reproducibility delivery | Frozen proofs and component figures exist | Supported claim, independent headline rerun, full hashes/figures/limitations and anonymized manuscript |

The archive retains every original named task, artifact, invariant and acceptance condition. The table groups that scope; it does not remove requirements. Physical hardware details have been requested and remain unanswered.

## Current diagnosis and next action

The latest uninstrumented paired run reports CPU/Snap model-forward medians24.79/25.11 ms; CPU required policy work adds approximately29.80 ms/token. An exact current-source16K/50 cProfile replay attributes work to scoring, visibility, transfer and per-layer updates. Cold native-library initialization and diagnostic resource observers are included in the profile; nested times overlap and are not predicted savings.

[Diagnostic proof](results/hardware/cpu_phase_policy_profile_v1/verified_profile.json), [attribution](results/hardware/cpu_phase_policy_profile_v1/attribution.json), [raw policy profile](results/hardware/cpu_phase_policy_profile_v1/policy.txt), [score profile](results/hardware/cpu_phase_policy_profile_v1/scores.txt).

A score-only optimistic screen costs2.75–2.91ms at the two current geometries; even zero work cannot save4ms. No score-only candidate is implemented. [Ceiling proof](results/hardware/score_stage_ceiling_v1/verified_screen.json).

**Bulk payload phase screen passes:** group8 fused kept/paid KV gathering, exact new-token conversion, F32 metadata movement and cold timestamps preserve all tested bits, including all65536 new BF16 patterns. Six malformed cases reject before any mutation; empty hot views require caller fallback. After that boundary fix, the same charged three-case3ABBA gate saves**7.62–8.06ms** with improved p95. [Stage proof](results/hardware/bulk_payload_phase_v1/verified_stage.json). Supplied decisions, CPU ownership/slots and physical transfers remain outside this primitive; no model speed or complete512MiB claim.

**Integration and resource gate pass:** the opt-in bulk controller preserves tiny full logits/cache/metadata through multi-token fallback and queued partial-failure cleanup. Full-model4K/12 and16K/50 exactly preserve state, predictions, counters and native transfers. All50 long-replay steps use bulk execution; no fallback. Scoped memory is**402.47MiB**, including a conservative upper bound for new CPU descriptor/index scratch; strict GPU decode allocation rises**0.11%**, within its2% guard. Prefill remains unchanged; the faithful Snap prefill comparison still fails for this global-prefill configuration. [Integrated resource proof](results/hardware/bulk_payload_controller_v1/verified_resources.json).

**Same-control macro gate passes:** **59.92→53.62ms/token,10.52% improvement and6.30ms saved**; p95 improves13.10%, TTFT improves0.82%. Three ABBA blocks,300 measured forwards per arm and25 quiet GPU observations preserve frozen predictions/state/counters/native transfers. [Timing proof](results/hardware/bulk_payload_controller_v1/verified_cost.json).

Mandatory8K/31.5K and cold-slot recycling parity pass:150 paired steps,307 reclaims;36 bulk and14 fallback steps in the small cold-tier case. [Stress proof](results/hardware/bulk_payload_controller_v1/verified_stress.json). Free generation passes12 reused documents across6tasks,700 steps, all bulk execution with exact predictions/scores/trajectories/counters/KV. Exclusive, floor-over-capacity and write-aware fallback pass150 additional paired steps. [Generation proof](results/hardware/bulk_payload_controller_v1/verified_generation.json), [boundary proof](results/hardware/bulk_payload_controller_v1/verified_boundaries.json), [timing figures/hashes](results/hardware/bulk_payload_controller_v1/figures/manifest.json). All owned jobs are terminal.

**Separate-process reproduction passes:**61.52→56.04ms/token,8.91% gain/5.48ms saved; p95 improves13.36%, TTFT improves0.32%. A second3ABBA run preserves all300 measured forwards per arm and25 quiet checks. Same code/model/data/seed; not a separate investigator or a full headline-baseline rerun. [Reproduction proof](results/hardware/bulk_payload_reproduction_v1/verified_cost.json), [two-run table and uncertainty](results/hardware/bulk_payload_reproduction_v1/reproduction_summary.json).

**Native cold-boundary stage passes:** direct F32 timestamp gathering, unchanged grouped ranking and one cold-tail scatter preserve selection/payload/metadata/native transfers at both geometries, including tied/NaN/ragged cases. Three stationary3ABBA cases save**4.87–6.49ms**; this is a stage result, not model speed. Nondefault-stream lifetime and malformed-state rejection pass. [Stage proof](results/hardware/native_cold_boundary_v1/verified_stage.json).

**Cold-boundary integration/resource gate passes:** **518 tests**, tiny full-logit/cache parity through multi-token fallback, full-model4K/12 and16K/50 exact replay. All50 ordinary decode steps use native cold composition; initial prefill uses the original path. A failure after coldH2D submission releases the pool/events/hooks/leases and leaves0 owned pinned bytes after cleanup. Scoped memory is**424.15MiB**, including conservative CPU scratch bounds; strict GPU active allocation, reservation and prefill remain unchanged versus the frozen bulk control. [Resource proof](results/hardware/cold_boundary_controller_v1/verified_resources.json), [late-transfer cleanup](results/hardware/cold_boundary_controller_v1/failure.json).

**Next gate is waiting for a quiet GPU:** same-bulk-control3ABBA speed attempt stopped before model load because an unrelated GPU0 process was present; **zero timing rows**, no performance result. The failed attempt is preserved. Other users' processes remain untouched. Resume the same frozen protocol only when GPU0 is quiet; require≥5% and≥4ms whole-loop saving plus p95/TTFT guards before mandatory wider-context/generation/boundary stress. No favorable measured-result retry. [Wait state](results/hardware/cold_boundary_controller_v1/cost_waiting.json), [preregistered timing plan](results/hardware/cold_boundary_controller_v1/cost_plan.json).

**Independent-data readiness checked:** refreshed source/hash/document-group exclusion audit finds45 unused Qasper groups,17 MultifieldQA,221 HotpotQA,221 TriviaQA and236 GovReport; NarrativeQA has0. The existing100-document selector requires20/task and is therefore unavailable unchanged. No new test selection or evaluation ran. Its3-document shortfall requires fresh independent data or a separately justified sampling protocol. [Verified availability](results/baseline_fidelity/unused_document_readiness_20261003.json).

Baseline/resource design, independent quality, physical measurements and remaining P1/P2 are still open. Defaults remain unchanged. Existing failed experiments remain closed.

Anonymous evidence manuscript: [PAPER_CURRENT_EVIDENCE.md](PAPER_CURRENT_EVIDENCE.md). Supported component and negative outcomes are written up; independent reproduction and full acceptance requirements remain open.

## Earlier checkpoints

The earlier current-source native CPU phase configuration hot991/cold1090 passes ordinary-CPU component timing:58.76 →54.12 ms,7.89% gain/4.64 ms saved; scoped memory433.33 MiB. This uses different capacities from the current faithful-baseline diagnostic and is not a joint baseline win. [Frozen proof](results/hardware/cpu_phase_score_guard_v1/verified_status.json).

The unsupported estimate, old task counts and old supervisor summaries in archived documents are historical. Use this page for current status; raw experiment evidence is immutable.
