"""Existing recorded4K12 fullmodel pair with scoped reservedappend cache lease."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'experiments'))
import compare_reuse_visible as driver
from compare_bulk_promotion import RecordedBulkPolicy
from reserved_decode_append import ReservedAppendPolicy,AppendLease
BASE=Path(__file__).resolve().parent
class RecordedAppendPolicy(driver.RecordedNativePolicy,ReservedAppendPolicy):
    append_counts={}
    def reset(self):
        type(self).append_counts=dict(reserved_buffer_allocations=getattr(self,'reserved_buffer_allocations',0),shared_hot_prefixes=getattr(self,'shared_hot_prefixes',0))
        super().reset()
def main():
    saved=(driver.RecordedNativePolicy,driver.trial.FusedBoundedPolicy,driver.trial.measure,driver.atomic_json,sys.argv)
    leases=[];summaries=[]
    def measure(model,*args,**kwargs):
        chosen=driver.trial.FusedBoundedPolicy;own=[]
        before=(len(model._forward_pre_hooks),len(model._forward_hooks))
        if chosen is RecordedAppendPolicy:
            def factory(**options):
                policy=chosen(**options);lease=AppendLease(model,policy);own.append(lease);leases.append(lease);return policy
            driver.trial.FusedBoundedPolicy=factory
        try:
            result=saved[2](model,*args,**kwargs)
            if own:
                result['append_lease_counts']=dict(fast_updates=sum(v.fast_updates for v in own),fallback_updates=sum(v.fallback_updates for v in own),pending_released=all(not v.pending for v in own),**RecordedAppendPolicy.append_counts)
                summaries.append(result['append_lease_counts'])
            return result
        finally:
            for lease in own:lease.close()
            assert before==(len(model._forward_pre_hooks),len(model._forward_hooks))
            driver.trial.FusedBoundedPolicy=chosen
    def write(path,report):
        report.update(actual_control='ordinary_bulk',actual_candidate='reserved_decode_append',append_summaries=summaries,owned_leases_closed=all(not v.pending and not v.handles for v in leases),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits='Existingrecorded4K12 pair. Exactcache/pred/visibility/counters/nativeKV; no separatelycapturedlogits, memoryprimary or speed/quality/full512MiB/adoption claim.')
        saved[3](path,report)
    driver.RecordedNativePolicy=RecordedAppendPolicy;driver.trial.FusedBoundedPolicy=RecordedBulkPolicy;driver.trial.measure=measure;driver.atomic_json=write
    sys.argv=['check','--output',str(BASE/'gpu.json'),'--contexts','4096','--decode','12']
    try:driver.main()
    finally:
        for lease in leases:lease.close()
        driver.RecordedNativePolicy,driver.trial.FusedBoundedPolicy,driver.trial.measure,driver.atomic_json,sys.argv=saved
if __name__=='__main__':main()
