# TieredKV: verified implementation guide

**Current checkpoint — early shared prefill (3 October):** 501 tests pass. Tiny GPU full-logit/KV parity and partial-failure cleanup pass; full-model4K/12 and16K/50 preserve predictions, state, counters and native transfers with all32 early roots and no fallback. Whole-prefill peak falls11.22% to16.5376GB; strict decode GPU active falls5.47%, scoped active including owned pinned/CPU is378.60MiB. Faithful Snap prefill ratio0.9840 passes. [Resource proof](results/hardware/early_shared_cpu_phase_v1/verified_resources.json). Initial resident KV matches341MiB at hot649/cold1982; candidate remains341MiB while Snap grows341–366MiB. Full-trajectory equality remains unresolved. Faithful-baseline quiet3ABBA timing **fails**: CPU54.59 vs Snap25.25ms/token (2.162x), p95CPU59.94 vs Snap25.47ms. TTFT+7.73% and prefill guards pass; median and p95 fail. All300 measured forwards/arm reproduce frozen predictions/state; CPU counters/native transfers and25 quiet observations pass. [Timing proof](results/hardware/early_shared_cpu_phase_v1/verified_cost.json), [figures](results/hardware/early_shared_cpu_phase_v1/figures/manifest.json). Candidate expansion/adoption stops under the preregistered gate; no favorable retry or final-holdout tuning. All owned jobs are terminal. Physical controller measurements, independent quality, generality and final delivery remain open. Repeated10–20day estimate withdrawn; full goal incomplete.

**CPU phase boundary and score-fallback checkpoint (3 October):** **498 tests pass**. Two reproduced regressions exposed a shared batched-score crash on multi-token attention. A single-query shape guard restores the ordinary scorer fallback. Real GPU appends of2/32 tokens preserve exact logits, KV data, metadata and slot order across7 boundaries, then return to native single-token phases. Transformers-owned lazy capture hooks are initialized before ownership checks; both failed harness attempts are preserved. [Fallback proof](results/hardware/cpu_phase_append_fallback_v1/verified_fallback.json).

Three full-model4K/50 checks preserve all predictions/state/counters/native KV: exclusive promotion24832 rows, floor-above-capacity protection, and50 write-aware fallback steps. Native cold reclaim executes1152 times. [Boundary proof](results/hardware/cpu_phase_boundaries_v1/verified_boundaries.json). Fresh current-source4K/12 parity also passes; current-source16K/50 resource and geometry proofs pass, scoped memory433.33 MiB. Fresh current-source3ABBA speed passes: **58.76 to54.12 ms median,7.89% gain/4.64 ms saved**, p95 improves8.87%, TTFT+1.37%. All300 measured predictions/arm, state/counters/native KV and25 quiet observations match. All owned jobs are terminal. The multi-query guard preserves existing ordinary scoring fallback; it does not redesign multi-query attention accumulation. [Current proof](results/hardware/cpu_phase_score_guard_v1/verified_status.json), [figures](results/hardware/cpu_phase_score_guard_v1/figures/manifest.json). Historical speed evidence below remains tied to its archived source.

The ownership audit confirms resident KV roots272.25 MiB constant across51 candidate boundaries versus faithful SnapKV487–512 MiB, growing0.5 MiB/step. Attention width1024 differs on49/50 steps. No fixed SnapKV prompt capacity can equal that constant allocation vector throughout decode. This is an unresolved comparison-design requirement, not permission to claim equality or pad allocations. [Geometry proof](results/hardware/cpu_phase_geometry_v1/verified_geometry.json). Full P0/P1/P2 remains open; no new day estimate.

**CPU phase controller integration (3 October):** **496 tests pass**, including seven integration checks. Native canonical CPU promotion, append and demotion are integrated with pooled GPU metadata and native KV transfers. Recorded 4K/12 matches all predictions, 13 state/visibility snapshots, counters and native KV traffic. All 384 layer transitions use the new CPU phases, with zero fallback. [Correctness proof](results/hardware/cpu_phase_controller_v1/verified_correctness.json).

Fresh 16K/50 matches frozen output/state/counters/native KV and passes scoped memory: **433.33 MiB including owned pinned and CPU array roots**, versus ordinary541.08 MiB. Prefill peak is unchanged. Quiet preregistered3ABBA speed gate **passes: 58.93 to54.09 ms median (8.22%,4.84 ms saved)**, p95 improves8.76%, TTFT+1.40%. All300 measured predictions/arm and frozen state/counters/native KV match;25 GPU quiet observations pass. Longer-context8K/31.5K teacher parity and forced cold256-row slot-recycling parity pass, each50 steps with native CPU phases and no fallback. Free-generation parity passes on all12 reused development documents across six tasks: exact tokens, scores, state, trajectory, counters and native KV. **597 native CPU phase steps/19104 layer transitions** execute with no fallback;174 additional native cold reclaims occur. All owned jobs are terminal. Joint faithful-baseline/quality gates remain open. Candidate remains research-only. Production defaults are unchanged. Full P0/P1/P2 remains incomplete; the unsupported day estimate is withdrawn. This checkpoint supersedes earlier statements that controller integration is unimplemented.

**Native CPU state phase checkpoint (3 October):** **489 tests pass**, including
30 focused phase checks. Fixed shared CPU owners hold hot/cold positions,
grace, shadow/resident flags, streaks and logical/free slot order. Native batch
operations perform promotion, hot append, complete demotion metadata updates
and cold compaction/reclaim. All malformed batch inputs reject before any
layer mutates; version and owner checks reject stale/foreign GPU commands.

All **1600 recorded layer transitions** replay exactly in50 native batches,
including2560 paid rows,23872 restored backups, F32 metadata commands and
physical slot order. Five GPU handoff fixtures across20 layers match original
cache payload/metadata bits, roots and padding: shadow-first reclaim, stable
LRU overflow, live-floor cover, exclusive promotion and eight-layer compaction.
Victim/cold-keep decisions are supplied; these fixtures do not independently
prove retention selection. GPU slot tensors emulate storage, not native host
transfers. Declared32-layer CPU owners are **1116896 bytes (1.065 MiB)**;
container/output/Python workspace and whole-model peaks remain unmeasured.

[Phase proof](results/hardware/cpu_state_transition_v1/verified_stage.json).
**Decode-controller integration remains incomplete.** Next attach canonical
CPU owners and consume these commands through promotion, demotion, native KV
transfers, visibility and cold reclaim, preserving unsupported fallback; then
run recorded model parity, actual resource and preregistered speed gates.
No speed/quality/adoption claim is established. All owned jobs are terminal;
production defaults and failed-candidate stops remain unchanged. Full P0/P1/P2
remains incomplete; day estimate withdrawn.

**CPU transition diagnostic and corpus (3 October):** Both fresh policy
profiles preserve all50 frozen predictions, final state, counters and native KV.
The0.836-second first extension load is already excluded by benchmark warmup;
it does not reverse the pooled controller's failed speed decision. Native
backup classification costs3.009 inclusive instrumented ms/step across1600
calls. Isolated backup batching is not justified as a4ms whole-loop fix.
Broader CPU state-transition work is the next mechanism, not another wrapper.

A recorded ordinary GPU run freezes **1600 layer transitions**. Independent
CPU/F32/slot replay is exact:2560 paid rows,23872 restored backups and1600
queued compactions. Positions, flags/streaks, metadata bits, logical/free slots
and outcomes match. The native backup classifier matches every record. This
corpus supports CPU-stage validation without repeated model launches per edit.
Cold occupancy reaches897/1090; no overflow occurs. Saturation/reclaim and
broader malformed/ragged/nonfinite fixtures remain mandatory.

[Diagnostic](results/hardware/pooled_controller_diagnostic_v1/verified_diagnostic.json),
[corpus](results/hardware/controller_transition_corpus_v1/verified_corpus.json),
[next phase plan](results/hardware/cpu_state_transition_v1/plan.json).
**Full CPU state-transition redesign is not implemented yet.** Existing459
unit tests remain passing; this checkpoint adds executable replay evidence,
not a speed/quality/adoption claim. All owned jobs are terminal; wrappers,
hooks and pinned roots release. Production defaults and failed-candidate
stops remain unchanged. Full P0/P1/P2 remains incomplete; day estimate withdrawn.

**Current pooled controller result:** 459 tests pass. Fixed GPU metadata
owners and fused transitions preserve 4K/12 and16K/50 recorded model behavior.
Scoped active memory is432.10 MiB (432.27 with CPU array bound), below512 MiB.
Quiet3ABBA median is58.06 to61.54 ms:6.00% slower. Both speed primaries fail;
p95 andTTFT pass. Stop expansion/adoption; no favorable timing retry.
All owned jobs are terminal. Full P0/P1/P2 remains incomplete; day estimate
withdrawn. Primitive/controller integration is now verified, but the combined
latency/memory/quality/faithful-baseline gate remains open.
[Evidence](results/hardware/pooled_controller_v1/README.md).

**Current native controller result:** 437 tests pass. Native promotion,
backup and address calculations preserve recorded model behavior. Scoped
active memory is432.12 MiB (432.29 with CPU array bound), but quiet3ABBA median
is57.92 to62.80 ms (8.43% slower), and p95 fails. Stop expansion/adoption.
All owned jobs are terminal. The complete controller/retention layout remains
open; wrapper consolidation has not closed the joint latency/memory/quality
gate. Full project incomplete; unsupported day estimate withdrawn.
[Evidence](results/hardware/native_controller_v1/README.md).

**Current bounded transition result:** 401 tests pass. Scoped active memory
is 432.12 MiB versus 541.08 MiB (20.14% less), but quiet 3ABBA median decode is
58.33 to 63.09 ms (8.15% slower), and p95 fails. Stop expansion/adoption.
Predictions, state, counters and native KV transfers match. All owned jobs are
terminal. Descriptor uploads are additional; the copied zero metadata scalar
is corrected in a separate artifact. Full project incomplete; day estimate
withdrawn. Next target: broader controller consolidation.
[Evidence and correction](results/hardware/bounded_deferred_ownership_v1/README.md).

**Current diagnostic:** the slowdown is localized to 1600 per-layer gathers
replacing 50 batched native gathers, plus shared-buffer checks/copies. Both
fresh GPU profiles preserve frozen behavior and release owned resources.
Controller consolidation remains the next target. The failed memory-only
design stays experimental. Full project incomplete; day estimate withdrawn.
[Diagnostic](results/hardware/shared_transition_diagnostic_v1/verified_diagnostic.json).

**Current measured progress:** 385 tests pass. Shared decode ownership cuts
scoped active memory from 541.08 to 415.16 MiB (23.27%), passing the 512 MiB gate.
Predictions, state, counters and transfers match on the frozen 50-step run.
Quiet 3ABBA median decode is 58.84 to 64.13 ms: 8.98% slower; p95 also fails.
Stop unified-transition expansion/adoption. All owned jobs are terminal.
The joint latency/memory/quality gate remains open. The unsupported 10–20-day
forecast remains withdrawn. Full project incomplete.
[Proof](results/hardware/shared_decode_transition_v1/verified_resource.json).

**Latest ordinary-backend test:** **358 tests pass**. CPU timestamp updates
with originalGPU tie sorting preserve model/cache behavior, but quiet3ABBA
improvesmedian only **0.88% / 0.51ms** (57.85→57.34ms), failingrequired5%/4ms.
**Stop standalone CPUtimestamp expansion/adoption.** Scopedmemory541.19MiB
still exceeds512MiB; extra metadatauploads5.692MB are charged. All owned jobs
are terminal. Broader transition/ownership restructuring remains; fullP0/P1/P2
open, unsupported10–20-day forecast withdrawn.
[Verified decision](results/hardware/cpu_lru_metadata_v1/verified_cost.json).

**Current critical-path diagnostic:** the GPU0 ordinary-bulk16K/50-step
profile replays every frozen prediction, finalcache, logicalcounter and native
payload/call total. All owned jobs are terminal; hooks and pinned roots release.
About967,000 policy calls take1.920s under instrumentation. Eviction/demotion
is11.48ms/decode; read preparation11.10ms and visibility9.94ms are overlapping
cumulative ranges, not additive speed estimates. Native visible gathering is
0.76ms/decode. Next preregister cross-layer eviction/demotion bookkeeping
consolidation on the ordinary backend and require preserved state/selection/
transfers plus whole-loop/resource gates. Fullquery derivatives remain stopped.
[Verified critical path](results/hardware/completion_critical_path_v1/verified_audit.json).

**Completion plan correction (3 October):** the repeated **10–20 days** estimate
is withdrawn; it was not recalculated from the remaining gates. Earlier
estimates below are historical and must not be treated as a current forecast.
[Critical-path audit](results/hardware/completion_critical_path_v1/audit.json)
separates failed research gates from incomplete deliverables and external hardware.
The existing ordinary CPU backend is541.08MiB versus528.74MiB SnapKV; both
exceed512MiB and attention widths differ on49/50steps. A frozen older faithful
latency study is60.56 versus25.83ms (2.34×); its independent quality comparison
also fails NI. These studies do not prove current bulk quality or a joint win.
PhysicalSTT/controller energy/endurance remains unavailable and unproven.

Execution priority: profile the current ordinary bulk/lastlogits backend with
frozen50-step state/prediction/payload replay; address one structural bottleneck
that can close a main memory/latency gate. Keep failed fullquery derivatives
stopped. Then verify actual resources before expanding independentquality and
baselines; prepare reproducibility/manuscript artifacts alongside those gates.
No full completion date is supported until the research and hardware gates resolve.

**Current result (3 October):** **328 tests pass**. Reading all cold keys but
only selected cold values preserves the model's predictions and cache state.
Copied K/V payload falls **45.53%** (5.826→3.173GB), but decode improves only
**4.57%** (97.48→93.02ms), below the required5%. **Stop standalone channel-reader
expansion/adoption.** Memory remains545.17MiB, above512MiB. All owned jobs are
terminal. PhysicalSTT, matched baselines and independentquality remain open;
estimate **10–20 working days**, conditional on hardware/research outcomes.
[Verified decision](results/hardware/query_channel_reads_v1/verified_cost.json),
[current status](PROJECT_STATUS.md). Older checkpoints below are historical.

**Latest ownership decision:** forward-owner release preserves all four
shared-budget pairs and 1,536 layer releases/restorations. Active decode
envelopes fall **3.29–3.86%**, below the 10% gate, and remain **518–521 MiB**.
The 4K diagnostic locates the peak during first pre-forward validation;
release then removes about128 MiB of live GPU allocation. Reject advancement.
Next investigate duplicate ownership at the compressed-prefill boundary.
**Current suite:227 tests pass.** [Verified decision](results/hardware/forward_owner_release_v1/verified_report.json).

**Latest memory decision:** the isolated raw-input-reuse prototype preserves
all four shared-budget context pairs, but decode active envelopes stay about
**539 MiB**; every 10% memory primary fails. A 4K phase audit confirms
384 bindings/compactions and about128 MiB released after forward. The peak is
already reached during forward (step2), so post-forward reuse is insufficient.
Stop before usual-budget/timing/generation/CLI expansion. **Suite at that milestone:
217 tests passed.** [Verified rejection](results/hardware/raw_input_reuse_screen_v1/verified_report.json).

**Latest verified diagnosis:** 3,072 layer checks across 4K/8K/16K/31.5K
and both capacities confirm the incoming raw KV already contains the exact hot
prefix and has room for actual promotions plus new tokens. All 16 rows replay
frozen outputs/state/counters/transfers; **206 tests passed at that milestone**. This supports an
isolated buffer-reuse prototype, not a memory gain or safe in-place mutation
claim. [Prefix/ownership proof](results/hardware/decode_prefix_audit_v1/verified_report.json).

**Latest screen decision:** charged per-token CUDA cache release is rejected.
It releases **104 MiB at the final boundary**, but lowers decode reserved
**peak by 0%**. The observed reserved envelope stays **519.74 MiB**, above
512 MiB. State, predictions, transfers and counters match; both host roots
release; **206 tests passed at that milestone**. Stop before timing/generation/CLI advancement.
[Verified decision](results/hardware/decode_reclaim_screen_v1/verified_report.json).

**Latest resource audit:** six GPU 0 processes are finished and independently
verified. Bulk/control outputs, cache state and fresh-process GPU peaks match.
Current ordinary paths exceed the 512 MiB target: allocated decode envelopes
are about **539 / 804 MiB** in the legacy caller and **1537 / 1800 MiB** in the
fresh caller. Both reserved scopes exceed 6 GiB. The fresh caller retains
1000 MiB of prefill logits through its first decode; model-only allocator slack
is just 3.49 MiB. These callers differ, so their difference is not a causal
saving. No new memory/default claim; [resource proof](results/hardware/bulk_resource_audit_v1/verified_report.json).

**Latest verified opt-in:** `--cpu-bulk-promotion` preserves decisions/state
and improves 16K decode **5.23% / 6.54%** against the same CPU backend at
1024/2048 and 991/1090 capacities. All three ABBA blocks per geometry and
p95/TTFT/GPU peak guards pass. Four-context parity, native lifetime, saturation,
24 generation pairs, six recycled requests and ordinary CLI checks pass;
**206 tests passed at that milestone**. Requires the existing native-reuse CPU chain; defaults
unchanged. Full-resource, quality, faithful SnapKV speed and hardware gates
remain open. See [current status and evidence](PROJECT_STATUS.md).

**Latest experimental allocator:** exact pinned roots reduce measured host
ranges 256→144.25 MiB / 512→264 MiB. Parity, timing, 24 generation pairs and
request recycling pass; full suite **199 tests**. GPU peak is unchanged.
Active decode envelopes are 427.40 / 556.25 MiB; usual active and both
reserved scopes fail the 512 MiB target. Candidate stays research-only.
See [current status and verified evidence](PROJECT_STATUS.md).

**Audited against the repository on 2026-09-27; default-versus-CPU-probe boundary updated on 2026-09-29.** Code is the source of truth. This document labels claims as **Implemented** (current code), **Intended** (target architecture), **Observed** (named artifact), or **Proposed** (future work).

**If this page feels difficult:** Start with [START_HERE.md](START_HERE.md),
then [SIMPLE_NOTES.md](SIMPLE_NOTES.md).
It explains tokens, attention, the two cache groups, and the results without
assuming systems background. This page is the technical reference; read one
section at a time as a question arises. “KV” means saved keys and values;
“prefill” means processing the prompt; “decode” means generating new tokens.
The [project status page](PROJECT_STATUS.md) says what is done and what remains.

## 1. Problem and scope

Autoregressive transformers retain one key and value per attended token at every layer. The tested Mistral-7B configuration has 32 layers, 8 KV heads, dimension 128, K and V, and bf16 storage: 128 KiB per retained token across the model. A 31,500-token KV cache is about 3.84 GiB before allocator overhead, weights, activations, and temporary buffers.

TieredKV studies a small fast working set backed by a larger slow victim cache. It trades selection work and slow-tier traffic for retained context, fast-tier capacity, and fewer writes to a write-expensive tier. The evaluated objectives are quality, decode latency, throughput potential, prefill/decode peak memory, logical capacity, write/transfer volume, and modeled energy.

**Default implementation boundary:** there is no physical STT-RAM, CPU offload, PCIe/CXL transfer, DMA, or device controller in the normal LongBench policy. Both logical tiers are PyTorch tensors on the model GPU. An opt-in experiment in `experiments/probe_cpu_cold.py` places cold K/V in CPU DRAM and synchronously copies selected rows to/from the GPU; it is slower and is not an STT-RAM measurement. Default wall-clock numbers measure the Python/GPU prototype. STT bandwidth, latency, and energy remain analytical. Current evidence does not prove simultaneous SOTA performance on all objectives.

## 2. Codebase and two execution paths

| Area | Source of truth | Responsibility |
|---|---|---|
| Cache core | `src/tiered_kv_cache.py` | Per-layer state, placement, simulator sketch/peek, promotion, demotion, capacity |
| Attention | `src/attention.py` | Exact simulator attention and SnapKV importance |
| Model harness | `experiments/longbench_eval.py` | Mistral integration, generation, policies, bounded prefill, scoring |
| Baselines | `src/baselines.py`, harness policies, `snapkv_adapter.py` | Simulation, in-harness policies, upstream-selector adapter |
| Accounting | `src/cost_model.py`, `src/metrics.py` | Analytical costs and per-step counters |
| Evidence | `results/remediation_v3/` and later result folders | Corrected controls, ablations, pilots, provenance |
| Verification | `tests/` and `report_*.py` | Invariants, integration, artifact checks |

Two paths must be distinguished:

1. **Standalone simulator:** `TieredKVCache.step()` uses the current query, page min/max bounds, optional peek attention, promotion, exact attention, and demotion.
2. **Real Mistral path:** `TieredKVPolicy` exposes uniformly sized K/V to Hugging Face. It promotes slow rows using attention measured during the previous decode step. It does not call the page-sketch selector and does not inject extra peek pages.

## 3. Actual architecture

```mermaid
flowchart TD
 A[Prompt] --> B[Mistral prefill on GPU]
 B --> C[Full prompt KV temporarily on GPU]
 C --> D[One TieredKVCache per layer]
 D --> E[Sink + recent + importance bifurcation]
 E --> F[Logical VRAM tensors on GPU]
 E --> G[Logical STT tensors on same GPU]
 E --> H[Dropped rows]
 F --> I[Equal-length visible cache]
 G --> I
 I --> J[GPU model attention]
 J --> K[Map attention to resident positions]
 K --> L[Promote hot slow rows]
 L --> M[Append new KV; demote/reclaim/drop]
 M --> I
```

The model, attention, both K/V tiers, cumulative scores, and slow-tier timestamps run on GPU. Small boolean metadata and Python position lists are host-side. Each layer owns independent state. Hugging Face uses one shared causal-mask length, so `_visible_tuple()` forces every layer to expose the same row count even when identities differ.

Original absolute positions in `sram_pos` and `stt_pos` are stable identities. Tensor indices are unstable because moves, deletion, and concatenation reindex storage.

## 4. Storage inventory

| Item | Logical fast tier | Logical slow tier | Host state | Actual behavior |
|---|---:|---:|---:|---|
| K/V | `sram_k/v (H,N,D)` | `stt_k/v (H,M,D)` | — | Both GPU tensors; cold dtype may be bf16 or experimental FP8 |
| Positions | — | — | `sram_pos`, `stt_pos` | Identity/protection |
| Hot value | `sram_cum`, `sram_age` | — | — | GPU float32 eviction state |
| Slow recency | — | `stt_last_access` | — | GPU float32 ordering state |
| Residency/history | — | — | `stt_shadow`, `stt_was_vram_resident` | Duplicate backup and re-entry state |
| Grace/hysteresis | — | — | `sram_grace`, `stt_peek_streak` | Immediate re-eviction and churn control |
| Slow attention | — | — | `_stt_attn` maps | Drives next-step real-model promotion |
| Visibility maps | — | — | `_vis_*` maps | Map returned rows back to state |
| Token IDs | — | — | generation tensors | Never migrated as KV |
| Weights/activations | — | — | — | Ordinary GPU state; outside policy ownership |

FP8 changes only cold K/V storage. Selected rows convert back to the hot compute dtype. Scores are not quantized.

## 5. Complete KV lifecycle

### Prompt placement

Default prefill first materializes exact full-prompt KV on GPU. `_bifurcate()` uses K as a Q proxy because retaining the full prefill attention matrix is infeasible at LongBench lengths. `initial_bifurcation()` computes SnapKV-style importance over the recent observation window.

The first `sink_size` and last `window_size` positions are pinned. If their union exceeds `sram_capacity`, initialization raises `ValueError`. Other positions are stably sorted by importance. The hottest fill logical VRAM; the next fill `floor(sttram_capacity * sttram_bifurcation_frac)`; the remainder are dropped permanently.

Opt-in bounded prefill feeds chunks with absolute position IDs and compresses after each chunk. `resident_tuple()` carries every retained live row, not only the decode exposure quota. This reduces peak allocation but is approximate because early compression affects later prompt processing.

### One real decode iteration

1. `_visible_tuple()` chooses a common fast-tier count and up to `stt_expose_quota` non-shadow slow rows per layer.
2. Hugging Face attention consumes those GPU tensors plus the new token. A logical STT row needs no physical transfer because it already resides on GPU.
3. `update_scores()` maps eager-attention weights to fast/slow positions, updates hot scores/age, and saves slow-row attention.
4. On the next policy call, `_decode_step()` ranks observed slow rows. At most `promote_top_pages * page_size` single-row candidates enter hysteresis.
5. Accepted K/V rows promote. New K/V appends. If fast capacity is exceeded, victims demote or drop and slow capacity is enforced.
6. Explicit absolute `position_ids` preserve true RoPE positions after trimming.

At request termination, `reset()` folds counters into cross-sample totals and discards cache objects. There is no physical-tier erase or persistent prefix cache.

## 6. Promotion

### Real-model path

The first decode step has no promotion because no slow attention has yet been observed. Later, `_stt_attn[layer]` maps original positions to prior-step attention. `_decode_step()` resolves positions to current indices, excludes shadows, sorts descending, and selects a bounded candidate set.

`resolve_promotions()` admits a never-hot row on first candidacy. A previously evicted row must qualify twice consecutively. A break resets its streak. Denied re-entry is counted as deferred; the real harness gives it no extra peek visibility. Inclusive promotion is capped to preserve `stt_live_floor` live rows.

`promote()` gathers **both** K and V, converts cold dtype when necessary, and concatenates them to `sram_k/v`. It adds the original position, zero score/age, and one-pass grace. Inclusive mode retains the old slow row as a shadow; non-inclusive mode deletes it and its metadata. Multiple candidates are processed hottest-first. Promotion may temporarily overfill fast storage; the subsequent demotion restores capacity. Grace prevents immediate same-pass reversal.

### Simulator difference

`sketch_check(q)` forms page-wise key minima/maxima and computes the Quest upper bound `sum_d max(q_d*min_d, q_d*max_d)`. It keeps at most `promote_top_pages` pages whose bound exceeds median fast-tier relevance. Denied pages can be gathered by `get_peek_kv()` and included in simulator attention. This is implemented and tested, but it is not the LongBench promotion path.

## 7. Demotion, eviction, and write saving

`evict_and_demote()` appends generated K/V, then restores `sram_capacity`. Sink positions, recent positions, and grace rows are protected. Eligible rows are ranked primarily by average/cumulative attention. `write_aware_lambda` slightly favors a near-tied row with an existing shadow because its backup avoids a new write.

Both K and V leave the fast tier. If a valid immutable shadow exists, it becomes live and `writes_saved` increments. Otherwise K/V append to slow storage and a paid write is recorded. KV is immutable after creation, so a retained duplicate does not become stale.

For several backed victims in one layer step, the implementation restores their shadow flags, LRU timestamps and re-entry streaks together. This changes the number of GPU metadata-update launches, not the residency decision or the modeled count of avoided slow-tier payload writes. The row-by-row control and batched path produced identical 32-token generations and paid/saved-write counters on 15 selected real prompts; the control remains selectable through `batch_backup_updates=False` for ablation.

Under slow-tier pressure, duplicate shadows are reclaimed first because their fast copies remain. If necessary, live cold rows are then removed while respecting the live floor where possible. A removed live row is permanently dropped and cannot be promoted later.

Promotion, new-token insertion, and demotion can occur in one call. Grace prevents immediate reversal; two-step re-entry hysteresis reduces but cannot eliminate later thrashing.

## 8. Physical migration mechanism

| Direction | Current source/destination | Operation | Synchronization |
|---|---|---|---|
| Slow → fast | GPU tensor → GPU tensor | gather/index both K/V, dtype conversion, `torch.cat` | Default PyTorch/CUDA ordering |
| Fast → slow | GPU tensor → GPU tensor | gather both K/V, conversion, append via `torch.cat` | Default PyTorch/CUDA ordering |
| FP8 slow operations | GPU byte views | `uint8` index/cat, reinterpret FP8, convert selected rows | Same stream semantics |

No metadata migrates with K/V. Metadata changes after tensor operations are enqueued. There is no explicit `non_blocking` copy, transfer stream, CUDA event, pinned host buffer, DMA control, partial-copy recovery, or overlap. Repeated concatenation allocates/copies temporaries and contributes to measured latency.

**Intended physical deployment** still needs a GPU-accessible controller, address translation, allocation, PCIe/CXL or other link behavior, completion events, failure handling, and transactional metadata. These are unverified.

A separate pinned CPU-DRAM↔GPU experiment bounds only the host transfer
component: on the model's L40S/Gen4×16 link, 4 MiB took 9.38 ms in 1,024
small copies, 0.299 ms in 32 layer copies, or 0.171 ms packed. It does not
turn this GPU-resident implementation into an STT-MRAM implementation. A
capacity-matched pair of 1Gb Everspin devices advertises at most 5.4 GB/s
aggregate read/write bandwidth, giving a 0.777 ms ideal device-only floor
for that 4 MiB read before controller/link losses; see
`results/hardware/host_transfer_report.json` and the sourced hardware
section of `README.md`.

## 9. Residency states and invariants

```mermaid
stateDiagram-v2
 [*] --> VRAM
 [*] --> STT_live
 [*] --> Dropped
 STT_live --> Both: inclusive promotion
 STT_live --> VRAM: non-inclusive promotion
 Both --> STT_live: demote using backup
 VRAM --> STT_live: paid demotion
 Both --> VRAM: reclaim shadow
 STT_live --> Dropped: pressure
```

Required invariants:

- K and V shapes match and move together.
- Position and metadata lengths match their tier’s sequence dimension.
- Fast occupancy is within capacity after a complete step.
- Every layer returns equal visible length for the shared mask.
- Shadows are excluded from attention, avoiding duplicate softmax entries.
- Original positions identify rows across reindexing.
- Sink/recent protection and absolute positions survive trimming.
- A token may validly exist in both tiers; “exactly one copy” is not an invariant. Duplicate immutable values must agree.

The real integration supports batch size one only; no concurrent-request invariant is implemented.

## 10. Decision table

| Confirmed condition | Action | Why |
|---|---|---|
| Prompt starts | Bifurcate per-layer KV | Establish bounded residents |
| Pinned union exceeds fast capacity | Raise | Avoid permanently overfull state |
| Exposed slow row was hot last step | Consider promotion | Make future reads fast |
| Previously evicted row has streak <2 | Defer | Reduce churn |
| Inclusive promotion would violate live floor | Defer tail | Avoid cross-layer exposure veto |
| New/promoted rows exceed fast capacity | Demote lowest eligible rows | Restore capacity |
| Victim has shadow | Reactivate it | Save logical slow write |
| Victim lacks shadow | Append both K/V to slow tier | Retain history |
| Slow capacity exceeded | Reclaim shadows, then drop live rows | Restore capacity |
| No layer has live slow rows | Count unused | Short workload, not starvation |
| Some live rows exist but common exposure is zero | Count starvation | Shared-mask visibility loss |
| Request ends | Aggregate and reset | Isolate samples |

There is no trigger based on CUDA free bytes, physical STT pressure, transfer queues, temperature, energy, concurrent priority, or device failure.

## 11. Worked example

Assume one layer, fast capacity 4, slow capacity 6, sink 1, recent 1, exposure quota 2, inclusive mode.

1. Eight prompt positions 0–7 arrive. Positions 0 and 7 are pinned; importance selects 2 and 5. Fast holds `[0,2,5,7]`; slow might hold `[1,3,4,6]`.
2. Attention sees four fast rows plus two selected live slow rows. Suppose slow position 3 receives most attention.
3. Next policy call promotes 3 immediately because it has never been hot. Fast temporarily has five rows; slow 3 becomes a shadow; fast 3 has grace.
4. Generated position 8 appends, producing six fast rows. Two eligible low-score rows leave while 0, 8, and grace row 3 are protected.
5. If victim 2 has no backup, both K/V append to slow storage and one paid demotion is counted. If victim 5 has a shadow, it reactivates and one write is saved.
6. If 5 later becomes hot, its first re-entry candidacy is deferred; a consecutive second candidacy promotes it.
7. If slow storage exceeds six rows, an unused shadow is deleted first. If that is insufficient, a live row is dropped permanently.

All tensors in this example remain on GPU today.

## 12. Edge cases

| Case | Implemented behavior | Limitation |
|---|---|---|
| Empty/short prompt | Helpers are safe; slow tier may stay unused | Cannot demonstrate tier benefit |
| Pins exactly at capacity | Valid, no discretionary hot slots | Expected boundary |
| Pins over capacity | Explicit error | Correct fail-fast |
| Very long prompt | Default builds full KV then compresses/drops | High prefill peak |
| Fast tier full | Demote after append/promotion | Cat/sort/index is slow |
| Slow tier full | Reclaim shadows then drop live rows | No CPU/disk spill |
| Immediate reverse move | One-pass grace blocks it | Later thrashing remains possible |
| Multiple moves | Logical batch, then capacity restore | Temporary allocations raise peak |
| Access during move | Single Python/default-stream sequence | No concurrent transfer validation |
| Partial/failing move | No explicit recovery | Physical system needs transactions |
| Duplicate copy | Immutable shadow, excluded from attention | No continuous byte equality assertion |
| Multiple sequences/batch change | Batch other than one raises | Serving not implemented |
| Different shape/dtype | Layer shapes inferred; bf16/FP8 cold tested | Other models require validation |
| Layer disagreement | Minimum common exposure count | One layer can throttle all layers |
| Middle document truncation | Halves receive contiguous positions | False adjacency remains |
| Request end | Reset/discard | No shared prefix/persistence |

## 13. Complexity and bottlenecks

For fast rows `S`, slow rows `T`, pages `P=ceil(T/page_size)`, heads `H`, dimension `D`, and exposure quota `Q`:

- K/V space is `O((S+T)HD)` per layer plus linear metadata.
- Visible attention is `O((S+Q)HD)` per decode layer.
- The simulator currently rebuilds page extrema in `O(THD)` and scores in `O(PHD)`.
- Ranking/eviction scans or sorts resident metadata.
- `torch.cat` copies tensors; Python loops, dictionaries, scalar extraction, and allocator activity add latency and synchronization.

The analytical model prices traffic but omits model compute, controller/interface overhead, prompt placement, and system power. Its nominal STT 50/12.5 GB/s and 2/8 pJ/bit are sensitivity assumptions, not a golden standard. The cited single Everspin device reports 2.7 GB/s both ways; aggregation requires hardware absent here.
The cost model also exposes an ideal two-device 5.4/5.4 GB/s bandwidth
scenario without claiming its energy numbers are device measurements.
Discarding a slow row invalidates metadata; it does not fetch that row's
payload. The earlier analytical charge for such a read was corrected, with
old-report deltas recorded in `results/hardware/drop_cost_correction.json`.

## 14. Experimental methodology

The corrected control uses Mistral-7B-Instruct-v0.2, bf16 KV, batch one, seed 0, maximum prompt 31,500, LongBench task prompts/scorers, 25 examples for each of five short tasks and 10 GovReport examples. Hardware is NVIDIA L40S 48 GB with CUDA 12.4. Model/source/dataset hashes, packages, predictions, per-example scores, and hardware are recorded in `results/remediation_v3/` and later report folders. Reproduction commands are in `README.md`.

The aggregate is task-balanced. Paired bootstrap intervals resample fixed examples within tasks; they do not capture new tasks, models, seeds, or machines. Latency uses fixed prompts and ABBA ordering where recorded. Warm-up and trial counts live in each JSON; historical files do not share one protocol.

`results/archive/` is not current evidence. Quest’s real-model policy is explicitly unimplemented. In-harness SnapKV is approximate. The upstream-selector adapter is closer to upstream selection but expands GQA heads; recent comparisons match a configured maximum final KV budget, not actual resident bytes or attended width.

## 15. Results and interpretation

- **Corrected control:** `results/remediation_v3/` provides the frozen reproducible baseline. Full-loop 16K latency was about 115.7 ms/token for TieredKV versus 34.4 for compact SnapKV. A later behavior-preserving metadata fast path measured 106.17 versus 120.48 ms/token in a same-process three-block 16K ABBA test with the same 128-row recent window; p95 was 129.53 versus 180.36 ms/token. The benchmark is still far above the compact baseline. Exact prefill peaked near 18.59 GB. This shows substantial remaining policy overhead and no default prefill-peak reduction.
- **Query-aware selection:** 135 fixed requests improved over access-time TieredKV by +4.35 task-balanced points, 95% CI [+2.12,+6.61], but latency rose to 158.91 from 115.53 ms/token and paid writes rose about 50%. Against the upstream-selector adapter the difference was -0.34, CI [-2.13,+1.56]. It is a diagnostic trade-off, not demonstrated SOTA.
- **Opt-in actual-query prompt placement:** the default uses K as a query proxy during initial bifurcation. A new experimental path captures the final 128 real rotary-positioned queries, causally masks future keys, and broadcasts GQA keys while computing global prompt importance. On 27 selected paired examples across six tasks it gained +4.45 task-balanced points (conditional interval [+0.81,+8.86]) and reduced logical paid demotion writes 109,660→60,643 (−44.7%), but 4 examples regressed, including both GovReport examples. A same-process prefill benchmark measured +7.53% time/+16 MiB peak on one Qasper prompt and +5.07%/+32 MiB on one NarrativeQA prompt. This is a trade-off, not the default, a physical endurance result, or a demonstrated SOTA improvement. Later full-sample and full-loop evidence follows. See `results/baseline_fidelity/real_q_prefill_six_task_report.json` and `real_q_prefill_abba_report.json`.
- **Larger actual-query result:** on the fixed 135-example six-task sample with query-scan decode, the same opt-in selector gained +2.34 task-balanced points over K-as-Q (conditional interval [+0.30,+4.42]) and reduced logical paid demotion writes 581,067→298,543 (−48.6%). MultiFieldQA declined 2.22 points and 19/135 examples regressed. Full-run latency/peak comparison is invalid because another GPU0 process overlapped the candidate. An independent three-block 16K ABBA measured median/p95 decode changes −1.23%/−1.21%, but TTFT +6.22% and prefill peak +0.199 GB. See `results/baseline_fidelity/real_q_prefill_full_report.json` and `real_q_full_loop_abba_report.json`.
- **Actual-query placement with access-time decode:** on the same 135 examples, it gained +5.20 task-balanced points over K-as-Q (conditional interval [+2.84,+7.69]) and cut logical paid demotion writes 359,473→292,996 (−18.49%). GovReport declined 1.35 points and 22/135 examples regressed. Three-block 16K ABBA found effectively neutral decode latency (median block −0.50%, p95 −0.13%), with TTFT +6.89% and prefill peak +0.199 GB. Stress bins show a long-output weakness: 6/10 GovReport examples regressed; six examples across tasks lost >10 points. This remains opt-in and is not SOTA or physical endurance evidence. See `results/baseline_fidelity/real_q_lru_full_report.json`, `real_q_lru_full_loop_abba_report.json`, and `real_q_lru_stress_report.json`.
- **Closer SnapKV payload screen:** with task-level SnapKV prompt capacities chosen from earlier observed output lengths, mean final KV bytes were within 2% of TieredKV for five Qasper, five NarrativeQA and five GovReport examples. TieredKV–SnapKV task-balanced quality was −0.68 points (conditional interval [−4.93,+3.36]); Qasper lost 4.64. GovReport per-request Snap/Tiered byte ratios varied 0.806–1.840 even though task means matched, and attended width differed. This is a diagnostic, not ex-ante equal-resource superiority (`results/baseline_fidelity/snap_task_bytes_report.json`).
- **Ex-ante ceiling SnapKV comparison:** both policies were constrained to a configured maximum of 512 MiB final resident KV on the frozen 135-example six-task set. Current-source TieredKV reproduced the archived predictions, bytes, and counters. TieredKV minus the upstream-selector SnapKV adapter was −0.05 task-balanced points (conditional interval [−1.36,+1.36]); Qasper was −3.46. Mean actual Snap/Tiered bytes still ranged from 0.944 to 1.296 by task, and attended width/prefill peak were not matched. This is evidence against a demonstrated quality lead, not a SOTA or latency comparison (`results/baseline_fidelity/snap_exante_full_report.json`).
- **Inclusive shadows:** the full ablation reports 88.1% fewer normalized paid demotion writes; quality difference -0.20, CI [-0.47,+0.07]. This supports a simulated write-counter effect, not physical endurance or energy. The [candidate 1Gb STT datasheet](https://www.everspin.com/sites/default/files/EMD4E001GAS2_1.3_10102022.pdf) rates endurance as 10^10 *accesses to one page* (1,024-bit x8 or 2,048-bit x16); this implementation has no page-address trace or physical controller, so it cannot predict lifetime from saved write bytes.
- **Page probe:** on one 16K prompt, 8 selected 16-token pages recalled 21.6% of exact top-32 rows; 32 pages reached 59.9% while selecting 33.0% of keys. It is offline and proves no serving benefit.
- **Centroid page follow-up:** query-dot-centroid ranking raised offline top-32 recall to 41.4% with eight pages and 72.4% with 32 pages, using 12.14 MiB of fp32 summaries across layers versus 24.27 MiB for box bounds. Candidate-only reranking retained this coverage. Ten GovReport examples scored 29.33 versus 27.00 for access-time selection, but a vectorized 16K full-loop pilot still took 150.80 versus 142.95 ms/token for full-query selection. Current centroids are rebuilt from all cold K each step; stable incremental metadata is not implemented. This is a retrieval research clue, not a memory-tier or latency improvement (`results/page_recall/centroid_report.json`, `centroid_quality_gov10.json`, `centroid_latency_abba_pilot.json`).
- **Stable-page grouping probe:** assigning 16-row page IDs when cold KV is first placed, then keeping each token's ID as packed rows move, preserved the offline retrieval signal: 41.87% top-32 recall with eight pages and 73.17% with 32, without underfilled exposures. This test still rebuilt every centroid from the full cold key tensor; it established that stable grouping is plausible, not that incremental maintenance or lower latency works (`results/page_recall/stable_page_report.json`).
- **FP8 cold storage:** five Qasper examples scored 6.51 vs 6.91 bf16, CI [-1.17,0]; four predictions matched. Cold resident bytes halved, decode peak fell slightly, prefill peak stayed unchanged, and latency improvement was unproven. Further quantization is paused.
- **Bounded prefill:** corrected 2,048-token chunks reduced 16K peak 18.594→16.113 GB (-13.3%) while TTFT rose 2.245→2.422 s (+7.9%). On 15 selected examples across Qasper, NarrativeQA, and GovReport, the task-balanced quality difference was +0.18 with paired 95% CI [-3.58,+4.82]. The interval is too wide to establish either improvement or the protocol's -0.5 non-inferiority margin. This is the current candidate beyond quantization, not the new default.
- **Reduced promotion admission:** an opt-in four-row cap with 32 slow rows still visible cut migration and paid writes in a 16K screen. In a paired 15-example quality pilot it left Qasper and NarrativeQA predictions unchanged, but GovReport fell by 0.92 ROUGE-L. Task-balanced difference was -0.31 with CI [-1.56,+0.94]. It does not meet the quality non-inferiority gate; default admission remains 32.
- **Faithful SnapKV comparison:** With a configured 512 MiB maximum final KV payload, the source-matched 135-example comparison found TieredKV−SnapKV task-balanced quality −0.05 points (conditional 95% interval [−1.36,+1.36]); Qasper favored Snap by 3.46 points. All 135 Tiered predictions, per-example scores, final resident bytes and cache counters exactly match the earlier Tiered control. The interval crosses zero; neither superiority nor equivalence is demonstrated. Under the final boolean-gather and boolean-hot-compaction source, a separate three-block ABBA on one 16K prompt and 50 fixed decode forwards measured complete-loop Tiered/Snap median 82.76/25.77 ms/token (3.21× slower), p95 86.34/26.03 ms, and TTFT 2194.82/2086.69 ms. Tiered had lower decode allocation peak (15.234/16.522 GB) but higher prefill peak (18.796/17.958 GB), and actual final KV payload was 425/512 MiB. Thus a joint Pareto win is unproved. Tiered's own forward was 25.12 ms/token; substantial policy/attention overhead remains. These are GPU-resident prototype measurements on one prompt, not physical slow-memory or serving throughput results (`results/baseline_fidelity/snap_exante_full_currenthot_report.json`, `bool_hot_compaction_parity.json`, `snap_tier_loop_currenthot_report.json`).

## 16. Conclusions and limitations

**Demonstrated:** bounded logical hot/cold residency; selected cold participation in real Mistral attention; consistent single-request GPU-simulated moves; large simulated write savings from immutable shadows; provenance-aware evaluation; and an approximate prefill mode that lowers measured peak.

**Not demonstrated:** physical STT access, PCIe/CXL overlap, measured migration energy/endurance, multi-request throughput, tail latency, cross-model generality, bounded-prefill quality non-inferiority, equal-byte superiority over faithful baselines, or SOTA. The bounded-prefill pilot is currently inconclusive because its interval crosses the preregistered non-inferiority boundary.

Main limitations are GPU-resident “slow” storage; synchronous tensor rebuilding; batch size one; shared-mask exposure coupling; hypothetical cost inputs; full prompt materialization by default; static capacities; permanent drops; incomplete baseline fidelity; and evidence concentrated on one model, machine, and seed.

## 17. Improvement plan

| Priority | Proposed work | Success evidence |
|---|---|---|
| P0 | Finish 2,048-token bounded-prefill validation | ≥10% peak reduction, quality non-inferiority, TTFT guard |
| P0 | Preallocate/page-table storage and batch decisions | Full-loop TPOT, p50/p95, allocator and profiler evidence |
| P1 | Serving-compatible per-layer page attention | Recall, quality, bytes, kernel and tail-latency results |
| P1 | Equal-byte faithful baselines; more tasks/models/seeds | Preregistered paired comparisons |
| P2 | Capacity-matched physical/emulated slow tier | Measured link traffic, power, thermal and write behavior |

Easy work: standardize per-step exports and warm-up metadata, add debug duplicate-byte assertions, and label figures by evidence class. Advanced work: incremental page summaries, adaptive layer budgets, and joint prefill/decode scheduling. These are proposals, not current features.

## 18. Glossary

- **TieredKV:** the logical two-tier policy and harness.
- **KV cache:** retained transformer keys and values.
- **VRAM/SRAM tier:** hot logical tier; historical `sram_*` names mean GPU VRAM, not on-chip SRAM.
- **STT tier:** slow logical victim tier; currently a GPU tensor with modeled costs.
- **Promotion/demotion:** moving both K and V into/out of the hot logical tier.
- **Drop:** permanent removal beyond retained capacity.
- **Shadow:** immutable slow backup of a row also hot-resident.
- **Live slow row:** slow row without a hot duplicate.
- **Residency:** VRAM, STT-live, both, or dropped.
- **Importance:** prompt-placement score; distinct from decode attention.
- **Page:** contiguous slow index group used by simulator sketches.
- **Exposure quota:** maximum slow rows per layer shown to real attention.
- **Write saving:** demotion that reuses a shadow instead of recording a new slow write.
- **Modeled cost:** analytical result from assumed hardware values.

## 19. Verification index

Cache transitions were checked in `src/tiered_kv_cache.py`; real lifecycle in `experiments/longbench_eval.py`; attention in `src/attention.py`; assumptions in `src/cost_model.py`; counters in `src/metrics.py`; dependencies in `requirements*.txt`; method in `README.md`; remaining work in `REMEDIATION_CHECKLIST.md` and `RESEARCH_ROADMAP.md`; evidence in `results/remediation_v3/`, `shadow_ablation_full/`, `query_selection_*`, `snapkv_adapter_full/`, `page_recall/`, `fp8_cold_pilot/`, and `bounded_prefill/`; invariants in `tests/`.


## 20. Opt-in physical CPU batching (1 October 2026)

`experiments/cpu_batched_cache.py` implements CPU-DRAM slots behind paired
storage hooks. It reuses `cpu_slot_cache.py` from the archived slot trial;
the older per-layer optimization failed its full-loop gate, while the new
shared-pool scheduling passes its separate CPU-control gate. Default
TieredKV remains GPU-resident. CPU DRAM is a surrogate, not physical STT-RAM.

The policy plans exact per-layer promotions once, batches their cold reads,
then keeps each layer's promotion-before-eviction order. Paid writes stay
queued until a read/visibility/inspection/reset boundary; reusing a pending
physical destination forces an ordered flush. Visibility chooses each
layer's own cold rows with the existing common count and batches their
reads. Canonical cache inspection synchronizes pending writes. The native
transfer binaries are unchanged and hash checked. Only homogeneous layer
geometry, bf16/fp16 cold storage and single-token model decode have been
exercised; shared-pool tensor reservation differs from occupied payload and
from process/allocator peak. The GPU default has unchanged selection rules.

Reproduction uses the project environment and GPU0 advisory lock:

```bash
CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  flock /data/nishant/tieredkv_external/gpu0_model.lock \
  ../venv_kvcache/bin/python experiments/compare_cpu_batched.py \
  --output results/hardware/cpu_batched_new_run.json \
  --contexts 16384 --decode 50 --blocks 3 --warmup 1
```

Output paths must be new. Raw parity/latency, reviewed resource arithmetic,
source hashes and limitations are in
`results/hardware/cpu_batched_gate_report_20261001.json` and its linked
frozen source bundle. The 11.76% measured gain is against packed CPU storage;
a fresh GPU control and matched-resource SnapKV comparison remain required.


The same runner now accepts `--control gpu` to compare GPU-resident
TieredKV with the opt-in CPU variant. Defaults still select packed CPU as
the control. Both require exact logical state and predicted-token parity;
physical host payload equality is required only between CPU arms. The GPU
control records zero host traffic rather than treating residency as a copy.
The frozen GPU-control gate fails speed promotion (1.93%, threshold 5%)
and total-memory promotion (1.55%, threshold 10%); CPU storage remains
opt-in. Evidence: `results/hardware/cpu_batched_gpu_gate_report_20261001.json`.
`profile_cpu_batched.py` profiles only decode/score policy calls; its times
include implicit GPU waits and instrumentation, so they are diagnostics.


`batched_score_policy.py` adds opt-in homogeneous score bookkeeping on the
shared CPU backend. It preserves the exact FP32 head means/hot cumulative
scores and cold attention dictionaries/LRU stamps while grouping native
addition and host score reads across layers. Incomplete, unordered or
heterogeneous visibility uses the original score update. It passed the
charged screen, 4K/8K/16K boundary-state parity and CPU-control full-loop
gate (6.66% gain); defaults still use the original method. Reproduce with
`compare_cpu_batched.py --control batched --candidate batched_scores`
and the same new output path/16K/50-step/three-block/warmup settings above.
The earlier GPU comparison covers transfer-only batching; a separate
score-batched GPU control is required. Source/payload/resource limits:
`results/hardware/batched_scores_gate_report_20261001.json`.


The score-batched variant has now passed its separate GPU-control latency
gate (6.00%) and a reused-corpus free-generation integrity pilot: 24 paired
requests across QA/summarization and two seeds preserve every generated ID,
quality score, final state and selection/shadow trajectory. The original
score/transfer/default policies remain available; no global replacement was
made. `check_batched_generation.py` uses the original generation function,
a forwarding tokenizer to capture final token IDs, and the same trajectory
observer in both arms. Native task generation limits and EOS handling remain
unchanged. Its source/data/manifest are frozen and its times are diagnostics.
Broader boundaries/rare retrieval, full saturation/bursts, max context,
allocator/process peaks, second model/concurrency and matched baselines
remain required. Evidence: the GPU gate and verified generation report
linked from `PROJECT_STATUS.md`; these do not close the broad research claim.


`check_batched_boundaries.py` freezes exact input IDs and compares GPU/CPU
integrity at hot/total-budget boundaries and max31500 context. Its all-layer
cold occupancy and migration deltas verify saturation/bursts actually occur.
A zero-generation empty input is a no-op, not a zero-length model forward.
Needle answer positions are used only for diagnostics, never selection.
A full-cache quality oracle recovers all six codes that both sparse policies
miss. Thus the optimized backend preserves current behavior, including
shared retention failures; it does not establish robust retrieval. Oracle
post-return allocation lacks retained KV ownership, so it is not a steady
memory comparison. Exact IDs, hashes, outcomes and scope qualifications are
in the boundary/retrieval report linked from `PROJECT_STATUS.md`.


`check_snapkv_needles.py` observes the faithful upstream selector's actual
indices through a read-only AST callback; removing it must reproduce the
original AST, and a CPU regression verifies bitwise K/V selection parity.
The six reused rare-code prompts recover6/6 versus Tiered0/6. Complete spans
remain in429–594 of1024 layer/query-head pairs, but SnapKV's32-head growing
cache owns524 MiB and differs from Tiered's8-KV-head common-position tiers.
This observation supports investigating retention; it establishes no isolated
cause, independent quality improvement or resource-matched superiority.
Frozen diagnostic evidence is linked from `PROJECT_STATUS.md`.


Actual three-arm resource accounting now covers51 cache boundaries on the
same16K prompt/50 fixed teacher inputs. Final distinct owned KV storage,
including the attention cache copy, is512 MiB GPU SnapKV,462.5 MiB GPU Tiered,
and260 MiB GPU+384.125 MiB reserved CPU batched Tiered. Useful cold occupancy
is202.508 MiB; the shared pinned pool is counted once across32layer views.
Tiered attention sees1057rows versus975–1024 SnapKV. GPU/CPU Tiered row
geometry and predictions agree exactly. None of these arms has equal actual
resources; logical-tier bytes alone undercount owned allocation. This is
observational accounting, not a latency/quality gate or full process peak
measurement. Source/data hashes and storage equations are verified in
`results/baseline_fidelity/snap_tier_resource_trajectory_verified_20261001.json`.


A Tiered-only paired diagnostic isolates the existing actual-query prefill
option on the six rare-code development probes:6/6 recovered versus0/6 proxy,
with equal initial1024hot/1536cold/1056visible rows and320 MiB hot+cold KV.
All32query captures are consumed, complete answer spans survive in22–29layers,
and fresh controls reproduce frozen state/output/trajectory. Additional
prefill work/peak and final free-generation resource changes remain relevant.
Keep the option experimental: the earlier24-document held-out quality
interval crossed zero despite a positive point estimate, with severe losses;
earlier two-prompt prefill guards passed. This synthetic diagnosis does not
justify default promotion, tuning the holdout, or equal-total-resource claims.
Evidence: `results/baseline_fidelity/tiered_query_needles_verified_v2_20261001.json`.


The actual-query option now also reproduces all six GPU needle requests
exactly on the batched CPU+score backend, including final full cache/metrics,
IDs, trajectories, initial payload and retention. Host reservation remains
384.125 MiB; this is integration integrity at unequal physical resources.
A source audit found no unused NarrativeQA documents in its current20-document
slice. Before inference,100distinct normalized unused documents were frozen
across five other tasks (20each), excluding recorded IDs, earlier manifests/
prefixes and standard/E context matches. The three-arm evaluation is not yet
started. Additional unseen NarrativeQA documents and semantic/training overlap
checks remain required. Evidence:
`results/baseline_fidelity/cpu_query_needles_verified_20261001.json` and
`results/baseline_fidelity/realq_cpu_fresh_documents_20261001/verified_manifest.json`.


The larger preregistered independent-document run is complete:100distinct
unused normalized contexts across five tasks,300three-arm generations.
CPU/GPU actual-query match every output/score/final cache/metric/trajectory.
Actual-query minus defaultproxy quality is+5.8658task-balanced points,
paired10000-draw document CI95[3.1641,8.8280]; NI−.5 and aggregate superiority
pass. Seventeen documents regress, five by>10points. This is conditional
placement evidence on one model/seed/five tasks at equal configured Tiered
budgets, not uniform quality, equal physical resources, faithful baseline or
SOTA. Fresh sources/metrics/caps/identities are independently verified:
`results/baseline_fidelity/realq_cpu_fresh_documents_20261001/verified_report.json`.
Combined actual-query CPU/GPU4K/8K/16Kfive-step fullstate parity also passes;
its preregistered whole-loop ABBA remains a separate systems gate.


The combined actual-query path now passes its same-placement systems gate:
GPU81.3295ms/token versus batchedCPU75.2703 (7.4502%gain), p9589.4505/84.6981,
allthreeABBA blocks improve. TTFT+3.4604%passes10%guard. Full state/prediction/
selection/counter parity and source identity are verified. Final GPU allocation
~223.18 MB lower, host211.81 MB occupied/402.78 MB reserved; physicalresources differ
and model-wide10% memory gate is not met. This does not establish faithful
baseline throughput or STT/controller benefit. Evidence:
`results/hardware/realq_cpu_systems_20261001/verified_gate_report.json`.
Together with the100-document conditional quality result, this supports an
opt-in integrated research path; defaults and broader P0/P1/P2 gates remain.


The adapted official NarrativeQA test-story stress now completed48arms over
16of20frozenstories, with4source failures/no replacements. All16CPU/GPU
actual-query paths agree exactly on generatedIDs/fullstate/trajectory/counters.
Placementquality CPUactualquery−GPUproxy +.36points CI95[−7.80,+9.06] fails
NI−.5/superiority gates;6regress,4losses>10. Six prompts middletruncated at
31500tokens. These are current adapted official stories, not published
LongBench samples; no universal quality preservation claim or default promotion.
`results/baseline_fidelity/narrativeqa_conditional_quality_20261001/verified_report.json`.


CPU request ownership now has two additional integrity checks:768delayed
K/Vread observations across independentcoldpools/1–2CUDAstreams, andthree
serializedmodelrequests where one retires/recycleswhileanothercontinues.
IDs/fullcacheboundaryhashes/counters match isolatedGPU andCPU controls.
NativeH2Dhostpointer iscapturedperlaunch;laterpoolregistrationdoesnotredirect
alreadyqueuedkernels. Registerthenlaunch remains two separatePythoncalls,
so concurrentthreadsafety isunproven. These areintegrity gates, not serving
throughput/pinnedallocatorpeak or physicalSTT evidence. Reports:
`results/hardware/cpu_multi_pool_20261001/verified_report.json`,
`results/hardware/cpu_interleaved_model_20261001/verified_report.json`.


Freshprocess memory audit shows CPU batching reduces peakGPUallocation only
.367% (18.69643→18.62783 GB), withsame20.60032 GB peakGPUreservation. Sampled
processRSS rises1.575→2.675 GB. CPUexplicitrootownershippeaks768.25 MiB while
consolidating32perlayerpools into384.125 MiB sharedpool;afterresetrootsreleased
but hostallocatorcache remains. Installedallocatorpower-of-two rounding
infers1GiBcapacity for theseallocations;RSS drops~1.08 GB afterhostcacheflush.
These areownedtrace/sourceinference/processRSS respectively, not exactpinned
allocatorreservationtelemetry. LifetimeRSSHWM~15.2 GB includesmodel-loading.
`results/hardware/fresh_process_memory_20261001/verified_report.json` and
`allocator_rounding_audit.json`; nooverallphysicalmemoryreductionclaim.


Direct shared initialization now avoids duplicate per-layer pinned pools.
The opt-in DirectScorePolicy uses one root allocation and unchanged transfer/
score/decode machinery. Peak owned pinned bytes halve805568512→402784256;
fresh-process sampledRSS falls~544 MB, GPUpeakunchanged. Exact cache-state/
ID/counter parity and32synthetic/768multipoolstream checks pass. TTFT+2.13%,
decode median−.18%/p95+.10% pass regression guards; no new speed claim.
See `results/hardware/direct_shared_init_20261001/verified_report.json`.
Existing defaultCPUbackend preserved; direct normalCLI integration andmodel
interleaving proof now pass (direct_integration_20261001/verified_report.json). Quality selection unchanged/NarrativeQANI unproven.


Direct initialization is available through the query-selection runner with
`--strategy lru --real-query-prefill --cpu-batched-scores --cpu-direct-shared`.
GPU/oldCPU defaults remain. Exact serializedmodel interleaving/reset/reuse
proof and nativeEOS CLI oldCPU/directCPU smoke pass; fullsuite127passes.
`results/hardware/direct_integration_20261001/verified_report.json`.
The inherited NarrativeQA quality gate remains unproven, so this is opt-in.


Current direct-path policy profile localizes eviction/bookkeeping overhead.
A CPU NumPy protected-mask screen preserved valid results and input errors
but saved only2.38ms per32layers, below4msheadroom, so it was rejected and
cache code stayed unchanged. cProfile nestedtimes/GPUwaits are not speed
evidence; investigate cross-layer eviction stages next. Reports:
`results/hardware/direct_decode_profile_20261001/verified_profile_summary.json`,
`results/hardware/protected_mask_screen_20261001/verified_report.json`.


A larger combined eviction-selection screen nowpassesheadroom: complete
32-layer CPUmask preparation/GPUstablevictimselection/finitecounts/host
return takes10.37→2.65ms (7.71ms saving). Batchingalone3.92msfailed4msgate.
Validtypical/ragged/tied/fallback/nonfinite/subnormal victimIDs matchexact
productionAST; lambda0 only. Currentcache/model code unchanged, so this is
syntheticheadroom, not model speed. Future cross-layer coordinator must prove
_t/LRU/ages/floor/grace/shadow/paidwrite parity andpairedwholeloopgates.
`results/hardware/batched_eviction_selection_20261001/verified_report.json`.


Cross-layer eviction coordinator gate (1 October 2026): archived verifier
recomputes exact source hashes, whole-body selector AST preservation,
32 synthetic cases, all four context boundaries, 12 ABBA arms and gates.
Median 74.8154 → 72.5004 ms = 3.0942% gain, below preregistered 5%:
REJECT performance promotion. All three blocks faster; p95 84.4049 →
77.1335 ms, TTFT 2271.9265 → 2271.7845 ms, prefill peak 18.627831296 GB
unchanged. All states/IDs/counters/payloads exact. No normal evaluator flag
added. Further free-generation/interleaved candidate gates are deferred
because this candidate failed the required speed gate. CPU/direct defaults
stay unchanged; prior independent NarrativeQA NI remains unresolved.
Artifact: results/hardware/batched_eviction_coordinator_20261001/verified_report.json.
Next research gate: matched resident resources and attended width against
faithful SnapKV, with joint quality/timing/peak evidence.


Shared owned-KV envelope systems result (2 October 2026): all12ABBAarms
and source/resource/repeatability verified. Snap median25.7417/p9525.9552ms;
directCPU median71.2026/p9578.6061ms, 2.7660×slower. All3blocks slower;
decode/p95 gates fail. TTFT2074.8358→2239.9855ms (+7.9597%) passes10%guard.
Prefill GPU peak16.958269→18.627831 GB; decode15.037793→14.901711 GB:
no10%modelwide memory improvement. These configurations share512 MiB boundary
owned-KV ceiling and1024forward-row ceiling, actualresources/widthdiffer.
CPU991hot/1090cold/32quota differs from prior default1024/2048quality study;
priorquality cannottransfer tothese capacities. No jointquality gate yet.
Artifact: results/baseline_fidelity/snap_tier_owned_envelope_20261002/verified_timing.json.
Refreshunused inventory:65Qasper/37Multi/241Hotpot/241Trivia/256Gov document
groups remain; NarrativeQA standardcorpus exhausted. Broad P0/P1/P2open.


Allocator boundary clarification (2October2026), capacities unchanged:
shared512 MiB is liveKV tensor-storage, not physicalallocator reservation.
SameinstalledTorch2.5coreheaderSHA34433351...a43c7 usesPowerOf2Ceil(size)
atline131. DirectCPU rootrequest260.25 MiB roundsbythat source to512 MiB;
with251.75MiBGPUKV, inferred763.75 MiB beforecachedblocks/otherallocations.
This is source/geometryinference, not measuredactivehost-reservationtelemetry.
Do not claim equalphysicalmemory. Frozenquality/timing continueunchanged.
Artifact: results/baseline_fidelity/snap_tier_owned_envelope_20261002/allocator_capacity_note.json.


Shared-ceiling independent quality gate (2 October2026) completed:
100new normalized unused documents/five tasks/200arms, all source/data/seed/
exclusion/sampling/prompt/nativecap/EOS/counters/geometry verified. CPUactualquery
991hot/1090cold/32quota/directshared minusfaithfulSnap task-balanced−2.56985,
paired95CI[−5.293844,−0.507108], bootstrap10000/seed20261005. NI−.5 and
superiorityfail; 33regressions/10losses>10. TaskmeansQasper−1.7946/Multi−5.1511/
Hotpot−2.0519/Trivia−5.0/Gov+1.1482. All resource-boundary guards pass for
liveKV tensor-storage; activeallocatorroundingexcluded (inferred763.75 MiB
rootcapacity+GPUKV, not512 MiB physicalparity). ThreeABBA systems comparison
alsofailed speedguards (2.766×slower). No advancement/defaultpromotion or
SOTAclaim. This is a result for these frozen capacities/one model/seed, not
all Tiered configurations. Do not tune inspected100documents. Standard
NarrativeQA exhausted; prior adapted-storyNI and broader P0/P1/P2stillopen.
Fullsuite128passes after optional experimentalmeasurefactory extension;
all ownedmodeljobs terminal, GPU0idle. Artifact:
results/baseline_fidelity/snap_tier_envelope_fresh_quality_20261002/verified_report.json.
Next: allocator-reservation efficiency and structural retention/eviction
costs on development inputs, preserve full-model gates.


Boundedpool milestone verified (2October2026): primary44.57%ownedhostroot
reduction andp95/TTFT/prefillguards pass,36nativecases/full1154slots,24free
generationpairs/6tasks,768delayedstreamobservations/48overlapflushes/4resets,
3interleavedrecycledrequests/51frames, CLIoutput/counts/score/payload/counters
match and3invalidflag combinations rejectbeforeload. Final143tests pass.
Opt-in--cpu-bounded-pool requires--cpu-direct-shared --cpu-batched-scores
--strategy lru, hot>=132; defaultsunchanged. Verified991/1090scope.
Before nextgeneralization no ownedGPUjoblive. Existingquality/speedfailures
remain; no globalpromotion/model GPU peak/physicalSTT/completion claim.
Evidence: results/hardware/bounded_pinned_pool_20261002/verified_stress_report.json.


Bounded pool CLI use (2 October 2026): add `--cpu-bounded-pool` to
`--strategy lru --real-query-prefill --cpu-batched-scores --cpu-direct-shared`.
The new policy preserves logical hot/cold capacities and the complete original
placement, promotion, score update, demotion and reclaim path. Physical slots
reserve `cold + promotion_budget + max_decode_append`, with the CLI's
32-token append bound. The old direct pool remains available without this
flag. Unsafe append or promotion geometry rejects before decode mutation.
The host-memory benefit depends on allocator rounding: do not generalize the
991/1090 result to every capacity. See the frozen default-geometry audit.


Defaultgeometry boundedpool result (2October2026) independentlyverified:
1024/2048 unchangedlogicalcapacities, root402784256→276824064bytes (31.27%
requestedreduction), sampledRSS2129731584→2128539648(~1.19 MB difference).
Bothrootactivecapacitiesinfer512 MiB frominstalledallocator; GPUpeakunchanged
18627830784bytes. Exact4K8K16K31500cacheboundarystate+50teacherfreshprocess
outputs/counters/payload;4nativefullfill/inclusioncases reach2112transient
slots and33appendrejectedbeforemutation. ThreeABBA16K50median75.2151→
75.1726ms, p9584.6353→84.1376ms, TTFT2302.8145→2296.769ms, prefillpeak
same18.627831296 GB. Regressionguardspass; no5%speedgain or substantial
RSS/backingallocation gain. Special991/1090memorybenefit notgeneralized.
Defaultgeometry freegeneration/interleaved notyetverified; retainopt-in.
No defaultpromotion/qualitywin/physicalSTT/broadP0/P1/P2completion.
Artifact: results/hardware/bounded_pool_default_geometry_20261002/verified_report.json.
AllownedGPUjobs terminal; fullsuite143passes fromintegration, onlyexperimental
nativechecker optionalgeometryflag addedsince; no modelalgorithmchanges.


50stepNVTX/CUDAtrace (2October2026) disprovescoldoverflowhypothesis: all
32layers end1616/2048coldrows, nosaturation anyboundary. Trace142645kernel
launches,37037cudaMemcpyAsync,25837cudaStreamSynchronize. Innermosthost
range attribution: hotselection17600kernels/36800APIcalls; remainingevict
24768kernels/47040APIcalls; visible8176kernels/19826APIcalls. Evictexcluding
hotselection hostAPI4.447ms/step/devicekernels1.385ms, overlappingdiagnostic
notadditive. CProfile/NVTX/CUPTI perturbations; nofull-loop speedclaim.
Nextcandidate screenhotstatecompaction usingoneGPUintindex reusedacross
KV/cum/age replacingrepeatedCPUbooladvancedindexing. Currentpurebool path
wasalreadybetterthanPythonlist indexing; this isdistinctindex_select stage.
Require entiremask/keepindices/CPUpositionbuild/GPUindexupload/gathers
charged, exactstate,≥4ms saving andp95≤2%; no backendeditbeforepasses.
Evidence: results/hardware/full_decode_trace_20261002/verified_trace_analysis.json.


Sharedhotindex screen outcome2October2026: charged full32layer hotcompaction
control6.52006→candidate4.38838ms, saving2.13168ms<4msminimum. All12edge
checks and primary/ABBApostarmKV/metadata/positions bit-equal, all3blocks
better/p956.75623→4.60991, but REJECT modeladvancement. No backend/core edit.
CandidateisoneGPUintkeepindex reusedbyK/V/cum/age, CPUgrace+position list;
notcurrentCPUlist/booleanvariant. Cannotaddthisisolatedsaving toprior
hotselection savings orcallitfullloop speedgain. ExactarchivedproductionAST
and allrawtimings/hash independentlyverified. Verifier firstfailedabsolute
__file__key vsrelativearchive name; normalizedrepo paths, before/errorretained.
Raw/source unchanged. Diagnosticrunner compiles; no newproductiontestsneeded.
Artifact: results/hardware/shared_hot_index_screen_20261002/verified_report.json.
Nsight50trace falsifiescoldoverflowexplanation, instead manytinyAPIlaunches/
metadata/visibility operations. Profiler times perturb andoverlap. Future
architecturalstage should combine complete update/materialization with
chargedcausalproof; no defaultpromotion or tuningoftestedqualityholdouts.
AllownedGPUjobs terminal; broadP0/P1/P2 stillopen.


### 2026-10-02 — Pooled-head maximum fails broader development gate

Independent verification confirms all 12 previous bounded-CPU control outputs,
IDs, states, trajectories, counters, task-native caps/EOS and transfer payloads.
Source archives, JSON-key comparison repair, dataset/sample/prompt hashes and
recomputed metrics pass. Candidate uses the unchanged global-token GQA layout.
Six-task task-balanced difference: −0.6012 points, paired within-task bootstrap
95% CI [−3.0922,1.8898], 10,000 draws/seed20261006. Two regressions; one loss
over 10 points (NarrativeQA −17.2727). The −.5 noninferiority screen and
individual-loss screen fail. This reused development set is not independent
quality evidence. Different initial importance also changes later cumulative
eviction scores; no pure prompt-retention causal isolation is claimed.

Three ABBA blocks, one warmup per arm, charge complete model SDPA prefill,
rotary-query capture and bounded CPU placement. At16K, median2.25558→2.25637s
(+.0351%); at31.5K, 5.06368→5.06438s (+.0139%). Peaks are identical within
length (18.62783/22.41822 GB), initial geometry and151257088-byte root request
match, and placements repeat within each arm. Prefill guards pass; no decode
or speed superiority claim. Quality failure rejects this frozen candidate
before unused evaluation documents. Defaults stay unchanged. Owned GPU0
process exited; last full suite153passed.

Evidence: `results/baseline_fidelity/head_max_retention_dev_20261002/` and
`results/baseline_fidelity/head_max_broader_dev_20261002/verified_report.json`.
Next: close the explicitly open usual-budget free-generation/interleaved
integrity checks; then screen a complete update/materialization architecture.


### 2026-10-02 — Usual-budget bounded pool free generation and isolation verified

At1024hot/2048cold, 12 direct-versus-bounded CPU free-generation pairs across
six tasks are exact in predictions, IDs, native caps/EOS, scores, state,
trajectories, counters, query shapes and submitted transfer payloads. Same
reused development documents, one greedy seed; occupied host data match.
Reserved roots differ402784256→276824064bytes as frozen. This establishes
storage preservation rather than independent quality superiority.

Three requests A4K12/B8K24/Cdistinct4K12 match isolated grouped-GPU and
old-CPU controls exactly at all51 complete boundary frames per mode. A is
reset/recycled into C while B remains live; all request roots reset cleanly.
Serialized Python/default model stream and fixed lengths ignore EOS in this
isolation test. No threaded/asynchronous serving, concurrency throughput,
saturation, physical STT or default-budget host-RSS gain is established.

Independent verifier checks executed source archive, dataset/sample/prompt/
input hashes, task metrics, caps/EOS, unchanged policy-class ASTs and all
per-boundary outputs. Generic experimental runner now reads frozen manifest
budgets and seed count. Its historical two-seed limitation string was fixed
for future runs after verification; raw/source are retained and exact
metadata-only text preservation is proved separately. No cache-policy or
default change. GPU0 owned jobs exited; last full suite153passed.

Evidence: `results/hardware/bounded_pool_default_stress_20261002/verified_report.json`
and `metadata_fix_report.json`. These explicitly close usual-budget
free-generation/interleaved integrity gaps, while broad P0/P1/P2 remain open.
Next: charged screen of complete update/materialization, then causal/actual
resource quality and wider systems gates. Estimate remains10–20workingdays,
contingent on hardware access and research outcomes.


### 2026-10-02 — Fused CPU coordinator/compaction integrated after all gates

The new opt-in combines the existing exact cross-layer eviction coordinator
with one CUDA gather of all hot BF16 keys/values and F32 score/age metadata.
CPU positions/grace compact immediately; GPU gathers complete before the
visible cache is materialized. Cold overflow and unsupported geometry use
the original eager compaction. The complete original eviction AST is
preserved outside its compaction hook; token ranking and budgets are unchanged.

The first charged prototype saved only0.3663ms and was rejected. Diagnosis
measured0.5232ms for the kernel and identified per-index Python checks/list
conversion as CPU overhead. Vectorizing CPU preparation, with the shader and
binary unchanged, saved4.0310ms (6.5361→2.5051) in the complete-stage screen;
all3ABBAblocks/p95/13bitwise cases pass. Initial missing-Ninja failure and all
original sources/results/logs are retained.

Independent model verification: all13boundaries at4K8K16K31500 exact,32
synthetic cases with442fused/222eager paths exact. Three ABBA16K50teacher-step
blocks, one whole-request warmup per arm, same CPU backend/query capture/
observer/synchronization: median75.4689→66.4404ms (11.9632% faster), p95
85.0156→72.1715ms; TTFT2281.77→2292.29ms (+.461%); prefillpeak 18.627831296 GB
identical, decodepeak14.91440→14.91133 GB. Both coordinator and compaction are
measured together; do not attribute this whole gain to the kernel alone.

Mandatory native proof includes all65,536BF16bit patterns, F32 signed zero,
subnormal/infinity/quiet+signalingNaN payloads, full/strided/reordered+duplicate
keeps, and12delayed gather/allocator-pressure rounds using one producer/two
consumer streams with explicit event waits. All15checks pass. Twelve reused
free-generation document pairs across six tasks/one greedy seed/native caps
and EOS have identical predictions/IDs/scores/state/trajectory/counters/
transfers. Three serialized interleaved/recycled requests match isolated GPU
and old CPU controls at all51boundaries per mode; roots reset cleanly. These
are integrity/ownership checks, not asynchronous model serving/throughput proof.

Ordinary CLI: add `--cpu-fused-compaction` to
`--strategy lru --real-query-prefill --cpu-batched-scores --cpu-direct-shared`.
Requires hot>=132; combining with bounded pool is explicitly rejected until
verified. Cached loader checks shader/binary hashes and measured Torch2.5.1+
cu124/Python3.10 ABI, then imports the verified binary without Ninja or a
recompile. Gather/compaction AST and shader are unchanged; one Qasper CLI
control/candidate matches predictions, score35.8974, token counts, payloads
and counters, with768fused compactions. Five invalid combinations fail before
model loading. Final full suite154passed (one dependency deprecation warning).

Evidence: `results/hardware/fused_hot_compaction_screen_20261002/`,
`fused_eviction_model_20261002/`, `fused_eviction_stress_20261002/`, and
`fused_cli_integration_20261002/` under `results/hardware/`.

No normal-policy default, STT bandwidth, quality ranking or capacity changes.
This12%improvement is within one CPU surrogate configuration; the earlier
shared-ceiling quality/SnapKV failures remain authoritative and have not been
rerun with this backend. No model-wide memory-gain, physical STT/controller,
energy/endurance, second-model or serving superiority is established. Broad
P0/P1/P2 remain open. Next: verify bounded+fused combination and shared-ceiling
resource/speed accounting, then broader research gates. Remaining estimate
10–20workingdays, conditional on hardware access and research outcomes.


### Verified composition and transient ownership — 2 October 2026

**Implemented:** `experiments/fused_bounded_pool.py` composes the existing
bounded constructor/guards with fused cache eviction and policy visibility.
The cache factory reserves promotion budget plus32 appended rows. Cooperative
MRO runs bounded geometry checks before preparation or cache mutation.
The ordinary actual-query CPU CLI accepts both opt-in flags after native,
model, generation/isolation and CLI gates at1024/2048 and991/1090. Defaults,
ranking, shader and STT model are unchanged; full suite168passes.

**Observed:** requested roots fall31.3%/44.6%, but request bytes do not measure
allocator or RSS gain. The frozen shared-boundary diagnostic finds396 MiB owned
KV. At fused launch, raw visible128 MiB, old hot128 MiB, new output123.875 MiB,
queued writes4.125 MiB and root144.25 MiB coexist:528.25 MiB. Metadata and allocator
blocks are excluded, so this is a lower bound. A boundary ceiling cannot
establish a transient ceiling. The measured CPU path remains2.34× slower than
SnapKV (60.56/25.83ms/token); median/p95/all-block speed gates fail, TTFT passes.
No new quality superiority or physical-STT claim follows.

**Proposed:** inspect live ownership across the remaining visible assembly
and transfer stages before another memory/speed candidate. Integrity proof
and exact timings: [combined CLI](results/hardware/fused_bounded_pool_20261002/cli/verified_report.json),
[resource/speed diagnostic](results/baseline_fidelity/snap_fused_bounded_envelope_20261002/verified_report.json).


## Experimental raw-buffer reuse (2 October 2026)

**Implemented, research-only:** `reuse_visible_policy.py` replaces exactly the
two hot/cold visibility concatenations after AST checks. Supported groups
consume distinct contiguous BF16 raw decode buffers and write kept hot rows
into their prefixes; cold rows fill the following quota, preserving head
strides and BF16/F32 bits. Unsupported layout/aliases use the prior fused
path; full cold overflow keeps the existing eager behavior. The new native
writer uses the existing five-tensor pybind ABI, a six-pointer source/destination
table, explicit widths and current CUDA stream; all inputs/destinations record
that stream. The ordinary CLI now exposes `--cpu-reuse-visible` only alongside
`--cpu-fused-compaction --cpu-bounded-pool --cpu-direct-shared
--cpu-batched-scores --real-query-prefill --strategy lru`. Defaults are unchanged.

**Observed:** same known policy KV peak528.26→406.25 MiB (−23.1%), boundary
272.25 MiB, excluding other forward temporaries and allocator blocks. Four
context lengths/both geometries match; three ABBA model regression guards
pass with median +1.34%/+1.76%, while whole-request peak stays 18.6278 GB.
Stage saving0.26–0.34ms fails4ms speed gate. Fifteen new native delayedstream/
owner-release checks pass. Twenty-four free-generation pairs/six tasks,40saturation/boundary cases and
three recycled requests/all51frames per mode/both geometries pass. Ordinary
CLI sample parity and seven preload rejections pass; verified native binary
loads without Ninja. Latest full suite187passes. No new speed,
model-wide memory, retention-quality, physical-STT or SnapKV superiority claim.
See [resource proof](results/hardware/reuse_visible_model_20261002/verified_parity_resource.json),
[timing proof](results/hardware/reuse_visible_model_20261002/verified_timing.json),
[native checks](results/hardware/reuse_visible_integrity_20261002/native.json).

CLI evidence: [verified integration](results/hardware/reuse_visible_integrity_20261002/cli/verified_report.json).
Actual allocator/process memory remains open; known live KV excludes cached
blocks/workspaces, and the whole-request peak is unchanged.


## Public pinned-memory audit (2 October 2026)

**Observed:** CUDA's public `cuPointerGetAttribute` host allocation-range
queries read256 MiB behind the 144.25 MiB shared root and512 MiB behind the 264 MiB
usual root. Six live size/alias cases match an archived private HostBlock
reader; active code now uses stdlib `ctypes` and the public CUDA driver,
with no host-probe extension, Ninja or private layout. Four public-API fresh
processes match eight prior runs for state, IDs, counters and GPU peaks.
Final GPU allocation falls129.8/134.1 MB with reuse, but whole-request GPU
allocation peak stays 18.627830784 GB, reserved peak 20.600324096 GB; sampled RSS
shows no substantial gain. Adding the shared host range's111.75 MiB excess to
the SAME prior weak-storage KV trace gives **518.0039 MiB**, already above
512 MiB. This remains a lower bound excluding other cached blocks, OS page
rounding, GPU workspaces and driver allocation; actual resource equality is
not established.

Two weak StorageImpl runs confirm a 1000 MiB BF16[1,16384,32000] prefill-logit
storage survives through the first decode forward in the fresh-memory driver,
then expires before the second. Observers keep no payload owners and preserve
state/IDs/counters/peaks. The legacy timing profile scopes prefill output in a
function, so its decode peak is not interchangeable with this harness's
15.826/15.834 GB peak. No model argument or default changed.

Next: test a root allocation with less excess capacity, then workspace/lifetime
and broader research gates. A last-logit-only prefill option must prove exact
outputs/state before any adoption; it is only a prospective experiment.
Evidence: [public memory audit](results/hardware/actual_reuse_memory_20261002/public/verified_report.json),
[weak logits audit](results/hardware/actual_reuse_memory_20261002/logits/verified_report.json).

## Exact channel-reader component — 3 October 2026

The research native kernel copies one pinned-pool channel on the current CUDA
stream. It reads all cold keys for the existing query/rotary/F32 score/top-k
math, and only32 chosen values per layer. Native raw-bit BF16/FP16/F32 proofs,
36 metadata guards, serial stream handoff, alternating pools and root cleanup
pass. GPU4K12 compares12 predictions,13 logit/cache/counter frames and384 visible
selections; canonical hot K/V and visible destination identity/offset/strides
are preserved. CPU suite328 passes, including22 focused tests.

Fresh16K50 copied K/V H2D falls5,825,961,984→3,173,392,384 bytes (45.53%);
D2H115,855,360 bytes and separately charged indexH2D75,333,120 bytes are unchanged.
H2D calls1701→3301. Key rows1,346,400 plus51,200 selected-value rows account for
all channel payload; common nonquery K/V is311,107,584 bytes. Active545.17MiB,
roundedhost256MiB, whole reserved5089.49MiB and prefill18.62783GB remain unchanged.

Frozen quiet3ABBA component median97.4781→93.0196ms (4.5738%,4.4585ms saved),
p95100.4879→95.8951ms, TTFT2214.127→2215.261ms. Predictions, final state/counters
and per-arm transfers replay300 measured forwards per arm.25 before/after GPU0
PID checks pass. The >=5% primary fails although saved-ms/p95/TTFT guards pass.
Stop standalone expansion/adoption before ordinaryLRU/quality gates; preserve
all evidence. Initial native build failure (Ninja PATH), accepted existing
CUDA12.4 toolchain and inherited stdout scope correction remain separate.
Copied payload excludes library transfers and physicalSTT/PCIe reads. No
physical hardware, independentquality, complete512MiB or jointwin claim.
See [evidence](results/hardware/query_channel_reads_v1/README.md) and
[figure](results/hardware/query_channel_reads_v1/channel_tradeoff.pdf).
