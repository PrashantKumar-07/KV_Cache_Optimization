# Controlled improvement protocol

Use this gate for every TieredKV change. It prevents uncontrolled fixes from changing quality, latency, and memory without a causal result.

## 1. Freeze and preregister

Before implementation, append to `EXPERIMENT_LOG.md`: ID and timestamp; one hypothesis/mechanism; frozen control artifact; revision; model/data/sample IDs/seed; hardware; precision/capacities; primary metric; and regression guards. Default control is `results/remediation_v3/` until a newer candidate passes every gate. Rerun both arms in one harness when code or dependencies differ.

## 2. Default progression criteria

- **Quality:** paired task-balanced 95% bootstrap lower bound above 0. For systems-only work, predeclare non-inferiority (default -0.5 points) and require the lower bound above it.
- **Latency:** ≥5% lower median full-loop TPOT and p95 no more than 2% worse; same fixed decode, ABBA order, at least three measured blocks after warm-up.
- **Memory:** ≥10% lower measured peak allocation, quality non-inferiority, and TTFT regression below a predeclared limit (default 10%).
- **Writes/energy:** ≥20% fewer paid bytes/events without quality loss. Publish energy only with an explicit measured or modeled boundary.

An improvement that violates a guard is a trade-off point, not the new default.

## 3. Implement and validate

Make the smallest isolated change and add one focused test for nontrivial logic. Run relevant tests, then the full suite. Record exact commands, hashes, raw artifacts, errors, uncertainty, and outcome. Never overwrite raw evidence. Start with a cheap falsification pilot; advance only if its direction meets the preregistered criterion. Do not tune on final test samples.

## 4. Mandatory stress gate after a significant gain

1. Boundaries: empty/one token, exactly at capacity, one over, short, 16K, and maximum context.
2. Retrieval: needle positions, repeated distractors, similar keys, rare answer spans, and requests for dropped content.
3. Distribution: held-out samples, retrieval/QA/summarization, second seed, and second model when supported.
4. Systems: p50/p95, allocator peak, slow-tier saturation, migration bursts, long decode, and concurrency when supported.
5. Integrity: K/V alignment, positions, shadows, capacities, duplicate exclusion, determinism, and cleanup.

Fix correctness faults before advancement. Unfixed research limitations constrain the claim; they are documented rather than hidden.

## 5. Decide and pivot

- **Promote:** primary metric and every guard pass; stress result is reproducible.
- **Trade-off:** useful Pareto point but a guard fails; keep opt-in.
- **Reject:** primary criterion fails or a defect invalidates comparison; log why.
- **Inconclusive:** interval crosses threshold; do not promote and estimate needed evidence.

Current candidate order: bounded prefill; batched/page-level execution; serving-compatible page attention; faithful broader baselines; physical-tier validation. Low-bit work is paused because FP8 halved cold bytes without improving prefill peak or proving quality/latency benefit.

## 6. Hyperparameters

Tune only after a core mechanism passes on development data. Declare a small space; use random/Bayesian search for interacting parameters and grid search for one or two. Keep held-out data untouched. If tuning fails, revert to the stable untuned core and log the failed space.

## Entry template

```text
ID / timestamp:
Hypothesis and one changed mechanism:
Frozen control / revision:
Data, model, hardware, config:
Primary threshold / regression guards:
Pilot and full commands/artifacts:
Result with uncertainty:
Stress-gate result:
Decision: promote | trade-off | reject | inconclusive
Failure analysis / next candidate:
```

