"""Reproducible runtime identity and crash-safe experiment checkpoints."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def read_jsonl(path):
    """Read physical JSONL records; Unicode separators inside strings are data."""
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def runtime_identity():
    files = sorted((ROOT / "src").glob("*.py")) + [
        ROOT / "experiments" / name for name in
        ("longbench_eval.py", "longbench_metrics.py", "latency_profile.py",
         "ppl_eval.py", "provenance.py")]
    digest = hashlib.sha256()
    for path in files:
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    try:
        revision = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except (OSError, subprocess.CalledProcessError):
        revision = "unknown"
    packages = {}
    for name in ("torch", "transformers", "datasets", "numpy", "accelerate",
                 "huggingface_hub", "rouge"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = "not installed"
    return {"git_revision": revision, "source_sha256": digest.hexdigest(),
            "packages": packages}


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", dir=path.parent,
                                         delete=False) as stream:
            temporary = stream.name
            json.dump(data, stream, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def resume_results(path, config):
    if not Path(path).exists():
        return {}
    data = json.loads(Path(path).read_text())
    if data.get("config") != config:
        raise ValueError(f"Configuration/runtime mismatch in {path}; use a new output path")
    return data["results"]
