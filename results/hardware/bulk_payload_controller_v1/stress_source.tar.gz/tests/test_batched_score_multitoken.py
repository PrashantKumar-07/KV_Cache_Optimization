"""Real multi-query score shapes must preserve ordinary fallback semantics."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'experiments'))
import pytest
import torch
from batched_score_policy import batched_update
from longbench_eval import TieredKVPolicy
from probe_batched_score_updates import fixture,assert_equal
@pytest.mark.parametrize('queries',[2,32])
def test_multi_token_attention_uses_ordinary_score_fallback(queries):
 generator=torch.Generator().manual_seed(7)
 weights=[torch.rand(1,2,queries,40+2+queries,generator=generator) for _ in range(4)]
 initial=torch.rand(4,40,generator=generator)
 ordinary,batched=(fixture(weights,initial,2) for _ in range(2))
 TieredKVPolicy.update_scores(ordinary,[(None,None)]*4,weights)
 batched_update(batched,[(None,None)]*4,weights)
 assert_equal(ordinary,batched)
 for i in range(4):assert torch.equal(batched.layer_caches[i].sram_cum,initial[i])
 assert batched._stt_attn==batched._stt_attn_idx=={}
