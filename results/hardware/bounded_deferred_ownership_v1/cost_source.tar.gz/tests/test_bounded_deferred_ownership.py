"""Physical pitch, bitwise two-pass ownership and fail-before-mutation checks."""
from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np
import pytest
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'experiments'))
import bounded_deferred_ownership as module

def state(offset=0):
    key=(torch.arange(2*20*4,dtype=torch.int16)+offset).reshape(1,2,20,4).view(torch.bfloat16).clone()
    value=(torch.arange(2*20*4,dtype=torch.int16)+offset+1000).reshape(1,2,20,4).view(torch.bfloat16).clone()
    return SimpleNamespace(_hot_buffer=(key[:,:,:16],value[:,:,:16]),sram_k=key[0,:,:14],sram_v=value[0,:,:14],sram_cum=torch.arange(14).float(),sram_age=torch.arange(14).float()/2,pending_keep=np.array([0,2,3,6,7,9,13],dtype=np.int32),batched_deferred_compactions=0)

def emulate(states,destinations):
    for s,(k,v) in zip(states,destinations):
        index=torch.as_tensor(s.pending_keep,dtype=torch.long);rows=len(index)
        old=[x.index_select(1,index).clone() for x in (s.sram_k,s.sram_v)]
        cum=s.sram_cum[index].clone();age=s.sram_age[index].clone()
        k[0,:,:rows].copy_(old[0]);v[0,:,:rows].copy_(old[1])
        s.sram_k,s.sram_v=k[0,:,:rows],v[0,:,:rows];s.sram_cum,s.sram_age=cum,age

@pytest.mark.parametrize('count',[1,3,8])
def test_two_pass_preserves_bits_metadata_stride_and_original_roots(monkeypatch,count):
    states=[state(i*2000) for i in range(count)];expected=[];roots=[]
    for s in states:
        index=torch.as_tensor(s.pending_keep,dtype=torch.long)
        expected.append([s.sram_k.index_select(1,index).clone(),s.sram_v.index_select(1,index).clone(),s.sram_cum[index].clone(),s.sram_age[index].clone()])
        roots.append([t.untyped_storage()._cdata for t in s._hot_buffer])
    calls=[]
    def checked(proxies,pairs):
        calls.append(True)
        if len(calls)==1:assert all(p.sram_k.shape[1]==20 for p in proxies)
        emulate(proxies,pairs)
    monkeypatch.setattr(module,'gather_into',checked)
    size=module.bounded_gather(states);assert size==2*count*2*7*4*2 and len(calls)==2
    for s,values,owners in zip(states,expected,roots):
        for current,value in zip([s.sram_k,s.sram_v,s.sram_cum,s.sram_age],values):assert torch.equal(current.contiguous().view(torch.uint8),value.contiguous().view(torch.uint8))
        assert [t.untyped_storage()._cdata for t in [s.sram_k,s.sram_v]]==owners
        assert s.sram_k.stride()==s._hot_buffer[0].stride()[1:]
        assert s.pending_keep is None and s.batched_deferred_compactions==1

@pytest.mark.parametrize('fault',['bounds','negative','dtype','metadata','key_alias','copied','offset','short','grad','ragged','duplicate','too_many'])
def test_bad_contract_stops_before_native_or_owner_mutation(monkeypatch,fault):
    states=[state(),state(2000)];s=states[1]
    if fault=='bounds':s.pending_keep[0]=14
    elif fault=='negative':s.pending_keep[0]=-1
    elif fault=='dtype':s.sram_k=s.sram_k.float()
    elif fault=='metadata':s.sram_cum=s.sram_cum[:-1]
    elif fault=='key_alias':s._hot_buffer=(s._hot_buffer[0],s._hot_buffer[0]);s.sram_v=s.sram_k
    elif fault=='copied':s.sram_k=s.sram_k.clone()
    elif fault=='offset':s._hot_buffer=tuple(t[:,:,:,1:] for t in s._hot_buffer)
    elif fault=='short':s._hot_buffer=tuple(t[:,:,:10] for t in s._hot_buffer)
    elif fault=='grad':s.sram_k.requires_grad_(True)
    elif fault=='ragged':s.pending_keep=s.pending_keep[:-1]
    elif fault=='duplicate':states=[states[0],states[0]]
    elif fault=='too_many':states=[state(i*1000) for i in range(9)]
    called=[];monkeypatch.setattr(module,'gather_into',lambda *args:called.append(True))
    with pytest.raises(ValueError):module.bounded_gather(states)
    assert not called and states[0].pending_keep is not None

def test_cold_overflow_uses_original_immediate_fallback(monkeypatch):
    s=module.DeferredOwnershipCache.__new__(module.DeferredOwnershipCache);s.__dict__.update(vars(state()));s.stt_pos=list(range(11));s.cfg=SimpleNamespace(sttram_capacity=10);calls=[]
    monkeypatch.setattr(module.SharedTransitionCache,'_compact_or_queue',lambda self,victims:calls.append(victims))
    module.DeferredOwnershipCache._compact_or_queue(s,[2]);assert calls==[[2]]
