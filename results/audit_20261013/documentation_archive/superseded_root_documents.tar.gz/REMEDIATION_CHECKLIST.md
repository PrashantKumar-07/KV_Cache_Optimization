# Review remediation checklist

**Current checkpoint — early shared prefill (3 October):** 501 tests pass. Tiny GPU full-logit/KV parity and partial-failure cleanup pass; full-model4K/12 and16K/50 preserve predictions, state, counters and native transfers with all32 early roots and no fallback. Whole-prefill peak falls11.22% to16.5376GB; strict decode GPU active falls5.47%, scoped active including owned pinned/CPU is378.60MiB. Faithful Snap prefill ratio0.9840 passes. [Resource proof](results/hardware/early_shared_cpu_phase_v1/verified_resources.json). Initial resident KV matches341MiB at hot649/cold1982; candidate remains341MiB while Snap grows341–366MiB. Full-trajectory equality remains unresolved. Faithful-baseline quiet3ABBA timing **fails**: CPU54.59 vs Snap25.25ms/token (2.162x), p95CPU59.94 vs Snap25.47ms. TTFT+7.73% and prefill guards pass; median and p95 fail. All300 measured forwards/arm reproduce frozen predictions/state; CPU counters/native transfers and25 quiet observations pass. [Timing proof](results/hardware/early_shared_cpu_phase_v1/verified_cost.json), [figures](results/hardware/early_shared_cpu_phase_v1/figures/manifest.json). Candidate expansion/adoption stops under the preregistered gate; no favorable retry or final-holdout tuning. All owned jobs are terminal. Physical controller measurements, independent quality, generality and final delivery remain open. Repeated10–20day estimate withdrawn; full goal incomplete.

**CPU phase boundary and score-fallback checkpoint (3 October):** **498 tests pass**. Two reproduced regressions exposed a shared batched-score crash on multi-token attention. A single-query shape guard restores the ordinary scorer fallback. Real GPU appends of2/32 tokens preserve exact logits, KV data, metadata and slot order across7 boundaries, then return to native single-token phases. Transformers-owned lazy capture hooks are initialized before ownership checks; both failed harness attempts are preserved. [Fallback proof](results/hardware/cpu_phase_append_fallback_v1/verified_fallback.json).

Three full-model4K/50 checks preserve all predictions/state/counters/native KV: exclusive promotion24832 rows, floor-above-capacity protection, and50 write-aware fallback steps. Native cold reclaim executes1152 times. [Boundary proof](results/hardware/cpu_phase_boundaries_v1/verified_boundaries.json). Fresh current-source4K/12 parity also passes; current-source16K/50 resource and geometry proofs pass, scoped memory433.33 MiB. Fresh current-source3ABBA speed passes: **58.76 to54.12 ms median,7.89% gain/4.64 ms saved**, p95 improves8.87%, TTFT+1.37%. All300 measured predictions/arm, state/counters/native KV and25 quiet observations match. All owned jobs are terminal. The multi-query guard preserves existing ordinary scoring fallback; it does not redesign multi-query attention accumulation. [Current proof](results/hardware/cpu_phase_score_guard_v1/verified_status.json), [figures](results/hardware/cpu_phase_score_guard_v1/figures/manifest.json). Historical speed evidence below remains tied to its archived source.

The ownership audit confirms resident KV roots272.25 MiB constant across51 candidate boundaries versus faithful SnapKV487–512 MiB, growing0.5 MiB/step. Attention width1024 differs on49/50 steps. No fixed SnapKV prompt capacity can equal that constant allocation vector throughout decode. This is an unresolved comparison-design requirement, not permission to claim equality or pad allocations. [Geometry proof](results/hardware/cpu_phase_geometry_v1/verified_geometry.json). Full P0/P1/P2 remains open; no new day estimate.

**CPU phase controller integration (3 October):** **496 tests pass**, including seven integration checks. Native canonical CPU promotion, append and demotion are integrated with pooled GPU metadata and native KV transfers. Recorded 4K/12 matches all predictions, 13 state/visibility snapshots, counters and native KV traffic. All 384 layer transitions use the new CPU phases, with zero fallback. [Correctness proof](results/hardware/cpu_phase_controller_v1/verified_correctness.json).

Fresh 16K/50 matches frozen output/state/counters/native KV and passes scoped memory: **433.33 MiB including owned pinned and CPU array roots**, versus ordinary541.08 MiB. Prefill peak is unchanged. Quiet preregistered3ABBA speed gate **passes: 58.93 to54.09 ms median (8.22%,4.84 ms saved)**, p95 improves8.76%, TTFT+1.40%. All300 measured predictions/arm and frozen state/counters/native KV match;25 GPU quiet observations pass. Longer-context8K/31.5K teacher parity and forced cold256-row slot-recycling parity pass, each50 steps with native CPU phases and no fallback. Free-generation parity passes on all12 reused development documents across six tasks: exact tokens, scores, state, trajectory, counters and native KV. **597 native CPU phase steps/19104 layer transitions** execute with no fallback;174 additional native cold reclaims occur. All owned jobs are terminal. Joint faithful-baseline/quality gates remain open. Candidate remains research-only. Production defaults are unchanged. Full P0/P1/P2 remains incomplete; the unsupported day estimate is withdrawn. This checkpoint supersedes earlier statements that controller integration is unimplemented.

**Native CPU state phase checkpoint (3 October):** **489 tests pass**, including
30 focused phase checks. Fixed shared CPU owners hold hot/cold positions,
grace, shadow/resident flags, streaks and logical/free slot order. Native batch
operations perform promotion, hot append, complete demotion metadata updates
and cold compaction/reclaim. All malformed batch inputs reject before any
layer mutates; version and owner checks reject stale/foreign GPU commands.

All **1600 recorded layer transitions** replay exactly in50 native batches,
including2560 paid rows,23872 restored backups, F32 metadata commands and
physical slot order. Five GPU handoff fixtures across20 layers match original
cache payload/metadata bits, roots and padding: shadow-first reclaim, stable
LRU overflow, live-floor cover, exclusive promotion and eight-layer compaction.
Victim/cold-keep decisions are supplied; these fixtures do not independently
prove retention selection. GPU slot tensors emulate storage, not native host
transfers. Declared32-layer CPU owners are **1116896 bytes (1.065 MiB)**;
container/output/Python workspace and whole-model peaks remain unmeasured.

[Phase proof](results/hardware/cpu_state_transition_v1/verified_stage.json).
**Decode-controller integration remains incomplete.** Next attach canonical
CPU owners and consume these commands through promotion, demotion, native KV
transfers, visibility and cold reclaim, preserving unsupported fallback; then
run recorded model parity, actual resource and preregistered speed gates.
No speed/quality/adoption claim is established. All owned jobs are terminal;
production defaults and failed-candidate stops remain unchanged. Full P0/P1/P2
remains incomplete; day estimate withdrawn.

**CPU transition diagnostic and corpus (3 October):** Both fresh policy
profiles preserve all50 frozen predictions, final state, counters and native KV.
The0.836-second first extension load is already excluded by benchmark warmup;
it does not reverse the pooled controller's failed speed decision. Native
backup classification costs3.009 inclusive instrumented ms/step across1600
calls. Isolated backup batching is not justified as a4ms whole-loop fix.
Broader CPU state-transition work is the next mechanism, not another wrapper.

A recorded ordinary GPU run freezes **1600 layer transitions**. Independent
CPU/F32/slot replay is exact:2560 paid rows,23872 restored backups and1600
queued compactions. Positions, flags/streaks, metadata bits, logical/free slots
and outcomes match. The native backup classifier matches every record. This
corpus supports CPU-stage validation without repeated model launches per edit.
Cold occupancy reaches897/1090; no overflow occurs. Saturation/reclaim and
broader malformed/ragged/nonfinite fixtures remain mandatory.

[Diagnostic](results/hardware/pooled_controller_diagnostic_v1/verified_diagnostic.json),
[corpus](results/hardware/controller_transition_corpus_v1/verified_corpus.json),
[next phase plan](results/hardware/cpu_state_transition_v1/plan.json).
**Full CPU state-transition redesign is not implemented yet.** Existing459
unit tests remain passing; this checkpoint adds executable replay evidence,
not a speed/quality/adoption claim. All owned jobs are terminal; wrappers,
hooks and pinned roots release. Production defaults and failed-candidate
stops remain unchanged. Full P0/P1/P2 remains incomplete; day estimate withdrawn.

**Pooled controller integration checkpoint (3 October):** **459 tests pass**.
The research controller now uses fixed GPU metadata owners, fused age/tail
preparation and bounded KV/F32 compaction. Recorded 4K/12 preserves all
predictions, 13 visibility/state frames, counters and native KV traffic;
12 pooled preparations and 48 compaction groups execute with no fallback.
Fresh 16K/50 also matches frozen predictions/state/counters/native KV.
Scoped active memory is **432.10 MiB** versus ordinary541.08 MiB (20.14% less);
with conservative CPU array roots it is432.27 MiB, below512 MiB. The417792-byte
GPU arena and descriptor work are charged by GPU peaks. Pooled descriptors
upload6457600 logical bytes per50-step trial, separately from KV traffic and
5555328 timestamp-rank descriptor bytes. Prefill peak is unchanged.

[Correctness proof](results/hardware/pooled_controller_v1/verified_correctness.json),
[resource proof](results/hardware/pooled_controller_v1/verified_resource.json).
Quiet3ABBA is complete: median **58.06 to61.54 ms (6.00% slower,3.48 ms
added)**. Both speed primaries fail; p95 +0.67% and TTFT +0.87% pass. All300
measured forwards per arm replay frozen predictions/state/counters/native KV;
all25 quietGPU0 observations pass. **Stop pooled controller expansion/adoption.**
No favorable timing retry or wider quality/baseline expansion for this candidate.
[Timing decision](results/hardware/pooled_controller_v1/verified_cost.json).
All owned jobs are terminal and hooks/leases/pinned roots release. Production
defaults are unchanged. Full P0/P1/P2 remains incomplete; day estimate is
withdrawn. Primitive proof remains historical component evidence, not full
model proof. Two failed startup attempts are retained, including the corrected
generated-helper name collision; neither measured candidate timing.

**Native controller prototype (3 October):** **437 tests pass**, including
36 focused native core/integration checks. A native CPU module, built with
existing Torch headers and system g++, computes cross-layer promotion plans,
hysteresis/live-floor transitions, backup classification and read addresses.
The research policy also groups timestamp ranking by identical live length,
using the verified fused gather and original unstable CUDA argsort. Grouped
sorting matches separate GPU sorting in 44 fixtures, including ties/nonfinite
values. No process-global patch, retention change or new dependency is used.

The recorded 4K/12-step GPU pair preserves all predictions, 13 cache/visibility
frames, counters and native KV transfers. There are 12 native plans, 384 backup
classifications, 25 address calculations and no planning fallback. Fresh
16K/50 matches all predictions, final state, counters and native KV traffic.
Scoped active memory is **432.12 MiB** versus ordinary 541.08 MiB (20.14% less),
passing the 512 MiB ceiling; with conservative CPU array roots it is432.29 MiB.
Prefill peak is unchanged; C++/Python allocator internals remain unmeasured.
Timestamp rank descriptors upload **5.555 MB** per measured trial; bounded
ownership descriptors derive12.864 MB. These are separate from native KV and
are charged by timing/GPU peaks. Quiet3ABBA is complete: median **57.92 to 62.80 ms (8.43% slower, 4.88 ms
added)**; p95 **64.38 to 66.79 ms (3.74% worse)**. TTFT +0.25% passes. All
300 measured forwards per arm replay frozen predictions, final state, counters
and native KV traffic; all25 quietGPU0 observations pass. **Stop native
controller expansion/adoption:** both speed primaries and p95 fail. No favorable
timing retry or wider quality/baseline expansion for this implementation.
[Timing decision](results/hardware/native_controller_v1/verified_cost.json).
All owned jobs are terminal; hooks, leases, methods and pinned roots release.

The native core proves promotion, backup and address calculations, not the full
controller gate. Promotion/address/ranking are grouped; backup classification
still enters native code once per layer. Complete transition pooling remains
unimplemented. Combining wrappers around the existing layer state has failed
the joint gate; the next mechanism must redesign the complete hot/cold state
layout and account for retention/quality, rather than expand these wrappers. Descriptor uploads and CPU arrays
must be reported separately from native KV transfers. Failed ownership-only
candidates remain stopped; production defaults are unchanged. Full P0/P1/P2
remains incomplete; the unsupported day estimate stays withdrawn.

**Bounded deferred ownership checkpoint (3 October):** **401 tests pass**,
including 16 focused checks. A distinct research transition defers compaction
when cold reclamation is unnecessary; overflow preserves immediate compaction.
Two passes of the existing verified native kernel gather to separate scratch
and copy back safely. Groups contain at most eight layers. GPU 4K/12 matches
all 12 predictions, 13 cache/visibility frames, counters and native KV traffic.
There are 384 deferred compactions in 48 groups, no immediate compactions or
append fallbacks, and scratch is bounded at **30.97 MiB**. Fresh 16K/50 exactly replays frozen predictions, final state, counters and
transfers. Scoped active memory is **432.12 MiB**, **20.14% lower** than ordinary
541.08 MiB, passing both the 512 MiB ceiling and 10% reduction gate. Prefill
peak is unchanged. Quiet 3ABBA is complete: median **58.33 to 63.09 ms (8.15% slower)**,
p95 **64.77 to 70.88 ms (9.43% worse)**; TTFT +0.36% passes. All 300 measured
forwards per arm exactly replay predictions, state, counters and native KV
traffic; 25 quiet GPU0 process checks pass. **Stop bounded deferred ownership
expansion/adoption:** speed primaries and p95 fail. No favorable timing retry.
[Timing decision](results/hardware/bounded_deferred_ownership_v1/verified_cost.json).

Reporting correction: the copied timing verifier's zero extra metadata scalar
is false. The native wrapper uploads descriptors: fixed geometry/source derives
**12.864 MB and 1200 upload calls per measured candidate trial**. These are
separate from native KV manager bytes/calls; total extra versus ordinary was
not independently instrumented. Timing and memory charge the descriptor work.
The original artifact remains retained and the failed decision is unchanged.
[Correction](results/hardware/bounded_deferred_ownership_v1/verified_descriptor_reporting_v2.json).
All owned jobs are terminal; hooks, instance methods and pinned roots release. Failed predecessors remain
stopped. [Correctness](results/hardware/bounded_deferred_ownership_v1/verified_correctness.json).
Next target is broader controller consolidation; bounded grouping alone has
failed to deliver a joint win. Do not expand this failed implementation. Production defaults are
unchanged; full P0/P1/P2 remains incomplete and the day estimate is withdrawn.

**Current regression diagnostic (3 October):** fresh paired GPU0 policy profiles
preserve all 50 predictions, final state, counters and native transfers in each
arm. Shared ownership performs **1600 per-layer in-place gathers**; ordinary
bulk performs **50 batched native gathers**. Instrumented compaction is
6.76 ms/decode versus 3.12 ms for ordinary compaction preparation; ordinary
native gathering adds 0.75 ms in its visibility boundary. Shared reservation
and hot extension also add validation/copy work. These overlapping profile
ranges are localization evidence, not a causal savings estimate or timing gate.

The code trace establishes the ordering constraint: after demotion, cold
reclaim requires compacted hot positions and scores; it does not read compacted
hot KV. A distinct ownership implementation could defer payload gathering with
bounded, alias-safe scratch. However, the ordinary controller still spends
instrumented time in preparation (10.96 ms), eviction (11.75 ms) and visibility
(9.86 ms); these ranges overlap and cannot be added as savings. Nearly one
million calls per 50 steps remain. Removing this regression alone would not
prove the required speed win or close the faithful-baseline gap.
[Verified diagnostic](results/hardware/shared_transition_diagnostic_v1/verified_diagnostic.json).

Next target is broader controller consolidation, with a preregistered complete
mechanism and actual whole-loop/resource/quality gates. Do not repeat the failed
shared implementation or promote a profile as a benchmark. All owned jobs are
terminal; production defaults are unchanged. Full P0/P1/P2 remains incomplete;
the unsupported day estimate remains withdrawn.

**Shared ownership milestone (3 October):** **385 tests pass**, including 11 focused
unified-transition checks. The GPU 4K/12-step pair matches all predictions,
13 cache/visibility-state frames, counters and native KV traffic. Fresh 16K/50
matches the frozen ordinary predictions, final state, counters and transfers.
Unified model append, promotion and immediate compaction share consumed buffers.
Scoped active memory falls **541.08 to 415.16 MiB (23.27%)**, passing both the
512 MiB ceiling and 10% reduction gate. This includes the owned 256 MiB pinned
allocator block; it excludes constant model storage and unowned process memory.
Whole reserved envelope remains 5089.49 MiB; prefill peak remains 18.62783 GB.
[Resource proof](results/hardware/shared_decode_transition_v1/verified_resource.json).

The standalone append reservation was stopped at **531.00 MiB**, below neither
512 MiB nor a 10% reduction. Its failure is preserved separately.
[Standalone stop](results/hardware/reserved_decode_append_v1/verified_resource.json).
Quiet 3ABBA timing is complete: median decode **58.84 to 64.13 ms (8.98%
slower, 5.28 ms added)**; p95 **64.55 to 69.32 ms (7.38% worse)**. TTFT +0.78%
passes. All 300 measured forwards per arm replay predictions, final state,
counters and native KV transfers; 25 quiet GPU0 observations pass. **Stop
unified-transition expansion/adoption:** both speed primaries and the p95 guard
fail. No favorable timing retry or wider quality/baseline run for this failed
candidate. [Timing proof](results/hardware/shared_decode_transition_v1/verified_cost.json),
[measured tradeoff](results/hardware/shared_decode_transition_v1/ownership_tradeoff.pdf).
All owned jobs are terminal; leases, hooks and pinned roots release.

The memory obstacle is resolved only for this experimental design and measured
scope. The joint memory/latency/quality acceptance gate remains open. Next
localize the added cost of consumed-buffer compaction before proposing another
mechanism; do not widen this failed implementation. Independent quality, current
faithful baselines and physical hardware evidence remain open. Full P0/P1/P2
is incomplete; the unsupported 10–20-day forecast remains withdrawn.

**Current CPU timestamp decision (3 October):** **358 tests pass**, including
11 focused checks. Cold timestamp transitions move toCPU; oneGPU snapshot
pervisibility boundary preserves the originalGPU unstabletie sorting.
GPU4K12 matches12predictions,13cache/visibility-state frames, counters and
nativeKVbytes/calls; eightGPU tie-order cases pass. Native kernels, ranking,
retention, cache storage and ordinary source/CLI/defaults are unchanged.
[Correctness](results/hardware/cpu_lru_metadata_v1/verified_correctness.json).

Fresh16K50 replays all frozenpred/state/counters/nativeKVpayload/calls.
Extra timestamp H2D **5.692MB** / initialD2H **0.1046MB** are charged separately;
newCPU timestamp+temporarypacked tensor peak is229632bytes. Scoped active
memory becomes **541.19MiB** versus541.08MiB ordinary; reserved5089.71MiB and
prefill18.62783GB. This passes576MiB pilot, **fails512MiB**; CPUmallocrounding/
otherhostretention remains unmeasured.
[Resource proof](results/hardware/cpu_lru_metadata_v1/verified_resource.json).

Quiet3ABBA whole-loop median **57.85→57.34ms (0.88% faster,0.51ms saved)**;
p95 **64.46→61.51ms**, TTFT+0.09% pass. All300 measuredforwards/arm replay
pred/state/counters/nativeKVtraffic/calls and candidate timestampcopies;
25 before/after quietGPU0 checks pass. **Both >=5% and >=4ms primaries fail.
Stop standalone CPUtimestamp expansion/adoption**, with no favorabletiming
retry or widergeneration/quality/faithfulbaseline run for this candidate.
[Timing/stop proof](results/hardware/cpu_lru_metadata_v1/verified_cost.json),
[figure](results/hardware/cpu_lru_metadata_v1/timestamp_tradeoff.pdf).

All owned jobs are terminal; temporarymirrors and pinned roots release.
The failed projection/timestamp-only screens leave broader hot/cold transition
and ownership restructuring as the target; require a preregistered complete
mechanism with whole-loop/resources and eventualfaithfulbaseline/quality gates.
FullP0/P1/P2 remains open; the unsupported10–20-day forecast stays withdrawn.

**Current ordinary-backend screen (3 October):** **347 tests pass**, including
19 focused projectedscore/victim cases. The research coordinator prepares
victim score/age projections once across layers rather than creating temporary
CUDA tensors per layer. SixGPU cases preserve projection bits/victims for
ragged/nonfinite/grace inputs and1/4/32-token appends. Original ranking, stable
ties, protection, promotion, cache types and unsupported fallback stay intact.

Charged complete preparation+selection 3ABBA yields **3.419→2.686ms**,
only **0.733ms saved** against the >=4ms gate. Candidatep95 **5.831ms** versus
control3.502ms (**1.665×**) fails its guard; all three medians improve and
25 before/after quietGPU0 checks pass. **Stop this projection-only candidate**
before fullmodel/resource/timing/quality expansion. CPU/GPU stage equality
is not proof of fullmodel candidate preservation or a mainlatency-gate win.
Ordinary source/CLI/defaults are unchanged; all owned jobs are terminal.
[Verified screen](results/hardware/batched_eviction_projection_v1/verified_stage.json).

The screen localizes preparation's limits: the broader eviction/demotion,
layer-state transitions and synchronization remain the structural target.
Next preregister a complete state-transition mechanism; do not retry this
failed stage or widen failed fullquery candidates. FullP0/P1/P2 remains open;
the unsupported10–20-day forecast stays withdrawn.

**Current critical-path diagnostic:** the GPU0 ordinary-bulk16K/50-step
profile replays every frozen prediction, finalcache, logicalcounter and native
payload/call total. All owned jobs are terminal; hooks and pinned roots release.
About967,000 policy calls take1.920s under instrumentation. Eviction/demotion
is11.48ms/decode; read preparation11.10ms and visibility9.94ms are overlapping
cumulative ranges, not additive speed estimates. Native visible gathering is
0.76ms/decode. Next preregister cross-layer eviction/demotion bookkeeping
consolidation on the ordinary backend and require preserved state/selection/
transfers plus whole-loop/resource gates. Fullquery derivatives remain stopped.
[Verified critical path](results/hardware/completion_critical_path_v1/verified_audit.json).

**Completion plan correction (3 October):** the repeated **10–20 days** estimate
is withdrawn; it was not recalculated from the remaining gates. Earlier
estimates below are historical and must not be treated as a current forecast.
[Critical-path audit](results/hardware/completion_critical_path_v1/audit.json)
separates failed research gates from incomplete deliverables and external hardware.
The existing ordinary CPU backend is541.08MiB versus528.74MiB SnapKV; both
exceed512MiB and attention widths differ on49/50steps. A frozen older faithful
latency study is60.56 versus25.83ms (2.34×); its independent quality comparison
also fails NI. These studies do not prove current bulk quality or a joint win.
PhysicalSTT/controller energy/endurance remains unavailable and unproven.

Execution priority: profile the current ordinary bulk/lastlogits backend with
frozen50-step state/prediction/payload replay; address one structural bottleneck
that can close a main memory/latency gate. Keep failed fullquery derivatives
stopped. Then verify actual resources before expanding independentquality and
baselines; prepare reproducibility/manuscript artifacts alongside those gates.
No full completion date is supported until the research and hardware gates resolve.

**Current channel-reader decision (3 October):** **328 tests pass**. An exact
native reader scans existing cold keys and fetches only selected cold values;
query/ranking math is unchanged. GPU4K/12-step pairs replay all predictions,
13 logit/cache/counter frames,384 selections and both arms' destination/prefix
ownership. Native BF16/FP16/F32 and36 metadata guards, stream/pool/root cleanup
pass. [Correctness](results/hardware/query_channel_reads_v1/verified_correctness.json).

Fresh16K/50-step replay verifies **45.53% less copied K/V payload**
(**5.826→3.173GB**), unchanged D2H115.86MB and index copies75.33MB. NativeH2D
calls increase1701→3301. Active decode remains **545.17MiB**, above512MiB but
within the576MiB pilot; reserved5089.49MiB, prefill18.62783GB and roundedhost
256MiB are unchanged. This measures copied nativeKV payload, not all library
transfers or physicalPCIe/STT reads.
[Resource proof](results/hardware/query_channel_reads_v1/verified_resource.json).

Quiet3ABBA component comparison yields **97.48→93.02ms (4.57% faster,
4.46ms saved)**; p95100.49→95.90ms and TTFT+0.05% pass. All300 measured
forwards/arm replay frozenpred/state/counters and each arm's payload/calls;
25 quiet-process checks pass. **The >=5% primary fails. Stop standalone
channel-reader expansion/adoption.** No fresh ordinaryLRU or independentquality
expansion follows this failed gate; no favorable timing retry.
[Timing/stop proof](results/hardware/query_channel_reads_v1/verified_cost.json),
[figure](results/hardware/query_channel_reads_v1/channel_tradeoff.pdf).

Ordinary source/CLI/defaults are unchanged by this mechanism; all owned jobs
are terminal and own hooks/index metadata/pinned roots release. Full512MiB,
matched baselines, independentquality, physicalSTT and P0/P1/P2 remain open.
Next preregister a distinct mechanism targeting the remaining query-loop or
synchronization cost, then require correctness/resources/component/LRU gates.
Estimate **10–20 working days**, conditional on hardware/research outcomes.
Earlier checkpoints below are historical evidence, not current next actions.

**Current visible-buffer decision (3 October):** **306 tests pass**. The
research selector retains the existing visible hot prefix and writes only
selected cold rows. GPU4K/12-step pairs exactly replay predictions, all logit/
cache/counter frames,384 visible-K/V selections and transfer metadata;384
candidate destinations retain their identity, offset and strides. Canonical
hot K/V remain unchanged and own hooks/index metadata release.
[Correctness](results/hardware/query_visible_suffix_v1/verified_correctness.json).

Fresh16K/50-step resource replay passes the576MiB pilot at **545.17MiB**,
versus547.49MiB query concat. This still exceeds512MiB; reserved5089.49MiB,
prefill18.62783GB and roundedhost256MiB are unchanged. NativeKV H2D remains
5.826GB, plus75.33MB of separately charged index copies. Three omitted native
source files were added in a SHA-matched supplemental archive; original source
archive and verifier are preserved. [Resource proof](results/hardware/query_visible_suffix_v1/verified_resource_v2.json).

Quiet3ABBA component comparison passes: **105.32→97.05ms (7.85% faster,
8.27ms saved)**, p95108.21→99.88ms; TTFT+0.34% passes. Frozen states, predictions,
counters, native bytes/calls and metadata replay;25 quiet-process checks pass.
But fresh ordinaryLRU comparison fails: **57.87→97.56ms (1.686×)**,
p9564.51→100.59ms (1.559×); TTFT+0.46% passes. **Stop standalone suffix-query
expansion/adoption.** The component improvement remains research-only.
[Component proof](results/hardware/query_visible_suffix_v1/verified_cost.json),
[LRU stop decision](results/hardware/query_visible_suffix_v1/verified_lru.json),
[comparison figure](results/hardware/query_visible_suffix_v1/suffix_tradeoff.pdf).

Next preregister a distinct lower-traffic reader: keys for ranking, values only
for selected rows, preserving existing Q/ranking/selection math. Ordinary source/
CLI/defaults are unchanged; all four owned GPU jobs are terminal. Full512MiB,
actual matched baselines, independent quality, physicalSTT and P0/P1/P2 remain
open. Estimate **10–20 working days**, conditional on hardware/research outcomes.

**Current diagnostic decision (3 October):** **287 tests pass**. The saved
16K/50-step GPU-query diagnostic replays the frozen prediction/state/counter/
transfer assertions. A corrected summary verifies **eight CPU phases, 1,600
observations each**, excluding six duplicate GPU annotation spans. All owned
jobs are terminal and own hooks/index metadata are released.

Visible-K/V composition is the largest instrumented CPU range: **15.89 ms per
decode**, including launch/waiting/profiler overhead. This is localization,
not a speedup estimate. Chrome export did not run; native GPU-kernel attribution
is incomplete. Failed reports and source archives are preserved.
[Diagnostic evidence](results/hardware/query_phase_profile_v1/verified_summary.json).

Next: preregister visible-buffer reuse with cold-row-only updates, then prove
ownership/parity/resources before component and ordinary-LRU latency gates.
The standalone fullscan candidate stays stopped at **1.810× median / 1.679×
p95** despite its **24.61%** read-index component improvement. Full512MiB,
actual matched baselines, independent quality, physical STT and P0/P1/P2 remain
open. Estimate **10–20 working days**, conditional on hardware/research outcomes.

**Current status (3 October):** batchedGPU native read indices preserve
query behavior and pass **283tests**, native3dtype/stream/pool/cleanup and
547.488MiB/576pilot resource checks. Component3ABBA median improves24.61%,
but freshordinaryLRU guard fails1.810×median/1.679×p95. **Stop standalone
full-query expansion/adoption.** KVreads5.826GB plus75.33MBcandidate metadata
charged; no totalH2D saving claim. Next inspect fusedranking/lower-traffic
retrieval/GPU selected-row indices. Ordinary source/CLI/defaults unchanged;
full512MiB/actualmatching and P0/P1/P2 remain open. Estimate10–20 working days,
conditional on hardware/research. [Current evidence](PROJECT_STATUS.md).

**Verified actual-resource audit (3 October):** fresh full-model GPU runs
with the adopted last-prefill-logit option reproduce all 50 frozen predictions
for ordinary bulk TieredKV and faithful SnapKV. Direct observations cover
**3200 layer-forward widths**: TieredKV uses1024 rows throughout, while SnapKV
grows975–1024;49/50 steps differ. Measured decode GPU allocation excluding
constant model storage is285.08MiB for TieredKV plus256MiB owned pinned capacity,
versus528.74MiB GPU-only for SnapKV. Combined active envelopes are therefore
**541.08 / 528.74MiB**; both exceed512MiB. Combined reserved envelopes are
**5089.49 / 2881.49MiB**, and whole-prefill peaks **18.6278 / 16.9583GB**.
CPU state/counters/transfers/phase peaks exactly replay its frozen ordinary run;
adapter groups/hooks and all owned roots are released. Both GPU jobs finished.
**Actual bytes and widths are unequal: the matched-resource P0 gate remains open.**
This audit supplies no new timing or independent quality result; the frozen
older DirectCPU NI failure remains separate evidence. Ordinary source is
unchanged and262-test validation remains current. Next preregister a comparison
that controls actual allocation ceilings and observed attention geometry before
quality/latency reruns. Full P0/P1/P2 remains open. Estimate **10–20 working days**,
conditional on hardware access and research outcomes.
[Verified actual-resource comparison](results/hardware/snap_actual_envelope_v1/verified_report.json).
[Diagnostic figure](results/hardware/snap_actual_envelope_v1/resource_gap.pdf).

**Verified layerwise-prefill experiment (3 October):** placing future KV
one layer at a time, while returning full raw KV to current prefill attention,
reduces the measured whole-prefill peak **18.6278 → 16.7095 GB (10.30%)**.
Eight tiny real-Mistral pairs preserve full prefill/decode logits, cache/state
and counters; partial-error reset and hook cleanup pass. The full GPU control
replays frozen ordinary results, and the candidate preserves all 50 predictions,
state, counters and transfer bytes/calls. Both jobs finished and roots/hooks
released. The 10% memory primary passes, but GPU-only decode active allocation
excluding constant model storage increases **285.08 → 291.65 MiB (2.31%)**,
failing the 2% guard. Including the unchanged 256 MiB pinned host capacity gives
**541.08 → 547.65 MiB (1.22%)**; that wider denominator does not establish the
stricter guard. **Research tradeoff only: stop expansion and ordinary adoption.**
Second geometry, GPU generation and timing runs are not launched. Ordinary
source is unchanged; existing **262-test** validation remains current. Next
return to P0 actual-resource matched quality/latency. Full P0/P1/P2 remains open;
estimate **10–20 working days**, conditional on hardware and research outcomes.
[Verified tradeoff and stop decision](results/hardware/layerwise_prefill_placement_v1/verified_guard_review.json).

**Verified GPU allocation diagnosis (3 October):** the unchanged 16K
Mistral prefill reaches **18.6278 GB** at the final MLP multiplication,
while retaining **2048 MiB** of full prompt KV. Each MLP operand/product
is **448 MiB**. Query scoring is not the origin of the first global peak.
Two accepted observers replay all 50 predictions, policy state, counters,
transfers and phase peaks against the frozen uninstrumented ordinary run.
Diagnostic hooks and roots are released; two initial cleanup assertion failures
are preserved and traced to 64 native Transformers output-capture hooks.
The accepted run establishes those native hooks before the strict baseline.
All four owned GPU jobs finished. Ordinary source is unchanged; the existing
**262-test** validation still applies. This is allocation diagnosis, not a
measured optimization. The layerwise experiment above now tests that mechanism
and stops on its decode-memory guard; continue actual-resource comparisons. Actual resource equality, matched
quality/latency, physical STT and full P0/P1/P2 remain open. Estimated remaining
effort: **10–20 working days**, conditional on hardware and research outcomes.
[Verified allocation audit](results/hardware/prefill_allocation_audit_v1/verified_report.json).

**Verified fixed-stream profiler fix:** FullCache, StreamingLLM, H2O and
SnapKV now profile fixed teacher tokens without requiring TieredKV's STT
counter keys. Policy counter deltas are emitted when available; `decode_steps`
counts measured model forwards. Only counter reporting changed. **262 tests
pass** after reproducing all four failures. Full Mistral GPU validation covers
five policies, both prefill-logit settings, warmup and repeated trials, with
**390 observed forwards** following the exact token stream and positions.
The ordinary bulk path replays archived predictions, cache/state histories,
transfer bytes/calls and counter deltas. The owned GPU job finished. These are
schema/preservation checks; budget-matched quality/latency and full resource
equality remain open. The allocation audit above resolves the next diagnosis;
continue actual-resource comparisons after the stopped layerwise experiment. Full P0/P1/P2 remains
open; estimate **10–20 working days**, conditional on hardware/research gates.
[Verified profiler fix](results/hardware/baseline_profile_counters_v1/verified_report.json).

**Verified ordinary opt-in integration:** `--prefill-last-logits` is wired
through the LongBench evaluator, ordinary bulk/query evaluator, latency profiler
and fresh-memory caller. It requires explicit native `logits_to_keep` support;
the default remains disabled. The evaluator fingerprints the option and treats
legacy checkpoints without it as disabled. **252 tests pass**, including chunk,
EOS, token-limit, unsupported-model and profiler cases; all four CLI help checks
pass. Real ordinary-bulk Qasper runs with the flag off/on preserve the answer,
score and transfer/payload counts. Real fresh-memory CLI runs at both capacities
preserve the frozen prototype predictions/state/counters/transfers. The guarded
research memory results are **64.36% / 54.72%** reductions of active decode
scope; whole-request prefill remains **18.6278 GB**. Both monitored 3-ABBA timing
runs passed median/p95/TTFT/peak regression guards on a quiet GPU. All **24
actual API generation pairs** preserve 16 fields and replay **48 frozen rows**;
all owned jobs finished. The option is **adopted as an ordinary opt-in**, with
legacy-disabled checkpoint resume and enabled-mismatch rejection verified.
Shared/usual active envelopes remain **541.08 / 806.50 MiB**, and reserved scope
**5089.49 / 5345.49 MiB**; complete 512 MiB equality is not achieved. Full
P0/P1/P2 remains open. The fixed-teacher baseline counter error was
subsequently resolved in the current proof above; continue actual-resource
matched quality/latency work. Estimate **10–20 working days**,
conditional on hardware access and research gates.
[Verified ordinary integration](results/hardware/prefill_last_logits_integration_v1/verified_final_status.json).
[Verified prototype timing](results/hardware/prefill_last_logits_v1/verified_timing.json).

**Frozen last-prompt-logit pilot:** a preregistered research wrapper uses
Mistral's native `logits_to_keep=1` for prefill only. The frozen pilot left ordinary source/defaults
unchanged. Seven tiny-Mistral branch cases preserve outputs/cache/counters.
Two fresh GPU processes at 991/1090 capacities preserve all 50 predictions,
state, counters and transfers, replaying frozen ordinary controls. The active
decode envelope falls **1518.29 to 541.08 MiB (64.36%)**, passing the 10%
primary. Reserved scope falls **6089.49 to 5089.49 MiB**. Whole-request prefill
peak stays **18.6278 GB**, and complete 512 MiB equality is still unproved.
Usual capacities 1024/2048 also pass: **1781.31 to 806.50 MiB (54.72%)**;
reserved scope is **5345.49 MiB**. All **24 generation pairs** across six tasks
and both geometries preserve 16 fields and replay **48 frozen ordinary rows**.
All six untimed GPU jobs finished. Both preregistered monitored 3-ABBA TTFT/decode
checks subsequently passed on a quiet GPU; ordinary integration is verified
above. Full P0/P1/P2 and complete resource equality remain open.
[Preservation proof](results/hardware/prefill_last_logits_v1/verified_preservation.json).
[Verified shared resources](results/hardware/prefill_last_logits_v1/verified_resources_shared.json).

**Verified caller lifetime fix:** the ordinary generator releases the unused
prefill output after selecting its first token; the fresh teacher-stream caller
releases it before decode. A tiny Mistral regression reproduced the bug in
normal and chunked prefill; **243 tests now pass**. Two fresh GPU processes
preserve all 50 predictions, state, counters and transfers. Weak storage handles
confirm the **1000 MiB** prefill logits expire before the first decode.
The unchanged phase peak improves only **1536.64 to 1518.29 MiB (1.19%)**,
failing the 10% primary: its scope includes the handoff before output release.
Reserved scope remains **6089.49 MiB** and prefill peak **18.6278 GB**.
Keep the lifetime fix; stop its expansion as a phase-memory optimization.
All **24 archived/current generation pairs** across six tasks and both
geometries match in all 16 integrity fields and replay **48 frozen ordinary
bulk rows**. All four owned GPU jobs finished. Ownership prototypes remain
research-only. Local Mistral source supports computing only the last prompt
logits; that option is not implemented or measured. Preregister its independent
preservation/resource gates next. Full P0/P1/P2 completion remains open.
[Combined preservation proof](results/hardware/prefill_output_release_v1/verified_report.json).
[Verified caller resources](results/hardware/prefill_output_release_v1/verified_resources.json).

**Previous frozen caller portability decision:** the frozen ownership prototype
preserves all 50 fixed-stream predictions, final state, counters and transfer
bytes/calls in the fresh generation caller. Its active decode envelope falls
**1536.64 to 1410.90 MiB (8.18%)**, below the 10% primary; both exceed 512 MiB.
Reserved scope stays 6089.49 MiB and prefill peak stays 18.6278 GB. Both arms
retain 1000 MiB of prefill logits through the first decode. Stop usual-caller,
timing and ordinary integration expansion for this variant. The earlier
20.7–21.2% legacy-caller result remains valid within its narrower scope.
Next investigate unused prefill-output ownership in the generation caller.
Both owned audit jobs finished; frozen helpers and ordinary defaults unchanged.
[Verified fresh-caller decision](results/hardware/fresh_prefill_owner_v1/verified_report.json).

**Latest prefill ownership pilot:** all eight paired contexts preserve outputs,
state and transfers. Sharing the initial hot payload lowers the measured active
decode envelope **20.7–21.2%** at 991/1090 capacities and **14.0–14.1%** at
1024/2048. Shared active storage is about **411 MiB**; usual active storage is
**672–673 MiB**. Reserved scopes exceed 512 MiB in both geometries, and prefill
peaks are unchanged. **236 tests pass.** Mandatory timing checks remain; this is a serial research prototype with no ordinary/default change.
GPU 0 has an unrelated workload, so timing awaits a quiet measurement window.
[Verified pilots](results/hardware/prefill_owner_share_v1/verified_pilot.json).

**Generation preservation:** all 24 pairs across six tasks and both geometries
match the ordinary bulk path and replay all 48 frozen rows. All 1,213 candidate
forwards restore ownership and request hooks are removed. Reused development
data only; timing and complete-resource gates remain open. Scoped GPU lifetime
is verified below.
[Generation proof](results/hardware/prefill_owner_share_v1/verified_generation.json).

**Boundary/recycling preservation:** all 40 saturation and append cases and
six serialized interleaved/recycled requests pass. All 102 boundary frames
match; all 18 request rows replay frozen controls. Every scoped lease restores
its active request and hooks are removed. All owned preservation jobs finished.
Quiet-GPU timing remains open; scoped GPU lifetime is verified below. No
ordinary adoption or complete 512 MiB claim.
[Batch proof](results/hardware/prefill_owner_share_v1/verified_report.json).

**Scoped GPU lifetime gate passes:** 14 checks preserve every BF16/F32 payload
bit, untouched tails, released owners under allocation pressure, and GPU hook
restoration after normal and partial toy DynamicCache forwards. Two consumers
run serially with explicit caller events and `record_stream`. This does not
establish automatic stream handoff, concurrent serving or full Mistral exception
compute. Frozen prototype sources stay unchanged. Clean timing remains pending.
[Lifetime proof](results/hardware/prefill_owner_share_v1/verified_lifetime.json).

Research experiments beyond this defect-remediation pass are prioritized in
[`RESEARCH_ROADMAP.md`](RESEARCH_ROADMAP.md); they are hypotheses, not results.

**Expanded active objective (2026-09-24):** finish the review fixes and full
Mistral revalidation; preserve source-matched evidence; resolve reporting and
hardware-assumption errors; audit write-savings magnitude and prior art;
investigate FlexGen and other relevant methods; then execute the research
roadmap toward a defensible top-tier contribution across quality, prefill,
decode, peak/steady-state memory, throughput, energy, endurance, hardware
feasibility, baseline fidelity, robustness, generality, and novelty. Each
new idea requires a paired experiment and explicit go/no-go result before it
becomes a claim. The research milestones remain open after the remediation
checks pass.

This checklist tracks the September 2026 `review-agent` findings. The
historical result files remain available for audit; `results/remediation/`
and the completed speed revalidation under `results/remediation_v3/`
use the corrected protocol. All 14 v3 jobs finished successfully, and the
quality/PPL records reproduce the earlier corrected run exactly. Each run's
`jobs.json` records its status. Only source comments about hardware provenance
were corrected after v3; no executed expression or numerical input changed.
The v3 source checksum identifies the exact pre-comment-correction snapshot.
The
first interrupted attempt is preserved
under `results/remediation_attempt1/`; it exposed a JSONL parsing bug in
TriviaQA and must not be mixed with the new run.

## Fixed and locally verified

- [x] Include cache-policy and token-delivery work in measured latency;
  retain forward-only time as a diagnostic.
- [x] Pass `--write-aware-lambda` into the actual TieredKV configuration.
- [x] Clear promotion hysteresis after a step with no candidates.
- [x] Append the new token before simulator attention, matching the full-cache
  oracle when capacity is sufficient.
- [x] Stop generation at the first EOS and follow LongBench's task-specific
  Mistral chat-template exclusions.
- [x] Read JSONL by physical newline so Unicode NEL characters inside
  TriviaQA strings do not split valid records; verified all six task files
  load, including all 300 TriviaQA records. Unaffected completed tasks
  reproduced exactly in scores and predictions after the clean rerun.
- [x] Reject fingerprintless/mismatched checkpoints and record sample IDs,
  predictions, scores, source hashes, and effective configuration.
- [x] Replace the invalid synthetic fallback and syntax error in PPL evaluation
  with teacher-forced, token-by-token loss on real text.
- [x] Feed figure and table generation from selected JSON inputs; keep old
  forward-only latency out of the new figure.
- [x] Require source-matched, dataset-matched accuracy and latency inputs
  before generating the current publication figures; mixed-source probe
  fails before writing files.
- [x] Show logical bf16 KV capacity with consistent MiB/MB units; distinguish
  it from measured GPU allocation and simulated STT-RAM occupancy.
- [x] Correct the README's old reproduction commands, false statistical and
  latency claims, and mark historical documents as historical.
- [x] Prepend a review notice to the historical PDF while preserving its
  original 16 pages for audit.
- [x] Capture the tested Python environment in `requirements.lock.txt`.
- [x] Capture GPU/driver/CUDA/Python details and the model snapshot revision
  in `results/remediation/hardware.json`.
- [x] Replace the deprecated model-download command with the tested `hf`
  command and pin the tested model revision.
- [x] Verify the active environment with `pip check` (no broken requirements).
- [x] Cover core regressions with CPU tests; the suite currently passes.

## Experiment verification

- [x] Finish the 2-GPU Mistral equal-logical-VRAM comparison on six tasks;
  TieredKV versus SnapKV is +0.58 points with paired 95% interval
  [−0.47, +1.79] under the fixed-task/sample/seed design.
- [x] Finish matched-attended comparison on the same six tasks; TieredKV
  versus SnapKV is −0.61 points with paired 95% interval [−2.39, +1.00].
- [x] Finish equal-total logical KV comparison on the same six tasks;
  TieredKV versus SnapKV is −5.09 points with paired 95% interval
  [−8.04, −2.52]. Its 373-versus-1024 attended-token difference limits
  causal attribution.
- [x] Re-run end-to-end latency under the latest source fingerprint. At 16k
  prompt tokens, TieredKV measured 115.70 ms/token versus SnapKV's
  34.42 ms/token; raw trials are in `results/remediation_v3/latency.json`.
- [x] Fold the latest latency into Figure 4, the master table, and the README;
  all now show the 115.70 ms/token v3 measurement.
- [x] Finish real-text PPL validation at budget 256 over 1024 tokens (so
  eviction occurs), write-weight ablation, and recent-window ablation.
- [x] Run paired, task-balanced fairness and ablation reports; verify
  matching sample IDs, complete records, configurations, code, and dataset
  hashes.
- [x] Rebuild publication figures/tables from the corrected JSONs, visually
  inspect key plots, and update the README with new results.
- [x] Repeat the full 63-test suite, compilation, dependency, and artifact
  checks after the v3 matrix; all 14 jobs completed successfully.

## Remaining engineering/research work by priority

- [ ] **P0 — Endurance evidence:** The vendor's
  [EMD4E001GAS2 datasheet](https://www.everspin.com/sites/default/files/EMD4E001GAS2_1.3_10102022.pdf)
  rates 10^10 *page accesses per page* (1,024-bit x8 or 2,048-bit x16),
  not a logical-write-byte total. Record physical page addresses and both
  read/write access counts, controller amplification, and ECC/error behavior
  under representative long-running workloads. Do not turn the 88.1%
  simulated demotion-write saving into an endurance or lifetime claim.

- [ ] **P1 — Peak VRAM:** The harness builds the full prompt KV before
  compression. At 16k tokens, measured prefill peak allocation is 18.59 GB
  for every method in `results/remediation_v3/latency.json`; a bounded-memory
  or chunked prefill is required before claiming reduced **peak** VRAM.
  The first corrected 512-token chunk prototype reduces 16k peak allocation
  from 18.594 to 15.804 GB while retaining identical tier counts, but doubles
  TTFT (2.245 to 4.449 s) and materially changes all five Qasper pilot
  outputs. Broader quality and chunk-size validation remain required.
  Sensitivity favors 2048-token chunks: 16.113 GB peak and 2.42 s TTFT
  versus 18.594 GB and 2.24 s exact; Qasper-5 is 8.19 vs 6.91, but four of
  five predictions differ and the paired interval is [−8.26, +14.06]. The
  completed 15-example Qasper/NarrativeQA/GovReport report finds +0.18
  task-balanced points with interval [−3.58, +4.82]; quality non-inferiority
  remains unproven (`results/bounded_prefill/quality_2048_report.json`).
- [ ] **P1 — Decode speed:** TieredKV's corrected full-loop latency shows
  substantial Python/cache policy overhead. A 16k-token profile identified
  promotion hysteresis, demotion, and visible-cache assembly as major costs.
  Moving hysteresis metadata to CPU reduced a focused 50-token, three-trial
  16k measurement from 149.93 to 117.09 ms/token; SnapKV measures 34.55
  ms/token in that new run. The full matrix's 16k latency job measures
  115.70 ms/token (TieredKV) versus 34.42 (SnapKV). LRU metadata remains on GPU because CPU/GPU
  unstable-sort tie behavior changed predictions in the rejected exploratory
  run under `results/remediation_v2/`. The complete v3 matrix reproduces
  all corrected quality/PPL records exactly. Further reduction of per-layer cache
  bookkeeping remains necessary before any speed claim.
  A behavior-preserving metadata fast path reduced corrected three-block
  same-process ABBA 16k median ITL from 120.48 to 106.17 ms/token and p95
  from 180.36 to 129.53 ms/token; 8k median fell from 120.50 to 106.41 ms.
  The earlier two-block 16k figure used a different recent-window setting
  and is superseded. Fifteen selected predictions matched the exact control.
  The current path remains far above
  the ~35 ms/token compact-cache target. A four-row admission cap cut migration
  in a 32-step screen but failed the paired 15-example quality non-inferiority
  gate (−0.31 points, interval [−1.56,+0.94], GovReport −0.92); default
  admission stays 32 (`results/promotion_budget/`).
  A one-pass PyTorch slow-tier compaction variant was tested and rejected:
  107.24 vs 106.89 ms/token median and 145.46 vs 135.38 ms/token p95 in
  three ABBA blocks, despite saving 7.45 MB decode peak. The experimental
  path was removed. Full-capacity recycled slots were inapplicable to the
  16-step control because the slow tier begins only 75% full; a reserved
  append probe for the active 1,536→1,552-row regime was 19.5% slower and
  used 58.7 MB more GPU allocation, so neither candidate was retained.
  A current 8K/16-token cProfile points to demotion policy work (0.751 s
  cumulative CPU over 512 layer calls), visible assembly (0.249 s), and
  score update (0.153 s); these overlap and are profiling-perturbed.
  A line trace then found 6,900 shadow restorations in 16 decode steps;
  per-row GPU `stt_last_access` writes were a concrete hot line. Batching
  restorations is now the default. Final-source three-block ABBA medians
  improved 109.22→98.13 ms/token at 8K and 108.30→97.80 at 16K; p95
  improved at both lengths, though only 2/3 paired blocks favored batch at
  each length. Fifteen paired real prompts matched exact generated text,
  paid-write counts and saved-write counts through 32 tokens. Peak memory
  was unchanged. This is a one-model/single-request result, still far from
  the ~35 ms/token compact-cache target. Next profile the remaining active
  per-layer work and test throughput/concurrency before a speed claim
  (`results/decode_overhead/batch_backup_abba_{8k,16k}_final.json`,
  `batch_backup_parity_15_final.json`).
  Current-source profiling reconfirmed 0.269 s in 320 `evict_and_demote`
  calls, 0.076 s in 10 score updates, and 0.120 s in 11 visible-cache builds
  during a profiled 10-step decode. Sort-only batching saved 3.70 ms/step,
  below the advancement gate; finite-count removal was already rejected at
  8K/16K. The next optimization must batch broader policy decisions/state
  updates and prove ≥4 ms/step screen headroom before full-loop ABBA
  (`results/baseline_fidelity/tier_policy_16k_10.txt`,
  `batched_stable_sort_probe.json`).
  The later faithful upstream-selector SnapKV loop control makes the gap
  sharper: 86.73 versus 25.76 ms/token at 16K after the accepted ordered boolean live-row gather, under a configured
  512 MiB final-KV ceiling. A deferred hot K/V append preserved exact cache state
  and output on three prompt lengths but regressed same-process 16K median
  latency 92.43→96.19 ms/token; it was removed. The next candidate must
  eliminate policy launches or visible-cache reconstruction, with full
  quality, p95 and memory gates (`results/baseline_fidelity/hot_defer_abba.json`).
  Batching the 32 visible-row index transfers preserved exact rows but cut
  median latency only 1.26% across six blocks (one block regressed), below
  its 5% gate; that path was removed
  (`results/baseline_fidelity/batched_visible_followup.json`).
- [ ] **P1 — Paired shadow-cache value:** The full 135-request six-task
  comparison under `results/shadow_ablation_full/` found 88.1% fewer paid
  decode-demotion writes per step with inclusive shadows (10.58 GB aggregate
  bf16 payload difference). Inclusive quality was −0.20 task-balanced points
  versus no-shadow, paired interval [−0.47, +0.07], with GovReport −1.44
  ROUGE-L on 10 samples. A same-GPU ABBA profile measured 117.17 versus
  135.82 ms/token full-loop prototype latency; prefill peak was unchanged.
  Inclusive predictions/counters match v3 exactly. Expand quality tasks and
  measure physical traffic/endurance before claiming practical device value;
  see roadmap.
- [ ] **P1 — Baseline fidelity:** Independent, upstream-faithful baseline
  replication has an experimental SnapKV adapter and passing tiny-model
  prefill/decode checks. The full 135-request six-task adapter run scores
  43.07 and passes source/sample, recomputed-score, and KV-byte checks.
  Query-aware TieredKV scores 42.73; no advantage is established.
  Equal-byte controls and isolated performance measurements remain open.
  Full independent
  replication remains unverified. The harness's SnapKV uses K-as-Q prefill,
  scores averaged across heads, and H2O-style decode eviction; vendored
  upstream SnapKV uses actual query states and per-head prefill selection.
  The completed byte audit finds 524,288 bytes per expanded-head SnapKV
  row versus 131,072 per TieredKV KV-head row; 134/135 saved SnapKV final
  payloads exceed TieredKV's configured 384 MiB resident ceiling
  (`results/baseline_fidelity/snapkv_byte_comparison.json`). This is a
  quantified mismatch, not an equal-byte quality comparison.
  A four-example eager/eager pilot at equal configured 512 MiB prompt
  ceilings and 1,024 attended rows still had TieredKV final resident KV
  bytes at only 68.5–83.1% of SnapKV's final bytes. Quality was mixed by
  task (Qasper −17.50, GovReport +5.23; task-balanced −6.13) and underpowered.
  Do not advance this configuration or claim an equal-byte win
  (`results/baseline_fidelity/matched_pilot_report.json`).
  A newer actual-query/access-time first-five-per-task screen chose SnapKV
  capacities 832/832/500 using prior output lengths. Mean final bytes then
  matched within 2%, yet TieredKV–SnapKV task-balanced quality was −0.68
  (conditional interval [−4.93,+3.36]); Qasper fell 4.64. GovReport
  per-request byte ratios still ranged 0.806–1.840, and attended widths
  differed. This blocks any superiority claim and still leaves faithful
  ex-ante equal-resource evaluation open
  (`results/baseline_fidelity/snap_task_bytes_report.json`).
  A stronger selected 135-example comparison matches a configured
  **512 MiB maximum final resident KV ceiling** ex ante. The accepted
  boolean-gather and boolean-hot-compaction source has now reproduced every Tiered prediction, score,
  final byte count, and cache counter; SnapKV was rerun under the same source
  fingerprint. Tiered−Snap quality remains −0.05 task-balanced points,
  conditional interval [−1.36,+1.36], with Qasper −3.46. This is neither a
  superiority nor equivalence result; mean actual bytes and attended widths
  still differ. The latest one-prompt, source-matched three-block ABBA found
  TieredKV 82.76 versus faithful SnapKV 25.77 ms/token (3.21x slower) after
  exact-parity boolean hot-row compaction, with p95 86.34/26.03 ms, TTFT
  2194.82/2086.69 ms, and
  Tiered prefill peak 18.796 versus 17.958 GB and decode peak 15.234 versus
  16.522 GB.
  A top-tier claim remains blocked by the quality near-tie, the latency
  deficit, faithful resource/serving baselines and generality
  (`results/baseline_fidelity/snap_exante_full_currenthot_report.json`,
  `snap_tier_loop_currenthot_report.json`).
  Widening cold exposure to 128 at the same ceilings reduced the paired
  two-example Qasper score from 13.12 to 10.82 despite full exposure;
  reject this setting (`results/baseline_fidelity/expose128_report.json`).
  An opt-in actual-query, causally masked prompt selector scored +4.45
  task-balanced points on 27 paired examples (conditional interval
  [+0.81,+8.86]) and reduced paid writes in all six tasks, but GovReport
  fell 1.72, 4/27 examples regressed, and median prefill time/peak rose.
  Keep as a research trade-off until larger held-out quality, exact prefill
  overhead, and full-loop latency are validated
  (`results/baseline_fidelity/real_q_prefill_six_task_report.json`).
  Optimized GQA scoring preserved all 27 predictions/counters. A same-process
  three-block ABBA prefill test found +7.53% time/+16 MiB peak on Qasper
  and +5.07%/+32 MiB on NarrativeQA versus K-as-Q. These pass the ≤10%
  prefill guard on two prompts but do not resolve the wider gates
  (`results/baseline_fidelity/real_q_prefill_abba_report.json`).
  The source-matched 135-example run now passes the overall selected-sample
  quality gate: +2.34 task-balanced points, conditional interval
  [+0.30,+4.42], and 48.6% fewer logical paid demotion writes. MultiFieldQA
  falls 2.22 points and 19/135 examples regress. Full-run timing/peak are
  invalid because an Ollama job overlapped the candidate run. An independent
  three-block 16K ABBA measured median/p95 complete-loop decode changes of
  −1.23%/−1.21%, but median TTFT +6.22% and prefill peak +0.199 GB.
  Keep this opt-in and complete held-out, adversarial, faithful-baseline and
  physical-tier gates (`results/baseline_fidelity/real_q_prefill_full_report.json`,
  `real_q_full_loop_abba_report.json`).
  The cheaper access-time decode pairing is a better practical candidate:
  selected-sample task-balanced quality +5.20 (conditional interval
  [+2.84,+7.69]), logical paid writes −18.49%, and effectively neutral
  16K decode ITL. GovReport fell 1.35, 22/135 examples regressed, TTFT
  rose 6.89%, and prefill peak rose 0.199 GB. The significant gain triggers
  an immediate stress audit before further optimization/default promotion
  (`results/baseline_fidelity/real_q_lru_full_report.json`,
  `real_q_lru_full_loop_abba_report.json`).
  Stress audit: all observed prompt-length bins improved, but ten long
  GovReport outputs averaged −1.35 (6/10 regressions); six examples lost
  >10 points and two positive scores became zero. Target the long-output
  retrieval failure and severe regressions before tuning or promoting;
  adversarial/OOD, concurrency, other models and physical-tier stress are
  still open (`results/baseline_fidelity/real_q_lru_stress_report.json`).
  Two frozen, non-overlapping fresh tranches (30 examples each, five per
  task) now test this policy without tuning. Tranche 1 was +5.17 with a 95%
  interval [−1.60,+12.95] and did not resolve the effect. The preregistered
  tranche 2 replicated +7.30 at a stricter 97.5% interval [+1.54,+15.12].
  The descriptive 60-example pooled estimate is +6.24 [1.48,+11.48], with
  10 regressions/60 and three >10-point losses; effects concentrate in
  MultiFieldQA and HotpotQA, while TriviaQA and GovReport are near zero.
  Error review found one Qasper answer omits precision/recall; two other
  large losses are likely surface-form penalties (a repeated correct HotpotQA
  answer and an acronym-only NLMS answer). Across both tranches, prefill
  medians and peak allocation rose in all six task groups; paid writes/step
  fell only 1.1% pooled. This is a replicated conditional quality tradeoff,
  not an all-metric win. Keep it opt-in pending second-model evaluation and
  systems optimization (`results/baseline_fidelity/real_query_holdout_20260929/`).
  A late-query scan after 32 steps recovered GovReport +3.98 points, but
  raised writes 10.8% and descriptive time/token about 45%; it was rejected
  and removed. The needed fix is bounded retrieval rather than a full
  cold-key scan (`results/baseline_fidelity/late_query32_gov10.json`).
  H2O also uses K-as-Q prefill. Quest remains guarded as unimplemented
  rather than producing a mislabeled Full-KV result.
- [ ] **P1 — Retrieval coverage:** A 16k real-text 50-step probe reached
  only ~115 distinct slow-tier rows per layer out of ~1,620 resident, with
  the 32-token quota filled every step. Access-time ranking repeatedly
  selects recently exposed rows; unexposed rows receive no attention score.
  A true-query diagnostic found only 0.14/32 overlap with query-scored
  top rows. A same-step selector improved quality by +4.35 task-balanced
  points on the full 135-request six-task sample, paired interval
  [+2.12, +6.61], but slowed 16k full-loop decode from 115.53 to 158.91
  ms/token and increased paid writes per step by 50%. At matched attended
  width, it scored 41.53 vs 37.80 for the in-harness SnapKV approximation,
  but still used 2048 extra simulated cold slots. The completed equal-total
  query run scored 36.31 vs 37.80 (paired −1.49, interval [−3.73, +0.44]);
  no equal-total advantage is established. Next
  avoid its ~102 MB/step full slow-tier key scan (18.9 ms ideal at the
  two-chip 5.4 GB/s anchor), optimize selection, test held-out tasks/models,
  and compare faithful
  Quest/RetrievalAttention at matched budgets (roadmap).
  A centroid-page diagnostic now raises offline top-32 recall from
  21.56%→41.41% at eight 16-row pages, using 12.14 MiB rather than
  24.27 MiB fp32 summaries across 32 layers. Candidate-only reranking
  preserves that recall. Ten GovReport examples gain 2.33 points over
  access-time selection, but the vectorized full-loop 16K pilot is still
  150.80 vs 142.95 ms/token for full query. This is not a deployable
  speed win; page summaries are rebuilt by reading the full cold pool,
  and packed-row compaction invalidates persistent row-page IDs. Next
  prove a stable incremental index and paired quality/latency before
  widening the evaluation (`results/page_recall/centroid_report.json`,
  `centroid_quality_gov10.json`, `centroid_latency_abba_pilot.json`).
  Stable dense page IDs passed the grouping prerequisite: 41.87% top-32
  recall at eight pages and 73.17% at 32, with no underfilled exposure
  across 640 layer-steps and ~12.51 MiB estimated index metadata across
  layers. Absolute-position pages failed due sparse retained positions.
  Incremental sums/counts and transition parity are still missing; do not
  treat this as reduced physical reads or a speed result
  (`results/page_recall/stable_page_report.json`).
  The first opt-in incremental index passed 300 synthetic transition
  parity checks and final checks on four real requests, but failed the
  same-process latency gate: 533.47 vs 146.72 ms/token for full-query
  selection. Its logical index reached 22.41 MiB across layers, excluding
  Python dictionary overhead, and changed-key maintenance read over 1 GiB
  on just two GovReport requests. Reject this implementation for serving;
  batch/native page updates and exact peak/throughput checks would be needed
  before another quality expansion (`results/page_recall/indexed_report.json`).
  Focused profile identified repeated full position-map construction in
  reconciliation (1.684 s self-time over five decode tokens); a set-delta
  patch passed parity but improved paired 16K latency only 0.51% and was
  reverted. A batched/native state representation is required before this
  index deserves more optimization (`results/page_recall/indexed_cprofile_8k.txt`,
  `index_set_delta_abba.json`).
- [ ] **P1 — Energy scope:** The analytical counters bill decode KV traffic,
  omitting initial prompt placement, model compute, and system power. Expand
  and validate the model before claiming whole-request energy savings.
- [ ] **P1 — STT bandwidth provenance:** The 21/5.25, 50/12.5, and 100/25
  GB/s pairs are hypothetical sensitivity scenarios, not three measured STT
  devices. Everspin reports 2.7 GB/s read and write per 1Gb product; its
  write bandwidth is not 4x lower. The cited 26.7 GB/s research result is
  an array-level read, and the cited CXL measurements are for another memory
  technology. Choose and validate a capacity-matched, GPU-accessible device
  topology before making a physical STT latency claim; see README.
  A local-NUMA pinned CPU-DRAM↔GPU0 surrogate now measures PCIe copy
  granularity: 4 MiB H2D takes 9.38 ms in 1,024 row copies versus 0.299 ms
  in 32 layer copies or 0.171 ms packed. Full 256 MiB copies reach 26.8
  GB/s on Gen4×16. This does not close the item: the two-chip capacity match
  has only 5.4 GB/s ideal device bandwidth, and no GPU-accessible STT
  controller, physical write amplification, or energy is measured
  (`results/hardware/host_transfer_report.json`).
  The model now has an explicit ideal two-chip 5.4/5.4 GB/s bandwidth
  scenario, but its energy constants remain assumptions. A false cold-drop
  payload-read charge was removed; the equal-VRAM control had zero drops,
  and the only affected corrected-control slice found was equal-total
  GovReport (−2.123 ms, −0.001699 J aggregate modeled bill). Older
  artifacts are not silently rewritten (`results/hardware/drop_cost_correction.json`).
- [ ] **P1 — Quantized cold tier experiment:** Keep the corrected bf16 run as
  control. Native one-byte FP8 cold storage now runs on L40S and halves the
  configured cold payload from 256 to 128 MiB. A source/sample-matched
  one-example Qasper pair scores 10.53 bf16 vs 8.57 FP8, so output changes
  and quality risk is real. The five-example follow-up scores 6.91 vs 6.51
  (FP8−bf16 −0.39, interval [−1.17, 0.00]); four predictions are identical.
  Measure conversion latency and allocated memory before a 4-bit cold tier,
  with measured scale/metadata,
  dequantization, prefill peak, decode latency, and held-out quality. The
  first ABBA check measures 117.23 vs 118.33 ms/token (no established
  speedup), halves final cold tensors from 208.0 to 104.0 MB, and leaves the
  18.594 GB prefill peak unchanged. Bounded prefill remains the priority.
- [ ] **P2 — Fairness sensitivity:** The equal-total setup attends at most
  373 tokens for TieredKV versus 1024 for baselines. Sweep slow-tier exposure
  under the same total capacity if attributing that accuracy gap to residency
  rather than attention width.
- [ ] **P2 — Device validation:** Physical STT-RAM measurements require
  suitable hardware. This prototype
  stores both tiers on GPU and models slow-tier latency/energy analytically.
- [ ] **P2 — Generality:** Results beyond the locally available
  Mistral-7B-Instruct model and the
  six sampled LongBench tasks require additional model/data runs.

## Document-overlap audit correction (2026-09-29)

The two recent 30-row evaluations are disjoint by sample ID, **not by
document**. Exact context hashes show that 9/10 NarrativeQA and 3/10
MultiFieldQA evaluation rows reuse contexts in the original development
prefix. NarrativeQA also has only eight unique contexts among its ten rows.
The reported score differences remain valid for these examples, but the
row-wise bootstrap ignores shared-document dependence. Crossing tranche 2’s
97.5% numerical threshold is not evidence of calibrated independent-document
replication. Earlier “independent replication” wording is superseded by this
audit. Near-duplicate contexts and model-training overlap were not assessed.

Before another generalization claim, freeze groups by document identity,
exclude development documents and near duplicates, and use paired bootstrap
resampling of document groups. Keep the current policy opt-in. Evidence:
`results/baseline_fidelity/real_query_holdout_20260929/context_overlap_audit.json`;
reproduce with `python experiments/audit_holdout_contexts.py`.

### Document-group holdout gate (2026-09-29)

- [x] Freeze 24 rows in six tasks with one row per distinct normalized
  source-context group, excluding groups in the prior development prefix and
  both earlier holdouts. Verify source/row/context hashes and paired configs.
- [x] Run unchanged K-as-Q/LRU and actual-query/LRU arms sequentially on
  Mistral-7B. Candidate−control = +4.14 task-balanced points, paired
  document-group 95% interval [−0.84,+9.01]; the lower-bound gate failed.
  NarrativeQA −6.25; three individual regressions, two >10 points.
- [x] Check systems cost: median prefill and peak allocated memory rose in
  every task. Different output lengths prevent a causal paid-write comparison
  from the per-step ratios. Retain the candidate as opt-in, not a default.
- [ ] Develop a distinct candidate without using held-out rows for tuning;
  evaluate fresh documents and another model, long-context/long-output stress,
  matched-output prefill/decode/throughput/peak/write metrics, and physical
  tier assumptions. Four documents per task do not establish generality.

Artifacts: `results/baseline_fidelity/real_query_document_holdout_20260929/`;
reproduce with `python experiments/report_real_query_document_holdout.py`.

- [x] Triage the two major factual losses at the prompt boundary. Qasper's
  18-token answer span loses hot coverage and is partly dropped under the
  actual-query arm; NarrativeQA's exact meeting scene is absent under the
  shared middle-truncation rule before either cache policy runs. Do not treat
  the latter as proven KV-selection failure. Diagnostic artifact:
  `results/baseline_fidelity/real_query_document_holdout_20260929/placement_diagnosis.json`.
- [ ] On development data, measure evidence-span coverage alongside quality
  for a fixed-budget retrieval candidate; separately assess truncation-aware
  context selection as a workload/harness change with matched baselines.
- [x] Screen fixed 50/50 actual-query/K-proxy importance on six development
  rows. It failed the preregistered quality gate (−1.56 task-balanced points),
  so its opt-in source change was removed and raw source/results archived at
  `results/baseline_fidelity/prompt_score_mix_dev_20260929/`. Do not tune
  the weight on the document holdout.
- [x] Remove output-length/content confounding from the no-shadow write
  comparison on a 16K fixed-token trace: four ABBA pairs each measured
  2,690 versus 26,432 paid layer-token writes per 50 steps (89.82% fewer).
  This is a logical GPU-resident result; physical page traffic, energy and
  endurance remain unverified. See `results/shadow_ablation_full/fixed_stream_20260929.json`
  and `fixed_stream_report_20260929.json`.
