"""Research-only gather into consumed raw KV with the existing pybind ABI."""
from functools import lru_cache
import os
from pathlib import Path
import numpy as np
import torch
from reuse_visible_policy import ReuseVisiblePolicy


@lru_cache(maxsize=1)
def kernel():
    from torch.utils.cpp_extension import load
    source=Path(__file__).resolve().parent
    build=Path('/data/nishant/tieredkv_external/reuse_visible_build_20261002')
    build.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('MAX_JOBS','1');os.environ.setdefault('TORCH_CUDA_ARCH_LIST','8.9')
    return load(name='tieredkv_reuse_hot_v1',sources=[str(source/'native_hot_compact.cpp'),
        str(source/'native_reuse_hot.cu')],build_directory=str(build),
        extra_cflags=['-O2'],extra_cuda_cflags=['-O3'])


def gather_into(states,destinations):
    """Caller must validate all source/destination bounds and aliases first."""
    first=states[0];heads,_,dim=first.sram_k.shape
    rows=len(first.pending_keep);device=first.sram_k.device
    if device.type!='cuda':raise ValueError('Native reuse requires CUDA tensors')
    pointer_array=np.asarray([[getattr(state,name).data_ptr() for name in
        ('sram_k','sram_v','sram_cum','sram_age')]+[key.data_ptr(),value.data_ptr()]
        for state,(key,value) in zip(states,destinations)],dtype=np.int64)
    size_array=np.asarray([[state.sram_k.shape[1],key.shape[2]]
        for state,(key,_) in zip(states,destinations)],dtype=np.int32)
    keeps=np.asarray([state.pending_keep for state in states],dtype=np.int32)
    pointers=torch.from_numpy(pointer_array).to(device)
    indices=torch.from_numpy(keeps).to(device);sizes=torch.from_numpy(size_array).to(device)
    geometry=torch.empty((2,len(states),heads,0,dim),dtype=torch.bfloat16,device=device)
    metadata=torch.empty((2,len(states),rows),dtype=torch.float32,device=device)
    stream=torch.cuda.current_stream(device)
    for state,pair in zip(states,destinations):
        for tensor in (state.sram_k,state.sram_v,state.sram_cum,state.sram_age,*pair):tensor.record_stream(stream)
    kernel().compact(pointers,indices,sizes,geometry,metadata)
    for i,(state,(key,value)) in enumerate(zip(states,destinations)):
        state.sram_k=key.as_strided((heads,rows,dim),key.stride()[1:])
        state.sram_v=value.as_strided((heads,rows,dim),value.stride()[1:])
        state.sram_cum=metadata.as_strided((rows,),(1,),i*rows)
        state.sram_age=metadata.as_strided((rows,),(1,),(len(states)+i)*rows)


class NativeReusePolicy(ReuseVisiblePolicy):
    hot_gather=staticmethod(gather_into)
